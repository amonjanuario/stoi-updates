'use strict';
// Stoi — alertas: produtos que acabaram ou estão a acabar, fiado em atraso, contagem por fazer,
// vendas abaixo do custo e produtos parados. Cada funcionário só vê os alertas que o dono lhe
// atribuiu (permissões al*). Sino no topo, janela de alertas, aviso ao vender e conversa
// "Avisos da loja" nas Mensagens.

/* global Store, App, Chat, $, $$, esc, t, icon, can, openModal, closeModal, stockEntryModal, itemFormModal, money, fmtQty, fmtDate, dn, render, toast */

const ALERT_DEF = { base: 'count', minBox: 5, minBottle: 3, out: true, low: true, defMin: 5, idle: false, idleDays: 30, credit: true, creditDays: 30, count: true, countDays: 7, cost: true, onSale: true, chat: true };
const ALERT_PERMS = ['alStock', 'alCredit', 'alCount', 'alCost', 'alIdle'];
const alertCfg = () => Object.assign({}, ALERT_DEF, Store.settings.alerts || {});
const DAY = 86400000;
// Lâminas (unidades que saem de uma caixa aberta) nunca dão alerta: o stock delas vem das caixas.
function isLamina(i) {
  const c = i.categoryId ? Store.find('categories', i.categoryId) : null;
  if (c && /l[âa]mina/i.test(c.name || '')) return true;
  return Store.data.items.some(b => b.opensInto === i.id);
}
function minOf(i, cfg = alertCfg()) {
  return i.lowStock === undefined || i.lowStock === null || i.lowStock === '' ? cfg.defMin : Number(i.lowStock) || 0;
}
// Regra por categoria: Caixas (5 ou menos), Garrafas (3 ou menos); as outras usam o mínimo do produto.
function catKind(i) {
  const c = i.categoryId ? Store.find('categories', i.categoryId) : null;
  const n = (c && c.name) || '';
  return /caixa/i.test(n) ? 'box' : /garrafa/i.test(n) ? 'bottle' : null;
}
function ruleMin(i, cfg = alertCfg()) {
  const k = catKind(i);
  return k === 'box' ? Number(cfg.minBox) || 0 : k === 'bottle' ? Number(cfg.minBottle) || 0 : minOf(i, cfg);
}
// Última contagem concluída (balanço normal): o que se contou de cada produto.
function lastCountInfo() {
  const done = Store.data.stockCounts.filter(c => c.status === 'done' && c.finishedAt && !Store.isCheck(c))
    .sort((a, b) => b.finishedAt.localeCompare(a.finishedAt));
  const c = done[0];
  if (!c) return null;
  const map = new Map();
  for (const l of c.lines || []) if (l.counted !== null && l.counted !== undefined && l.counted !== '') map.set(l.itemId, Number(l.counted) || 0);
  const who = Store.find('employees', c.finishedBy || c.employeeId);
  return { count: c, at: c.finishedAt, who: who ? who.name : '', map };
}

// Vendas por produto: média por dia (últimos 14 dias) e data da última venda.
function salesStats(days = 14) {
  const since = Date.now() - days * DAY;
  const qty = new Map(), last = new Map();
  for (const r of Store.data.receipts) {
    const ms = Date.parse(r.date);
    const sign = r.type === 'refund' ? -1 : 1;
    for (const l of r.lines || []) {
      if (!l.itemId) continue;
      if (sign > 0 && (!last.has(l.itemId) || last.get(l.itemId) < ms)) last.set(l.itemId, ms);
      if (ms >= since) qty.set(l.itemId, (qty.get(l.itemId) || 0) + sign * (Number(l.qty) || 0));
    }
  }
  const perDay = new Map([...qty].map(([k, v]) => [k, Math.max(0, v) / days]));
  return { perDay, last };
}

// Desde quando um cliente deve (a última vez que a dívida passou de 0 para mais).
function debtSince(c) {
  const ev = Store.debtHistory(c.id).slice().reverse();
  let bal = 0, start = null;
  for (const e of ev) {
    const before = bal;
    bal += e.kind === 'payment' || e.kind === 'refund' ? -e.amount : e.amount;
    if (before <= 0.005 && bal > 0.005) start = e.date;
    if (bal <= 0.005) start = null;
  }
  return start ? Date.parse(start) : null;
}

function computeAlerts(e = App.user) {
  const cfg = alertCfg();
  const res = { out: [], low: [], other: [], count: 0 };
  if (!e) return res;
  const items = Store.data.items.filter(i => i.trackStock && !isLamina(i));
  const now = Date.now();
  const stats = (can('alStock', e) || can('alIdle', e)) ? salesStats() : null;
  if (can('alStock', e)) {
    const seen = seenMap();
    const lc = cfg.base === 'count' ? lastCountInfo() : null;
    res.base = cfg.base === 'count' ? 'count' : 'stock';
    res.countInfo = lc;
    for (const i of items) {
      // Base "última contagem": só os produtos contados nela (os não contados ficam de fora).
      let st;
      if (res.base === 'count') { if (!lc || !lc.map.has(i.id)) continue; st = lc.map.get(i.id); } else st = Number(i.stock) || 0;
      if (isSeen(i, seen, st)) continue;
      const min = ruleMin(i, cfg);
      const rate = stats.perDay.get(i.id) || 0;
      if (cfg.out && st <= 0) res.out.push({ item: i, stock: st, min, last: stats.last.get(i.id) || null, rate, kind: catKind(i) });
      else if (cfg.low && st <= min) res.low.push({ item: i, stock: st, min, days: rate > 0 ? st / rate : null, kind: catKind(i) });
    }
    res.out.sort((a, b) => (b.rate - a.rate) || dn(a.item).localeCompare(dn(b.item), 'pt'));
    res.low.sort((a, b) => (a.stock / (a.min || 1)) - (b.stock / (b.min || 1)) || dn(a.item).localeCompare(dn(b.item), 'pt'));
  }
  if (can('alCredit', e) && cfg.credit) {
    for (const c of Store.data.customers) {
      if ((c.debt || 0) <= 0.005) continue;
      const since = debtSince(c);
      const days = since ? Math.floor((now - since) / DAY) : null;
      if (days !== null && days >= cfg.creditDays) res.other.push({ k: 'credit', customer: c, days });
    }
  }
  if (can('alCount', e) && cfg.count && items.length) {
    const done = Store.data.stockCounts.filter(c => c.status === 'done' && c.finishedAt && !Store.isCheck(c)).map(c => Date.parse(c.finishedAt));
    const last = done.length ? Math.max(...done) : null;
    const days = last ? Math.floor((now - last) / DAY) : null;
    if (days === null || days >= cfg.countDays) res.other.push({ k: 'count', days, last });
  }
  if (can('alCost', e) && cfg.cost) {
    for (const i of Store.data.items) if ((Number(i.cost) || 0) > 0 && (Number(i.price) || 0) > 0 && Number(i.price) < Number(i.cost)) res.other.push({ k: 'cost', item: i });
  }
  if (can('alIdle', e) && cfg.idle) {
    const idle = items.filter(i => (Number(i.stock) || 0) > 0 && (now - (stats.last.get(i.id) || 0)) >= cfg.idleDays * DAY);
    if (idle.length) res.other.push({ k: 'idle', items: idle });
  }
  // Outros: "Visto" esconde até a situação mudar; "Arquivar" esconde até à data escolhida.
  const sz = snoozeMap(), nowMs = Date.now();
  res.hidden = [];
  res.other = res.other.filter(o => {
    o.key = otherKey(o);
    const v = sz[o.key];
    if (v && (v === 'seen' || v > nowMs)) { o.snooze = v; res.hidden.push(o); return false; }
    return true;
  });
  res.count = res.out.length + res.low.length + res.other.length;
  return res;
}
function otherKey(o) {
  if (o.k === 'credit') return `credit:${o.customer.id}:${round2(o.customer.debt || 0)}`;
  if (o.k === 'count') return `count:${o.last || 0}`;
  if (o.k === 'cost') return `cost:${o.item.id}:${o.item.price}:${o.item.cost}`;
  return `idle:${o.items.map(i => i.id).sort().join(',')}`;
}
const snoozeKey = () => `stoi-al-snooze-${App.user ? App.user.id : ''}`;
function snoozeMap() { try { return JSON.parse(localStorage.getItem(snoozeKey())) || {}; } catch (e) { return {}; } }
function setSnooze(key, v) {
  const m = snoozeMap();
  if (v) m[key] = v; else delete m[key];
  for (const k of Object.keys(m)) if (typeof m[k] === 'number' && m[k] < Date.now() - 86400000 * 60) delete m[k]; // limpa antigos
  try { localStorage.setItem(snoozeKey(), JSON.stringify(m)); } catch (e) { /* sem espaço */ }
}

// ---------- Sino no topo ----------
let bellTimer = null;
function paintBell() {
  clearTimeout(bellTimer);
  bellTimer = setTimeout(() => {
    const b = document.getElementById('top-bell');
    if (!b) return;
    const n = App.user && ALERT_PERMS.some(k => can(k)) ? computeAlerts().count : 0;
    b.hidden = !n;
    b.title = t('al.title'); b.setAttribute('aria-label', t('al.title'));
    b.innerHTML = `${icon('bell')}${n ? `<span class="bell-dot">${n > 99 ? '99+' : n}</span>` : ''}`;
    b.onclick = () => alertsModal();
  }, 60);
}

// ---------- "Visto": esconde o alerta de um produto até o stock dele mudar ----------
const seenKey = () => `stoi-al-seen-${App.user ? App.user.id : ''}`;
function seenMap() { try { return JSON.parse(localStorage.getItem(seenKey())) || {}; } catch (e) { return {}; } }
function markSeen(entries) {
  const m = seenMap();
  for (const o of entries) m[o.item.id] = Number(o.stock) || 0;
  try { localStorage.setItem(seenKey(), JSON.stringify(m)); } catch (e) { /* sem espaço */ }
}
const isSeen = (i, map, v) => i.id in map && map[i.id] === (Number(v) || 0);

// ---------- Janela de alertas ----------
// Cada tabela (Acabaram / Pouco stock) tem caixas já marcadas e, por baixo, uma faixa verde com
// "N selecionados" e as ações em ícones: um toque age sobre os marcados; desmarque o que não quer.
let alOff = { out: new Set(), low: new Set() }; // produtos desmarcados em cada tabela
function alertsModal() {
  alOff = { out: new Set(), low: new Set() };
  const m = openModal({ title: t('al.title'), body: '<div class="al-sheet"></div>', autofocus: false });
  paintAlerts(m);
}
function groupActions() {
  const acts = [];
  if (can('stockIn')) acts.push(['in', 'inbox', t('al.addEntry')]);
  if (can('fixStock')) acts.push(['adjust', 'tune', t('al.adjust')]);
  if (typeof Chat !== 'undefined' && Chat.available()) acts.push(['chat', 'send', t('al.sendChat')]);
  acts.push(['seen', 'doneAll', t('al.seen')]);
  return acts;
}
function paintAlerts(m) {
  const box = $('.al-sheet', m);
  if (!box) return;
  const a = computeAlerts();
  box._alerts = a;
  const ago = ms => { const d = Math.floor((Date.now() - ms) / DAY); return d <= 0 ? t('al.today') : d === 1 ? t('al.yesterday') : t('al.daysAgo', { n: d }); };
  const row = (attrs, left, title, sub, right) => `<div class="sx-row al-row" ${attrs}>${left}<span class="sx-t"><b>${title}</b>${sub ? `<small>${esc(sub)}</small>` : ''}</span>${right}</div>`;
  const ic = (name, col) => `<span class="sx-ic" style="background:${col}">${icon(name)}</span>`;
  const tag = k => (k === 'box' ? `<span class="al-tag cx">${esc(t('al.tagBox'))}</span>` : k === 'bottle' ? `<span class="al-tag gf">${esc(t('al.tagBottle'))}</span>` : '');
  const unit = t(a.base === 'count' ? 'al.counted' : 'al.inStock');
  const acts = groupActions();
  const group = (g, label, list, sub) => {
    if (!list.length) return '';
    const n = list.filter(o => !alOff[g].has(o.item.id)).length;
    return `<div class="sx-gt">${esc(label)} · ${list.length}</div><div class="sx-list al-group" data-g="${g}">${list.map(o => row(`data-id="${o.item.id}"`,
      `<span class="al-ck ${alOff[g].has(o.item.id) ? '' : 'on'}"></span>`, `${esc(dn(o.item))}${tag(o.kind)}`, sub(o),
      `<span class="al-n ${o.stock <= 0 || o.stock <= o.min / 3 ? 'red' : 'org'}"><b>${esc(fmtQty(o.stock))}</b><small>${esc(unit)}</small></span>`)).join('')}
      <div class="al-bar7"><button type="button" class="al-cnt" data-allg="${g}">${esc(t('al.selected', { n }))}</button>${acts.map(([k, icn, l]) => `<button type="button" class="al-ib al-ib-${k}" data-act="${k}" data-g="${g}" title="${esc(l)}" aria-label="${esc(l)}" ${n ? '' : 'disabled'}>${icon(icn)}</button>`).join('')}</div></div>`;
  };
  let body = '';
  if (a.base === 'count' && (a.out.length || a.low.length || can('alStock'))) {
    const lc = a.countInfo;
    body += `<div class="al-src">${icon('clipboard')}<span>${lc ? `${t('al.fromCount')} · ${esc(fmtDate(lc.at))}${lc.who ? ` (${esc(lc.who)})` : ''}` : esc(t('al.noCount'))}<small>${esc(t('al.rules', { box: alertCfg().minBox, bottle: alertCfg().minBottle }))}</small></span></div>`;
  }
  body += group('out', t('al.out'), a.out, o => [t('al.minN', { n: fmtQty(o.min) }), o.last ? t('al.lastSale', { when: ago(o.last) }) : ''].filter(Boolean).join(' · '));
  body += group('low', t('al.low'), a.low, o => [t('al.minN', { n: fmtQty(o.min) }), o.days !== null ? (o.days < 1.5 ? t('al.days1s') : t('al.daysNs', { n: Math.round(o.days) })) : ''].filter(Boolean).join(' · '));
  const otherRow = (o, hidden) => {
    const btns = hidden
      ? `<span class="al-snz">${o.snooze === 'seen' ? esc(t('al.wasSeen')) : esc(t('al.until', { d: new Date(o.snooze).toLocaleDateString(dateLocale(), { day: '2-digit', month: '2-digit' }) }))}</span><button type="button" class="al-ob" data-unsnz="${esc(o.key)}" title="${esc(t('al.restore'))}" aria-label="${esc(t('al.restore'))}">${icon('undo')}</button>`
      : `<button type="button" class="al-ob" data-seen1="${esc(o.key)}" title="${esc(t('al.seen'))}" aria-label="${esc(t('al.seen'))}">${icon('check')}</button><button type="button" class="al-ob" data-snz="${esc(o.key)}" title="${esc(t('al.archive'))}" aria-label="${esc(t('al.archive'))}">${icon('clock')}</button>`;
    const right = `<span class="al-obs">${btns}</span>`;
    if (o.k === 'credit') return row(`data-go="clientes"`, ic('people', '#7c3aed'), esc(t('al.credit')), t('al.creditSub', { name: o.customer.name, v: money(o.customer.debt), n: o.days }), right);
    if (o.k === 'count') return row(`data-go="balanco"`, ic('clipboard', '#0891b2'), esc(t('al.count')), o.days === null ? t('al.countNever') : t('al.countSub', { n: o.days }), right);
    if (o.k === 'cost') return row(`data-edit="${o.item.id}"`, ic('tag', '#db2777'), esc(t('al.cost')), t('al.costSub', { name: dn(o.item), p: money(o.item.price), c: money(o.item.cost) }), right);
    return row(`data-go="stock"`, ic('clock', '#64748b'), esc(t('al.idle', { n: o.items.length })), o.items.slice(0, 4).map(dn).join(', ') + (o.items.length > 4 ? '…' : ''), right);
  };
  if (a.other.length) body += `<div class="sx-gt">${esc(t('al.other'))}</div><div class="sx-list">${a.other.map(o => otherRow(o, false)).join('')}</div>`;
  if (a.hidden && a.hidden.length) {
    const open = box.dataset.arch === '1';
    body += `<button type="button" class="al-archbtn" data-arch>${icon('clock')}<span>${esc(t('al.archived', { n: a.hidden.length }))}</span><span class="al-chev ${open ? 'up' : ''}">›</span></button>`;
    if (open) body += `<div class="sx-list al-archlist">${a.hidden.map(o => otherRow(o, true)).join('')}</div>`;
  }
  if (!a.count) body += `<div class="empty"><b>${esc(t('al.none'))}</b></div>`;
  box.innerHTML = body;
  const refresh = () => { paintAlerts(m); paintBell(); };
  $$('[data-seen1]', box).forEach(b => b.addEventListener('click', e => { e.stopPropagation(); setSnooze(b.dataset.seen1, 'seen'); toast(t('al.seenOne')); refresh(); }));
  $$('[data-unsnz]', box).forEach(b => b.addEventListener('click', e => { e.stopPropagation(); setSnooze(b.dataset.unsnz, null); refresh(); }));
  $$('[data-snz]', box).forEach(b => b.addEventListener('click', e => {
    e.stopPropagation();
    const key = b.dataset.snz;
    const done = (until, label, at) => { setSnooze(key, until); toast(t(at ? 'al.archivedAt' : 'al.archivedOne', { d: label })); paintBell(); alertsModal(); };
    snoozePicker(done);
  }));
  const ab = $('[data-arch]', box);
  if (ab) ab.addEventListener('click', () => { box.dataset.arch = box.dataset.arch === '1' ? '' : '1'; paintAlerts(m); });
  // Tocar num produto marca / desmarca; o número da faixa marca ou desmarca todos.
  $$('.al-group [data-id]', box).forEach(r => r.addEventListener('click', () => {
    const g = r.closest('.al-group').dataset.g, id = r.dataset.id;
    if (alOff[g].has(id)) alOff[g].delete(id); else alOff[g].add(id);
    paintAlerts(m);
  }));
  $$('[data-allg]', box).forEach(b => b.addEventListener('click', () => {
    const g = b.dataset.allg, list = g === 'out' ? a.out : a.low;
    alOff[g] = alOff[g].size ? new Set() : new Set(list.map(o => o.item.id));
    paintAlerts(m);
  }));
  $$('[data-act]', box).forEach(b => b.addEventListener('click', () => {
    const g = b.dataset.g, list = (g === 'out' ? a.out : a.low).filter(o => !alOff[g].has(o.item.id));
    runGroupAction(m, b.dataset.act, list);
  }));
  $$('[data-go]', box).forEach(b => b.addEventListener('click', () => { closeModal(); location.hash = `#${b.dataset.go}`; }));
  $$('[data-edit]', box).forEach(b => b.addEventListener('click', () => { closeModal(); itemFormModal(Store.find('items', b.dataset.edit)); }));
}

// Ações sobre os produtos marcados (lista de { item, stock, min }).
function runGroupAction(m, k, list) {
  if (!list.length) return;
  const items = list.map(o => o.item);
  if (k === 'seen') { markSeen(list); paintAlerts(m); paintBell(); toast(t('al.seenDone', { n: list.length })); if (!computeAlerts().count) closeModal(); return; }
  if (k === 'chat') {
    const out = list.filter(o => o.stock <= 0), low = list.filter(o => o.stock > 0);
    // Sem emojis; títulos a negrito. Primeiro o pouco stock, depois o que acabou.
    const lines = [];
    if (low.length) lines.push(`*${t('al.lowHead')}:*`, ...low.map(o => `${fmtQty(o.stock)}x ${dn(o.item)}`));
    if (out.length && low.length) lines.push('');
    if (out.length) lines.push(`*${t('al.outHead')}:*`, ...out.map(o => dn(o.item)));
    // Vai para o rascunho da conversa escolhida (junta-se ao que já lá estiver); só sai ao carregar em enviar.
    Chat.pickRoom(t('chat.sendTo'), room => {
      Chat.addToDraft(room, lines.join('\n'));
      alertsModal(); // volta aos alertas, para juntar outra tabela ao mesmo rascunho
      showAlertBar(t('al.draftAdded', { room: Chat.roomName(room) }), t('al.openChat'), () => { closeModal(); Chat.room = room; if (location.hash === '#chat') render(); else location.hash = '#chat'; });
    });
    return;
  }
  if (items.length === 1 && (k === 'in' || k === 'adjust')) { closeModal(); stockEntryModal({ itemId: items[0].id, type: k }); return; }
  multiStockModal(items, k);
}
// Entrada (ou ajuste) de vários produtos de uma vez: uma linha por produto.
function multiStockModal(items, kind) {
  const adj = kind === 'adjust';
  const today = new Date().toISOString().slice(0, 10);
  const m = openModal({
    title: t(adj ? 'al.adjustTitle' : 'al.entryTitle'), autofocus: false,
    body: `<p class="muted small" style="margin-top:0">${esc(t(adj ? 'al.adjustHint' : 'al.entryHint'))}</p>
      <div class="sx-list al-multi">${items.map(i => `<label class="sx-row"><span class="sx-t"><b>${esc(dn(i))}</b><small>${esc(t('al.nowHas', { n: fmtQty(i.stock) }))}</small></span>
        <input class="input" inputmode="decimal" data-q="${i.id}" placeholder="${adj ? esc(fmtQty(i.stock)) : '0'}"></label>`).join('')}</div>`,
    footer: `<button class="btn primary" data-ok>${esc(t('common.save'))}</button>`,
  });
  $('[data-ok]', m).onclick = () => {
    let n = 0;
    try {
      for (const inp of $$('[data-q]', m)) {
        const v = String(inp.value).trim();
        if (v === '') continue;
        const q = Number(v.replace(',', '.'));
        if (!Number.isFinite(q)) continue;
        const it = Store.find('items', inp.dataset.q);
        if (adj) { const d = Math.round((q - (Number(it.stock) || 0)) * 1000) / 1000; if (!d) continue; Store.addStockEntry({ itemId: it.id, type: 'adjust', qty: d, date: today, reason: 'manual' }, App.user.id); }
        else { if (q <= 0) continue; Store.addStockEntry({ itemId: it.id, type: 'in', qty: q, date: today }, App.user.id); }
        n++;
      }
    } catch (e) { toast(t(e.message), true); return; }
    closeModal();
    if (n) { toast(t('al.savedN', { n })); render(); }
  };
}

// ---------- Aviso ao vender ----------
// Stock dos produtos da conta antes da venda, para saber quais passaram o mínimo.
function alertSnap(ticket) {
  const m = new Map();
  for (const l of ticket.lines || []) { const i = Store.find('items', l.itemId); if (i && i.trackStock) m.set(i.id, Number(i.stock) || 0); }
  for (const i of Store.data.items) if (i.trackStock && !m.has(i.id)) m.set(i.id, Number(i.stock) || 0); // caixas abertas, etc.
  return m;
}
function alertAfterSale(before) {
  const cfg = alertCfg();
  const hits = [];
  for (const [id, was] of before) {
    const i = Store.find('items', id);
    if (!i || !i.trackStock || isLamina(i)) continue;
    const now = Number(i.stock) || 0, min = ruleMin(i, cfg);
    if (cfg.out && was > 0 && now <= 0) hits.push({ i, now, min, k: 'out' });
    else if (cfg.low && was > min && now <= min && now > 0) hits.push({ i, now, min, k: 'low' });
  }
  paintBell();
  if (!hits.length) return;
  const text = h => (h.k === 'out' ? t('al.toastOut', { name: dn(h.i) }) : t('al.toastLow', { name: dn(h.i), n: fmtQty(h.now), min: fmtQty(h.min) }));
  if (cfg.onSale && can('alStock')) showAlertBar(hits.length === 1 ? text(hits[0]) : t('al.toastMany', { n: hits.length }));
  if (cfg.chat && typeof Chat !== 'undefined' && Chat.available()) for (const h of hits) Chat.sendSystem(text(h));
}
let barTimer = null;
function showAlertBar(msg, btnLabel, onBtn) {
  let el = document.getElementById('al-bar');
  if (!el) { el = document.createElement('div'); el.id = 'al-bar'; el.className = 'al-bar'; document.body.appendChild(el); }
  el.innerHTML = `<span>${esc(msg)}</span><button type="button">${esc(btnLabel || t('al.see'))}</button>`;
  $('button', el).onclick = () => { el.classList.remove('on'); if (onBtn) onBtn(); else alertsModal(); };
  requestAnimationFrame(() => el.classList.add('on'));
  if (navigator.vibrate) navigator.vibrate([20, 60, 20]);
  clearTimeout(barTimer);
  barTimer = setTimeout(() => el.classList.remove('on'), 5000);
}

// ---------- Configurações → Alertas ----------
function alertsSettingsHtml() {
  const c = alertCfg();
  const tg = (k, on) => `<span class="tg ${on ? 'on' : ''}" data-tg="${k}"><i></i></span>`;
  const r = (k, title, sub, right) => `<div class="sx-row" ${k ? `data-row="${k}"` : ''}><span class="sx-t"><b>${esc(title)}</b>${sub ? `<small>${esc(sub)}</small>` : ''}</span>${right}</div>`;
  const nb = (k, v, unit) => `<label class="al-num"><input class="input" inputmode="numeric" data-num="${k}" value="${esc(String(v))}">${unit ? `<span>${esc(unit)}</span>` : ''}</label>`;
  const radio = (v, title, sub) => `<div class="sx-row" data-base="${v}"><span class="al-rd ${c.base === v ? 'on' : ''}"></span><span class="sx-t"><b>${esc(title)}</b><small>${esc(sub)}</small></span></div>`;
  return `<div class="al-set">
    <div class="sx-gt">${esc(t('al.sBase'))}</div><div class="sx-list">
      ${radio('count', t('al.sBaseCount'), t('al.sBaseCountSub'))}
      ${radio('stock', t('al.sBaseStock'), t('al.sBaseStockSub'))}</div>
    <div class="sx-gt">${esc(t('al.sRules'))}</div><div class="sx-list">
      ${r('', t('al.sBoxes'), t('al.sBoxesSub'), nb('minBox', c.minBox, t('al.orLess')))}
      ${r('', t('al.sBottles'), t('al.sBottlesSub'), nb('minBottle', c.minBottle, t('al.orLess')))}
      ${r('', t('al.sLaminas'), t('al.sLaminasSub'), '')}</div>
    <div class="sx-gt">${esc(t('al.sStock'))}</div><div class="sx-list">
      ${r('out', t('al.sOut'), '', tg('out', c.out))}
      ${r('low', t('al.sLow'), t('al.sLowSub'), tg('low', c.low))}
      ${r('', t('al.sDefMin'), t('al.sDefMinOther'), nb('defMin', c.defMin))}
      ${r('idle', t('al.sIdle'), t('al.sIdleSub'), tg('idle', c.idle))}
      ${r('', t('al.sIdleDays'), '', nb('idleDays', c.idleDays, t('al.days')))}</div>
    <div class="sx-gt">${esc(t('al.sMoney'))}</div><div class="sx-list">
      ${r('credit', t('al.credit'), '', tg('credit', c.credit))}
      ${r('', t('al.sAfter'), '', nb('creditDays', c.creditDays, t('al.days')))}
      ${r('count', t('al.count'), '', tg('count', c.count))}
      ${r('', t('al.sAfter'), '', nb('countDays', c.countDays, t('al.days')))}
      ${r('cost', t('al.cost'), '', tg('cost', c.cost))}</div>
    <div class="sx-gt">${esc(t('al.sHow'))}</div><div class="sx-list">
      ${r('onSale', t('al.sOnSale'), t('al.sOnSaleSub'), tg('onSale', c.onSale))}
      ${r('chat', t('al.sChat'), t('al.sChatSub'), tg('chat', c.chat))}</div>
    <p class="muted small" style="margin:10px 4px 0">${esc(t('al.sWho'))}</p>
  </div>`;
}
function wireAlertsSettings(root) {
  const box = $('.al-set', root);
  if (!box) return;
  const save = patch => { Store.settings.alerts = Object.assign(alertCfg(), patch); Store.save(); paintBell(); };
  $$('[data-row]', box).forEach(row => row.addEventListener('click', () => {
    const k = row.dataset.row, tgl = $('[data-tg]', row), on = !tgl.classList.contains('on');
    tgl.classList.toggle('on', on); save({ [k]: on });
  }));
  $$('[data-base]', box).forEach(row => row.addEventListener('click', () => {
    $$('[data-base] .al-rd', box).forEach(x => x.classList.toggle('on', x.parentNode === row));
    save({ base: row.dataset.base });
  }));
  $$('[data-num]', box).forEach(inp => inp.addEventListener('change', () => {
    const v = Math.max(0, Math.round(Number(String(inp.value).replace(',', '.')) || 0));
    inp.value = v; save({ [inp.dataset.num]: v }); toast(t('settings.saved'));
  }));
}
function alertsSummary() {
  const c = alertCfg();
  const on = [c.out || c.low ? t('perm.short.alStock') : '', c.credit ? t('perm.short.alCredit') : '', c.count ? t('perm.short.alCount') : '', c.cost ? t('perm.short.alCost') : '', c.idle ? t('perm.short.alIdle') : ''].filter(Boolean);
  return on.length ? on.join(', ') : t('al.sOff');
}

// Janela "Voltar a avisar daqui a": 1 dia, 3 dias, 1 semana, 1 mês ou Personalizar.
// done(até quando em ms, texto do tempo, true se foi uma data certa).
function snoozePicker(done) {
  const opts = [['1', t('al.snz1')], ['3', t('al.snz3')], ['7', t('al.snz7')], ['30', t('al.snz30')]];
    const DAYMS = 86400000;
  const pm = openModal({ title: t('al.archiveQ'), autofocus: false, body: `<p class="muted small" style="margin:0 2px 10px">${esc(t('al.archiveHint'))}</p>
      <div class="sx-list">${opts.map(([v, l]) => `<button type="button" class="sx-row" data-d="${v}"><span class="sx-ic" style="background:#64748b">${icon('clock')}</span><span class="sx-t"><b>${esc(l)}</b></span></button>`).join('')}
        <button type="button" class="sx-row" data-custom><span class="sx-ic" style="background:#1f6f3a">${icon('edit')}</span><span class="sx-t"><b>${esc(t('al.snzCustom'))}</b><small>${esc(t('al.snzCustomSub'))}</small></span></button></div>
      <div class="al-custom" hidden>
        <div class="al-cu-row"><input class="input" type="number" min="1" max="999" inputmode="numeric" value="2" id="cu-n">
          <div class="al-units">${[['h', t('al.uHours')], ['d', t('al.uDays')], ['w', t('al.uWeeks')], ['m', t('al.uMonths')]].map(([u, l], i) => `<button type="button" class="${i === 1 ? 'on' : ''}" data-u="${u}">${esc(l)}</button>`).join('')}</div></div>
        <div class="al-or">${esc(t('al.orDate'))}</div>
        <input class="input" type="datetime-local" id="cu-dt">
        <button type="button" class="btn primary block" id="cu-ok" style="margin-top:12px">${esc(t('al.archive'))}</button>
      </div>` });
    $$('[data-d]', pm).forEach(x => x.addEventListener('click', () => done(Date.now() + Number(x.dataset.d) * DAYMS, x.querySelector('b').textContent.toLowerCase())));
    let unit = 'd';
    const pad = n => String(n).padStart(2, '0');
    const local = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
    $('[data-custom]', pm).onclick = () => {
      const c = $('.al-custom', pm); c.hidden = !c.hidden;
      const dt = $('#cu-dt', pm); dt.min = local(new Date(Date.now() + 60000)); if (!c.hidden) $('#cu-n', pm).focus();
    };
    $$('[data-u]', pm).forEach(b => b.addEventListener('click', () => { unit = b.dataset.u; $$('[data-u]', pm).forEach(x => x.classList.toggle('on', x === b)); $('#cu-dt', pm).value = ''; }));
    $('#cu-n', pm).addEventListener('input', () => { $('#cu-dt', pm).value = ''; });
    $('#cu-ok', pm).onclick = () => {
      const dt = $('#cu-dt', pm).value;
      if (dt) {
        const at = new Date(dt).getTime();
        if (!(at > Date.now())) { toast(t('al.snzPast'), true); return; }
        done(at, new Date(at).toLocaleString(dateLocale(), { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }), true);
        return;
      }
      const n = Math.max(1, Math.min(999, Math.round(Number($('#cu-n', pm).value) || 0)));
      const ms = { h: 3600000, d: DAYMS, w: 7 * DAYMS, m: 30 * DAYMS }[unit];
      const names = { h: ['al.uHour1', 'al.uHours'], d: ['al.uDay1', 'al.uDays'], w: ['al.uWeek1', 'al.uWeeks'], m: ['al.uMonth1', 'al.uMonths'] }[unit];
      done(Date.now() + n * ms, `${n} ${t(n === 1 ? names[0] : names[1]).toLowerCase()}`);
    };
}

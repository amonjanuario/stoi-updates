'use strict';
/* global Store, Sync, Printer, NativePrint, EXPENSE_CATEGORIES, ADJUST_REASONS, EscPos, receiptEscPos, computeTotals, newTicket, round2, uid, dayKey, receiptNo,
   CURRENCIES, PAY_TYPES, t, LANGS, getLang, setLang, dateLocale */

// ================= Utilitários =================

const $ = (sel, el = document) => el.querySelector(sel);
const $$ = (sel, el = document) => [...el.querySelectorAll(sel)];
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const num = v => {
  const n = parseFloat(String(v ?? '').replace(',', '.'));
  return Number.isFinite(n) ? n : 0;
};

let moneyFmt = null;
function money(n) {
  if (!moneyFmt) {
    const cur = Store.settings.currency;
    const locale = (CURRENCIES[cur] || CURRENCIES.MZN).locale;
    try { moneyFmt = new Intl.NumberFormat(locale, { style: 'currency', currency: cur }); }
    catch (e) { moneyFmt = new Intl.NumberFormat('pt-MZ', { style: 'currency', currency: 'MZN' }); }
  }
  return moneyFmt.format(round2(n || 0));
}
const fmtQty = q => (Number.isInteger(q) ? String(q) : String(round2(q)).replace('.', ','));
const fmtDate = iso => new Date(iso).toLocaleString(dateLocale(), { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });
const fmtTime = iso => new Date(iso).toLocaleTimeString(dateLocale(), { hour: '2-digit', minute: '2-digit' });
const initials = name => {
  const words = String(name).trim().split(/\s+/).filter(w => /^\p{L}/u.test(w));
  if (!words.length) return String(name).trim().slice(0, 2).toUpperCase();
  return (words.length === 1 ? words[0].slice(0, 2) : words[0][0] + words[1][0]).toUpperCase();
};
const empName = id => (Store.find('employees', id) || { name: '—' }).name;
const payLabel = type => t(`pay.${type}`);
const roleLabel = role => t(`role.${role}`);
const COLORS = ['#e53935', '#d81b60', '#8e24aa', '#5e35b1', '#1e88e5', '#00897b', '#43a047', '#fb8c00', '#6d4c41', '#546e7a'];

// Configuração deste dispositivo (não sincronizada): idioma, impressora e identificador.
const DEVICE_KEY = 'stoi-device';
const Device = {
  conf: { id: null, printer: null },
  load() {
    try { this.conf = Object.assign(this.conf, JSON.parse(localStorage.getItem(DEVICE_KEY)) || {}); } catch (e) { /* ignorar */ }
    if (!this.conf.id) { this.conf.id = uid() + uid(); this.save(); }
  },
  save() {
    try { localStorage.setItem(DEVICE_KEY, JSON.stringify(this.conf)); } catch (e) { /* ignorar */ }
  },
};

const ICONS = {
  // Ícones de contorno dos separadores de Gestão.
  oBox: 'M20 2H4c-1 0-2 .9-2 2v3.01c0 .72.43 1.34 1 1.69V20c0 1.1 1.1 2 2 2h14c.9 0 2-.9 2-2V8.7c.57-.35 1-.97 1-1.69V4c0-1.1-1-2-2-2zm-1 18H5V9h14v11zm1-13H4V4h16v3zM9 12h6v2H9z',
  oTag: 'M21.41 11.58l-9-9C12.05 2.22 11.55 2 11 2H4c-1.1 0-2 .9-2 2v7c0 .55.22 1.05.59 1.42l9 9c.36.36.86.58 1.41.58s1.05-.22 1.41-.59l7-7c.37-.36.59-.86.59-1.41s-.23-1.06-.59-1.42zM13 20.01L4 11V4h7v-.01l9 9-7 7.02zM6.5 5a1.5 1.5 0 1 0 0 3 1.5 1.5 0 1 0 0-3z',
  oWarehouse: 'M18.36 9l.6 3H5.04l.6-3h12.72M20 4H4v2h16V4zm0 3H4l-1 5v2h1v6h10v-6h4v6h2v-6h1v-2l-1-5zM6 18v-4h6v4H6z',
  oDollar: 'M11.8 10.9c-2.27-.59-3-1.2-3-2.15 0-1.09 1.01-1.85 2.7-1.85 1.78 0 2.44.85 2.5 2.1h2.21c-.07-1.72-1.12-3.3-3.21-3.81V3h-3v2.16c-1.94.42-3.5 1.68-3.5 3.61 0 2.31 1.91 3.46 4.7 4.13 2.5.6 3 1.48 3 2.41 0 .69-.49 1.79-2.7 1.79-2.06 0-2.87-.92-2.98-2.1h-2.2c.12 2.19 1.76 3.42 3.68 3.83V21h3v-2.15c1.95-.37 3.5-1.5 3.5-3.55 0-2.84-2.43-3.81-4.5-4.4z',
  oCount: 'M18 9l-1.41-1.42L10 14.17l-2.59-2.58L6 13l4 4zm1-6h-4.18C14.4 1.84 13.3 1 12 1s-2.4.84-2.82 2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-7-.25c.41 0 .75.34.75.75s-.34.75-.75.75-.75-.34-.75-.75.34-.75.75-.75zM19 19H5V5h14v14z',
  oMoney: 'M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm.31-8.86c-1.77-.45-2.34-.94-2.34-1.67 0-.84.79-1.43 2.1-1.43 1.38 0 1.9.66 1.94 1.64h1.71c-.05-1.34-.87-2.57-2.49-2.97V5H10.9v1.69c-1.51.32-2.72 1.3-2.72 2.81 0 1.79 1.49 2.69 3.66 3.21 1.95.46 2.34 1.15 2.34 1.87 0 .53-.39 1.39-2.1 1.39-1.6 0-2.23-.72-2.32-1.64H8.04c.1 1.7 1.36 2.66 2.86 2.97V19h2.34v-1.67c1.52-.29 2.72-1.16 2.73-2.77-.01-2.2-1.9-2.96-3.66-3.42z',
  oWallet: 'M21 7.28V5c0-1.1-.9-2-2-2H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2v-2.28c.59-.35 1-.98 1-1.72V9c0-.74-.41-1.37-1-1.72zM20 9v6h-7V9h7zM5 19V5h14v2h-6c-1.1 0-2 .9-2 2v6c0 1.1.9 2 2 2h6v2H5zm11-6.5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z',
  cart: 'M7 18a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm10 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4zM7.2 14.6 7.3 14h8.9c.7 0 1.4-.4 1.7-1l3.6-6.5L19.8 5H5.2l-.9-2H1v2h2l3.6 7.6L5.2 15c-.7 1.3.3 3 1.8 3h12v-2H7.4c-.1 0-.2-.1-.2-.2z',
  receipt: 'M18 17H6v-2h12v2zm0-4H6v-2h12v2zm0-4H6V7h12v2zM3 22l1.5-1.5L6 22l1.5-1.5L9 22l1.5-1.5L12 22l1.5-1.5L15 22l1.5-1.5L18 22l1.5-1.5L21 22V2l-1.5 1.5L18 2l-1.5 1.5L15 2l-1.5 1.5L12 2l-1.5 1.5L9 2 7.5 3.5 6 2 4.5 3.5 3 2v20z',
  clock: 'M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm0 18a8 8 0 1 1 0-16 8 8 0 0 1 0 16zm.5-13H11v6l5.2 3.2.8-1.3-4.5-2.7V7z',
  box: 'M20 7l-8-4-8 4v10l8 4 8-4V7zm-8-1.8L17.5 8 12 10.8 6.5 8 12 5.2zM6 9.6l5 2.5v6.3l-5-2.5V9.6zm7 8.8v-6.3l5-2.5v6.3l-5 2.5z',
  tag: 'M21.4 11.6l-9-9C12.1 2.2 11.6 2 11 2H4c-1.1 0-2 .9-2 2v7c0 .6.2 1.1.6 1.4l9 9c.4.4.9.6 1.4.6s1-.2 1.4-.6l7-7c.4-.4.6-.9.6-1.4s-.2-1-.6-1.4zM5.5 7C4.7 7 4 6.3 4 5.5S4.7 4 5.5 4 7 4.7 7 5.5 6.3 7 5.5 7z',
  people: 'M16 11c1.7 0 3-1.3 3-3s-1.3-3-3-3-3 1.3-3 3 1.3 3 3 3zm-8 0c1.7 0 3-1.3 3-3S9.7 5 8 5 5 6.3 5 8s1.3 3 3 3zm0 2c-2.3 0-7 1.2-7 3.5V19h14v-2.5C15 14.2 10.3 13 8 13zm8 0c-.3 0-.6 0-1 .1 1.2.8 2 2 2 3.4V19h6v-2.5c0-2.3-4.7-3.5-7-3.5z',
  chart: 'M5 9.2h3V19H5V9.2zM10.6 5h2.8v14h-2.8V5zm5.6 8H19v6h-2.8v-6z',
  badge: 'M12 12c2.2 0 4-1.8 4-4s-1.8-4-4-4-4 1.8-4 4 1.8 4 4 4zm0 2c-2.7 0-8 1.3-8 4v2h16v-2c0-2.7-5.3-4-8-4z',
  gear: 'M19.4 13c0-.3.1-.6.1-1s0-.7-.1-1l2.1-1.6c.2-.2.2-.4.1-.6l-2-3.5c-.1-.2-.4-.3-.6-.2l-2.5 1c-.5-.4-1.1-.7-1.7-1l-.4-2.6c0-.2-.3-.4-.5-.4h-4c-.3 0-.5.2-.5.4l-.4 2.7c-.6.2-1.1.6-1.7 1l-2.5-1c-.2-.1-.5 0-.6.2l-2 3.5c-.1.2-.1.5.1.6L4.6 11c0 .3-.1.6-.1 1s0 .7.1 1l-2.1 1.6c-.2.2-.2.4-.1.6l2 3.5c.1.2.4.3.6.2l2.5-1c.5.4 1.1.7 1.7 1l.4 2.7c0 .2.2.4.5.4h4c.3 0 .5-.2.5-.4l.4-2.7c.6-.3 1.2-.6 1.7-1l2.5 1c.2.1.5 0 .6-.2l2-3.5c.1-.2.1-.5-.1-.6L19.4 13zM12 15.5c-1.9 0-3.5-1.6-3.5-3.5s1.6-3.5 3.5-3.5 3.5 1.6 3.5 3.5-1.6 3.5-3.5 3.5z',
  user: 'M12 12c2.2 0 4-1.8 4-4s-1.8-4-4-4-4 1.8-4 4 1.8 4 4 4zm0 2c-2.7 0-8 1.3-8 4v2h16v-2c0-2.7-5.3-4-8-4z',
  trash: 'M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z',
  list: 'M3 13h2v-2H3v2zm0 4h2v-2H3v2zm0-8h2V7H3v2zm4 4h14v-2H7v2zm0 4h14v-2H7v2zM7 7v2h14V7H7z',
  close: 'M19 6.4 17.6 5 12 10.6 6.4 5 5 6.4 10.6 12 5 17.6 6.4 19 12 13.4 17.6 19 19 17.6 13.4 12z',
  cash: 'M2 6h20v12H2V6zm2 2v8h16V8H4zm8 1.5a2.5 2.5 0 1 1 0 5 2.5 2.5 0 0 1 0-5z',
  card: 'M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 14H4v-6h16v6zm0-10H4V6h16v2z',
  mobile: 'M16 1H8C6.3 1 5 2.3 5 4v16c0 1.7 1.3 3 3 3h8c1.7 0 3-1.3 3-3V4c0-1.7-1.3-3-3-3zm-4 21a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3zm5-4H7V4h10v14z',
  clipboard: 'M19 3h-4.18C14.4 1.84 13.3 1 12 1s-2.4.84-2.82 2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-7 0c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1zm-2 14-4-4 1.41-1.41L10 14.17l6.59-6.59L18 9l-8 8z',
  logout: 'M10.09 15.59 11.5 17l5-5-5-5-1.41 1.41L12.67 11H3v2h9.67l-2.58 2.59zM19 3H5a2 2 0 0 0-2 2v4h2V5h14v14H5v-4H3v4a2 2 0 0 0 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2z',
  edit: 'M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04a1 1 0 0 0 0-1.41l-2.34-2.34a1 1 0 0 0-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z',
  spark: 'M12 2l2.4 6.6L21 11l-6.6 2.4L12 20l-2.4-6.6L3 11l6.6-2.4z',
  table: 'M3 3h18v18H3V3zm2 4v4h6V7H5zm8 0v4h6V7h-6zm-8 6v4h6v-4H5zm8 0v4h6v-4h-6z',
  camera: 'M12 15.2a3.2 3.2 0 1 0 0-6.4 3.2 3.2 0 0 0 0 6.4zM9 2 7.17 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2h-3.17L15 2H9zm3 15a5 5 0 1 1 0-10 5 5 0 0 1 0 10z',
  image: 'M21 19V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v14c0 1.1.9 2 2 2h14a2 2 0 0 0 2-2zM8.5 13.5l2.5 3 3.5-4.5 4.5 6H5l3.5-4.5z',
  copy: 'M16 1H4a2 2 0 0 0-2 2v14h2V3h12V1zm3 4H8a2 2 0 0 0-2 2v14c0 1.1.9 2 2 2h11a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2zm0 16H8V7h11v14z',
  refresh: 'M17.65 6.35A7.96 7.96 0 0 0 12 4a8 8 0 1 0 7.73 10h-2.08A6 6 0 1 1 12 6c1.66 0 3.14.69 4.22 1.78L13 11h7V4l-2.35 2.35z',
  undo: 'M12.5 8c-2.65 0-5.05.99-6.9 2.6L2 7v9h9l-3.62-3.62c1.39-1.16 3.16-1.88 5.12-1.88 3.54 0 6.55 2.31 7.6 5.5l2.37-.78C21.08 11.03 17.15 8 12.5 8z',
  text: 'M4 5h16v2H4V5zm0 4h16v2H4V9zm0 4h16v2H4v-2zm0 4h10v2H4v-2z',
  layers: 'M11.99 18.54l-7.37-5.73L3 14.07l9 7 9-7-1.63-1.27-7.38 5.74zM12 16l7.36-5.73L21 9l-9-7-9 7 1.63 1.27L12 16z',
  print: 'M19 8H5c-1.66 0-3 1.34-3 3v6h4v4h12v-4h4v-6c0-1.66-1.34-3-3-3zm-3 11H8v-5h8v5zm3-7c-.55 0-1-.45-1-1s.45-1 1-1 1 .45 1 1-.45 1-1 1zm-1-9H6v4h12V3z',
  calendar: 'M19 4h-1V2h-2v2H8V2H6v2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 16H5V9h14v11zM7 11h5v5H7z',
  download: 'M5 20h14v-2H5v2zM19 9h-4V3H9v6H5l7 7 7-7z',
  calc: 'M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-5.97 4.06L14.09 6l1.41 1.41L16.91 6l1.06 1.06-1.41 1.41 1.41 1.41-1.06 1.06-1.41-1.4-1.41 1.41-1.06-1.06 1.41-1.41-1.41-1.42zm-6.78.66h5v1.5h-5v-1.5zM11.5 16h-2v2H8v-2H6v-1.5h2v-2h1.5v2h2V16zm6.5 1.25h-5v-1.5h5v1.5zm0-2.5h-5v-1.5h5v1.5z',
  search: 'M15.5 14h-.79l-.28-.27A6.47 6.47 0 0 0 16 9.5 6.5 6.5 0 1 0 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z',
  chevron: 'M7.4 8.6 12 13.2l4.6-4.6L18 10l-6 6-6-6z',
  back: 'M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20z',
  play: 'M8 5v14l11-7z',
  more: 'M12 8c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm0 2c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 6c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z',
  filter: 'M10 18h4v-2h-4v2zM3 6v2h18V6H3zm3 7h12v-2H6v2z',
  wrench: 'M22.7 19l-9.1-9.1c.9-2.3.4-5-1.5-6.9-2-2-5-2.4-7.4-1.3L9 6 6 9 1.6 4.7C.4 7.1.9 10.1 2.9 12.1c1.9 1.9 4.6 2.4 6.9 1.5l9.1 9.1c.4.4 1 .4 1.4 0l2.3-2.3c.5-.4.5-1.1.1-1.4z',
  plus: 'M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z',
  check: 'M9 16.2 4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4L9 16.2z',
  credit: 'M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm1 15h-2v-1.1c-1.5-.3-2.7-1.2-2.8-2.7h1.6c.1.8.8 1.4 2.2 1.4 1.5 0 1.8-.7 1.8-1.2 0-.6-.3-1.2-2-1.6-1.9-.5-3.2-1.2-3.2-2.8 0-1.3 1-2.2 2.4-2.5V5h2v1.1c1.5.4 2.2 1.5 2.3 2.7h-1.6c0-.9-.5-1.4-1.7-1.4-1.1 0-1.8.5-1.8 1.2 0 .6.5 1 2 1.4 1.5.4 3.2 1 3.2 3 0 1.4-1.1 2.3-2.4 2.6V17z',
  wallet: 'M21 7.28V5c0-1.1-.9-2-2-2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14c1.1 0 2-.9 2-2v-2.28A2 2 0 0 0 22 15V9a2 2 0 0 0-1-1.72zM20 9v6h-7V9h7zM5 19V5h14v2h-6c-1.1 0-2 .9-2 2v6c0 1.1.9 2 2 2h6v2H5zm11-6.5a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3z',
  other: 'M6 10c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm12 0c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm-6 0c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z',
  chat: 'M20 2H4a2 2 0 0 0-2 2v18l4-4h14a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2zM7 9h10v2H7zm6 5H7v-2h6zm4-6H7V6h10z',
  pin: 'M16 9V4h1a1 1 0 0 0 0-2H7a1 1 0 0 0 0 2h1v5a3 3 0 0 1-3 3v2h6v7l1 1 1-1v-7h6v-2a3 3 0 0 1-3-3z',
  forward: 'M14 9V5l7 7-7 7v-4.1c-5 0-8.5 1.6-11 5.1 1-5 4-10 11-11z',
  share: 'M18 16.08c-.76 0-1.44.3-1.96.77L8.91 12.7c.05-.23.09-.46.09-.7s-.04-.47-.09-.7l7.05-4.11A2.99 2.99 0 0 0 21 5a3 3 0 1 0-5.91.7L8.04 9.81A2.99 2.99 0 0 0 3 12a3 3 0 0 0 5.04 2.19l7.12 4.16c-.05.21-.08.43-.08.65A2.92 2.92 0 1 0 18 16.08z',
  inbox: 'M19 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V5a2 2 0 0 0-2-2zm0 12h-4a3 3 0 0 1-6 0H5V5h14v10zm-3-5h-2V7h-4v3H8l4 4 4-4z',
  tune: 'M3 17v2h6v-2H3zM3 5v2h10V5H3zm10 16v-2h8v-2h-8v-2h-2v6h2zM7 9v2H3v2h4v2h2V9H7zm14 4v-2H11v2h10zm-6-4h2V7h4V5h-4V3h-2v6z',
  send: 'M2.01 21 23 12 2.01 3 2 10l15 2-15 2z',
  doneAll: 'M18 7l-1.41-1.41-6.34 6.34 1.41 1.41L18 7zm4.24-1.41L11.66 16.17 7.48 12l-1.41 1.41L11.66 19l12-12-1.42-1.41zM.41 13.41 6 19l1.41-1.41L1.83 12 .41 13.41z',
  checkbox: 'M19 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V5a2 2 0 0 0-2-2zm-9 14-5-5 1.4-1.4 3.6 3.6 7.6-7.6L19 8l-9 9z',
  percent: 'M7.5 11a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7zm9 9a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7zM5.4 20 4 18.6 18.6 4 20 5.4z',
  bell: 'M12 22a2 2 0 0 0 2-2h-4a2 2 0 0 0 2 2zm6-6V11c0-3.07-1.64-5.64-4.5-6.32V4a1.5 1.5 0 0 0-3 0v.68C7.63 5.36 6 7.92 6 11v5l-2 2v1h16v-1l-2-2z',
  phone: 'M17 1H7a2 2 0 0 0-2 2v18a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V3a2 2 0 0 0-2-2zm0 18H7V5h10v14z',
  mail: 'M20 4H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2zm0 4-8 5-8-5V6l8 5 8-5z',
  lock: 'M18 8h-1V6a5 5 0 0 0-10 0v2H6a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V10a2 2 0 0 0-2-2zm-6 9a2 2 0 1 1 0-4 2 2 0 0 1 0 4zm3.1-9H8.9V6a3.1 3.1 0 0 1 6.2 0z',
  eye: 'M12 4.5C7 4.5 2.7 7.6 1 12c1.7 4.4 6 7.5 11 7.5s9.3-3.1 11-7.5c-1.7-4.4-6-7.5-11-7.5zM12 17a5 5 0 1 1 0-10 5 5 0 0 1 0 10zm0-8a3 3 0 1 0 0 6 3 3 0 0 0 0-6z',
  eyeOff: 'M12 7a5 5 0 0 1 5 5c0 .6-.1 1.3-.4 1.8l2.9 2.9A11.8 11.8 0 0 0 23 12c-1.7-4.4-6-7.5-11-7.5-1.4 0-2.7.2-4 .7l2.2 2.1c.5-.2 1.1-.3 1.8-.3zM2 4.3l2.3 2.3.4.4A11.8 11.8 0 0 0 1 12c1.7 4.4 6 7.5 11 7.5 1.5 0 3-.3 4.4-.8l.4.4 2.9 2.9 1.3-1.3L3.3 3 2 4.3zM7.5 9.8 9.1 11.4 9 12a3 3 0 0 0 3 3l.6-.1 1.6 1.6A5 5 0 0 1 7 12c0-.8.2-1.5.5-2.2zm4.3-.8 3.2 3.2V12a3 3 0 0 0-3-3h-.2z',
  shield: 'M12 1 3 5v6c0 5.6 3.8 10.7 9 12 5.2-1.3 9-6.4 9-12V5l-9-4zm-2 16-4-4 1.4-1.4L10 14.2l6.6-6.6L18 9l-8 8z',
  cloud: 'M19.4 10A7.5 7.5 0 0 0 5.3 8 6 6 0 0 0 6 20h13a5 5 0 0 0 .4-10z',
  cloudOff: 'M19.4 10A7.5 7.5 0 0 0 8.1 5.4l1.5 1.5A5.5 5.5 0 0 1 17.5 11v.5H19a3 3 0 0 1 1.6 5.5l1.4 1.5A5 5 0 0 0 19.4 10zM3 5.3 5.8 8A6 6 0 0 0 6 20h11.7l2 2 1.3-1.3L4.3 4 3 5.3zM7.7 10l8 8H6a4 4 0 0 1 0-8h1.7z',
};
const icon = name => `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="${ICONS[name]}"/></svg>`;

const ALL = ['owner', 'manager', 'cashier', 'supplier'];
const ADMIN = ['owner', 'manager'];

// ---------- Permissões de cada funcionário ----------
// A função (Gerente / Vendedor) liga as permissões de base; cada uma pode mudar-se por pessoa
// (fica "Personalizada"). O Dono pode tudo. Vender e enviar mensagens estão sempre ligados.
const PERM_GROUPS = [
  ['perm.gSales', [['sell', 'cart', '#16a34a'], ['discount', 'percent', '#0ea5e9'], ['credit', 'people', '#7c3aed'], ['refund', 'undo', '#dc2626']]],
  ['perm.gStock', [['stockIn', 'box', '#ea580c'], ['count', 'clipboard', '#0891b2'], ['products', 'edit', '#db2777'], ['fixStock', 'wrench', '#64748b']]],
  ['perm.gMoney', [['reports', 'chart', '#2563eb'], ['close', 'check', '#16a34a'], ['expenses', 'cash', '#ca8a04']]],
  ['perm.gAlerts', [['alStock', 'box', '#ea580c'], ['alCredit', 'people', '#7c3aed'], ['alCount', 'clipboard', '#0891b2'], ['alCost', 'tag', '#db2777'], ['alIdle', 'clock', '#64748b']]],
  ['perm.gChat', [['chat', 'chat', '#16a34a'], ['pin', 'pin', '#d97706']]],
  ['perm.gData', [['editData', 'edit', '#b91c1c']]],
];
const PERM_KEYS = PERM_GROUPS.flatMap(g => g[1].map(x => x[0]));
const PERM_ALWAYS = ['sell', 'chat'];
const ROLE_PERMS = {
  manager: Object.fromEntries(PERM_KEYS.map(k => [k, true])),
  cashier: { sell: true, credit: true, stockIn: true, count: true, expenses: true, chat: true, alStock: true },
  // Fornecedor: só ver (stock, balanço, fecho e relatórios) e falar no chat.
  supplier: { chat: true, reports: true, close: true },
};
function can(k, e = App.user) {
  if (!e) return false;
  if (e.role === 'owner') return true;
  if (PERM_ALWAYS.includes(k) && !(e.role === 'supplier' && k === 'sell')) return true;
  if (e.perms && k in e.perms) return !!e.perms[k];
  return !!(ROLE_PERMS[e.role] || {})[k];
}
const canAny = (keys, e) => keys.some(k => can(k, e));
const canShare = e => canAny(['reports', 'close'], e); // enviar, copiar e exportar tabelas
const isCustom = e => e.role !== 'owner' && (!!e.custom || (!!e.perms && PERM_KEYS.some(k => !PERM_ALWAYS.includes(k) && k in e.perms && !!e.perms[k] !== !!(ROLE_PERMS[e.role] || {})[k])));
const roleName = e => (e.role === 'owner' ? roleLabel('owner') : isCustom(e) ? (e.customName || t('role.custom')) : roleLabel(e.role));
function need(k) { if (can(k)) return true; toast(t('perm.denied'), true); return false; }
const STOCK_PERMS = ['stockIn', 'count', 'products', 'fixStock'];
const ROUTES = [
  { id: 'vendas', label: 'nav.sales', icon: 'cart', roles: ALL, perm: e => can('sell', e), view: viewSales },
  { id: 'recibos', label: 'nav.receipts', icon: 'receipt', roles: ALL, view: viewReceipts },
  { id: 'turnos', label: 'nav.shifts', icon: 'clock', roles: ALL, view: viewShifts },
  { id: 'chat', label: 'nav.chat', icon: 'chat', roles: ALL, view: main => Chat.view(main) },
  // Produtos, Stock e Contagem/Fecho são separadores de um só menu ("Stock").
  { id: 'stock', label: 'nav.stock', icon: 'layers', roles: ALL, perm: e => canAny(STOCK_PERMS, e), view: viewStock, group: 'stock' },
  { id: 'itens', label: 'nav.items', icon: 'box', roles: ALL, perm: e => can('products', e), view: viewItems, group: 'stock', hidden: true },
  { id: 'balanco', label: 'nav.stockCount', icon: 'clipboard', roles: ALL, perm: e => canAny(['count', 'close'], e), view: viewCount, group: 'stock', hidden: true },
  { id: 'categorias', label: 'nav.categories', icon: 'tag', roles: ALL, perm: e => can('products', e), view: viewCategories, group: 'stock', hidden: true },
  { id: 'clientes', label: 'nav.customers', icon: 'people', roles: ALL, view: viewCustomers, group: 'vendas', hidden: true },
  // Relatórios: fora do menu, com ícone no cabeçalho.
  { id: 'relatorios', label: 'nav.reports', icon: 'chart', roles: ALL, perm: e => can('reports', e), view: viewReports, hidden: true, group: 'vendas' },
  { id: 'funcionarios', label: 'nav.employees', icon: 'badge', roles: ['owner'], view: viewEmployees },
  { id: 'definicoes', label: 'nav.settings', icon: 'gear', roles: ['owner'], view: viewSettings },
];

const App = {
  user: null,
  ticket: null,
  showTicket: false,
  posCats: [],
  posOut: false,
  posSearch: '',
  itemsFilter: { q: '', cats: [], low: false, stock: '', type: '', code: '', sort: 'name' },
  receiptsQ: '',
  customersQ: '',
  reportRange: { preset: 'today', from: '', to: '' },
};

// ================= Toast / modal =================

let toastTimer = null;
// Avisos: só erros e o que não se vê no ecrã (atualizações, ficheiro guardado). As ações cujo
// resultado já se vê (arquivar, guardar, apagar…) não mostram aviso. "Copiado" já o Android diz.
function toast(msg, isError, show = false) {
  if (!isError && !show) return;
  const el = $('#toast');
  el.innerHTML = `<i class="toast-ic">${isError ? '✕' : '✓'}</i><span>${esc(msg)}</span>`;
  el.classList.toggle('error', !!isError);
  el.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('show'), 2800);
}

function openModal({ title, body, footer = '', wide = false, autofocus = true, sheet = false, head = '', keepFoot = false }) {
  closeModal();
  const root = $('#modal-root');
  root.innerHTML = `
    <div class="modal-backdrop sheet-bd">
      <div class="modal ${wide ? 'wide' : ''} sheet" role="dialog" aria-modal="true" aria-label="${esc(title)}">
        <div class="sheet-handle"></div><div class="modal-head" style="display:none"><button type="button" data-close aria-label="${esc(t('common.close'))}"></button></div>${sheet && head ? head : `<div class="modal-head"><h2>${esc(title)}</h2></div>`}
        <div class="modal-body">${body}</div>
        ${footer ? `<div class="modal-foot">${footer}</div>` : ''}
      </div>
    </div>`;
  const backdrop = root.firstElementChild;
  if (!keepFoot) footActionsToHead(backdrop);
  setTimeout(() => { tableTools(backdrop); sortIcons(backdrop); shareGate(backdrop); }, 0); // depois de a janela se preencher
  // Fecha como o antigo "X" (que continua escondido): tocar fora, arrastar para baixo, ou o botão voltar.
  const dismiss = () => { const x = $('[data-close]', backdrop); if (x) x.click(); else closeModal(); };
  backdrop.addEventListener('mousedown', e => { if (e.target === backdrop) dismiss(); });
  $$('[data-close]', backdrop).forEach(b => b.addEventListener('click', closeModal));
  sheetSwipe(backdrop, dismiss);
  const first = $('input:not([type=hidden]):not([type=checkbox]):not([type=radio]), select, textarea', backdrop);
  if (first && autofocus) setTimeout(() => { first.focus(); if (first.select) first.select(); }, 30);
  return backdrop;
}
// Em todas as janelas, as ações secundárias do rodapé (apagar, exportar, editar, imprimir,
// devolver, partilhar) passam para ícones de traço fino no título; o rodapé fica com a ação principal.
const HEAD_ACTS = [['data-chat', 'send', 'al.sendChat'], ['data-edit', 'pen', 'count.edit'], ['data-refund', 'undo', 'receipt.refundShort'], ['data-print', 'print', 'receipt.printShort'],
  ['data-share', 'share', 'cd.share'], ['data-xp', 'download', 'xp.title'], ['data-del', 'trash', 'common.delete'], ['data-del-r', 'trash', 'common.delete']];
function footActionsToHead(backdrop) {
  const foot = $('.modal-foot', backdrop);
  const head = $$('.modal-head, .sheet-head', backdrop).find(h => h.style.display !== 'none');
  if (!foot || !head || $('.cd-icons', head)) return;
  const icons = [];
  for (const [attr, ic, label] of HEAD_ACTS) {
    const b = foot.querySelector(`[${attr}]`);
    if (!b) continue;
    const red = attr.startsWith('data-del');
    icons.push(`<button type="button" class="cd-ic ${red ? 'red' : ''}" ${attr}${b.getAttribute(attr) ? `="${esc(b.getAttribute(attr))}"` : ''} title="${esc(t(label))}" aria-label="${esc(t(label))}">${thinIcon(ic)}</button>`);
    b.remove();
  }
  if (!icons.length) return;
  head.classList.add('cd-head');
  if (!$('.sheet-title', head)) { const h2 = $('h2', head); if (h2) h2.classList.add('sheet-title'); }
  head.insertAdjacentHTML('beforeend', `<div class="cd-icons">${icons.join('')}</div>`);
  const row = $('.foot-row', foot);
  if (row) row.style.setProperty('--n', row.children.length || 1);
  if (!foot.textContent.trim() && !foot.querySelector('button, input, select')) foot.remove();
}
// Janelas com uma tabela de dados ganham, no título, os mesmos ícones do balanço:
// Filtrar (procurar nas linhas), Selecionar, Enviar (rascunho do chat) e Exportar.
const tblText = el => (el ? el.textContent.replace(/\s+/g, ' ').trim() : '');
const tblNorm = x => x.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
// Ícones do topo das janelas: a ordem escolhida (tocar e manter e arrastar) vale para todas.
function sortIcons(root) {
  $$('.cd-icons', root).forEach(box => {
    const kids = [...box.children].filter(x => x.classList.contains('cd-ic'));
    if (kids.length < 2) return;
    kids.forEach(x => { if (!x.dataset.ik) x.dataset.ik = Object.keys(x.dataset).find(k => k !== 'ik') || x.title || ''; });
    byLayout(kids, 'order.icons', x => x.dataset.ik).forEach(x => box.appendChild(x));
    if (box.dataset.sortable) return;
    box.dataset.sortable = '1';
    makeSortable(box, '.cd-ic', 'data-ik', ids => {
      const old = Layout.get('order.icons') || [];
      const full = [...old, ...ids.filter(i => !old.includes(i))];
      Layout.set('order.icons', mergeOrder(full, ids));
    });
  });
}
// Sem permissão para partilhar (ver relatórios e balanço / confirmar o fecho): na Gestão de stock
// não aparecem Enviar, Copiar nem Exportar (botões grandes, ícones e rodapés).
const SHARE_SEL = '#exp, #sx, .stock-xp, [data-cbxp], [data-sb-xp], #sup-xp, [data-xp], [data-txp], [data-tsend], [data-send]';
function shareGate(root) {
  if (canShare()) return;
  const r = currentRoute && currentRoute();
  if (!r || r.group !== 'stock') return;
  $$(SHARE_SEL, root).forEach(x => { x.hidden = true; x.style.display = 'none'; });
}
// Páginas da Gestão de stock: cartões grandes e tabelas mudam de lugar com tocar e manter numa
// parte vazia (não nas linhas de produtos, que servem para selecionar). A ordem fica guardada.
function pageBlocks(main) {
  const page = $('.page', main) || main;
  const isBlock = x => x.matches && x.matches('.card, .table-wrap, .kpis, .stat-rows, section, .sup-card, .cb-card, .grid-2') && !x.matches('.cnt-tabs, .notice, .page-head');
  const blocks = [...page.children].filter(isBlock);
  if (blocks.length < 2) return;
  const sig = x => `${x.tagName}.${x.classList[0] || ''}:${tblText($('h2, h3, h4, .k-label, thead th', x)).slice(0, 24)}`;
  const used = {};
  blocks.forEach(x => { let k = sig(x); used[k] = (used[k] || 0) + 1; if (used[k] > 1) k += `#${used[k]}`; x.dataset.blk = k; });
  const key = `blk.${(tblText($('#view-title')) || location.hash).slice(0, 30)}`;
  const slots = blocks.map(x => { const c = document.createComment('blk'); x.before(c); return c; });
  byLayout(blocks, key, x => x.dataset.blk).forEach((x, i) => slots[i].after(x));
  slots.forEach(c => c.remove());
  makeSortable(page, '[data-blk]', 'data-blk', ids => Layout.set(key, ids), 'tbody tr, [data-kid], button, a, input, select, textarea, .tt-ctx');
}
// Tabelas que recebem os ícones: com 2+ linhas e sem campos para escrever.
const TT_SKIP = 'table.summary, table.cbd-sum, table.bp-tbl';
const ttOk = tb => tb && !tb.matches(TT_SKIP) && tb.tBodies[0] && tb.tBodies[0].rows.length >= 2 && !tb.querySelector('tbody input, tbody select') && !tb.closest('.tt-done-skip');
function tableTools(backdrop) {
  if (!document.body.contains(backdrop) || $('[data-tsend]', backdrop) || $('[data-sel]', backdrop) || $('[data-cdf]', backdrop) || $('[data-send]', backdrop)) return; // o balanço tem os seus
  const pick = () => $$('.modal-body table', backdrop).find(ttOk);
  if (!pick()) return;
  const head = $$('.modal-head, .sheet-head', backdrop).find(h => h.style.display !== 'none');
  if (!head) return;
  head.classList.add('cd-head');
  if (!$('.sheet-title', head)) { const h2 = $('h2', head); if (h2) h2.classList.add('sheet-title'); }
  let box = $('.cd-icons', head);
  if (!box) { head.insertAdjacentHTML('beforeend', '<div class="cd-icons"></div>'); box = $('.cd-icons', head); }
  const title = () => tblText($('.sheet-title', head) || $('h2', head)) || ($('.modal', backdrop).getAttribute('aria-label') || '');
  // Tabela aberta a partir do chat: sem Filtrar (quem recebe não vê nem mexe no filtro de quem enviou).
  attachTableTools({ root: backdrop, box, pick, title, hasXp: !!$('[data-xp]', backdrop), noFilter: !!$('.tc-from', backdrop) });
}
// Páginas da Gestão de stock: uma barra fina com os mesmos ícones por cima de cada tabela.
// Páginas da Gestão de stock: a tabela fica igual. Tocar e manter num produto seleciona-o
// (a linha fica verde) e o topo da app mostra as ações; tocar fora da tabela limpa.
function pageTableTools(main) {
  $$('table', main).filter(ttOk).forEach(tb => {
    if (tb.dataset.tt) return;
    tb.dataset.tt = '1';
    let h = null, el = tb.closest('.table-wrap') || tb;
    while (el && !h) { let q = el.previousElementSibling; while (q && !h) { if (/^H[1-4]$/.test(q.tagName) || q.classList.contains('sx-gt')) h = q; else { const z = $$('h2, h3, h4, .sx-gt', q).pop(); if (z) h = z; } q = q.previousElementSibling; } el = el.parentElement; if (el === main) break; }
    const name = tblText(h) || tblText($('#view-title'));
    attachTableTools({ root: tb, box: null, pick: () => (document.body.contains(tb) ? tb : null), title: () => name, hasXp: false, modal: null });
  });
}
function attachTableTools({ root, box, pick, title, hasXp, noFilter }) {
  const btn = (k, ic, label) => `<button type="button" class="cd-ic" data-${k} title="${esc(t(label))}" aria-label="${esc(t(label))}">${thinIcon(ic)}</button>`;
  const share = canShare();
  if (box) box.insertAdjacentHTML('afterbegin', (noFilter ? '' : btn('tflt', 'filter', 'flt.title')) + (share ? btn('tsend', 'send', 'al.sendChat') + (hasXp ? '' : btn('txp', 'download', 'xp.title')) : ''));
  const st = { q: '', ids: new Set(), hide: new Set() };
  const rows = () => { const tb = pick(); return tb ? [...tb.tBodies[0].rows] : []; };
  const visible = () => rows().filter(r => !r.hidden);
  const allCols = () => { const tb = pick(); return tb && tb.tHead ? [...tb.tHead.rows[0].cells].map(tblText) : []; };
  // Colunas escolhidas no Filtrar (só muda o que se vê, envia e exporta; os dados não mudam).
  const keep = (arr, n) => (st.hide.size && arr.length === n ? arr.filter((_, i) => !st.hide.has(i)) : arr);
  const cols = () => { const c = allCols(); return keep(c, c.length); };
  const cells = r => { const n = allCols().length; return keep([...r.cells].map(tblText), n); };
  const applyCols = () => {
    const tb = pick(); if (!tb) return;
    const n = allCols().length;
    [...tb.rows].forEach(r => { if (r.cells.length === n) [...r.cells].forEach((c, i) => { c.style.display = st.hide.has(i) ? 'none' : ''; }); });
    if (box && $('[data-tflt]', box)) $('[data-tflt]', box).classList.toggle('on', !!(st.q.trim() || st.hide.size));
  };
  const chosen = () => { const v = visible(); return st.ids.size ? v.filter(r => st.ids.has(r)) : v; };
  const applyQ = () => {
    const q = tblNorm(st.q.trim());
    rows().forEach(r => { r.hidden = !!q && !tblNorm(tblText(r)).includes(q); });
    if (box && $('[data-tflt]', box)) $('[data-tflt]', box).classList.toggle('on', !!(q || st.hide.size));
  };
  // Mensagem: título (e o filtro) a negrito; uma linha por produto.
  const message = () => {
    const c = cols();
    const lines = chosen().map(r => {
      const cl = cells(r);
      const first = cl.shift();
      const rest = cl.map((v, i) => (v && v !== '—' ? (c[i + 1] ? `${c[i + 1]} ${v}` : v) : '')).filter(Boolean);
      return rest.length ? `${first}: ${rest.join(' · ')}` : first;
    });
    const ttl = String(title()).toUpperCase(); // sem mostrar o filtro aplicado
    const ft = totals(), c2 = cols();
    const tl = ft ? ft.slice(1).map((v, i) => (v ? `${c2[i + 1] || ''} ${v}`.trim() : '')).filter(Boolean).join(' · ') : '';
    return [`*${ttl}*`, ...lines, ...(tl ? [`*${ft[0] || t('totals.total')}: ${tl}*`] : [])].join('\n');
  };
  // Linha de total: soma das colunas numéricas sobre as linhas escolhidas (se a tabela tinha total).
  const numOf = v => { const x = String(v || '').replace(/[^\d,.−-]/g, '').replace(/−/g, '-'); if (!/\d/.test(x)) return null; const n = Number(x.replace(/\s/g, '').replace(/\.(?=\d{3}(\D|$))/g, '').replace(',', '.')); return Number.isFinite(n) ? n : null; };
  const fmtLike = (n, ref) => { const r = String(ref || ''); const dec = /,\d{2}\b/.test(r) ? 2 : 0; let out = n.toLocaleString('pt-PT', { minimumFractionDigits: dec, maximumFractionDigits: dec }).replace(/\u00a0|\u202f/g, ' '); if (/^\+/.test(r) && n > 0) out = `+${out}`; const suf = r.replace(/^[\s\d,.+−-]+/, '').trim(); return suf && !/^\d/.test(suf) ? `${out} ${suf}` : out; };
  const totals = () => {
    const tb = pick(); if (!tb || !tb.tFoot || !tb.tFoot.rows[0]) return null;
    const n = allCols().length;
    // Cada célula do total vai para a sua coluna (uma célula larga conta para a última que ocupa).
    const fr = Array(n).fill('');
    let at = 0;
    [...tb.tFoot.rows[0].cells].forEach(cell => { const sp = cell.colSpan || 1, txt = tblText(cell); const k = at === 0 ? 0 : Math.min(n - 1, at + sp - 1); if (k < n) fr[k] = txt; at += sp; });
    const list = chosen(), all = !st.ids.size && !st.q.trim() && visible().length === rows().length;
    const out = fr.map((txt, i) => {
      if (all || i === 0) return i === 0 ? (txt.replace(/\(.*\)/, '').trim() || t('totals.total')) : txt;
      if (numOf(txt) == null) return '';
      const vals = list.map(r => numOf(tblText(r.cells[i])));
      if (vals.some(x => x == null && x !== 0)) return '';
      return fmtLike(Math.round(vals.reduce((a, x) => a + (x || 0), 0) * 100) / 100, txt);
    });
    return keep(out, n);
  };
  const card = () => {
    const c = cols(), list = chosen().map(cells);
    const w = Math.max(c.length, list[0] ? list[0].length : 0);
    const full = c.length ? c : Array.from({ length: w }, (_, i) => `#${i + 1}`);
    const pk = full.length <= 4 ? full.map((_, i) => i) : [0, full.length - 3, full.length - 2, full.length - 1];
    return { v: 1, type: 'snap', title: title(), sub: '',
      cols: pk.map(i => full[i]), rows: list.slice(0, 4).map(r => pk.map(i => (r[i] || '').slice(0, 40))), more: Math.max(0, list.length - 4),
      snap: { cols: full, rows: list.slice(0, 200).map(r => r.map(x => x.slice(0, 80))), foot: totals() } };
  };
  const send = () => { if (!chosen().length) { toast(t('cd.nothing'), true); return; } sendTableToChat(card(), message()); };
  const exportIt = () => {
    const tb = pick(); if (!tb) return;
    const c = cols(), list = chosen().map(cells);
    const foot = totals();
    const name = title();
    exportModal({ title: name, subtitle: '', file: name.toLowerCase().replace(/[^a-z0-9]+/gi, '_').slice(0, 40) || 'stoi', notes: [],
      columns: c.length ? c : list[0].map((_, i) => `#${i + 1}`), numeric: [], rows: list, totals: foot && foot.length === c.length ? foot : null, text: () => message().replace(/\*/g, '') });
  };
  const copy = async () => { const txt = message().replace(/\*/g, ''); try { await navigator.clipboard.writeText(txt); toast(t('tt.copied')); } catch (e) { toast(t('tt.copyFail'), true); } };
  if (box) {
    // Filtrar: escolher as colunas que aparecem (e que vão para o chat e para o ficheiro) e procurar.
    if ($('[data-tflt]', box)) $('[data-tflt]', box).onclick = () => openFilter();
  }
  function openFilter() {
    {
      const tb = pick(); if (!tb) return;
      const wrap = tb.closest('.table-wrap') || tb;
      // Se a tabela é um bloco que muda de lugar, o painel vai dentro dele (para mudar junto).
      const inBlk = !!(wrap.dataset && wrap.dataset.blk);
      // Um só painel por tabela: tocar outra vez no Filtrar fecha-o.
      let f = inBlk ? wrap.querySelector(':scope > .tt-flt') : (wrap.previousElementSibling && wrap.previousElementSibling.classList.contains('tt-flt') ? wrap.previousElementSibling : null);
      if (f) { f.remove(); return; } // fecha o painel; as colunas escolhidas ficam
      const c = allCols();
      wrap.insertAdjacentHTML(inBlk ? 'afterbegin' : 'beforebegin', `<div class="tt-flt"><div class="tt-flt-h">${esc(t('tt.cols'))}</div>
        <div class="tt-cols">${c.map((n, i) => `<button type="button" class="${st.hide.has(i) ? '' : 'on'}" data-col="${i}">${esc(n || `#${i + 1}`)}</button>`).join('')}</div>
        <div class="tbl-q">${icon('search')}<input class="input" placeholder="${esc(t('tbl.search'))}" value="${esc(st.q)}"></div></div>`);
      f = inBlk ? wrap.querySelector(':scope > .tt-flt') : wrap.previousElementSibling;
      $$('[data-col]', f).forEach(b => b.addEventListener('click', () => {
        const i = Number(b.dataset.col);
        if (!st.hide.has(i) && c.length - st.hide.size <= 1) { toast(t('tt.oneCol'), true); return; } // fica pelo menos uma
        if (st.hide.has(i)) st.hide.delete(i); else st.hide.add(i);
        b.classList.toggle('on', !st.hide.has(i)); applyCols();
      }));
      const inp = $('input', f);
      inp.addEventListener('input', () => { st.q = inp.value; applyQ(); });
    }
  }
  if (box) {
    if ($('[data-tsend]', box)) $('[data-tsend]', box).onclick = send;
    const xp = $('[data-txp]', box); if (xp) xp.onclick = exportIt;
  }
  // ----- Seleção: tocar e manter pinta a linha; depois cada toque junta ou tira; tocar fora limpa -----
  const ctx = () => document.getElementById('tt-ctx');
  const paint = () => {
    rows().forEach(r => r.classList.toggle('tt-sel', st.ids.has(r)));
    const n = st.ids.size;
    if (box) { // janela: número de selecionados no ícone Enviar
      const b = $('[data-tsend]', box) || document.createElement('i'); let badge = $('.cd-n', b);
      if (n) { if (!badge) { b.insertAdjacentHTML('beforeend', '<i class="cd-n"></i>'); badge = $('.cd-n', b); } badge.textContent = n; } else if (badge) badge.remove();
      return;
    }
    // página: o topo da app mostra as ações enquanto houver selecionados
    let bar = ctx();
    if (!n) { if (bar) bar.remove(); return; }
    if (!bar) {
      $('.topbar').insertAdjacentHTML('beforeend', `<div id="tt-ctx" class="tt-ctx"><button type="button" data-x aria-label="${esc(t('common.close'))}">${thinIcon('x')}</button><b></b>
        <button type="button" data-f title="${esc(t('flt.title'))}">${thinIcon('filter')}</button><button type="button" data-s title="${esc(t('al.sendChat'))}">${thinIcon('send')}</button><button type="button" data-c title="${esc(t('tt.copy'))}">${thinIcon('copy')}</button><button type="button" data-e title="${esc(t('xp.title'))}">${thinIcon('download')}</button></div>`);
      bar = ctx();
      $('[data-x]', bar).onclick = () => clear();
      $('[data-s]', bar).onclick = send; $('[data-c]', bar).onclick = copy; $('[data-e]', bar).onclick = exportIt; $('[data-f]', bar).onclick = openFilter;
    }
    const all = visible().length && visible().every(r => st.ids.has(r));
    $('b', bar).textContent = all ? t('tt.selAll', { n }) : t(n === 1 ? 'tt.sel1' : 'tt.selN', { n });
  };
  const clear = () => { st.ids.clear(); paint(); window.ttClear = null; };
  const tb0 = pick(); if (!tb0 || !share) return;
  let timer = null, sx = 0, sy = 0, picked = false, upAt = 0;
  const swallow = () => picked && Date.now() - upAt < 400; // o clique do próprio "tocar e manter"
  tb0.addEventListener('pointerdown', e => {
    const r = e.target.closest('tbody tr'); if (!r || !rows().includes(r)) return;
    sx = e.clientX; sy = e.clientY; clearTimeout(timer);
    timer = setTimeout(() => {
      timer = null; picked = true;
      if (!st.ids.size) window.ttClear = clear;
      if (st.ids.has(r)) st.ids.delete(r); else st.ids.add(r);
      if (navigator.vibrate) navigator.vibrate(18);
      paint();
    }, 480);
  });
  tb0.addEventListener('pointermove', e => { if (timer && Math.hypot(e.clientX - sx, e.clientY - sy) > 10) { clearTimeout(timer); timer = null; } });
  ['pointerup', 'pointercancel', 'pointerleave'].forEach(ev => tb0.addEventListener(ev, () => { clearTimeout(timer); timer = null; if (ev === 'pointerup') upAt = Date.now(); }));
  tb0.addEventListener('pointerdown', () => { if (!timer) return; picked = false; }, true);
  tb0.addEventListener('contextmenu', e => { if (e.target.closest('tbody tr')) e.preventDefault(); });
  // Tocar no cabeçalho da tabela: seleciona tudo (outra vez: limpa).
  if (tb0.tHead) tb0.tHead.addEventListener('click', e => {
    if (e.defaultPrevented) return;
    const v = visible();
    if (v.length && v.every(r => st.ids.has(r))) { clear(); return; }
    v.forEach(r => st.ids.add(r)); window.ttClear = clear; paint();
  });
  root.addEventListener('click', e => {
    const r = e.target.closest('tbody tr');
    if (swallow()) { picked = false; e.stopPropagation(); e.preventDefault(); return; } // o toque que acabou de selecionar
    if (!st.ids.size || !r || !rows().includes(r)) return;
    e.stopPropagation(); e.preventDefault(); // a selecionar, tocar na linha não abre o detalhe
    if (st.ids.has(r)) st.ids.delete(r); else st.ids.add(r);
    paint(); if (!st.ids.size) window.ttClear = null;
  }, true);
  // tocar fora da tabela (e fora das ações) limpa a seleção
  const outside = e => {
    const tb = pick();
    if (!tb) { document.removeEventListener('click', outside, true); return; }
    if (!st.ids.size || tb.contains(e.target) || (ctx() && ctx().contains(e.target)) || (box && box.contains(e.target)) || (!box && e.target.closest('#modal-root'))) return;
    if (swallow()) return;
    clear();
  };
  document.addEventListener('click', outside, true);
  tb0.dataset.ttOwn = '1';
}
// Arrastar a janela para baixo para fechar (pelo tracinho, pelo título ou pelo conteúdo já no topo).
function sheetSwipe(backdrop, dismiss) {
  const sheet = $('.modal', backdrop);
  const body = $('.modal-body', sheet);
  let y0 = null, dy = 0, fromBody = false;
  const start = e => {
    const tgt = e.target;
    if (tgt.closest('input, textarea, select')) return;
    fromBody = !!tgt.closest('.modal-body');
    if (fromBody && body.scrollTop > 0) return;
    y0 = (e.touches ? e.touches[0] : e).clientY; dy = 0;
    sheet.style.transition = 'none';
  };
  const move = e => {
    if (y0 == null) return;
    dy = (e.touches ? e.touches[0] : e).clientY - y0;
    if (dy <= 0) { sheet.style.transform = ''; if (fromBody) y0 = null; return; }
    if (fromBody && body.scrollTop > 0) { y0 = null; sheet.style.transform = ''; return; }
    sheet.style.transform = `translateY(${dy}px)`;
    if (e.cancelable && dy > 6) e.preventDefault();
  };
  const end = () => {
    if (y0 == null) return;
    y0 = null;
    sheet.style.transition = 'transform .18s ease-out';
    if (dy > Math.min(120, sheet.offsetHeight * 0.25)) {
      sheet.style.transform = 'translateY(100%)';
      setTimeout(dismiss, 160);
    } else sheet.style.transform = '';
  };
  sheet.addEventListener('touchstart', start, { passive: true });
  sheet.addEventListener('touchmove', move, { passive: false });
  sheet.addEventListener('touchend', end);
  sheet.addEventListener('touchcancel', end);
  // Rato (computador): só pelo tracinho e pelo título.
  $$('.sheet-handle, .modal-head, .sheet-head', sheet).forEach(h => h.addEventListener('mousedown', e => {
    start(e);
    const mm = ev => move(ev), mu = () => { end(); window.removeEventListener('mousemove', mm); window.removeEventListener('mouseup', mu); };
    window.addEventListener('mousemove', mm); window.addEventListener('mouseup', mu);
  }));
}
// Fecha o menu lateral e aplica os dados que chegaram enquanto estava aberto.
function closeNav() { $('#app').classList.remove('nav-open'); if (App.stale) setTimeout(refreshView, 0); }
function closeModal() { $('#modal-root').innerHTML = ''; if (App.stale) setTimeout(refreshView, 0); }

// Redesenha o ecrã atual com os dados novos (de outro dispositivo), mantendo a posição.
// Se houver uma janela aberta ou o utilizador estiver a escrever, espera até acabar.
function refreshView() {
  if (!App.user) return;
  const active = document.activeElement;
  const typing = active && /INPUT|TEXTAREA|SELECT/.test(active.tagName) && $('#main').contains(active);
  // Também espera com o menu aberto: redesenhar fechava o menu sozinho a cada sincronização.
  if (typing || $('#modal-root').innerHTML || $('#app').classList.contains('nav-open')) { App.stale = true; return; }
  App.stale = false;
  const main = $('#main'), y = window.scrollY, my = main.scrollTop;
  const before = $$('.num', main).map(el => el.textContent);
  renderShell(); render();
  window.scrollTo(0, y); main.scrollTop = my;
  flashChanged(before);
}
// Números que mudaram depois de redesenhar: piscam a amarelo um instante.
function flashChanged(before) {
  const now = $$('.num', $('#main'));
  if (!before.length || now.length !== before.length) return 0;
  let n = 0;
  now.forEach((el, i) => { if (el.textContent !== before[i]) { el.classList.remove('chg-flash'); void el.offsetWidth; el.classList.add('chg-flash'); n++; } });
  return n;
}

// Puxar para baixo no topo da página: atualiza (vai buscar à nuvem e refaz as contas).
// O ícone sai de baixo do cabeçalho e o conteúdo desce só o espaço do ícone. No chat não
// (aí puxar serve para ver mensagens antigas).
function initPullRefresh() {
  const main = $('#main');
  const ptr = document.createElement('div');
  ptr.id = 'ptr';
  ptr.innerHTML = `<i class="ptr-ic">${icon('refresh')}</i><i class="ptr-spin"></i>`;
  document.body.appendChild(ptr);
  const MAX = 30, GO = 26;
  let y0 = null, d = 0, busy = false;
  // Não atualiza quando o dedo está numa janela/painel por cima (conta das vendas, folhas, menu).
  const blocked = t0 => busy || location.hash === '#chat' || $('#modal-root').innerHTML || $('#app').classList.contains('nav-open') || !App.user
    || document.querySelector('.pos.show-ticket, #ginfo') || (t0 && t0.closest && t0.closest('.ticket, .ticket-scrim, .modal-backdrop, .sheet, [class*="-sheet"]'));
  const set = px => {
    main.style.transform = px ? `translateY(${px}px)` : '';
    ptr.style.opacity = px ? Math.min(1, px / GO) : 0;
    ptr.querySelector('.ptr-ic').style.transform = `rotate(${px * 8}deg)`;
  };
  main.addEventListener('touchstart', e => { y0 = !blocked(e.target) && main.scrollTop <= 0 && e.touches.length === 1 ? e.touches[0].clientY : null; d = 0; }, { passive: true });
  main.addEventListener('touchmove', e => {
    if (y0 == null) return;
    const dy = e.touches[0].clientY - y0;
    if (dy <= 0) { d = 0; set(0); return; }
    d = Math.min(MAX, dy * 0.4);
    main.style.transition = 'none';
    set(d);
  }, { passive: true });
  main.addEventListener('touchend', async () => {
    if (y0 == null) return;
    y0 = null;
    main.style.transition = 'transform .2s ease';
    if (d < GO) { set(0); return; }
    busy = true;
    set(MAX);
    ptr.classList.add('on');
    try { if (Sync.enabled()) await Sync.syncNow(); } catch (e) { /* sem rede: refaz só as contas daqui */ }
    const before = $$('.num', main).map(el => el.textContent);
    App.stale = false;
    renderShell(); render();
    const n = flashChanged(before);
    ptr.classList.remove('on');
    set(0);
    busy = false;
    toast(t(n ? 'ptr.done' : 'ptr.same'));
  });
}
document.addEventListener('keydown', e => { if (e.key === 'Escape' && $('#modal-root').innerHTML) closeModal(); });

// O X de uma janela passa a fazer outra coisa (ex.: voltar à janela anterior em vez de fechar tudo).
function onModalClose(m, fn) {
  const x = $('.modal-head [data-close], .sheet-head [data-close]', m);
  if (!x) return;
  const nx = x.cloneNode(true);
  x.replaceWith(nx);
  nx.addEventListener('click', fn);
}

function confirmDialog(message, okLabel, danger = false) {
  return new Promise(resolve => {
    const m = openModal({
      title: t('common.confirmTitle'),
      body: `<p>${esc(message)}</p>`,
      footer: `<button class="btn ${danger ? 'danger' : 'primary'}" data-yes>${esc(okLabel || t('common.confirm'))}</button>`,
    });
    $('[data-yes]', m).onclick = () => { closeModal(); resolve(true); };
    // Fechar no X (ou tocar fora) responde "não".
    onModalClose(m, () => { closeModal(); resolve(false); });
    m.addEventListener('mousedown', e => { if (e.target === m) resolve(false); });
  });
}

const formObj = form => Object.fromEntries(new FormData(form).entries());
const errText = e => t(e && e.message ? e.message : String(e));

function guard(fn) {
  try { return fn(); } catch (e) { toast(errText(e), true); return undefined; }
}

function langOptions(selected) {
  return Object.entries(LANGS).map(([k, v]) => `<option value="${k}" ${k === selected ? 'selected' : ''}>${esc(v)}</option>`).join('');
}

// ================= Sessão / navegação =================

function showLogin() {
  App.user = null;
  try { sessionStorage.removeItem('stoi-user'); } catch (e) { /* ignorar */ }
  closeModal();
  $('#app').hidden = true;
  const el = $('#login');
  el.hidden = false;
  let pin = '';
  const onlyDefault = Store.data.employees.length === 1 && Store.data.employees[0].pin === '0000';
  el.innerHTML = `
    <div class="login-card">
      <img src="icons/icon.svg" alt="">
      <h2>${esc(Store.settings.storeName)}</h2>
      <div class="muted small">${esc(t('login.enterPin'))}</div>
      <div class="pin-dots" id="pin-dots">${'<span></span>'.repeat(4)}</div>
      <div class="pinpad">
        ${[1, 2, 3, 4, 5, 6, 7, 8, 9].map(n => `<button data-k="${n}">${n}</button>`).join('')}
        <button data-k="c" aria-label="${esc(t('login.clear'))}">C</button><button data-k="0">0</button><button data-k="b" aria-label="${esc(t('login.backspace'))}">⌫</button>
      </div>
      ${onlyDefault ? `<p class="muted small" style="margin-top:16px">${t('login.defaultPin', { pin: '<b>0000</b>' })}</p>` : ''}
      <label class="login-lang"><span class="muted small">${esc(t('settings.language'))}</span>
        <select class="input" id="login-lang">${langOptions(getLang())}</select></label>
    </div>`;
  const dots = $('#pin-dots', el);
  const paint = () => $$('span', dots).forEach((s, i) => s.classList.toggle('on', i < pin.length));
  const press = k => {
    if (k === 'c') pin = '';
    else if (k === 'b') pin = pin.slice(0, -1);
    else if (pin.length < 4) pin += k;
    paint();
    if (pin.length === 4) {
      const emp = Store.data.employees.find(e => e.pin === pin);
      if (emp) { document.removeEventListener('keydown', onKey); login(emp); }
      else {
        dots.classList.add('shake');
        setTimeout(() => { dots.classList.remove('shake'); pin = ''; paint(); }, 380);
      }
    }
  };
  const onKey = e => {
    if (e.target && e.target.tagName === 'SELECT') return;
    if (/^\d$/.test(e.key)) press(e.key);
    else if (e.key === 'Backspace') press('b');
  };
  $$('.pinpad button', el).forEach(b => b.addEventListener('click', () => press(b.dataset.k)));
  $('#login-lang', el).addEventListener('change', e => {
    document.removeEventListener('keydown', onKey);
    setLang(e.target.value);
    showLogin();
  });
  document.addEventListener('keydown', onKey);
}

function login(emp) {
  App.user = emp;
  try { sessionStorage.setItem('stoi-user', emp.id); } catch (e) { /* ignorar */ }
  $('#login').hidden = true;
  $('#app').hidden = false;
  renderShell();
  const route = currentRoute();
  if (!routeOk(route, emp)) location.hash = '#' + ((allowedRoutes()[0] || {}).id || 'chat');
  else render();
}

function routeOk(r, e = App.user) { return !!e && r.roles.includes(e.role) && (!r.perm || e.role === 'owner' || r.perm(e)); }
function allowedRoutes() { return ROUTES.filter(r => routeOk(r)); }
function currentRoute() {
  const id = location.hash.replace('#', '') || 'vendas';
  return ROUTES.find(r => r.id === id) || ROUTES[0];
}

function renderShell() {
  document.documentElement.lang = getLang();
  compactFmt = null;
  $('#sidebar').innerHTML = `
    <div class="brand"><img src="icons/icon.svg" alt=""><span>Stoi</span></div>
    ${Store.settings.storeName && !['Stoi', 'Stoi POS'].includes(Store.settings.storeName) ? `<div class="brand-store">${esc(Store.settings.storeName)}</div>` : ''}
    ${byLayout(allowedRoutes().filter(r => !r.hidden), 'order.menu').map(r => `<a href="#${r.id}" data-route="${r.id}" draggable="false">${icon(r.icon)}<span>${esc(t(r.label))}</span></a>`).join('')}
    <div class="spacer"></div>
    <div class="side-acct"><div class="side-acct-row"><button id="sync-badge" class="side-sync" type="button"></button><button class="side-out" id="lock-btn" type="button" title="${esc(t('common.lock'))}">${icon('logout')}<span class="out-short">${esc(t('common.lockShort'))}</span><span class="out-long">${esc(t('common.lock'))}</span></button></div></div>
    <div class="footer">${esc(App.user.name)} · ${esc(roleLabel(App.user.role))}</div>`;
  $('#user-name').textContent = `${App.user.name} · ${roleLabel(App.user.role)}`;
  $('#lock-btn').addEventListener('click', showLogin);
  // Cabeçalho: Relatórios e, por último à direita, o carrinho (abre a conta da venda).
  const calc = $('#top-calc');
  calc.innerHTML = icon('calc'); calc.title = t('calc.title'); calc.setAttribute('aria-label', t('calc.title'));
  calc.onclick = () => changeCalcModal();
  const rep = $('#top-reports');
  rep.innerHTML = icon('chart'); rep.title = t('nav.reports'); rep.setAttribute('aria-label', t('nav.reports'));
  rep.onclick = () => { location.hash = '#relatorios'; };
  const cart = $('#top-cart');
  cart.title = t('ticket.title'); cart.setAttribute('aria-label', t('ticket.title'));
  cart.onclick = () => {
    if ((location.hash || '#vendas') === '#vendas' && $('#pos')) toggleTicket(!App.showTicket);
    else { App.showTicket = true; location.hash = '#vendas'; }
  };
  paintCartBadge();
  const side = $('#sidebar');
  if (!side.dataset.sortable) {
    side.dataset.sortable = '1';
    makeSortable(side, 'a[data-route]', 'data-route', ids => Layout.set('order.menu', ids));
  }
  paintSyncBadge();
  Sync.who = App.user.name;
  if (typeof paintBell === 'function') paintBell();
  if (typeof Chat !== 'undefined') { Chat.start(); Chat.paintBadges(); }
}

// Título do cabeçalho: mostra o texto inteiro, reduzindo a letra se não couber.
// Página dentro de outra (secção das Configurações, Balanço): no cabeçalho, a seta "‹" fica no
// lugar do menu e o título passa a ser o nome da página.
let MENU_SVG = '';
const setBack = (title, fn) => { App.back = { title, fn }; };
function paintBack() {
  const b = $('#menu-btn');
  if (!b) return;
  const on = !!App.back;
  $('#app').classList.toggle('has-back', on);
  if (MENU_SVG) b.innerHTML = on ? '<svg viewBox="0 0 24 24"><path d="M15.4 7.4 14 6l-6 6 6 6 1.4-1.4-4.6-4.6z"/></svg>' : MENU_SVG;
  b.setAttribute('aria-label', on ? t('common.back') : 'Menu');
  if (on) setTitle(App.back.title);
  if (typeof Chat !== 'undefined') Chat.paintBadges();
}

// Botão/gesto "voltar" do Android (chamado pela parte nativa). Devolve true se a app tratou;
// false quando já não há para onde voltar (a app vai então para segundo plano).
window.stoiBack = () => {
  if (window.ttClear) { window.ttClear(); return true; }
  const iv = document.querySelector('.iv');
  if (iv) { if (iv.ivClose) iv.ivClose(); else iv.remove(); return true; }
  const x = $('#modal-root [data-close]');
  if (x) { x.click(); return true; }
  const app = $('#app');
  if (!App.user || !app || app.hidden) return false;
  if (app.classList.contains('nav-open')) { closeNav(); return true; }
  if (App.showTicket && $('#pos')) { toggleTicket(false); return true; }
  if (App.back) { App.back.fn(); return true; }
  if (currentRoute().id !== 'vendas') {
    if (history.length > 1) history.back(); else location.hash = '#vendas';
    return true;
  }
  return false;
};

function setTitle(text) {
  const h = $('#view-title');
  h.textContent = text;
  h.style.fontSize = '';
  fitTitle(h);
  requestAnimationFrame(() => fitTitle(h));
}
function fitTitle(h = $('#view-title')) {
  if (!h || !h.clientWidth) return;
  h.style.fontSize = '';
  let size = parseFloat(getComputedStyle(h).fontSize);
  while (h.scrollWidth > h.clientWidth && size > 11) { size -= 0.5; h.style.fontSize = size + 'px'; }
}

// Tamanho do texto (por dispositivo).
const FONT_SIZES = [['s', 0.9], ['m', 1], ['l', 1.15], ['xl', 1.3]];
function applyFontSize() {
  const k = Layout.get('fontSize') || 's';
  const f = (FONT_SIZES.find(x => x[0] === k) || FONT_SIZES[0])[1];
  document.documentElement.style.setProperty('--fs', f);
}

function paintCartBadge() {
  const cart = $('#top-cart');
  if (!cart) return;
  const n = App.ticket ? round2(App.ticket.lines.reduce((a, l) => a + l.qty, 0)) : 0;
  cart.innerHTML = `${icon('cart')}${n ? `<span class="cart-count">${esc(fmtQty(n))}</span>` : ''}`;
}

function paintSyncBadge() {
  // Fundo do menu: na mesma linha, o estado da nuvem (toque = sincronizar) e Sair.
  const b = $('#sync-badge');
  if (!b) return;
  const solo = !Sync.enabled(); // sem conta na nuvem: só o Sair, por extenso
  b.hidden = solo; b.parentNode.classList.toggle('solo', solo);
  if (solo) return;
  const s = Sync.status;
  const pending = Sync.pendingCount();
  const label = s === 'syncing' ? t('cloud.syncing') : s === 'offline' ? t('cloud.offline') : s === 'error' ? t('cloud.error') : pending ? t('cloud.pending', { n: pending }) : t('cloud.synced');
  b.className = `side-sync ${s === 'offline' || s === 'error' ? 'warn' : ''}`;
  b.innerHTML = `<i class="sync-pill">${icon(s === 'offline' || s === 'error' ? 'cloudOff' : 'cloud')}${esc(label)}</i>`;
  b.title = label;
}

// Venda à consignação: sem custos, margens nem lucro; as diferenças valem ao preço de venda.
const CONSIGN = () => !!Store.settings.consignment;
// Preço de custo, margens e lucro: só aparecem se ligados nas Configurações.
const NOCOST = () => !Store.showCost();
const unitValue = x => (NOCOST() ? x.price || 0 : x.cost || 0);
// Unidades em stock por categoria (ex.: Por Caixa 45 · A Garrafa 120 · Por Lâmina 30), por baixo do total.
function stockByCatRows(cats = []) {
  const groups = new Map();
  for (const i of Store.data.items) {
    if (!i.trackStock || !(i.stock > 0)) continue;
    const k = catKey(i);
    if (cats.length && !cats.includes(k)) continue;
    groups.set(k, round2((groups.get(k) || 0) + i.stock));
  }
  return [...groups.entries()].map(([k, n]) => [k === 'none' ? t('items.noCategory') : Store.find('categories', k).name, n])
    .sort((a, b) => a[0].localeCompare(b[0], 'pt'))
    .map(([name, n]) => `<div class="s-row sub-row"><span>${esc(name)}</span><span class="num">${fmtQty(n)}</span></div>`).join('');
}
// ================= Organização do ecrã (em cada telemóvel) =================
// Ordem e escolha de cartões, painéis, produtos nas Vendas, categorias e menu. Fica só neste telemóvel.
const Layout = {
  KEY: 'stoi-layout',
  data: null,
  all() { if (!this.data) { try { this.data = JSON.parse(localStorage.getItem(this.KEY)) || {}; } catch (e) { this.data = {}; } } return this.data; },
  get(k) { return this.all()[k] || null; },
  set(k, v) { this.all()[k] = v; try { localStorage.setItem(this.KEY, JSON.stringify(this.data)); } catch (e) { /* ignorar */ } },
};
// Ordena uma lista pela ordem guardada (os que não estão na ordem ficam no fim, como estavam).
function byLayout(list, key, idOf = x => x.id) {
  const order = Layout.get(key);
  if (!order) return list;
  const pos = new Map(order.map((id, i) => [id, i]));
  return list.map((x, i) => [x, pos.has(idOf(x)) ? pos.get(idOf(x)) : 1e6 + i]).sort((a, b) => a[1] - b[1]).map(x => x[0]);
}

// Nova ordem de uma parte da lista (ex.: só os produtos visíveis) dentro da ordem completa.
function mergeOrder(fullIds, newVisible) {
  const set = new Set(newVisible);
  let k = 0;
  return fullIds.map(id => (set.has(id) ? newVisible[k++] : id));
}

// Arrastar para ordenar: tocar e segurar (ou clicar e segurar) e depois arrastar.
// onOrder recebe os ids pela nova ordem. Um toque normal continua a funcionar.
function makeSortable(container, itemSel, idAttr, onOrder, skip = '') {
  if (!container) return;
  let timer = null, drag = null, sx = 0, sy = 0;
  const items = () => [...container.querySelectorAll(itemSel)].filter(x => x.parentNode === (drag ? drag.item.parentNode : x.parentNode));
  const stop = () => { clearTimeout(timer); timer = null; };
  container.addEventListener('pointerdown', e => {
    const item = e.target.closest(itemSel);
    if (!item || !container.contains(item) || e.target.closest('input, select, textarea') || e.button > 0) return;
    if (skip && e.target.closest(skip)) return;
    if (item.querySelector && item.querySelector('tr.tt-sel')) return; // com linhas selecionadas, o quadro não se move
    sx = e.clientX; sy = e.clientY;
    stop();
    timer = setTimeout(() => {
      drag = { item, pid: e.pointerId };
      item.classList.add('dragging'); container.classList.add('sorting');
      if (navigator.vibrate) navigator.vibrate(15);
    }, e.pointerType === 'mouse' ? 250 : 450);
  });
  container.addEventListener('pointermove', e => {
    if (!drag) { if (timer && Math.hypot(e.clientX - sx, e.clientY - sy) > 10) stop(); return; }
    e.preventDefault();
    const el = document.elementFromPoint(e.clientX, e.clientY);
    const over = el && el.closest(itemSel);
    if (!over || over === drag.item || over.parentNode !== drag.item.parentNode) return;
    const list = items();
    const before = list.indexOf(over) < list.indexOf(drag.item);
    over.parentNode.insertBefore(drag.item, before ? over : over.nextSibling);
  });
  const end = () => {
    stop();
    if (!drag) return;
    const { item } = drag;
    item.classList.remove('dragging'); container.classList.remove('sorting');
    drag = null;
    // O toque que acabou o arrasto não deve contar como clique.
    const swallow = ev => { if (item.contains(ev.target)) { ev.stopPropagation(); ev.preventDefault(); } };
    window.addEventListener('click', swallow, { capture: true, once: true });
    setTimeout(() => window.removeEventListener('click', swallow, { capture: true }), 400);
    onOrder(items().map(x => x.getAttribute(idAttr)));
  };
  container.addEventListener('pointerup', end);
  container.addEventListener('pointercancel', end);
  // Durante o arrasto não deixa a página deslizar nem abrir o menu do toque longo.
  container.addEventListener('touchmove', e => { if (drag) e.preventDefault(); }, { passive: false });
  container.addEventListener('contextmenu', e => { if (drag || timer) e.preventDefault(); });
}

// Painéis (cartões grandes) que se podem reordenar: filhos com data-sec dentro do contentor.
function arrangeSections(container, key) {
  if (!container) return;
  const kids = [...container.children].filter(x => x.dataset && x.dataset.sec);
  byLayout(kids, key, x => x.dataset.sec).forEach(x => container.appendChild(x));
  makeSortable(container, '[data-sec]', 'data-sec', ids => Layout.set(key, ids));
}

// Cartões do topo: mostra só os escolhidos (por defeito, defaults), pela ordem guardada, e deixa arrastar.
// A escolha dos cartões fica dentro do filtro de cada página (secção "Cartões").
function arrangeKpis(root, page, defaults) {
  const box = root && root.querySelector(`[data-kpis="${page}"]`);
  if (!box) return;
  const all = [...box.querySelectorAll('[data-kid]')];
  const labels = all.map(x => ({ id: x.dataset.kid, name: (x.querySelector('.k-label') || x).textContent.trim() }));
  const key = `kpi.${page}`;
  App.kpiInfo = App.kpiInfo || {};
  App.kpiInfo[page] = { labels, defaults };
  const chosen = (Layout.get(key) || defaults).filter(id => all.some(x => x.dataset.kid === id));
  all.forEach(x => { if (!chosen.includes(x.dataset.kid)) x.remove(); });
  chosen.forEach(id => box.appendChild(all.find(x => x.dataset.kid === id)));
  box.hidden = !chosen.length;
  makeSortable(box, '[data-kid]', 'data-kid', ids => Layout.set(key, ids));
}

// Secção "Cartões" dentro de um filtro: escolher que cartões aparecem no topo da página.
function cardsSectionHtml(page) {
  const info = App.kpiInfo && App.kpiInfo[page];
  if (!info) return '';
  const chosen = (Layout.get(`kpi.${page}`) || info.defaults).filter(id => info.labels.some(o => o.id === id));
  const list = [...chosen.map(id => info.labels.find(o => o.id === id)), ...info.labels.filter(o => !chosen.includes(o.id))];
  return `<h4 class="pick-sec">${esc(t('kpi.cards'))}</h4>
    <div class="cards-pick">${list.map(o => `<label class="check cat-check"><input type="checkbox" data-card="${esc(o.id)}" ${chosen.includes(o.id) ? 'checked' : ''}> ${esc(o.name)}</label>`).join('')}</div>`;
}
// Guarda os cartões marcados (os que já estavam mantêm a ordem; os novos vão para o fim).
function saveCardsSection(m, page) {
  const info = App.kpiInfo && App.kpiInfo[page];
  const boxes = $$('[data-card]', m);
  if (!info || !boxes.length) return;
  const on = boxes.filter(b => b.checked).map(b => b.dataset.card);
  const prev = (Layout.get(`kpi.${page}`) || info.defaults).filter(id => on.includes(id));
  Layout.set(`kpi.${page}`, [...prev, ...on.filter(id => !prev.includes(id))]);
}

// Nome do produto com a categoria quando há outro igual noutra categoria (ex.: "Gold (lâmina)").
const dn = i => Store.displayName(i);
const nameOf = (id, fallback) => { const i = Store.find('items', id); return i ? dn(i) : fallback; };
const catLabelOf = i => { const c = i && i.categoryId && Store.find('categories', i.categoryId); return c ? c.name : t('items.noCategory'); };
const countDiffValue = c => round2(c.lines.reduce((a, l) => a + (l.diff || 0) * unitValue(l), 0));
const diffValueLabel = () => t(NOCOST() ? 'count.diffValueSale' : 'count.diffValue');

function render() {
  if (!App.user) return;
  document.body.classList.toggle('consign', CONSIGN());
  document.body.classList.toggle('no-cost', NOCOST());
  setTermOverrides(Store.settings.terms);
  const route = currentRoute();
  if (!routeOk(route)) { location.hash = '#' + ((allowedRoutes()[0] || {}).id || 'chat'); return; }
  $$('#sidebar a').forEach(a => a.classList.toggle('active', a.dataset.route === (route.group || route.id)));
  const bellEl = $('#top-bell');
  if (bellEl && bellEl.closest('#top-tabs')) { $('.topbar-right').insertBefore(bellEl, $('#top-calc')); bellEl.removeAttribute('data-tk'); }
  $('#top-tabs').innerHTML = '';
  $('#main').classList.toggle('gestao', route.group === 'stock');
  setTitle(t(route.group && !route.ownTitle ? (route.group === 'stock' ? 'nav.stock' : 'nav.sales') : route.label));
  // Relatórios e carrinho só nas páginas de Vendas (Vender, Clientes, Relatórios).
  const inSales = route.id === 'vendas' || route.group === 'vendas';
  $('#top-cart').hidden = !inSales;
  // Relatórios é agora um separador de Vendas (Vender · Clientes · Relatórios).
  $('#top-reports').hidden = true;
  $('#top-calc').hidden = !inSales;
  $('#top-chat').hidden = true;
  if (typeof Chat !== 'undefined' && Chat.hideTop) Chat.hideTop();
  $('#app').classList.toggle('in-chat', route.id === 'chat'); // no chat não aparece o sino dos alertas
  $('#app').classList.remove('nav-open');
  const main = $('#main');
  main.scrollTop = 0;
  main.classList.remove('flush');
  App.back = null;
  if (route.id !== 'vendas') App.daySales = false;
  route.view(main);
  if (route.group === 'stock') setTimeout(() => { pageTableTools(main); pageBlocks(main); shareGate(main); }, 0);
  if (['itens', 'stock', 'categorias'].includes(route.id)) addStockTabs(main, route.id);
  if (route.id === 'clientes' || route.id === 'relatorios') {
    // Clientes é um separador de Vendas: mantém os mesmos indicadores e separadores no topo.
    const pg = $('.page', main);
    if (pg) { pg.insertAdjacentHTML('afterbegin', `<div class="sales-head"><div class="pos-kpis" id="pos-kpis"></div>${salesTabs(route.id)}</div>`); bindSalesTabs(pg); paintPosKpis(); }
  }
  paintSyncBadge();
  paintBack();
}

// ================= Vendas =================

// Separadores de Vendas: Vender · Clientes.
function salesTabs(active) {
  const tabs = [['vendas', 'cart', 'sales.tabSell'], ['clientes', 'people', 'nav.customers']];
  if (allowedRoutes().some(r => r.id === 'relatorios')) tabs.push(['relatorios', 'chart', 'nav.reports']);
  return `<div class="seg bal-tabs sales-tabs" role="tablist">${tabs.map(([k, ic, label]) =>
    `<button role="tab" data-sv="${k}" class="${active === k ? 'active' : ''}" aria-selected="${active === k}">${icon(ic)}<span>${esc(t(label))}</span></button>`).join('')}</div>`;
}
function bindSalesTabs(root) {
  $$('[data-sv]', root).forEach(b => b.addEventListener('click', () => { location.hash = `#${b.dataset.sv}`; }));
}

function saveTicket() { try { localStorage.setItem('stoi-ticket', JSON.stringify(App.ticket)); } catch (e) { /* ignorar */ } }
function loadTicket() {
  try { App.ticket = JSON.parse(localStorage.getItem('stoi-ticket')) || newTicket(); }
  catch (e) { App.ticket = newTicket(); }
}

function addToTicket(item, qty = 1) {
  const tk = App.ticket;
  const line = tk.lines.find(l => l.itemId === item.id && l.price === item.price);
  if (line) line.qty = round2(line.qty + qty);
  else tk.lines.push({ itemId: item.id, name: dn(item), price: item.price, cost: item.cost || 0, qty, categoryId: item.categoryId || null });
  saveTicket();
  if (item.trackStock) {
    const inTicket = tk.lines.filter(l => l.itemId === item.id).reduce((a, l) => a + l.qty, 0);
    // Conta também as lâminas que se podem tirar das caixas ligadas.
    const fromBoxes = Store.data.items.filter(b => b.opensInto === item.id && b.trackStock && b.stock > 0).reduce((a, b) => a + Math.floor(b.stock) * (Number(b.opensQty) || 1), 0);
    if (inTicket > item.stock + fromBoxes) toast(t('sales.lowStockWarn', { item: item.name, n: fmtQty(round2(item.stock + fromBoxes)) }), true);
  }
}

function viewSales(main) {
  if (App.daySales) { daySalesPage(main); return; }
  if (Store.settings.useShifts && !Store.currentShift()) {
    main.innerHTML = `
      <div class="page"><div class="card card-pad empty">
        <h3>${esc(t('sales.noShiftTitle'))}</h3>
        <p>${esc(t('sales.noShiftText'))}</p>
        <a class="btn primary" href="#turnos">${esc(t('shift.open'))}</a>
      </div></div>`;
    return;
  }
  main.innerHTML = `
    <div class="pos ${App.showTicket ? 'show-ticket' : ''}" id="pos">
      <section class="catalog">
        <div class="pos-kpis" id="pos-kpis"></div>
        ${salesTabs('vendas')}
        <div class="catalog-bar">
          <input id="pos-search" class="input" type="search" placeholder="${esc(t('stock.searchPlaceholder'))}" title="${esc(t('sales.searchPlaceholder'))}" autocomplete="off" value="${esc(App.posSearch)}">
          <button id="pos-cat" class="btn pos-cat" title="${esc(t('items.category'))}">${icon('layers')}<span></span></button>
        </div>
        <div class="item-grid" id="pos-grid"></div>
      </section>
      <div class="ticket-scrim" id="ticket-scrim"></div>
      <aside class="ticket" id="ticket"></aside>
    </div>`;
  bindSalesTabs(main);
  // Telemóvel: tocar fora da conta (na parte escurecida) fecha-a.
  $('#ticket-scrim', main).addEventListener('click', () => toggleTicket(false));
  bindTicketSwipe($('#ticket', main));
  const search = $('#pos-search');
  search.addEventListener('input', () => { App.posSearch = search.value; renderGrid(); });
  search.addEventListener('keydown', e => {
    if (e.key !== 'Enter') return;
    const it = Store.findByCode(search.value);
    if (it && isSoldOut(it)) { toast(t('pos.cantSellOut', { item: it.name }), true); return; }
    if (it) {
      addToTicket(it);
      App.posSearch = search.value = '';
      renderGrid(); renderTicket();
      toast(t('sales.added', { item: it.name }));
    } else {
      const list = filteredSaleItems();
      if (list.length === 1) {
        addToTicket(list[0]);
        App.posSearch = search.value = '';
        renderGrid(); renderTicket();
      } else if (!list.length) toast(t('sales.itemNotFound'), true);
    }
  });
  renderCats(); renderGrid(); renderTicket();
}

// Telemóvel: arrastar a conta para baixo fecha-a (a partir do topo do painel,
// ou da lista quando já está no início).
function bindTicketSwipe(el) {
  let y0 = null, dy = 0, t0 = 0;
  el.addEventListener('touchstart', e => {
    if (!$('#pos') || !$('#pos').classList.contains('show-ticket') || getComputedStyle(el).position !== 'fixed') return;
    const top = el.getBoundingClientRect().top, y = e.touches[0].clientY;
    const lines = $('.lines', el);
    const inHead = y - top < 80;
    const inList = lines && lines.contains(e.target) && lines.scrollTop <= 0;
    if (!inHead && !inList) return;
    y0 = y; dy = 0; t0 = Date.now();
  }, { passive: true });
  el.addEventListener('touchmove', e => {
    if (y0 == null) return;
    dy = e.touches[0].clientY - y0;
    if (dy <= 0) { el.style.transform = ''; return; }
    e.preventDefault();
    el.style.transition = 'none';
    el.style.transform = `translateY(${dy}px)`;
  }, { passive: false });
  const end = () => {
    if (y0 == null) return;
    const fast = dy > 40 && Date.now() - t0 < 250;
    el.style.transition = ''; el.style.transform = '';
    if (dy > 90 || fast) toggleTicket(false);
    y0 = null; dy = 0;
  };
  el.addEventListener('touchend', end);
  el.addEventListener('touchcancel', end);
}

function toggleTicket(show) {
  App.showTicket = show;
  const pos = $('#pos');
  if (pos) pos.classList.toggle('show-ticket', show);
}

// Seletor de categoria ao lado da pesquisa (toca-se e escolhe-se da lista).
function renderCats() {
  const el = $('#pos-cat');
  const hasNone = Store.data.items.some(i => catKey(i) === 'none');
  const soldOut = Store.data.items.filter(isSoldOut).length;
  App.posCats = validCats(App.posCats);
  if (!soldOut) App.posOut = false;
  const label = [App.posCats.length ? catLabel(App.posCats, false, '') : '', App.posOut ? t('sales.soldOut') : ''].filter(Boolean).join(' · ') || t('stock.allCats');
  $('span', el).textContent = label;
  el.classList.toggle('filtered', !!(App.posCats.length || App.posOut));
  el.onclick = () => multiPickModal({
    title: t('items.category'), allLabel: t('stock.allCats'), options: catOptions(hasNone), selected: App.posCats,
    extras: soldOut ? [{ id: 'out', name: t('sales.soldOutN', { n: soldOut }) }] : [], extraSelected: App.posOut ? ['out'] : [],
    onApply: (v, x) => { App.posCats = v; App.posOut = x.includes('out'); renderCats(); renderGrid(); },
  });
}

// Produtos com controlo de stock e stock 0 (ou menos) não aparecem na venda; ficam em "Esgotados".
const isSoldOut = i => i.trackStock && i.stock <= 0 && !Store.packSource(i.id);

function filteredSaleItems() {
  const q = App.posSearch.trim().toLowerCase();
  const cats = App.posCats;
  // Por nome, ou pela ordem que se arrastou neste telemóvel.
  return byLayout(Store.data.items
    .filter(i => (App.posOut ? isSoldOut(i) : !isSoldOut(i)))
    .filter(i => !cats.length || cats.includes(catKey(i)))
    .filter(i => !q || i.name.toLowerCase().includes(q) || i.barcode === q || i.sku === q)
    .sort((a, b) => a.name.localeCompare(b.name, 'pt')), 'order.pos');
}

function renderGrid() {
  const el = $('#pos-grid');
  const items = filteredSaleItems();
  if (!items.length && !App.posOut && App.posSearch.trim()) {
    const q = App.posSearch.trim().toLowerCase();
    const out = Store.data.items.filter(i => isSoldOut(i) && i.name.toLowerCase().includes(q));
    if (out.length) {
      el.innerHTML = `<div class="empty" style="grid-column:1/-1">${esc(t('sales.onlySoldOut', { names: out.slice(0, 3).map(i => i.name).join(', ') }))}<br><button class="btn small" id="see-out" style="margin-top:10px">${esc(t('sales.seeSoldOut'))}</button></div>`;
      $('#see-out').onclick = () => { App.posOut = true; App.posCats = []; renderCats(); renderGrid(); };
      return;
    }
  }
  if (!items.length) {
    el.innerHTML = `<div class="empty" style="grid-column:1/-1">${Store.data.items.length ? esc(t('sales.noItemsFound')) : `${esc(t('sales.noItemsYet'))} <a href="#itens">${esc(t('sales.createItems'))}</a>`}</div>`;
    return;
  }
  el.innerHTML = items.map(tileHtml).join('');
  $$('.tile', el).forEach(b => b.addEventListener('click', () => tapTile(b)));
  // Tocar, segurar e arrastar um produto muda a sua posição (guardada neste telemóvel).
  if (!el.dataset.sortable) {
    el.dataset.sortable = '1';
    makeSortable(el, '.tile', 'data-id', ids => {
      const full = byLayout(Store.data.items.slice().sort((a, b) => a.name.localeCompare(b.name, 'pt')), 'order.pos').map(i => i.id);
      Layout.set('order.pos', mergeOrder(full, ids));
    });
  }
  paintSelection();
}

// Estado de stock com os valores reais (lâminas a zero com caixas fechadas continuam vendáveis).
function stockState(i) {
  if (!i.trackStock) return null;
  const n = round2(i.stock);
  if (n <= 0) {
    const fromBoxes = Store.data.items.filter(b => b.opensInto === i.id && b.trackStock && b.stock > 0)
      .reduce((a, b) => a + Math.floor(b.stock) * (Number(b.opensQty) || 1), 0);
    return fromBoxes > 0 ? { k: 'pack', text: t('pos.fromBox', { n: fmtQty(fromBoxes) }) } : { k: 'out', text: t('pos.soldOut') };
  }
  if (n <= (i.lowStock || 0)) return { k: 'low', text: t('pos.low', { n: fmtQty(n) }) };
  return { k: 'ok', text: t('pos.inStock', { n: fmtQty(n) }) };
}

// Miniatura do produto: a imagem, ou as iniciais na cor do produto.

// ================= Ícones de produtos (garrafas, latas, caixas...) =================
// Desenhos em SVG; a faixa do rótulo usa currentColor (a cor da categoria).
const PICONS = (() => {
  let uid = 0;
  const GLASS = {
    amber: ['#3f1f07', '#7a4012', '#c27a34', '#5b2d0b'], green: ['#0b2e17', '#1b6331', '#5cbf78', '#123f22'],
    clear: ['#9fb0ba', '#dde6eb', '#ffffff', '#b2c1c9'], wine: ['#14060a', '#3a0e1b', '#7a2a3f', '#22070f'],
    white: ['#6f7d3c', '#b9c67a', '#eef4c6', '#8d9a52'], whisky: ['#6b3206', '#c47019', '#f2b65e', '#8f480c'],
    gin: ['#5f97ab', '#b3dcea', '#f4fbff', '#7fb5c8'], cream: ['#2e1a0b', '#5e3a1c', '#9a6a40', '#3b2210'],
    cola: ['#1c0b05', '#4a1d0c', '#8c3d1c', '#2a1007'], water: ['#7fb6d6', '#cfe8f6', '#ffffff', '#9cc8e2'],
  };
  const grad = (g, id) => `<linearGradient id="${id}" x1="0" x2="1" y1="0" y2="0"><stop offset="0" stop-color="${g[0]}"/><stop offset=".28" stop-color="${g[1]}"/><stop offset=".45" stop-color="${g[2]}"/><stop offset=".72" stop-color="${g[1]}"/><stop offset="1" stop-color="${g[3]}"/></linearGradient>`;
  const shadow = w => `<ellipse cx="24" cy="77" rx="${w}" ry="2" fill="#000" opacity=".16"/>`;
  const path = ({ nw, top, nh, sh, bw, br = 3, bottom = 75, square = false }) => {
    const c = 24, y1 = top + nh, y2 = y1 + sh;
    const sL = square ? `C ${c - nw} ${y1 + sh * .2}, ${c - bw} ${y1 + sh * .15}, ${c - bw} ${y2}` : `C ${c - nw} ${y1 + sh * .55}, ${c - bw} ${y1 + sh * .35}, ${c - bw} ${y2}`;
    const sR = square ? `C ${c + bw} ${y1 + sh * .15}, ${c + nw} ${y1 + sh * .2}, ${c + nw} ${y1}` : `C ${c + bw} ${y1 + sh * .35}, ${c + nw} ${y1 + sh * .55}, ${c + nw} ${y1}`;
    return `M ${c - nw} ${top} L ${c - nw} ${y1} ${sL} L ${c - bw} ${bottom - br} Q ${c - bw} ${bottom} ${c - bw + br} ${bottom} L ${c + bw - br} ${bottom} Q ${c + bw} ${bottom} ${c + bw} ${bottom - br} L ${c + bw} ${y2} ${sR} L ${c + nw} ${top} Z`;
  };
  const bottle = (o, wrap = true) => {
    const id = 'pi' + (++uid), g = GLASS[o.glass], p = path(o), y2 = o.top + o.nh + o.sh, bottom = o.bottom || 75;
    const w = o.nw * 2;
    const cap = o.cap === 'foil' ? `<path d="M ${24 - o.nw - .6} ${o.top - 1} h ${w + 1.2} v ${o.foil || 14} h ${-(w + 1.2)} z" fill="${o.capColor}"/><rect x="${24 - o.nw - .6}" y="${o.top + (o.foil || 14) - 3}" width="${w + 1.2}" height="1.4" fill="#fff" opacity=".35"/>`
      : o.cap === 'screw' ? `<rect x="${24 - o.nw - 1}" y="${o.top - 4}" width="${w + 2}" height="6" rx="1" fill="${o.capColor}"/>`
        : o.cap === 'cork' ? `<rect x="${24 - o.nw - 1.6}" y="${o.top - 5}" width="${w + 3.2}" height="5.5" rx="1.5" fill="#2b1a10"/><rect x="${24 - o.nw - 1.6}" y="${o.top - 5}" width="${w + 3.2}" height="1.6" rx=".8" fill="#c9a227"/>`
          : `<rect x="${24 - o.nw - 1}" y="${o.top - 2.5}" width="${w + 2}" height="3.6" rx="1" fill="${o.capColor}"/>`;
    const lb = o.label;
    const label = lb ? `<rect x="${24 - o.bw}" y="${lb.y}" width="${o.bw * 2}" height="${lb.h}" fill="${lb.bg || '#fdfaf2'}"/><rect x="${24 - o.bw}" y="${lb.y}" width="${o.bw * 2}" height="${Math.max(2.5, lb.h * .2)}" fill="currentColor"/><rect x="${24 - o.bw * .6}" y="${lb.y + lb.h * .45}" width="${o.bw * 1.2}" height="${Math.max(1.6, lb.h * .12)}" rx="1" fill="currentColor" opacity=".85"/><rect x="${24 - o.bw * .42}" y="${lb.y + lb.h * .68}" width="${o.bw * .84}" height="1.3" rx=".6" fill="#000" opacity=".25"/>` : '';
    const liquid = o.liquid ? `<rect x="${24 - o.bw + .8}" y="${o.liquid}" width="${o.bw * 2 - 1.6}" height="${bottom - o.liquid - 1}" rx="2" fill="${o.liquidColor}" opacity=".85"/>` : '';
    const body = `<defs>${grad(g, id)}<linearGradient id="n${id}" gradientUnits="userSpaceOnUse" x1="${24 - o.nw}" x2="${24 + o.nw}" y1="0" y2="0"><stop offset="0" stop-color="${g[0]}"/><stop offset=".38" stop-color="${g[2]}"/><stop offset=".6" stop-color="${g[1]}"/><stop offset="1" stop-color="${g[3]}"/></linearGradient><clipPath id="c${id}"><path d="${p}"/></clipPath></defs>
      <path d="${p}" fill="url(#${id})"/><g clip-path="url(#c${id})"><rect x="${24 - o.nw}" y="${o.top}" width="${w}" height="${o.nh + o.sh * .25}" fill="url(#n${id})"/>${liquid}${label}
      <rect x="${24 - o.bw + 2}" y="${y2 + 2}" width="2.2" height="${bottom - y2 - 6}" rx="1.1" fill="#fff" opacity=".45"/></g>
      <path d="${p}" fill="none" stroke="#000" stroke-opacity=".18" stroke-width=".6"/>${cap}`;
    return wrap ? `<svg viewBox="0 0 48 80" aria-hidden="true">${shadow(o.bw + 2)}${body}</svg>` : body;
  };
  const can = (tall = false) => {
    const id = 'pi' + (++uid), x0 = 13, x1 = 35, b = 75, t = tall ? 6 : 12;
    const shape = `M ${x0 + 1.5} ${t + 3} L ${x1 - 1.5} ${t + 3} L ${x1} ${t + 7} L ${x1} ${b - 4} L ${x1 - 1.5} ${b} L ${x0 + 1.5} ${b} L ${x0} ${b - 4} L ${x0} ${t + 7} Z`;
    return `<svg viewBox="0 0 48 80" aria-hidden="true"><defs><linearGradient id="${id}" x1="0" x2="1"><stop offset="0" stop-color="#000" stop-opacity=".35"/><stop offset=".3" stop-color="#fff" stop-opacity="0"/><stop offset=".42" stop-color="#fff" stop-opacity=".45"/><stop offset=".55" stop-color="#fff" stop-opacity="0"/><stop offset="1" stop-color="#000" stop-opacity=".4"/></linearGradient><linearGradient id="m${id}" x1="0" x2="1"><stop offset="0" stop-color="#8d969e"/><stop offset=".45" stop-color="#eef1f4"/><stop offset="1" stop-color="#7c858d"/></linearGradient></defs>${shadow(12)}
      <path d="${shape}" fill="currentColor"/><rect x="${x0}" y="${t + 16}" width="${x1 - x0}" height="${tall ? 30 : 22}" fill="#fff" opacity=".9"/><rect x="${x0 + 4}" y="${t + 21}" width="${x1 - x0 - 8}" height="4" rx="2" fill="currentColor"/><rect x="${x0 + 6}" y="${t + 28}" width="${x1 - x0 - 12}" height="1.6" rx=".8" fill="#000" opacity=".25"/>
      <path d="${shape}" fill="url(#${id})"/><path d="M ${x0 + 1.5} ${t + 3} L ${x1 - 1.5} ${t + 3} L ${x1 - 2.5} ${t} L ${x0 + 2.5} ${t} Z" fill="url(#m${id})"/><rect x="${x0 + 1.5}" y="${b - 1.5}" width="${x1 - x0 - 3}" height="1.5" fill="#aab2b9"/></svg>`;
  };
  const crate = () => {
    const id = 'pi' + (++uid);
    const tops = [10, 18, 26, 34].map(x => `<rect x="${x - 2}" y="18" width="4" height="12" rx="1.5" fill="#4a250b"/><rect x="${x - 2.4}" y="15.5" width="4.8" height="3" rx="1" fill="#c9a227"/>`).join('');
    return `<svg viewBox="0 0 48 80" aria-hidden="true"><defs><linearGradient id="${id}" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stop-color="#d9a066"/><stop offset="1" stop-color="#a86b34"/></linearGradient></defs>${shadow(20)}${tops}
      <path d="M4 28 h40 v44 a3 3 0 0 1 -3 3 H7 a3 3 0 0 1 -3 -3z" fill="url(#${id})"/><rect x="4" y="28" width="40" height="5" fill="#000" opacity=".18"/><rect x="18" y="35" width="12" height="4" rx="2" fill="#5b3415" opacity=".75"/>
      <rect x="10" y="45" width="28" height="18" rx="1.5" fill="#fdfaf2"/><rect x="10" y="45" width="28" height="4" fill="currentColor"/><rect x="15" y="53" width="18" height="2.6" rx="1.3" fill="currentColor" opacity=".85"/><rect x="18" y="58" width="12" height="1.4" rx=".7" fill="#000" opacity=".25"/></svg>`;
  };
  const pack = () => {
    const one = () => bottle({ glass: 'amber', nw: 2.2, top: 20, nh: 9, sh: 8, bw: 4.6, bottom: 74, cap: 'crown', capColor: '#c9a227' }, false);
    return `<svg viewBox="0 0 48 80" aria-hidden="true">${shadow(21)}<g transform="translate(-14 0)">${one()}</g><g>${one()}</g><g transform="translate(14 0)">${one()}</g>
      <path d="M3 44 h42 v28 a3 3 0 0 1 -3 3 H6 a3 3 0 0 1 -3 -3z" fill="#fff" opacity=".22"/><rect x="3" y="48" width="42" height="13" rx="1.5" fill="#fdfaf2" opacity=".95"/><rect x="3" y="48" width="42" height="3.4" fill="currentColor"/><rect x="12" y="54" width="24" height="2.6" rx="1.3" fill="currentColor" opacity=".85"/></svg>`;
  };
  // Estilo "plano colorido" para caixas e lâminas (viewBox 100×100; a etiqueta usa a cor da categoria).
  const bSil = (cx, top, cut, w, fill) => `<path d="M ${cx - 2.6} ${top + 2} h 5.2 v 9 c 0 3 ${w - 2.6} 4 ${w - 2.6} 10 V ${cut} H ${cx - w} V ${top + 21} c 0 -6 ${w - 2.6} -7 ${w - 2.6} -10 z" fill="${fill}"/><rect x="${cx - 3.4}" y="${top}" width="6.8" height="3" rx="1" fill="${fill}"/>`;
  const flatBox = () => `<svg viewBox="3 14 94 78" aria-hidden="true"><path d="M14 52 L5 38 H21 L28 52z" fill="#f4b860"/><path d="M86 52 L95 38 H79 L72 52z" fill="#e0993c"/>
    ${[27, 42, 57, 72].map(x => `${bSil(x, 20, 54, 6.6, '#8d4a12')}<rect x="${x - 6.6}" y="40" width="13.2" height="7" fill="#fff"/><rect x="${x - 6.6}" y="40" width="13.2" height="2.4" fill="currentColor"/>`).join('')}
    <rect x="14" y="52" width="72" height="36" rx="3" fill="#f0a94a"/><rect x="14" y="52" width="13" height="36" rx="3" fill="#d98f30"/>
    <rect x="56" y="68" width="24" height="12" rx="2" fill="#fff"/><rect x="56" y="68" width="24" height="4" rx="1.5" fill="currentColor"/></svg>`;
  const flatPack = () => `<svg viewBox="20 5 60 86" aria-hidden="true"><path d="M24 54 L30 12 Q31 8 35 8 H65 Q69 8 70 12 L76 54z" fill="#f0a94a"/><rect x="40" y="15" width="20" height="8" rx="4" fill="#fff"/>
    ${[37, 50, 63].map(x => bSil(x, 28, 56, 6, '#8d4a12')).join('')}
    <rect x="24" y="54" width="52" height="34" rx="3" fill="currentColor"/><rect x="32" y="63" width="36" height="15" rx="2" fill="#fff"/><rect x="37" y="68.5" width="26" height="3.2" rx="1.6" fill="currentColor"/></svg>`;
  return {
    'caixa-plano': flatBox,
    'lamina-plano': flatPack,
    'cerveja': () => bottle({ glass: 'amber', nw: 3, top: 8, nh: 20, sh: 12, bw: 8.5, cap: 'crown', capColor: '#c9a227', label: { y: 48, h: 16 } }),
    'cerveja-verde': () => bottle({ glass: 'green', nw: 3, top: 8, nh: 20, sh: 12, bw: 8.5, cap: 'crown', capColor: '#d7dbe0', label: { y: 48, h: 16 } }),
    'cerveja-curta': () => bottle({ glass: 'amber', nw: 3.4, top: 22, nh: 9, sh: 10, bw: 10, cap: 'crown', capColor: '#c9a227', label: { y: 50, h: 15 } }),
    'miniatura': () => bottle({ glass: 'clear', nw: 2.6, top: 30, nh: 8, sh: 7, bw: 7, cap: 'screw', capColor: '#c9a227', liquid: 52, liquidColor: '#c87a22', label: { y: 56, h: 12 } }),
    'lata': () => can(false),
    'lata-alta': () => can(true),
    'vinho': () => bottle({ glass: 'wine', nw: 3.2, top: 6, nh: 22, sh: 9, bw: 9, cap: 'foil', capColor: '#7a1022', foil: 15, label: { y: 46, h: 18, bg: '#f5eedc' } }),
    'vinho-branco': () => bottle({ glass: 'white', nw: 3.2, top: 6, nh: 22, sh: 9, bw: 9, cap: 'foil', capColor: '#c9a227', foil: 15, label: { y: 46, h: 18, bg: '#fffdf5' } }),
    'espumante': () => bottle({ glass: 'green', nw: 3.6, top: 6, nh: 18, sh: 14, bw: 10, cap: 'foil', capColor: '#d4af37', foil: 20, label: { y: 50, h: 15, bg: '#fffaf0' } }),
    'whisky': () => bottle({ glass: 'whisky', nw: 3.2, top: 10, nh: 12, sh: 5, bw: 11, square: true, br: 2, cap: 'cork', label: { y: 40, h: 22, bg: '#111' } }),
    'vodka': () => bottle({ glass: 'clear', nw: 3, top: 6, nh: 16, sh: 10, bw: 9, cap: 'screw', capColor: '#b0b7be', label: { y: 42, h: 20, bg: '#ffffff' } }),
    'gin': () => bottle({ glass: 'gin', nw: 3.4, top: 10, nh: 12, sh: 6, bw: 11, square: true, br: 2, cap: 'cork', label: { y: 42, h: 20, bg: '#fdfaf2' } }),
    'licor': () => bottle({ glass: 'cream', nw: 3, top: 10, nh: 12, sh: 24, bw: 12, br: 8, cap: 'screw', capColor: '#c9a227', label: { y: 46, h: 16, bg: '#f3e6cf' } }),
    'refrigerante': () => bottle({ glass: 'cola', nw: 3.4, top: 8, nh: 10, sh: 12, bw: 9.5, cap: 'screw', capColor: '#c62828', label: { y: 42, h: 14, bg: '#c62828' } }),
    'agua': () => bottle({ glass: 'water', nw: 3.4, top: 8, nh: 8, sh: 12, bw: 9.5, cap: 'screw', capColor: '#1e88e5', label: { y: 44, h: 13, bg: '#e3f2fd' } }),
    'caixa': crate,
    'lamina': pack,
  };
})();
const PICON_KEYS = Object.keys(PICONS);

// Ícone automático pelo nome e pela categoria (quando não foi escolhido nenhum).
function guessIcon(item, cat) {
  const c = String((cat && cat.name) || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
  const n = `${String((item && item.name) || '')} ${c}`.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
  if (/lamina|pack/.test(c) || /lamina/.test(n)) return 'lamina-plano';
  if (/caixa|grade/.test(c)) return 'caixa-plano';
  if (/\blata\b|\bcan\b/.test(n)) return 'lata';
  if (/espumante|champanhe|champagne/.test(n)) return 'espumante';
  if (/vinho branco|white wine/.test(n)) return 'vinho-branco';
  if (/vinho|wine|tinto/.test(n)) return 'vinho';
  if (/whisk/.test(n)) return 'whisky';
  if (/vodka/.test(n)) return 'vodka';
  if (/\bgin\b/.test(n)) return 'gin';
  if (/licor|amarula|creme/.test(n)) return 'licor';
  if (/agua|water/.test(n)) return 'agua';
  if (/refrigerante|coca|cola|fanta|sprite|sumo|soda/.test(n)) return 'refrigerante';
  if (/\bshot\b|mini/.test(n)) return 'miniatura';
  if (/caixa/.test(n)) return 'caixa-plano';
  return 'cerveja';
}
// Ícone de um produto: o do produto, senão o da categoria, senão o automático.
function iconKeyOf(item) {
  const cat = item && item.categoryId && Store.find('categories', item.categoryId);
  const k = (item && item.icon) || (cat && cat.icon) || guessIcon(item, cat);
  return PICONS[k] ? k : 'cerveja';
}
const iconColorOf = item => { const cat = item && item.categoryId && Store.find('categories', item.categoryId); return (cat && cat.color) || (item && item.color) || '#64748b'; };

// Grelha para escolher um ícone (com uma primeira opção "automático"/"da categoria").
function iconPickerModal({ title, current, color, autoLabel, autoKey, onPick }) {
  const cell = (k, label, on) => `<button type="button" class="ip-cell ${on ? 'on' : ''}" data-ik="${esc(k)}" title="${esc(label)}" style="color:${esc(color)}">${PICONS[k === '' ? autoKey : k]()}<span>${esc(label)}</span></button>`;
  const m = openModal({
    title, autofocus: false,
    body: `<div class="ip-grid">${cell('', autoLabel, !current)}${PICON_KEYS.map(k => cell(k, t(`picon.${k}`), current === k)).join('')}</div>`,
  });
  $$('[data-ik]', m).forEach(b => b.addEventListener('click', () => { closeModal(); onPick(b.dataset.ik); }));
}

// Miniatura do produto: a foto, ou o ícone (do produto, da categoria ou automático).
const thumbHtml = (i, cls = 'thumb-sq') => (i && i.image
  ? `<span class="${cls}"><img src="${esc(i.image)}" alt="" loading="lazy" decoding="async"></span>`
  : `<span class="${cls} ico" style="color:${esc(iconColorOf(i))}">${PICONS[iconKeyOf(i)]()}</span>`);

function tileHtml(i) {
  const st = stockState(i);
  return `<button class="tile${st ? ` st-${st.k}` : ''}" data-id="${i.id}">
      <span class="in-qty" hidden></span>
      ${thumbHtml(i)}
      <span class="tile-info">
        <span class="tile-name">${esc(dn(i))}</span>
        <span class="tile-price num">${money(i.price)}</span>
        ${st ? `<span class="tile-badge">${esc(st.text)}</span>` : ''}
      </span>
    </button>`;
}

// Indicadores do topo das vendas: hoje, recibos e conta atual.
function paintPosKpis() {
  const box = $('#pos-kpis');
  if (!box) return;
  const day = new Date(); day.setHours(0, 0, 0, 0);
  const next = new Date(day); next.setDate(day.getDate() + 1);
  const prev = new Date(day); prev.setDate(day.getDate() - 1);
  const r = Store.report(day, next);
  const y = Store.report(prev, day);
  const pct = y.total > 0 ? round2(((r.total - y.total) / y.total) * 100) : null;
  const tk = App.ticket;
  const tot = computeTotals(tk, Store.settings);
  const items = round2(tk.lines.reduce((a, l) => a + l.qty, 0));
  // Valores arredondados e sem moeda, para caberem nos 3 indicadores.
  const short = v => new Intl.NumberFormat('pt-PT', { maximumFractionDigits: 0 }).format(Math.round(v || 0));
  const k = (label, value, sub, cls = '', go = false) => `<div class="pk${go ? ' pk-go' : ''}"${go ? ' role="button" tabindex="0" data-day' : ''}><small>${esc(label)}${go ? ' <em>›</em>' : ''}</small><b class="num">${value}</b><i class="${cls}">${esc(sub)}</i></div>`;
  box.onclick = ev => { if (ev.target.closest('[data-day]')) { App.daySales = true; App.dayHour = null; if (location.hash !== '#vendas') location.hash = '#vendas'; else render(); } };
  box.innerHTML = k(t('pos.kToday'), short(r.total), pct == null ? t('pos.kNoPrev') : t('pos.kVsYesterday', { p: `${pct >= 0 ? '↗' : '↘'} ${fmtQty(Math.abs(pct))}%` }), pct != null && pct < 0 ? 'down' : '', true)
    + k(t('pos.kReceipts'), String(r.salesCount), r.salesCount ? t('pos.kAvg', { v: short(r.average || (r.total / r.salesCount)) }) : '—', 'muted', true)
    + k(t('pos.kTicket'), short(tot.total), t(items === 1 ? 'pos.kItem1' : 'pos.kItems', { n: fmtQty(items) }), 'muted');
}

// "Vendas de hoje": total, gráfico de barras por hora e os recibos do dia.
// Tocar numa barra mostra só os recibos dessa hora; tocar outra vez mostra todos.
function daySalesPage(main) {
  App.back = { title: t('day.title'), fn: () => { App.daySales = false; render(); } };
  const day = new Date(); day.setHours(0, 0, 0, 0);
  const next = new Date(day); next.setDate(day.getDate() + 1);
  const rs = Store.data.receipts.filter(r => { const x = new Date(r.date).getTime(); return x >= day.getTime() && x < next.getTime(); })
    .sort((a, b) => new Date(b.date) - new Date(a.date));
  const val = r => (r.type === 'refund' ? -r.total : r.total);
  const hourOf = r => new Date(r.date).getHours();
  const byH = {};
  rs.forEach(r => { byH[hourOf(r)] = round2((byH[hourOf(r)] || 0) + val(r)); });
  const hs = Object.keys(byH).map(Number);
  const nowH = new Date().getHours();
  const h0 = Math.min(8, ...hs), h1 = Math.max(nowH, 18, ...hs);
  const max = Math.max(1, ...Object.values(byH));
  const total = round2(rs.reduce((a, r) => a + val(r), 0));
  const hh = h => `${String(h).padStart(2, '0')}h`;
  const bars = [];
  for (let h = h0; h <= h1; h++) bars.push(`<button type="button" class="ds-bar${App.dayHour === h ? ' on' : ''}${!(byH[h] > 0) ? ' zero' : ''}" data-h="${h}" aria-label="${hh(h)}"><i style="height:${byH[h] > 0 ? Math.max(4, Math.round(byH[h] / max * 100)) : 0}%"></i></button>`);
  const mid = Math.round((h0 + h1) / 2);
  const list = App.dayHour == null ? rs : rs.filter(r => hourOf(r) === App.dayHour);
  const sel = App.dayHour == null ? null : round2(list.reduce((a, r) => a + val(r), 0));
  main.innerHTML = `
    <div class="page ds-page">
      <div class="card ds-chart">
        <div class="ds-top"><span>${esc(App.dayHour == null ? t('day.total') : t('day.hour', { h: hh(App.dayHour), n: list.length }))}</span><b class="num">${money(sel == null ? total : sel)}</b></div>
        <div class="ds-bars">${bars.join('')}</div>
        <div class="ds-axis"><span>${hh(h0)}</span><span>${hh(mid)}</span><span>${hh(h1)}</span></div>
      </div>
      ${list.length ? `<div class="ds-list">${list.map(r => `<button type="button" class="ds-rec" data-id="${r.id}">
        <span class="ds-l"><b>#${esc(receiptNo(r))} · ${esc(fmtTime(r.date))}</b><small>${esc(empName(r.employeeId))} · ${esc(payLabel(r.payment.type))}</small></span>
        <span class="ds-v num${r.type === 'refund' ? ' neg-val' : ''}">${r.type === 'refund' ? '−' : ''}${money(r.total)}${r.type === 'refund' ? `<small>${esc(t('receipts.refundBadge'))}</small>` : ''}</span>
      </button>`).join('')}</div>` : `<div class="card empty">${esc(t('day.none'))}</div>`}
      <a class="ds-all" href="#recibos">${esc(t('day.all'))} ›</a>
    </div>`;
  $$('.ds-bar', main).forEach(b => b.addEventListener('click', () => { const h = Number(b.dataset.h); App.dayHour = App.dayHour === h ? null : h; daySalesPage(main); }));
  $$('.ds-rec', main).forEach(b => b.addEventListener('click', () => receiptModal(Store.find('receipts', b.dataset.id))));
  paintBack();
}

// Toque num cartão: adiciona 1 à venda. Ignora o segundo toque acidental (menos de 250 ms no mesmo cartão)
// e não deixa vender produtos esgotados.
function tapTile(b) {
  const now = Date.now();
  if (b._lastTap && now - b._lastTap < 250) return;
  b._lastTap = now;
  const item = Store.find('items', b.dataset.id);
  if (!item) return;
  if (isSoldOut(item)) { toast(t('pos.cantSellOut', { item: item.name }), true); return; }
  addToTicket(item);
  renderTicket();
}

// Marca os cartões dos itens que já estão no ticket, com a quantidade.
function paintSelection() {
  const qty = {};
  for (const l of App.ticket.lines) qty[l.itemId] = round2((qty[l.itemId] || 0) + l.qty);
  $$('#pos-grid .tile').forEach(tile => {
    const q = qty[tile.dataset.id] || 0;
    tile.classList.toggle('in-ticket', q > 0);
    tile.setAttribute('aria-pressed', q > 0 ? 'true' : 'false');
    const badge = $('.in-qty', tile);
    badge.hidden = !q;
    badge.textContent = q ? `×${fmtQty(q)}` : '';
  });
}

function renderTicket() {
  const tk = App.ticket;
  const el = $('#ticket');
  if (!el) return;
  paintSelection();
  const tot = computeTotals(tk, Store.settings);
  const customer = tk.customerId ? Store.find('customers', tk.customerId) : null;
  const count = tk.lines.reduce((a, l) => a + l.qty, 0);
  const openCount = Store.data.openTickets.length;
  const s = Store.settings;
  const dis = tk.lines.length ? '' : 'disabled';
  el.innerHTML = `
    <div class="ticket-head">
      <strong>${esc(tk.name || t('ticket.title'))}</strong>
      <button class="icon-btn" data-act="customer" title="${esc(t('ticket.customer'))}">${icon('user')}</button>
      <button class="icon-btn" data-act="open-tickets" title="${esc(t('ticket.saved'))}">${icon('list')}${openCount ? `<span class="count">${openCount}</span>` : ''}</button>
      <button class="icon-btn" data-act="clear" title="${esc(t('ticket.clear'))}">${icon('trash')}</button>
    </div>
    ${customer ? `<div class="ticket-customer">${icon('user')}<div class="grow"><b>${esc(customer.name)}</b><div class="small muted">${esc(t('customers.pointsN', { n: fmtQty(customer.points) }))}${customer.debt > 0 ? ` · <span class="neg-val">${esc(t('debt.owes', { value: money(customer.debt) }))}</span>` : ''}</div></div><button class="btn ghost small" data-act="rm-customer">${esc(t('common.remove'))}</button></div>` : ''}
    <ul class="lines">
      ${tk.lines.length ? tk.lines.map((l, i) => `
        <li data-idx="${i}">
          ${thumbHtml(Store.find('items', l.itemId), 'thumb-sq sm')}
          <div class="l-name">${esc(l.name)}<small class="num">${money(l.price)}</small></div>
          <span class="stepper"><button type="button" data-step="-1" data-i="${i}" aria-label="−1">−</button><b class="num">${fmtQty(l.qty)}</b><button type="button" data-step="1" data-i="${i}" aria-label="+1">+</button></span>
          <div class="l-total num">${money(l.price * l.qty)}</div>
        </li>`).join('') : `<li class="empty">${esc(t('ticket.empty'))}</li>`}
    </ul>
    <div class="totals">
      ${tk.lines.length ? `<div class="t-row"><span>${esc(t('totals.subtotal'))}</span><span class="num">${money(tot.subtotal)}</span></div>` : ''}
      ${tot.discount ? `<div class="t-row"><span>${esc(t('totals.discount'))}${tk.discount.type === '%' ? ` (${fmtQty(tk.discount.value)}%)` : ''}</span><span class="num neg-val">−${money(tot.discount)}</span></div>` : ''}
      ${tot.points ? `<div class="t-row"><span>${esc(t('totals.pointsRedeemed'))}</span><span class="num neg-val">−${money(tot.points)}</span></div>` : ''}
      ${tot.tax ? `<div class="t-row"><span>${esc(t('totals.tax'))} ${fmtQty(s.taxRate)}%${s.taxMode === 'included' ? ` (${esc(t('totals.included'))})` : ''}</span><span class="num">${money(tot.tax)}</span></div>` : ''}
      <div class="t-row total"><span>${esc(t('totals.total'))}</span><span class="num">${money(tot.total)}</span></div>
    </div>
    <div class="ticket-foot">
      <button class="btn" data-act="discount" ${dis}>${esc(t('ticket.discount'))}</button>
      <button class="btn" data-act="save" ${dis}>${esc(t('common.save'))}</button>
      <button class="btn primary charge" data-act="charge" ${dis}>${esc(t('ticket.charge'))} ${money(tot.total)}</button>
    </div>`;
  paintCartBadge();
  paintPosKpis();

  $$('.lines li[data-idx]', el).forEach(li => li.addEventListener('click', () => editLineModal(+li.dataset.idx)));
  // − / +: muda a quantidade sem abrir a janela; a 0 tira o produto da conta.
  $$('[data-step]', el).forEach(b => b.addEventListener('click', e => {
    e.stopPropagation();
    const i = +b.dataset.i, d = +b.dataset.step, line = tk.lines[i];
    if (!line) return;
    if (d > 0) {
      const item = Store.find('items', line.itemId);
      if (item && isSoldOut(item)) { toast(t('pos.cantSellOut', { item: item.name }), true); return; }
      line.qty = round2(line.qty + 1);
    } else if (line.qty > 1) line.qty = round2(line.qty - 1);
    else tk.lines.splice(i, 1);
    saveTicket(); renderTicket();
  }));
  const acts = {
    customer: pickCustomerModal,
    'open-tickets': openTicketsModal,
    clear: async () => {
      if (!tk.lines.length && !tk.customerId) return;
      if (await confirmDialog(t('ticket.clearConfirm'), t('ticket.clear'), true)) {
        App.ticket = newTicket(); saveTicket(); renderTicket();
      }
    },
    hide: () => toggleTicket(false),
    'rm-customer': () => { tk.customerId = null; tk.pointsRedeemed = 0; saveTicket(); renderTicket(); },
    discount: discountModal,
    save: saveTicketModal,
    charge: chargeModal,
  };
  $$('[data-act]', el).forEach(b => b.addEventListener('click', () => acts[b.dataset.act]()));
}

function editLineModal(idx) {
  const l = App.ticket.lines[idx];
  if (!l) return;
  const m = openModal({
    title: l.name,
    body: `
      <div class="qty-ctrl">
        <button class="btn" data-d="-1">−</button>
        <input class="input" id="lq" inputmode="decimal" value="${fmtQty(l.qty)}" aria-label="${esc(t('common.quantity'))}">
        <button class="btn" data-d="1">+</button>
      </div>
      <label class="field"><span>${esc(t('ticket.unitPrice'))}</span><input class="input" id="lp" inputmode="decimal" value="${l.price}"></label>`,
    footer: `<button class="btn danger left" data-rm>${esc(t('common.remove'))}</button><button class="btn primary" data-ok>${esc(t('common.save'))}</button>`,
  });
  const q = $('#lq', m);
  $$('[data-d]', m).forEach(b => b.addEventListener('click', () => {
    q.value = fmtQty(Math.max(0, round2(num(q.value) + +b.dataset.d)));
  }));
  $('[data-rm]', m).onclick = () => { App.ticket.lines.splice(idx, 1); saveTicket(); closeModal(); renderTicket(); };
  const ok = () => {
    const qty = round2(num(q.value));
    if (qty <= 0) App.ticket.lines.splice(idx, 1);
    else { l.qty = qty; l.price = round2(Math.max(0, num($('#lp', m).value))); }
    saveTicket(); closeModal(); renderTicket();
  };
  $('[data-ok]', m).onclick = ok;
  m.addEventListener('keydown', e => { if (e.key === 'Enter') ok(); });
}

function discountModal() {
  if (!need('discount')) return;
  const tk = App.ticket;
  const customer = tk.customerId ? Store.find('customers', tk.customerId) : null;
  let type = tk.discount.type;
  const m = openModal({
    title: t('ticket.discount'),
    body: `
      <div class="field"><span>${esc(t('discount.type'))}</span>
        <div class="seg"><button data-t="%">${esc(t('discount.percent'))}</button><button data-t="$">${esc(t('discount.fixed'))}</button></div>
      </div>
      <label class="field"><span>${esc(t('discount.value'))}</span><input class="input" id="dv" inputmode="decimal" value="${tk.discount.value || ''}" placeholder="0"></label>
      ${customer ? `<label class="field"><span>${esc(t('discount.redeemPoints', { n: fmtQty(customer.points), value: money(customer.points) }))}</span>
        <input class="input" id="dp" inputmode="decimal" value="${tk.pointsRedeemed || ''}" placeholder="0"></label>` : `<p class="muted small">${esc(t('discount.needCustomer'))}</p>`}`,
    footer: `<button class="btn left" data-clear>${esc(t('discount.remove'))}</button><button class="btn primary" data-ok>${esc(t('common.apply'))}</button>`,
  });
  const paintSeg = () => $$('[data-t]', m).forEach(b => b.classList.toggle('active', b.dataset.t === type));
  $$('[data-t]', m).forEach(b => b.addEventListener('click', () => { type = b.dataset.t; paintSeg(); }));
  paintSeg();
  $('[data-clear]', m).onclick = () => { tk.discount = { type: '%', value: 0 }; tk.pointsRedeemed = 0; saveTicket(); closeModal(); renderTicket(); };
  const ok = () => {
    const v = Math.max(0, num($('#dv', m).value));
    if (type === '%' && v > 100) return toast(t('discount.over100'), true);
    tk.discount = { type, value: v };
    if (customer) {
      const p = Math.max(0, num($('#dp', m).value));
      if (p > customer.points + 1e-9) return toast(t('err.notEnoughPoints'), true);
      tk.pointsRedeemed = round2(p);
    }
    saveTicket(); closeModal(); renderTicket();
    return undefined;
  };
  $('[data-ok]', m).onclick = ok;
  m.addEventListener('keydown', e => { if (e.key === 'Enter') ok(); });
}

function pickCustomerModal(after) {
  const m = openModal({
    title: t('ticket.addCustomer'),
    body: `
      <input class="input" id="cq" type="search" placeholder="${esc(t('customers.searchPlaceholder'))}">
      <ul class="pick-list" id="cl" style="margin-top:10px"></ul>`,
    footer: `<button class="btn primary" data-new>+ ${esc(t('customers.new'))}</button>`,
  });
  const paint = () => {
    const q = $('#cq', m).value.trim().toLowerCase();
    const list = Store.data.customers.filter(c => !q || [c.name, c.phone, c.email].some(v => String(v || '').toLowerCase().includes(q)));
    $('#cl', m).innerHTML = list.length ? list.map(c => `
      <li data-id="${c.id}"><span class="badge grey">${esc(initials(c.name))}</span>
        <div class="grow"><b>${esc(c.name)}</b><div class="small muted">${esc(c.phone || c.email || '')}</div></div>
        <span class="small muted">${esc(t('customers.pointsShort', { n: fmtQty(c.points) }))}</span></li>`).join('') : `<li class="muted">${esc(t('customers.noneFound'))}</li>`;
    $$('#cl li[data-id]', m).forEach(li => li.addEventListener('click', () => {
      App.ticket.customerId = li.dataset.id; App.ticket.pointsRedeemed = 0;
      saveTicket(); closeModal(); renderTicket();
      if (typeof after === 'function') after();
    }));
  };
  $('#cq', m).addEventListener('input', paint);
  $('[data-new]', m).onclick = () => customerFormModal(null, c => {
    App.ticket.customerId = c.id; saveTicket(); renderTicket();
    if (typeof after === 'function') after();
  });
  paint();
}

function saveTicketModal() {
  const tk = App.ticket;
  const m = openModal({
    title: t('ticket.saveTitle'),
    body: `<label class="field"><span>${esc(t('ticket.nameLabel'))}</span><input class="input" id="tn" value="${esc(tk.name || `${t('ticket.title')} ${fmtTime(new Date().toISOString())}`)}"></label>`,
    footer: `<button class="btn primary" data-ok>${esc(t('common.save'))}</button>`,
  });
  const ok = () => {
    Store.saveOpenTicket(tk, $('#tn', m).value.trim());
    App.ticket = newTicket(); saveTicket(); closeModal(); renderTicket();
    toast(t('ticket.savedToast'));
  };
  $('[data-ok]', m).onclick = ok;
  m.addEventListener('keydown', e => { if (e.key === 'Enter') ok(); });
}

function openTicketsModal() {
  const list = Store.data.openTickets;
  const m = openModal({
    title: t('ticket.saved'),
    body: list.length ? `<ul class="pick-list">${list.map(o => {
      const tot = computeTotals(o, Store.settings);
      return `<li data-id="${o.id}"><div class="grow"><b>${esc(o.name)}</b><div class="small muted">${fmtTime(o.date)} · ${esc(t('ticket.linesN', { n: o.lines.length }))}</div></div>
        <span class="num">${money(tot.total)}</span><button class="icon-btn" data-del="${o.id}" title="${esc(t('common.delete'))}">${icon('trash')}</button></li>`;
    }).join('')}</ul>` : `<div class="empty">${esc(t('ticket.noSaved'))}</div>`,
  });
  $$('[data-del]', m).forEach(b => b.addEventListener('click', async e => {
    e.stopPropagation();
    if (await confirmDialog(t('ticket.deleteSavedConfirm'), t('common.delete'), true)) {
      Store.data.openTickets = Store.data.openTickets.filter(o => o.id !== b.dataset.del);
      Store.save(); renderTicket(); openTicketsModal();
    }
  }));
  $$('li[data-id]', m).forEach(li => li.addEventListener('click', () => {
    const cur = App.ticket;
    if (cur.lines.length && cur.openTicketId !== li.dataset.id) Store.saveOpenTicket(cur, cur.name);
    const o = Store.data.openTickets.find(x => x.id === li.dataset.id);
    App.ticket = JSON.parse(JSON.stringify(o));
    App.ticket.openTicketId = o.id;
    saveTicket(); closeModal(); renderTicket(); toggleTicket(true);
  }));
}

// Calculadora de troco: total da conta, valor entregue (teclado numérico) e troco ou quanto falta.
function changeCalcModal() {
  const tk = App.ticket;
  const tot = computeTotals(tk, Store.settings).total;
  const items = round2(tk.lines.reduce((a, l) => a + l.qty, 0));
  const keys = ['1', '2', '3', '4', '5', '6', '7', '8', '9', ',', '0', 'del'];
  const m = openModal({
    title: t('calc.title'), autofocus: false,
    body: `<div class="calc-total"><span>${esc(t('calc.total'))}<small>${esc(items ? t(items === 1 ? 'pos.kItem1' : 'pos.kItems', { n: fmtQty(items) }) : t('calc.empty'))}</small></span><b class="num">${money(tot)}</b></div>
      <div class="calc-disp"><span>${esc(t('calc.given'))}</span><b class="num" id="cd">0</b></div>
      <div class="calc-res zero" id="cres"></div>
      <div class="calc-pad">${keys.map(k => `<button type="button" data-ck="${k}" class="${k === 'del' ? 'del' : ''}" aria-label="${k === 'del' ? esc(t('calc.del')) : k}">${k === 'del' ? '⌫' : k}</button>`).join('')}
        <button type="button" class="clr" data-cclr>${esc(t('calc.clear'))}</button><button type="button" class="exact" data-cexact>${esc(t('calc.exact'))}</button></div>`,
    footer: `<button class="btn primary" data-cpay ${tk.lines.length ? '' : 'disabled'}>${esc(t('calc.pay'))}</button>`,
  });
  let v = '';
  const value = () => num((v || '0').replace(',', '.'));
  const paint = () => {
    const n = value(), d = round2(n - tot);
    const [int, dec] = v.split(',');
    $('#cd', m).textContent = v ? `${(int || '0').replace(/\B(?=(\d{3})+(?!\d))/g, ' ')}${v.includes(',') ? `,${dec}` : ''}` : '0';
    const res = $('#cres', m);
    res.className = `calc-res ${!n ? 'zero' : d >= 0 ? 'ok' : 'miss'}`;
    res.innerHTML = `<span>${esc(t(!n || d >= 0 ? 'pay.change' : 'calc.missing'))}</span><b class="num">${money(n ? Math.abs(d) : 0)}</b>`;
  };
  $$('[data-ck]', m).forEach(b => b.addEventListener('click', () => {
    const k = b.dataset.ck;
    if (k === 'del') v = v.slice(0, -1);
    else if (k === ',') { if (!v.includes(',')) v = `${v || '0'},`; }
    else if (!v.includes(',') || v.split(',')[1].length < 2) { if (v.replace(',', '').length < 10) v = v === '0' ? k : v + k; }
    paint();
  }));
  $('[data-cclr]', m).onclick = () => { v = ''; paint(); };
  $('[data-cexact]', m).onclick = () => { v = String(round2(tot)).replace('.', ','); paint(); };
  $('[data-cpay]', m).onclick = () => { if (tk.lines.length) chargeModal('cash', value() || tot); };
  paint();
}

function chargeModal(initialType, received) {
  const tk = App.ticket;
  const tot = computeTotals(tk, Store.settings);
  let type = typeof initialType === 'string' ? initialType : 'cash';
  const notes = [5, 10, 20, 50, 100, 200, 500, 1000, 2000];
  const quick = [tot.total, ...notes.filter(n => n > tot.total)].slice(0, 5);
  if (Math.ceil(tot.total) !== tot.total && !quick.includes(Math.ceil(tot.total))) quick.splice(1, 0, Math.ceil(tot.total));
  const m = openModal({
    title: t('pay.title'),
    body: `
      <div class="charge-total num">${money(tot.total)}</div>
      <div class="pay-types">${PAY_TYPES.filter(k => k !== 'credit' || can('credit')).map(k => `<button data-pay="${k}">${icon(k)}${esc(payLabel(k))}</button>`).join('')}</div>
      <div id="credit-box" class="credit-box" hidden></div>
      <div id="cash-box">
        <label class="field"><span>${esc(t('pay.received'))}</span><input class="input" id="recv" inputmode="decimal" value="${received != null ? round2(received) : tot.total}"></label>
        <div class="quick-cash">${quick.slice(0, 5).map(v => `<button class="btn small" data-q="${v}">${money(v)}</button>`).join('')}</div>
        <div class="change-box"><span>${esc(t('pay.change'))}</span><strong class="num" id="chg">${money(0)}</strong></div>
      </div>`,
    footer: `<button class="btn primary" data-ok>${esc(t('pay.confirm'))}</button>`,
  });
  const recv = $('#recv', m);
  const paint = () => {
    $$('[data-pay]', m).forEach(b => b.classList.toggle('active', b.dataset.pay === type));
    $('#cash-box', m).hidden = type !== 'cash';
    const cb = $('#credit-box', m);
    cb.hidden = type !== 'credit';
    if (type === 'credit') {
      const cust = tk.customerId ? Store.find('customers', tk.customerId) : null;
      cb.innerHTML = cust
        ? `${icon('user')}<div>${esc(t('debt.willOwe', { name: cust.name }))}<div class="small muted">${esc(t('debt.newTotal', { value: money((cust.debt || 0) + tot.total) }))}</div></div>`
        : `${icon('user')}<div>${esc(t('err.creditNeedsCustomer'))} <button type="button" class="btn small" data-pick-customer>${esc(t('ticket.addCustomer'))}</button></div>`;
      const pick = $('[data-pick-customer]', cb);
      if (pick) pick.onclick = () => pickCustomerModal(() => chargeModal('credit'));
    }
    const ch = round2(num(recv.value) - tot.total);
    $('#chg', m).textContent = ch >= 0 ? money(ch) : '—';
  };
  $$('[data-pay]', m).forEach(b => b.addEventListener('click', () => { type = b.dataset.pay; paint(); }));
  $$('[data-q]', m).forEach(b => b.addEventListener('click', () => { recv.value = b.dataset.q; paint(); }));
  recv.addEventListener('input', paint);
  const ok = () => guard(() => {
    const before = typeof alertSnap === 'function' ? alertSnap(tk) : null;
    const r = Store.finalizeSale(tk, { type, received: type === 'cash' ? num(recv.value) : null }, App.user.id);
    if (before) setTimeout(() => alertAfterSale(before), 600);
    App.ticket = newTicket(); saveTicket();
    toggleTicket(false);
    render();
    receiptModal(r, true);
    const pr = Device.conf.printer;
    if (pr && pr.address && pr.auto && Printer.available()) printReceipt(r);
  });
  $('[data-ok]', m).onclick = ok;
  m.addEventListener('keydown', e => { if (e.key === 'Enter') ok(); });
  paint();
}

// ================= Recibos =================

function receiptHtml(r) {
  const s = Store.settings;
  const c = r.customerId ? Store.find('customers', r.customerId) : null;
  const orig = r.refundOf ? Store.find('receipts', r.refundOf) : null;
  const footer = s.receiptFooter || t('receipt.thanks');
  return `<div class="receipt">
    ${r.type === 'refund' ? `<div class="r-refund">${esc(t('receipt.refundBanner'))}</div>` : ''}
    <div class="r-center r-title">${esc(s.storeName)}</div>
    ${s.address ? `<div class="r-center">${esc(s.address)}</div>` : ''}
    ${s.phone ? `<div class="r-center">${esc(t('receipt.phone'))} ${esc(s.phone)}</div>` : ''}
    <hr>
    <div class="r-row"><span>${esc(t('receipt.number'))} ${esc(receiptNo(r))}</span><span>${fmtDate(r.date)}</span></div>
    ${orig ? `<div>${esc(t('receipt.refOf'))} ${esc(receiptNo(orig))}</div>` : ''}
    <div>${esc(t('receipt.operator'))}: ${esc(empName(r.employeeId))}</div>
    ${c ? `<div>${esc(t('receipt.customer'))}: ${esc(c.name)}</div>` : ''}
    <hr>
    ${r.lines.map(l => `<div class="r-line"><div>${esc(l.name)}</div><div class="r-row"><span>${fmtQty(l.qty)} × ${money(l.price)}</span><span>${money(l.qty * l.price)}</span></div></div>`).join('')}
    <hr>
    <div class="r-row"><span>${esc(t('totals.subtotal'))}</span><span>${money(r.subtotal)}</span></div>
    ${r.discount ? `<div class="r-row"><span>${esc(t('totals.discount'))}</span><span>−${money(r.discount)}</span></div>` : ''}
    ${r.points ? `<div class="r-row"><span>${esc(t('totals.pointsRedeemed'))}</span><span>−${money(r.points)}</span></div>` : ''}
    ${r.tax ? `<div class="r-row"><span>${esc(t('totals.tax'))}${s.taxMode === 'included' ? ` (${esc(t('totals.included'))})` : ''}</span><span>${money(r.tax)}</span></div>` : ''}
    <div class="r-row r-total"><span>${esc(t('totals.total').toUpperCase())}</span><span>${money(r.total)}</span></div>
    <div class="r-row"><span>${esc(payLabel(r.payment.type))}</span><span>${money(r.payment.received)}</span></div>
    ${r.payment.change ? `<div class="r-row"><span>${esc(t('pay.change'))}</span><span>${money(r.payment.change)}</span></div>` : ''}
    ${r.pointsEarned ? `<div class="r-row"><span>${esc(t('receipt.pointsEarned'))}</span><span>${fmtQty(r.pointsEarned)}</span></div>` : ''}
    ${footer ? `<hr><div class="r-center">${esc(footer)}</div>` : ''}
  </div>`;
}

function receiptFormatters(r) {
  const c = r.customerId ? Store.find('customers', r.customerId) : null;
  const orig = r.refundOf ? Store.find('receipts', r.refundOf) : null;
  return {
    t, money, qty: fmtQty, date: fmtDate, number: receiptNo, store: Store.settings,
    payLabel: payLabel(r.payment.type), employee: empName(r.employeeId),
    customer: c ? c.name : null, refOf: orig ? receiptNo(orig) : null,
  };
}

// Erros do Bluetooth: o plugin nativo devolve um código (BT_OFF, BT_PERMISSION, …) que traduzimos.
const PRINTER_ERRORS = ['BT_OFF', 'BT_PERMISSION', 'BT_UNAVAILABLE', 'BT_UNREACHABLE'];
function printerError(e) {
  if (e && PRINTER_ERRORS.includes(e.code)) return t(`printer.err.${e.code}`);
  return t('printer.failed', { error: (e && e.message) || e });
}

async function printReceipt(r) {
  const pr = Device.conf.printer;
  if (Printer.available() && pr && pr.address) {
    try {
      await Printer.printBytes(pr.address, receiptEscPos(r, receiptFormatters(r), pr.width || 32));
      toast(t('printer.printed'));
    } catch (e) {
      toast(printerError(e), true);
    }
    return;
  }
  printDocument(`${t('receipt.number')} ${receiptNo(r)}`, receiptHtml(r));
}

// Estilos do documento impresso (o serviço de impressão do Android não usa o CSS da app).
const PRINT_CSS = `
  * { box-sizing: border-box; }
  /* A mesma margem em todas as páginas (antes só a 1.ª tinha margem em cima). */
  @page { margin: 10mm 9mm; }
  body { margin: 0; font-family: system-ui, -apple-system, "Segoe UI", Roboto, Arial, sans-serif; color: #1f2937; font-size: 12px; }
  .doc { padding: 0; }
  .doc h2, .doc h3, .doc h4 { break-after: avoid; page-break-after: avoid; }
  .doc tr { break-inside: avoid; page-break-inside: avoid; }
  .doc thead { display: table-header-group; }
  .doc h1 { font-size: 20px; margin: 0; }
  .doc h2 { font-size: 14px; margin: 18px 0 8px; padding-bottom: 4px; border-bottom: 1px solid #d1d5db; }
  .doc .meta { color: #6b7280; margin: 4px 0 12px; }
  .doc table { width: 100%; border-collapse: collapse; }
  .doc th, .doc td { padding: 5px 6px; border-bottom: 1px solid #e5e7eb; text-align: left; font-variant-numeric: tabular-nums; }
  .doc th { font-size: 10px; text-transform: uppercase; color: #6b7280; }
  .doc .r { text-align: right; }
  .doc .total-row td { font-weight: 700; border-top: 2px solid #9ca3af; border-bottom: none; }
  .kpi-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 6px; }
  .kpi-grid div { border: 1px solid #e5e7eb; border-radius: 6px; padding: 6px 8px; }
  .kpi-grid span { display: block; color: #6b7280; font-size: 10px; }
  .kpi-grid b { font-size: 14px; }
  .two { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
  .notes { margin: 14px 0; padding: 10px 14px; background: #fff3e0; border-radius: 6px; line-height: 1.5; }
  .xn-h { font-weight: 700; margin-top: 8px; } .xn-h:first-child { margin-top: 0; }
  .avoid { break-inside: avoid; page-break-inside: avoid; }
  :root { --c1: #2a78d6; --c2: #eb6834; --c3: #1baf7a; --c4: #eda100; --c5: #e87ba4; --c6: #008300; --c-none: #8f8e88; --c-other: #b5b4ae; }
  svg { max-width: 100%; height: auto; }
  .chart text { font-size: 11px; fill: #6b7280; }
  .chart .grid { stroke: #e5e7eb; stroke-dasharray: 2 3; }
  .chart .axis { stroke: #9ca3af; }
  .chart .col { fill: #2e7d32; }
  .chart .line { fill: none; stroke: #2e7d32; stroke-width: 2; }
  .chart .area { fill: #2e7d32; opacity: .12; }
  .chart .dot { fill: #2e7d32; }
  .chart .hit, .chart [hidden] { display: none; }
  .donut-svg { width: 120px; height: 120px; }
  .donut .slice { stroke: #fff; stroke-width: 2; }
  .donut circle.slice { stroke-width: 24; }
  .donut .d-total { font-size: 18px; font-weight: 700; fill: #1f2937; }
  .donut .d-sub { font-size: 10px; fill: #6b7280; }
  .sw { display: inline-block; width: 10px; height: 10px; border-radius: 2px; margin-right: 6px; vertical-align: -1px; }
  .receipt { font-family: ui-monospace, Menlo, Consolas, monospace; font-size: 12px; max-width: 80mm; margin: 0 auto; color: #111; }
  .receipt .r-center { text-align: center; }
  .receipt .r-title { font-size: 15px; font-weight: 700; }
  .receipt hr { border: none; border-top: 1px dashed #999; margin: 8px 0; }
  .receipt .r-row { display: flex; justify-content: space-between; gap: 8px; }
  .receipt .r-line { margin-bottom: 3px; }
  .receipt .r-total { font-size: 15px; font-weight: 700; }
  .receipt .r-refund { text-align: center; font-weight: 700; border: 2px solid #111; padding: 3px; margin-bottom: 6px; }
`;

// Na app Android abre o serviço de impressão do sistema (PDF ou impressora); no browser, a janela de impressão.
// PDF exportado: na app guarda-se direto em Documentos/Stoi. Se a APK ainda não sabe fazer isso
// (versão antiga), abre a janela de impressão como antes ("Guardar como PDF").
async function savePdfDoc(title, bodyHtml, name) {
  if (NativePrint.available()) {
    const html = `<!doctype html><html lang="${getLang()}"><head><meta charset="utf-8"><title>${esc(title)}</title><style>${PRINT_CSS}</style></head><body>${bodyHtml}</body></html>`;
    try { await NativePrint.savePdf(html, name, SAVE_FOLDER); toast(t('xp.saved', { f: `${t('xp.docs')}/${SAVE_FOLDER}`, name }), false, true); return; } catch (e) { /* APK antiga: janela de impressão */ }
  }
  return printDocument(title, bodyHtml);
}

async function printDocument(title, bodyHtml) {
  if (NativePrint.available()) {
    const html = `<!doctype html><html lang="${getLang()}"><head><meta charset="utf-8"><title>${esc(title)}</title><style>${PRINT_CSS}</style></head><body>${bodyHtml}</body></html>`;
    try { await NativePrint.print(html, title); } catch (e) { toast(t('printer.failed', { error: e.message || e }), true); }
    return;
  }
  $('#print-area').innerHTML = `<style>${PRINT_CSS}</style>${bodyHtml}`;
  window.print();
}

function receiptModal(r, justSold) {
  const canRefund = r.type === 'sale' && !r.refundedBy && can('refund');
  const canDelete = can('refund');
  const m = openModal({
    title: justSold ? t('receipt.saleDone') : `${t('receipt.number')} ${receiptNo(r)}`,
    body: `
      ${justSold && r.payment.change ? `<div class="change-box" style="margin-bottom:14px"><span>${esc(t('pay.change'))}</span><strong class="num">${money(r.payment.change)}</strong></div>` : ''}
      ${r.refundedBy ? `<p><span class="badge danger">${esc(t('receipt.refunded'))}</span></p>` : ''}
      ${receiptHtml(r)}`,
    footer: footer3([
      ...(canDelete ? [['danger', 'data-del-r', 'trash', t('common.delete')]] : []),
      ...(canRefund ? [['', 'data-refund', 'undo', t('receipt.refundShort')]] : []),
      ['', 'data-print', 'print', t('receipt.printShort')],
      ...(justSold ? [['primary', 'data-close', 'check', t('receipt.newSale')]] : []),
    ]),
  });
  if (canDelete) {
    $('[data-del-r]', m).onclick = async () => {
      const msg = r.type === 'refund' ? 'receipt.deleteRefundConfirm' : r.refundedBy ? 'receipt.deleteRefundedConfirm' : 'receipt.deleteConfirm';
      if (!await confirmDialog(t(msg, { n: receiptNo(r), total: money(r.total) }), t('common.delete'), true)) return receiptModal(r);
      guard(() => { Store.deleteReceipt(r.id); toast(t('receipt.deleted', { n: receiptNo(r) })); render(); });
    };
  }
  $('[data-print]', m).onclick = () => printReceipt(r);
  if (canRefund) {
    $('[data-refund]', m).onclick = async () => {
      if (!await confirmDialog(t('receipt.refundConfirm', { n: receiptNo(r), total: money(r.total) }), t('receipt.refund'), true)) return;
      guard(() => {
        const ref = Store.refund(r.id, App.user.id);
        toast(t('receipt.refundDone', { n: receiptNo(ref) }));
        render();
        receiptModal(ref);
      });
    };
  }
}

function viewReceipts(main) {
  main.innerHTML = `
    <div class="page">
      <div class="page-head">
        <input class="input grow" id="rq" type="search" placeholder="${esc(t('receipts.searchPlaceholder'))}" value="${esc(App.receiptsQ)}">
      </div>
      <div class="card table-wrap" id="rl"></div>
    </div>`;
  const paint = () => {
    const q = App.receiptsQ.trim().toLowerCase();
    const list = Store.data.receipts.filter(r => {
      if (!q) return true;
      const c = r.customerId ? Store.find('customers', r.customerId) : null;
      return receiptNo(r).includes(q) || (c && c.name.toLowerCase().includes(q)) || empName(r.employeeId).toLowerCase().includes(q);
    }).slice(0, 300);
    $('#rl').innerHTML = list.length ? `<table class="table">
      <thead><tr><th>${esc(t('receipts.no'))}</th><th>${esc(t('common.date'))}</th><th class="hide-sm">${esc(t('receipts.employee'))}</th><th class="hide-sm">${esc(t('receipt.customer'))}</th><th>${esc(t('receipts.payment'))}</th><th class="right">${esc(t('totals.total'))}</th><th></th></tr></thead>
      <tbody>${list.map(r => {
        const c = r.customerId ? Store.find('customers', r.customerId) : null;
        return `<tr class="clickable" data-id="${r.id}">
          <td>${esc(receiptNo(r))}</td><td>${fmtDate(r.date)}</td>
          <td class="hide-sm">${esc(empName(r.employeeId))}</td><td class="hide-sm">${esc(c ? c.name : '—')}</td>
          <td>${esc(payLabel(r.payment.type))}</td>
          <td class="right num ${r.type === 'refund' ? 'neg-val' : ''}">${r.type === 'refund' ? '−' : ''}${money(r.total)}</td>
          <td>${r.type === 'refund' ? `<span class="badge danger">${esc(t('receipts.refundBadge'))}</span>` : r.refundedBy ? `<span class="badge grey">${esc(t('receipt.refunded'))}</span>` : ''}</td>
        </tr>`;
      }).join('')}</tbody>
      <tfoot><tr class="total-row"><td colspan="2">${esc(t('totals.total'))} <span class="muted small">(${esc(t('receipts.countN', { n: list.length }))})</span></td><td class="hide-sm"></td><td class="hide-sm"></td><td></td>
        <td class="right num">${money(round2(list.reduce((a, r) => a + (r.type === 'refund' ? -r.total : r.total), 0)))}</td><td></td></tr></tfoot></table>` : `<div class="empty">${esc(t('receipts.none'))}</div>`;
    $$('#rl tr[data-id]').forEach(tr => tr.addEventListener('click', () => receiptModal(Store.find('receipts', tr.dataset.id))));
  };
  $('#rq').addEventListener('input', e => { App.receiptsQ = e.target.value; paint(); });
  paint();
}

// ================= Itens =================

function viewItems(main) {
  const cats = Store.data.categories;
  main.innerHTML = `
    <div class="page">
      ${listBarHtml('iq', t('items.searchPlaceholder'), App.itemsFilter.q, t('items.add'), true)}
      <div class="fchips" id="fchips"></div>
      <div class="card table-wrap" id="il"></div>
    </div>`;
  // Filtros: categorias, stock, tipo, código e ordem (vazio = todos).
  const f = App.itemsFilter;
  if (f.low) { f.stock = 'low'; f.low = false; }
  const sold = soldQtyByItem();
  const filtered = () => itemsFiltered(f, sold);
  const paintFilter = () => {
    f.cats = validCats(f.cats);
    const tags = itemFilterTags(f);
    const btn = $('#iq-f');
    btn.classList.toggle('on', tags.length > 0);
    $('.fbadge', btn).textContent = tags.length || '';
    $('#fchips').innerHTML = tags.length ? `${tags.map(x => `<button type="button" class="fchip on" data-untag="${x.k}">${esc(x.label)} ✕</button>`).join('')}<button type="button" class="fchip clear" data-untag="all">${esc(t('flt.clear'))}</button>` : '';
    $$('[data-untag]', main).forEach(b => b.addEventListener('click', () => { clearItemFilter(f, b.dataset.untag); paintFilter(); paint(); }));
  };
  const paint = () => {
    const list = filtered();
    $('#il').innerHTML = list.length ? `<table class="table">
      <thead><tr><th>${esc(t('common.name'))}</th><th class="hide-sm">${esc(t('items.category'))}</th><th class="right">${esc(t('items.price'))}</th><th class="right hide-sm cost-only">${esc(t('items.cost'))}</th><th class="right hide-sm cost-only">${esc(t('items.margin'))}</th><th class="right">${esc(t('items.stock'))}</th></tr></thead>
      <tbody>${(App.itemsAll || f.q.trim() ? list : list.slice(0, 5)).map(i => {
        const c = i.categoryId ? Store.find('categories', i.categoryId) : null;
        const margin = i.price > 0 ? Math.round((i.price - (i.cost || 0)) / i.price * 100) : 0;
        const low = i.trackStock && i.stock <= (i.lowStock || 0);
        return `<tr class="clickable" data-id="${i.id}">
          <td class="wrap">${i.image ? `<img class="thumb" src="${esc(i.image)}" alt="">` : `<span class="swatch" style="background:${esc(i.color)}"></span>`}${esc(dn(i))}<div class="small muted">SKU ${esc(i.sku || '—')}${i.barcode ? ` · ${esc(i.barcode)}` : ''}</div></td>
          <td class="hide-sm">${esc(c ? c.name : t('items.noCategory'))}</td>
          <td class="right num">${money(i.price)}</td>
          <td class="right num hide-sm cost-only">${money(i.cost)}</td>
          <td class="right hide-sm cost-only">${margin}%</td>
          <td class="right num">${i.trackStock ? `<span class="${low ? 'badge danger' : ''}">${fmtQty(i.stock)}</span>` : '<span class="muted">—</span>'}</td>
        </tr>`;
      }).join('')}</tbody>
      <tfoot><tr class="total-row"><td>${esc(t('totals.total'))} <span class="muted small">(${esc(t('stock.itemsN', { n: list.length }))})</span></td><td class="hide-sm"></td><td></td><td class="hide-sm cost-only"></td><td class="hide-sm cost-only"></td>
        <td class="right num">${fmtQty(round2(list.filter(i => i.trackStock).reduce((a, i) => a + Math.max(0, i.stock), 0)))}</td></tr></tfoot></table>${list.length > 5 && !f.q.trim() ? `<button class="fold-toggle" id="items-more" type="button">${esc(App.itemsAll ? t('sup.seeLess') : t('sup.seeAll', { n: list.length }))}</button>` : ''}` : `<div class="empty">${esc(t('sales.noItemsFound'))}</div>`;
    // Só 5 linhas; "Ver tudo" expande (ao pesquisar, mostra tudo o que encontrar).
    const more = $('#items-more');
    if (more) more.addEventListener('click', () => { App.itemsAll = !App.itemsAll; paint(); });
    $$('#il tr[data-id]').forEach(tr => tr.addEventListener('click', () => itemFormModal(Store.find('items', tr.dataset.id))));
  };
  $('#iq').addEventListener('input', e => { App.itemsFilter.q = e.target.value; paint(); });
  $('#iq-f').addEventListener('click', () => itemFilterModal(f, sold, () => { paintFilter(); paint(); }));
  paintFilter();
  $('#new').addEventListener('click', () => itemFormModal(null));

  if ($('#exp')) $('#exp').addEventListener('click', () => {
    const list = filtered();
    const subtitle = [catLabel(f.cats, true, t('items.allCategories')), ...itemFilterTags(f).filter(x => x.k !== 'cats').map(x => x.label)].filter(Boolean).join(' · ');
    const tracked = list.filter(i => i.trackStock);
    exportModal({
      title: t('xp.productsTitle'), subtitle, file: 'produtos', notes: productNotes(list),
      columns: [t('common.name'), t('items.category'), t('items.price'), t('items.stock')],
      numeric: [2, 3],
      rows: list.map(i => [dn(i), (Store.find('categories', i.categoryId) || {}).name || '', i.price, i.trackStock ? i.stock : '—']),
      totals: [t('totals.total'), '', '', round2(tracked.reduce((a, i) => a + Math.max(0, i.stock), 0))],
    });
  });
  paint();
}

// Barra das listas: pesquisa + botão de filtro numa linha; Adicionar (e Exportar) por baixo.
function listBarHtml(id, ph, q, addLabel, withExport) {
  // Pesquisa sozinha em cima; por baixo, Adicionar e o Filtrar (exportar faz-se pela tabela).
  return `<div class="lbar">
      <label class="lsearch">${icon('search')}<input id="${id}" type="search" placeholder="${esc(ph)}" value="${esc(q || '')}"></label>
    </div>
    <div class="lbar">
      <button class="btn primary grow" id="new" type="button">${icon('plus')}<span>${esc(addLabel)}</span></button>
      <button class="fbtn" id="${id}-f" type="button" aria-label="${esc(t('flt.title'))}" title="${esc(t('flt.title'))}">${icon('filter')}<span class="fbadge"></span></button>
    </div>`;
}
// Quantidade vendida por produto (todas as vendas; devoluções descontam).
function soldQtyByItem() {
  const m = {};
  for (const r of Store.data.receipts) for (const l of r.lines || []) m[l.itemId] = (m[l.itemId] || 0) + (r.type === 'refund' ? -1 : 1) * (l.qty || 0);
  return m;
}
const ITEM_FILTERS = {
  stock: ['in', 'low', 'out', 'none'],
  type: ['box', 'unit', 'other'],
  code: ['yes', 'no'],
  sort: ['name', 'price', 'stockDesc', 'stockAsc', 'sold'],
};
function itemType(i) {
  if (i.opensInto) return 'box';
  return Store.data.items.some(b => b.opensInto === i.id) ? 'unit' : 'other';
}
function itemsFiltered(f, sold, over = {}) {
  const g = Object.assign({}, f, over);
  const q = (g.q || '').trim().toLowerCase();
  const cats = validCats(g.cats || []);
  const st = i => (!i.trackStock ? 'none' : i.stock <= 0 ? 'out' : i.stock <= (i.lowStock || 0) ? 'low' : 'in');
  const list = Store.data.items.filter(i => {
    if (cats.length && !cats.includes(catKey(i))) return false;
    if (g.stock && (g.stock === 'in' ? !(i.trackStock && i.stock > 0) : st(i) !== g.stock)) return false;
    if (g.type && itemType(i) !== g.type) return false;
    if (g.code === 'yes' && !i.barcode) return false;
    if (g.code === 'no' && i.barcode) return false;
    return !q || i.name.toLowerCase().includes(q) || (i.sku || '').includes(q) || (i.barcode || '').includes(q);
  });
  const by = { name: (a, b) => a.name.localeCompare(b.name, 'pt'), price: (a, b) => b.price - a.price,
    stockDesc: (a, b) => (b.trackStock ? b.stock : -1e9) - (a.trackStock ? a.stock : -1e9), stockAsc: (a, b) => (a.trackStock ? a.stock : 1e9) - (b.trackStock ? b.stock : 1e9),
    sold: (a, b) => (sold[b.id] || 0) - (sold[a.id] || 0) };
  return list.sort((a, b) => (by[g.sort] || by.name)(a, b) || a.name.localeCompare(b.name, 'pt'));
}
function itemFilterTags(f) {
  const out = [];
  validCats(f.cats || []).forEach(id => { const c = Store.find('categories', id); out.push({ k: `cat:${id}`, label: c ? c.name : t('items.noCategory') }); });
  for (const k of ['stock', 'type', 'code']) if (f[k]) out.push({ k, label: t(`flt.${k}.${f[k]}`) });
  if (f.sort && f.sort !== 'name') out.push({ k: 'sort', label: t(`flt.sort.${f.sort}`) });
  return out;
}
function clearItemFilter(f, k) {
  if (k === 'all') { f.cats = []; f.stock = ''; f.type = ''; f.code = ''; f.sort = 'name'; return; }
  if (k.startsWith('cat:')) { f.cats = (f.cats || []).filter(x => x !== k.slice(4)); return; }
  f[k] = k === 'sort' ? 'name' : '';
}
// Folha de filtros: grupos de botões; o botão de baixo diz quantos produtos ficam.
function chipGroup(label, key, opts, cur, multi) {
  return `<div class="fgroup"><div class="flabel">${esc(label)}</div><div class="fchips">${opts.map(([v, l]) =>
    `<button type="button" class="fchip ${(multi ? cur.includes(v) : cur === v) ? 'on' : ''}" data-g="${key}" data-v="${esc(v)}">${esc(l)}</button>`).join('')}</div></div>`;
}
function itemFilterModal(f, sold, onApply) {
  const d = { cats: validCats(f.cats || []).slice(), stock: f.stock || '', type: f.type || '', code: f.code || '', sort: f.sort || 'name' };
  const body = () => chipGroup(t('items.category'), 'cats', [['', t('flt.all')], ...catOptions().map(o => [o.id, o.name])], d.cats.length ? d.cats : [''], true)
    + ['stock', 'type', 'code'].map(k => chipGroup(t(`flt.${k}`), k, [['', t('flt.all')], ...ITEM_FILTERS[k].map(v => [v, t(`flt.${k}.${v}`)])], d[k])).join('')
    + chipGroup(t('flt.sort'), 'sort', ITEM_FILTERS.sort.map(v => [v, t(`flt.sort.${v}`)]), d.sort);
  const m = openModal({ title: t('flt.itemsTitle'), autofocus: false, body: `<div id="fbody"></div>`,
    footer: `<button class="btn left" data-clear>${esc(t('flt.clear'))}</button><button class="btn primary" data-ok></button>` });
  const paint = () => {
    $('#fbody', m).innerHTML = body();
    $('[data-ok]', m).textContent = t('flt.showN', { n: itemsFiltered(f, sold, d).length });
    $$('.fchip[data-g]', m).forEach(b => b.addEventListener('click', () => {
      const g = b.dataset.g, v = b.dataset.v;
      if (g === 'cats') d.cats = !v ? [] : d.cats.includes(v) ? d.cats.filter(x => x !== v) : [...d.cats, v];
      else d[g] = v;
      paint();
    }));
  };
  paint();
  $('[data-clear]', m).onclick = () => { Object.assign(d, { cats: [], stock: '', type: '', code: '', sort: 'name' }); paint(); };
  $('[data-ok]', m).onclick = () => { Object.assign(f, d); closeModal(); onApply(); };
}

function colorPicker(name, current) {
  return `<div class="color-picker">${COLORS.map(c => `<label><input type="radio" name="${name}" value="${c}" ${c === current ? 'checked' : ''}><span style="background:${c}"></span></label>`).join('')}</div>`;
}

// Reduz uma imagem para no máximo 240 px (fundo branco, JPEG) — fica com poucos KB.
function shrinkImage(file, max = 240) {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onerror = reject;
    r.onload = () => {
      const img = new Image();
      img.onerror = reject;
      img.onload = () => {
        const k = Math.min(1, max / Math.max(img.width, img.height));
        const w = Math.max(1, Math.round(img.width * k)), h = Math.max(1, Math.round(img.height * k));
        const c = document.createElement('canvas');
        c.width = w; c.height = h;
        const g = c.getContext('2d');
        g.fillStyle = '#fff'; g.fillRect(0, 0, w, h);
        g.drawImage(img, 0, 0, w, h);
        resolve(c.toDataURL('image/jpeg', 0.8));
      };
      img.src = r.result;
    };
    r.readAsDataURL(file);
  });
}

function itemFormModal(item) {
  if (!need('products')) return;
  const isNew = !item;
  // Produto já com stock: a gestão do stock é no Stock; aqui só se mostra o número.
  const managed = !!(item && item.trackStock);
  const it = item || { name: '', categoryId: App.itemsFilter.cats.length === 1 && Store.find('categories', App.itemsFilter.cats[0]) ? App.itemsFilter.cats[0] : '', price: '', cost: '', sku: Store.nextSku(), barcode: '', trackStock: false, stock: 0, lowStock: 5, color: COLORS[6] };
  const m = openModal({
    title: isNew ? t('items.newTitle') : t('items.editTitle'),
    wide: true,
    body: `<form id="if">
      <label class="field"><span>${esc(t('common.name'))} *</span><input class="input" name="name" required value="${esc(it.name)}"></label>
      <div class="row">
        <label class="field"><span>${esc(t('items.category'))}</span><select class="input" name="categoryId">
          <option value="">${esc(t('items.noCategory'))}</option>
          ${Store.data.categories.map(c => `<option value="${c.id}" ${c.id === it.categoryId ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}
        </select></label>
        <label class="field"><span>${esc(t('items.salePrice'))} *</span><input class="input" name="price" inputmode="decimal" required value="${it.price}"></label>
        <label class="field cost-only"><span>${esc(t('items.cost'))}</span><input class="input" name="cost" inputmode="decimal" value="${it.cost}"></label>
      </div>
      <div class="row">
        <label class="field"><span>SKU</span><input class="input" name="sku" value="${esc(it.sku)}"></label>
        <label class="field"><span>${esc(t('items.barcode'))}</span><input class="input" name="barcode" value="${esc(it.barcode)}"></label>
      </div>
      ${managed ? '<input type="hidden" name="trackStock" value="on">' : `<label class="check"><input type="checkbox" name="trackStock" ${it.trackStock ? 'checked' : ''}> ${esc(t('items.trackStock'))}</label>`}
      <div id="stock-row">
        ${it.trackStock && !isNew ? `
        <button type="button" class="stock-summary stock-link" data-check>
          <div><span class="muted small">${esc(t('stock.tab'))}</span><b class="num">${fmtQty(it.stock)}</b></div>
          <span class="stock-go">${esc(t('fix.check'))} ›</span>
        </button>
        <input type="hidden" name="lowStock" value="${it.lowStock ?? 5}">` : `
        <div class="row">
          <label class="field"><span>${esc(t('stock.initial'))}</span><input class="input" name="initialQty" inputmode="decimal" placeholder="0"></label>
          <label class="field"><span>${esc(t('stock.entryDate'))}</span><input class="input" type="date" name="entryDate" value="${dayKey(new Date())}" max="${dayKey(new Date())}"></label>
        </div>`}
        ${managed ? '' : `<label class="field"><span>${esc(t('items.lowStockAlert'))}</span><input class="input" name="lowStock" inputmode="decimal" value="${it.lowStock ?? 5}"></label>`}
        <div class="row">
          <label class="field"><span>${esc(t('pack.opensInto'))}</span><select class="input" name="opensInto">
            <option value="">${esc(t('pack.none'))}</option>
            ${Store.data.items.filter(x => x.id !== it.id && x.trackStock).sort((a, b) => a.name.localeCompare(b.name, 'pt')).map(x => `<option value="${x.id}" ${x.id === it.opensInto ? 'selected' : ''}>${esc(x.name)}${x.categoryId && Store.find('categories', x.categoryId) ? ` (${esc(Store.find('categories', x.categoryId).name)})` : ''}</option>`).join('')}
          </select></label>
          <label class="field"><span>${esc(t('pack.qty'))}</span><input class="input" name="opensQty" inputmode="numeric" value="${it.opensQty || 4}"></label>
        </div>
        <p class="muted small" style="margin-top:-6px">${esc(t('pack.hint'))}</p>
      </div>
      <div class="field"><span>${esc(t('picon.field'))}</span>
        <button type="button" class="btn icon-choose" id="ic-pick" aria-expanded="false"><span class="ic-prev" id="ic-prev"></span><span id="ic-name"></span><span class="ic-chev">▾</span></button>
        <div class="ip-grid inline" id="ic-grid" hidden></div>
      </div>
      <div class="field"><span>${esc(t('items.color'))}</span>${colorPicker('color', it.color)}</div>
    </form>`,
    footer: `${isNew ? '' : `<button class="btn danger left" data-del>${esc(t('common.delete'))}</button>`}<button class="btn primary" data-ok>${esc(t('common.save'))}</button>`,
  });
  const form = $('#if', m);
  // Imagem do produto: a secção foi tirada do formulário; uma imagem antiga fica como está.
  const image = it.image || '';
  // Ícone do produto: vazio = o da categoria (ou o automático).
  let iconSel = it.icon || '';
  const paintIcon = () => {
    const probe = Object.assign({}, it, { name: form.name.value || it.name, categoryId: form.categoryId.value || null, icon: iconSel });
    $('#ic-prev', m).style.color = iconColorOf(probe);
    $('#ic-prev', m).innerHTML = PICONS[iconKeyOf(probe)]();
    $('#ic-name', m).textContent = iconSel ? t(`picon.${iconSel}`) : t('picon.fromCategory');
  };
  paintIcon();
  form.categoryId.addEventListener('change', paintIcon);
  form.name.addEventListener('change', paintIcon);
  // A grelha abre dentro do formulário (a app só mostra uma janela de cada vez).
  $('#ic-pick', m).onclick = () => {
    const grid = $('#ic-grid', m), open = grid.hidden;
    if (open) {
      const probe = Object.assign({}, it, { name: form.name.value || it.name, categoryId: form.categoryId.value || null, icon: '' });
      const color = iconColorOf(probe), autoKey = iconKeyOf(probe);
      const cell = (k, label) => `<button type="button" class="ip-cell ${iconSel === k ? 'on' : ''}" data-ik="${esc(k)}" style="color:${esc(color)}">${PICONS[k || autoKey]()}<span>${esc(label)}</span></button>`;
      grid.innerHTML = cell('', t('picon.fromCategory')) + PICON_KEYS.map(k => cell(k, t(`picon.${k}`))).join('');
      $$('[data-ik]', grid).forEach(b => b.addEventListener('click', () => { iconSel = b.dataset.ik; grid.hidden = true; $('#ic-pick', m).setAttribute('aria-expanded', 'false'); paintIcon(); }));
    }
    grid.hidden = !open; $('#ic-pick', m).setAttribute('aria-expanded', String(open));
  };
  const syncStock = () => { $('#stock-row', m).hidden = !managed && !form.trackStock.checked; };
  if (!managed) form.trackStock.addEventListener('change', syncStock);
  syncStock();
  // "Conferir": vai para o Stock e abre a gestão deste produto.
  const chk = $('[data-check]', m);
  if (chk) chk.onclick = () => { closeModal(); App.stockOpen = it.id; if (location.hash === '#stock') render(); else location.hash = '#stock'; };
  const ok = () => {
    const f = formObj(form);
    if (!f.name.trim()) return toast(t('items.needName'), true);
    if (f.price === '' || num(f.price) < 0) return toast(t('items.needPrice'), true);
    const code = f.barcode.trim();
    if (code && Store.data.items.some(x => x.id !== it.id && x.barcode === code)) return toast(t('items.barcodeTaken'), true);
    const startsTracking = !!f.trackStock && !(it.trackStock && !isNew);
    const initialQty = startsTracking ? round2(num(f.initialQty)) : 0;
    if (initialQty < 0) return toast(t('err.invalidQty'), true);
    if (initialQty > 0 && (!f.entryDate || f.entryDate > dayKey(new Date()))) return toast(t('err.invalidDate'), true);
    const saved = Store.upsert('items', {
      id: it.id, name: f.name.trim(), categoryId: f.categoryId || null,
      price: round2(num(f.price)), cost: round2(num(f.cost)), sku: f.sku.trim(), barcode: code,
      trackStock: !!f.trackStock, stock: startsTracking ? 0 : it.stock, lowStock: round2(num(f.lowStock)),
      color: f.color || COLORS[6],
      opensInto: f.trackStock && f.opensInto ? f.opensInto : null, opensQty: Math.max(1, Math.round(num(f.opensQty)) || 4),
      image: image || null,
      icon: iconSel || null,
    });
    if (initialQty > 0) {
      Store.addStockEntry({ itemId: saved.id, qty: initialQty, date: f.entryDate, cost: saved.cost, note: t('stock.initial') }, App.user.id);
    }
    closeModal(); render(); toast(t('items.saved'));
    return undefined;
  };
  $('[data-ok]', m).onclick = ok;
  form.addEventListener('submit', e => { e.preventDefault(); ok(); });
  if (!isNew) $('[data-del]', m).onclick = async () => {
    if (await confirmDialog(t('common.deleteConfirm', { name: it.name }), t('common.delete'), true)) { Store.remove('items', it.id); render(); toast(t('items.deleted')); }
  };
}

// ================= Stock =================

const daysSince = date => Math.max(0, Math.floor((new Date(`${dayKey(new Date())}T00:00:00`) - new Date(`${date}T00:00:00`)) / 864e5));
const fmtEntryDate = date => new Date(`${date}T00:00:00`).toLocaleDateString(dateLocale(), { day: '2-digit', month: '2-digit', year: 'numeric' });

function viewStock(main) {
  setTimeout(() => { const d = document.getElementById('dbl'); if (d) d.onclick = doubleRemovalsModal; }, 0);
  const q = (App.stockQ || '').trim().toLowerCase();
  // Categorias escolhidas (vazio = todas); 'none' = sem categoria. Ignora categorias apagadas.
  const cats = validCats(App.stockCats);
  const cf = cats.length ? 'some' : 'all';
  // Situações escolhidas (vazio = todos).
  const sits = (App.stockSits || []).filter(k => SITS.includes(k));
  const one = sits.length === 1 ? sits[0] : null;
  const sel = stockSelection({ cats, q, from: App.stockFrom, to: App.stockTo });
  // Com uma data escolhida, a tabela mostra só o que entrou nesse dia/período (quanto e quando).
  const dated = !!App.stockFrom;
  const isNew = one === 'new' || dated;
  const inSit = { new: i => sel.entered.has(i.id), low: stockIsLow, out: i => i.stock <= 0 };
  const list = sel.items.filter(i => (!sits.length || sits.some(k => inSit[k](i))) && (!dated || sel.entered.has(i.id)));
  // Na lista: o stock atual e a última data de entrada (ou, em "Novo estoque", quanto entrou no período).
  // Só as 5 primeiras linhas; "Ver todos" expande (ao pesquisar, mostra tudo o que encontrar).
  const STOCK_ROWS = 5;
  const showAll = !!App.stockAll || !!q;
  const rows = (showAll ? list : list.slice(0, STOCK_ROWS)).map(i => {
    const low = i.stock <= (i.lowStock || 0);
    const en = sel.entered.get(i.id);
    const last = isNew ? en.last : sel.lastEntry(i.id);
    return `<tr class="clickable" data-id="${i.id}">
      <td class="wrap"><span class="swatch" style="background:${esc(i.color)}"></span>${esc(dn(i))}</td>
      <td class="right num">${isNew ? `<span class="pos-val">+${fmtQty(en.qty)}</span>` : `<span class="${low ? 'badge danger' : ''}">${fmtQty(i.stock)}</span>`}</td>
      <td class="num">${last ? fmtEntryDate(last) : '<span class="muted">—</span>'}</td>
    </tr>`;
  }).join('');
  const dateLabel = App.stockFrom ? (sel.from === sel.to ? fmtEntryDate(sel.from).slice(0, 5) : `${fmtEntryDate(sel.from).slice(0, 5)}–${fmtEntryDate(sel.to).slice(0, 5)}`) : t('stock.datesShort');
  const dbl = can('fixStock') || can('products') ? Store.doubleRemovals() : [];
  main.innerHTML = `
    <div class="page">
      ${dbl.length ? `<button type="button" class="notice warn dbl-notice" id="dbl">${icon('bell')}<div><b>${esc(t('dbl.title'))}</b> · ${esc(t('dbl.short', { n: dbl.length }))} <u>${esc(t('dbl.review'))}</u></div></button>` : ''}
      <div class="page-head stock-head">
        <input class="input grow" id="sq" type="search" placeholder="${esc(t('stock.searchPlaceholder'))}" value="${esc(App.stockQ || '')}">
        <button class="btn stock-dates stock-cats ${cats.length ? 'on' : ''}" id="sc" title="${esc(t('items.category'))}">${icon('layers')}<span>${esc(catLabel(cats))}</span></button>
      </div>
      <div class="page-head stock-head stock-filters">
        <button class="btn stock-dates ${sits.length ? 'on' : ''}" id="ss" title="${esc(t('stock.situation'))}">${icon('check')}<span>${esc(sitLabel(sits))}</span></button>
        <button class="btn stock-dates ${App.stockFrom ? 'on' : ''}" id="sd" title="${esc(t('stock.dates'))}">${icon('calendar')}<span>${esc(dateLabel)}</span></button>
      </div>
      ${(() => {
        const sum = f => round2(list.reduce((a, i) => a + f(i), 0));
        const kpi = (id, label, value, cls = '') => `<div class="card kpi" data-kid="${id}"><div class="k-label">${esc(label)}</div><div class="k-value num ${cls}">${value}</div></div>`;
        if (dated) {
          const q2 = sum(i => (sel.entered.get(i.id) || {}).qty || 0);
          const v2 = sum(i => ((sel.entered.get(i.id) || {}).qty || 0) * (i.price || 0));
          return `<div class="kpis fin-kpis">${kpi('enteredQ', t('stock.entered'), `+${fmtQty(q2)}`, 'pos-val')}${kpi('enteredV', t('stock.kpiEnteredValue'), money(v2))}${kpi('products', t('common.products'), list.length)}</div>`;
        }
        return `<div class="kpis fin-kpis" data-kpis="stock">
          ${kpi('units', t('count.units'), fmtQty(sum(i => Math.max(0, i.stock))))}
          ${kpi('value', t('count.valueRetail'), money(sum(i => Math.max(0, i.stock) * (i.price || 0))))}
          ${kpi('products', t('common.products'), list.length)}
          ${kpi('low', t('stock.sit.low'), list.filter(stockIsLow).length, list.some(stockIsLow) ? 'neg-val' : '')}
          ${kpi('out', t('stock.sit.out'), list.filter(i => i.stock <= 0).length, list.some(i => i.stock <= 0) ? 'neg-val' : '')}
          ${kpi('entered', t('stock.kpiEntered'), `+${fmtQty(sum(i => (sel.entered.get(i.id) || {}).qty || 0))}`)}
          ${NOCOST() ? '' : kpi('cost', t('count.valueCost'), money(sum(i => Math.max(0, i.stock) * (i.cost || 0))))}
        </div>`;
      })()}
      ${sits.includes('new') && !App.stockFrom && sel.from ? `<p class="muted small" style="margin:-4px 0 10px">${esc(t('stock.lastDayHint', { date: fmtEntryDate(sel.from) }))}</p>` : ''}
      <div class="card table-wrap">${list.length ? `<table class="table fit">
        <thead><tr><th>${esc(t('stock.item'))}</th><th class="right">${esc(t(isNew ? 'stock.entered' : 'stock.inStock'))}</th><th>${esc(t(isNew ? 'stock.entryDate' : 'stock.lastEntry'))}</th></tr></thead>
        <tbody>${rows}</tbody>
        <tfoot><tr class="total-row"><td>${esc(t('totals.total'))} <span class="muted small">(${esc(t('stock.itemsN', { n: list.length }))})</span></td>
          <td class="right num">${isNew ? `+${fmtQty(round2(list.reduce((a, i) => a + sel.entered.get(i.id).qty, 0)))}` : fmtQty(round2(list.reduce((a, i) => a + Math.max(0, i.stock), 0)))}</td><td></td></tr></tfoot></table>${list.length > STOCK_ROWS && !q ? `<button class="fold-toggle" id="stock-more" type="button">${esc(showAll ? t('sup.seeLess') : t('sup.seeAll', { n: list.length }))}</button>` : ''}` : `<div class="empty">${esc(t(q || cf !== 'all' || sits.length || App.stockFrom ? 'sales.noItemsFound' : 'stock.noTracked'))}</div>`}</div>
      ${dated && list.length ? `<button class="btn danger block" id="del-day" style="margin-top:14px">${icon('trash')} ${esc(t('stock.delDay', { n: list.length }))}</button>` : ''}
    </div>`;
  if (!dated) arrangeKpis(main, 'stock', ['units', 'value', 'low', 'out']);
  const more = $('#stock-more', main);
  if (more) more.addEventListener('click', () => { App.stockAll = !App.stockAll; render(); });
  // Apagar de uma vez as entradas dos produtos mostrados, nas datas escolhidas (ex.: stock inicial registado em duplicado).
  const delDay = $('#del-day', main);
  if (delDay) delDay.addEventListener('click', async () => {
    const ids = new Set(list.map(i => i.id));
    const ents = Store.data.stockEntries.filter(e => e.type === 'in' && ids.has(e.itemId) && e.date >= sel.from && e.date <= sel.to);
    const qty = round2(ents.reduce((a, e) => a + e.qty, 0));
    if (!await confirmDialog(t('stock.delDayConfirm', { n: ents.length, qty: fmtQty(qty), date: dateLabel }), t('common.delete'), true)) return;
    guard(() => {
      for (const e of ents) Store.removeStockEntry(e.id);
      App.stockFrom = ''; App.stockTo = '';
      render(); toast(t('stock.delDayDone', { n: ents.length }));
    });
  });
  $('#ss').addEventListener('click', () => multiPickModal({
    title: t('stock.situation'), allLabel: t('stock.sit.all'), selected: sits,
    options: SITS.map(k => ({ id: k, name: t(`stock.sit.${k}`) })),
    onApply: v => { App.stockSits = v; render(); },
  }));
  $('#sd').addEventListener('click', stockDatesModal);
  if ($('#sx')) $('#sx').addEventListener('click', () => {
    const catName = catLabel(cats, true);
    const sitName = sitLabel(sits, true);
    const range = sel.from ? (sel.from === sel.to ? fmtEntryDate(sel.from) : `${fmtEntryDate(sel.from)} – ${fmtEntryDate(sel.to)}`) : '';
    const catOf = i => (Store.find('categories', i.categoryId) || {}).name || '';
    exportModal({
      title: t('stock.xpTitle'),
      subtitle: [catName, sitName, !sits.length || sits.includes('new') ? range : ''].filter(Boolean).join(' · '),
      file: 'stock', notes: stockNotes(sel, sits, list),
      ...(isNew ? {
        columns: [t('stock.item'), t('items.category'), t('stock.entryDate'), t('stock.entered'), t('items.price')],
        numeric: [3, 4],
        rows: list.map(i => [dn(i), catOf(i), fmtEntryDate(sel.entered.get(i.id).last), round2(sel.entered.get(i.id).qty), i.price]),
        totals: [t('totals.total'), '', '', round2(list.reduce((a, i) => a + sel.entered.get(i.id).qty, 0)), ''],
      } : {
        columns: [t('stock.item'), t('items.category'), t('items.price'), t('stock.inStock'), t('stock.lastEntry')],
        numeric: [2, 3],
        rows: list.map(i => { const l = sel.lastEntry(i.id); return [dn(i), catOf(i), i.price, round2(i.stock), l ? fmtEntryDate(l) : '—']; }),
        totals: [t('totals.total'), '', '', round2(list.reduce((a, i) => a + Math.max(0, i.stock), 0)), ''],
      }),
    });
  });
  const sq = $('#sq');
  sq.addEventListener('input', () => {
    App.stockQ = sq.value;
    const pos = sq.selectionStart;
    render();
    const again = $('#sq'); again.focus(); again.setSelectionRange(pos, pos);
  });
  $('#sc').addEventListener('click', () => multiPickModal({ cards: 'stock',
    title: t('items.category'), allLabel: t('stock.allCats'), options: catOptions(), selected: cats,
    onApply: v => { App.stockCats = v; render(); },
  }));
  $$('tr[data-id]', main).forEach(tr => tr.addEventListener('click', () => itemStockModal(tr.dataset.id)));
  if (App.stockOpen) { const id = App.stockOpen; App.stockOpen = null; setTimeout(() => itemStockModal(id)); }
}

const SITS = ['new', 'low', 'out'];
// Nome do filtro de situações: "Todos", o nome da única escolhida ou "N situações" (full: todos os nomes).
const sitLabel = (sits, full = false) => (!sits.length ? t('stock.sit.all') : full || sits.length === 1 ? sits.map(k => t(`stock.sit.${k}`)).join(', ') : t('stock.sitsN', { n: sits.length }));

// Nome do filtro de categorias: "Todas", o nome da única escolhida ou "N categorias" (full: todos os nomes).
function catLabel(cats, full = false, all = t('stock.allCats')) {
  if (!cats.length) return all;
  const names = cats.map(c => (c === 'none' ? t('items.noCategory') : Store.find('categories', c).name));
  return full || names.length === 1 ? names.join(', ') : t('stock.catsN', { n: names.length });
}

// Escolha de várias opções com caixas de seleção. "Todas" = nenhuma escolhida.
// extras: opções à parte (ex.: "Só stock baixo"), que não mexem em "Todas".
function multiPickModal({ title, allLabel, options, selected, extras = [], extraSelected = [], onApply, cards = null }) {
  const box = (o, on) => `<label class="check cat-check"><input type="checkbox" value="${esc(o.id)}" ${on ? 'checked' : ''}>${o.color ? `<span class="swatch" style="background:${esc(o.color)}"></span>` : ''}${esc(o.name)}</label>`;
  const m = openModal({
    title,
    autofocus: false,
    body: `
      <label class="check cat-check cat-all"><input type="checkbox" id="ca" ${selected.length ? '' : 'checked'}> <b>${esc(allLabel)}</b></label>
      <div id="cb">${options.map(o => box(o, selected.includes(o.id))).join('')}</div>
      ${extras.length ? `<div id="cx" class="cat-extras">${extras.map(o => box(o, extraSelected.includes(o.id))).join('')}</div>` : ''}
      ${cards ? cardsSectionHtml(cards) : ''}`,
    footer: `<button class="btn primary" data-ok>${esc(t('common.apply'))}</button>`,
  });
  const all = $('#ca', m), boxes = $$('#cb input', m);
  // "Todas" desmarca as outras; marcar uma opção desmarca "Todas".
  all.addEventListener('change', () => { if (all.checked) boxes.forEach(b => { b.checked = false; }); else if (!boxes.some(b => b.checked)) all.checked = true; });
  boxes.forEach(b => b.addEventListener('change', () => { all.checked = !boxes.some(x => x.checked); }));
  $('[data-ok]', m).onclick = () => {
    const picked = boxes.filter(b => b.checked).map(b => b.value);
    if (cards) saveCardsSection(m, cards);
    onApply(picked.length === options.length ? [] : picked, $$('#cx input', m).filter(b => b.checked).map(b => b.value));
    closeModal();
  };  return m;
}

// Opções de categoria para as janelas de escolha (com "Sem categoria" no fim).
const catOptions = (withNone = true) => [...byLayout(Store.data.categories, 'order.cats').map(c => ({ id: c.id, name: c.name, color: c.color })), ...(withNone ? [{ id: 'none', name: t('items.noCategory') }] : [])];
// Categoria efetiva de um produto ('none' quando não tem ou foi apagada).
const catKey = i => (i.categoryId && Store.find('categories', i.categoryId) ? i.categoryId : 'none');
const validCats = list => (list || []).filter(c => c === 'none' || Store.find('categories', c));

// Intervalo de datas de entrada para filtrar o stock (vazio = dia da última entrada).
function stockDatesModal() {
  const m = openModal({
    title: t('stock.dates'),
    autofocus: false,
    body: `
      <p class="muted small">${esc(t('stock.datesHint'))}</p>
      <div class="row">
        <label class="field"><span>${esc(t('reports.from'))}</span><input class="input" type="date" id="df" value="${esc(App.stockFrom || '')}"></label>
        <label class="field"><span>${esc(t('reports.to'))}</span><input class="input" type="date" id="dt" value="${esc(App.stockTo || '')}"></label>
      </div>`,
    footer: `<button class="btn" data-clear>${esc(t('stock.allDates'))}</button><button class="btn primary" data-ok>${esc(t('common.apply'))}</button>`,
  });
  $('[data-clear]', m).onclick = () => { App.stockFrom = App.stockTo = ''; closeModal(); render(); };
  $('[data-ok]', m).onclick = () => {
    let f = $('#df', m).value, tt = $('#dt', m).value || f;
    f = f || tt;
    if (!f) { toast(t('reports.needDates'), true); return; }
    if (f > tt) [f, tt] = [tt, f];
    App.stockFrom = f; App.stockTo = tt;
    closeModal(); render();
  };
}

// Stock tirado duas vezes: "Tirado: stock sem data" depois de uma contagem que já tinha acertado o stock.
function doubleRemovalsModal() {
  if (!need('editData')) return;
  const list = Store.doubleRemovals();
  const m = openModal({ title: t('dbl.title'), autofocus: false,
    body: `<p class="muted small" style="margin:0 0 10px">${esc(t('dbl.hint'))}</p>
      <div class="uc-list">${list.map(x => `<div class="uc-li"><span>${esc(dn(x.item))}<small class="muted" style="display:block;font-size:11.5px">${esc(fmtEntryDate(x.entry.date))} · ${fmtQty(x.entry.qty)} · ${esc(x.entry.note || '')}</small></span><b><span class="neg-val">${fmtQty(x.now)}</span> → <span class="pos-val">${fmtQty(x.after)}</span></b></div>`).join('')}</div>`,
    footer: list.length ? `<button class="btn primary" data-ok>${esc(t('dbl.undo', { n: list.length }))}</button>` : '' });
  const ok = $('[data-ok]', m);
  if (ok) ok.onclick = () => guard(() => { const n = Store.undoDoubleRemovals(); App.stale = true; toast(t('dbl.done', { n })); closeModal(); render(); });
}

// Stock de um item, repartido pelas datas de entrada, e o histórico de entradas e ajustes.
// Stock sem data de entrada: dar-lhe uma data, ou tirá-lo do stock.
function unknownStockModal(itemId, unknown, back) {
  const item = Store.find('items', itemId);
  const today = dayKey(new Date());
  let mode = 'date';
  const m = openModal({ title: `${t('stock.noDate')} · ${dn(item)}`, autofocus: false,
    body: `<p class="muted small" style="margin:0 0 10px">${esc(t('unk.hint', { n: fmtQty(unknown) }))}</p>
      <div class="seg" style="margin-bottom:12px"><button type="button" data-mode="date">${esc(t('unk.date'))}</button><button type="button" data-mode="remove">${esc(t('unk.remove'))}</button></div>
      <div class="row">
        <label class="field"><span>${esc(t('stock.qty'))}</span><input class="input" id="uq" inputmode="decimal" value="${fmtQty(unknown)}"></label>
        <label class="field"><span id="ud-l">${esc(t('stock.entryDate'))}</span><input class="input" type="date" id="ud" value="${today}" max="${today}"></label>
      </div>
      <p class="muted small" id="u-note"></p>`,
    footer: `<button class="btn primary" data-ok>${esc(t('common.save'))}</button>` });
  if (back) onModalClose(m, back);
  const paint = () => {
    $$('[data-mode]', m).forEach(b => b.classList.toggle('active', b.dataset.mode === mode));
    $('#u-note', m).textContent = t(mode === 'date' ? 'unk.dateNote' : 'unk.removeNote');
    $('#ud-l', m).textContent = t(mode === 'date' ? 'stock.entryDate' : 'unk.removeDate');
  };
  $$('[data-mode]', m).forEach(b => b.addEventListener('click', () => { mode = b.dataset.mode; paint(); }));
  paint();
  $('[data-ok]', m).onclick = () => guard(() => {
    const q = num($('#uq', m).value), d = $('#ud', m).value;
    if (!(q > 0) || q > unknown + 1e-9) throw new Error('err.invalidQty');
    if (mode !== 'date' && q > (Number(item.stock) || 0) + 1e-9) throw new Error('err.negStock');
    if (mode === 'date') Store.dateUnknownStock(itemId, q, d, App.user.id, t('unk.noteDated'));
    else { const e = Store.addStockEntry({ itemId, type: 'adjust', reason: 'manual', qty: -q, date: d, note: t('unk.noteRemoved') }, App.user.id); if (e) { e.unkRemoved = true; Store.save(); } }
    toast(t('stock.edited')); App.stale = true; render(); if (back) back(); else closeModal();
  });
}

// Corrigir uma entrada ou um ajuste já registado: data, quantidade, nota (e custo, nas entradas).
function entryEditModal(id, back) {
  if (!need('fixStock') || !need('editData')) return;
  const e = Store.find('stockEntries', id);
  if (!e) return;
  const today = dayKey(new Date());
  let kind = e.type === 'in' ? 'in' : (e.reason || 'manual');
  const kinds = [['in', 'stock.in'], ['break', 'adj.break'], ['loss', 'adj.loss'], ['manual', 'fix.kindAdjust']];
  const items = Store.data.items.filter(i => i.trackStock || i.id === e.itemId).sort((a, b) => a.name.localeCompare(b.name, 'pt'));
  const m = openModal({ title: t('fix.moveTitle'), autofocus: false,
    body: `<form id="eef">
      ${e.dated ? '' : `<div class="field"><span>${esc(t('fix.kind'))}</span><div class="cnt-tabs" style="margin:4px 0 0">${kinds.map(([k, l]) => `<button type="button" data-kind="${k}">${esc(t(l))}</button>`).join('')}</div></div>
      <label class="field"><span>${esc(t('fix.product'))}</span><select class="input" name="itemId">${items.map(i => `<option value="${i.id}" ${i.id === e.itemId ? 'selected' : ''}>${esc(dn(i))}</option>`).join('')}</select></label>`}
      <div class="row">
        <label class="field"><span>${esc(t('stock.qty'))}</span><input class="input" name="qty" inputmode="decimal" value="${fmtQty(kind === 'in' || kind === 'manual' ? e.qty : -e.qty)}"></label>
        <label class="field"><span>${esc(t('stock.entryDate'))}</span><input class="input" type="date" name="date" value="${e.date}" max="${today}"></label>
      </div>
      <label class="field" id="ee-cost"><span>${esc(t('fix.unitPrice'))}</span><input class="input" name="cost" inputmode="decimal" value="${e.cost == null ? '' : e.cost}"></label>
      <label class="field"><span>${esc(t('stock.note'))}</span><input class="input" name="note" value="${esc(e.note || '')}"></label>
      <p class="muted small" id="ee-hint"></p></form>`,
    footer: `<button class="btn danger left" data-del>${esc(t('common.delete'))}</button><button class="btn primary" data-ok>${esc(t('common.save'))}</button>` });
  if (back) onModalClose(m, back);
  const paint = () => {
    $$('[data-kind]', m).forEach(b => b.classList.toggle('on', b.dataset.kind === kind));
    $('#ee-cost', m).hidden = kind !== 'in';
    $('#ee-hint', m).textContent = t(kind === 'manual' ? 'fix.hintManual' : kind === 'in' ? 'fix.hintIn' : 'fix.hintOut');
  };
  $$('[data-kind]', m).forEach(b => b.addEventListener('click', () => { kind = b.dataset.kind; paint(); }));
  paint();
  const done = () => { App.stale = true; render(); if (back) back(); else closeModal(); };
  const ok = () => guard(() => {
    const f = formObj($('#eef', m));
    Store.updateStockEntry(e.id, { date: f.date, qty: num(f.qty), note: f.note, kind, ...(f.itemId ? { itemId: f.itemId } : {}), ...(kind === 'in' ? { cost: f.cost === '' ? null : num(f.cost) } : {}) }, App.user.id);
    toast(t('stock.edited')); done();
  });
  $('[data-ok]', m).onclick = ok;
  $('[data-del]', m).onclick = async () => {
    if (!await confirmDialog(t('stock.deleteConfirm', { qty: fmtQty(e.qty), date: fmtEntryDate(e.date) }), t('common.delete'), true)) { entryEditModal(id, back); return; }
    Store.removeStockEntry(e.id); toast(t('fix.deleted')); done();
  };
  $('#eef', m).addEventListener('submit', ev => { ev.preventDefault(); ok(); });
}

// Gestão do stock de um produto (no Stock): stock certo (sem "diferença"), alerta de stock baixo,
// controlar stock e todos os movimentos, cada um corrigível.
function itemStockModal(itemId, back) {
  // Sem permissão para corrigir stock: só regista entradas (se puder).
  if (!can('fixStock')) { if (can('stockIn')) stockEntryModal({ itemId, type: 'in' }); else toast(t('perm.denied'), true); return; }
  const item = Store.find('items', itemId);
  if (!item) return;
  const again = () => itemStockModal(itemId, back);
  const { unknown } = item.trackStock && !Store.wasCounted(itemId) ? Store.stockLots(itemId) : { unknown: 0 };
  const moves = Store.entriesFor(itemId).slice().reverse();
  const kindOf = e => (e.countId ? t('stock.tabCount') : e.open ? t('pack.open') : e.type === 'in' ? t('stock.in') : e.reason && e.reason !== 'manual' ? t(`adj.${e.reason}`) : t('fix.kindAdjust'));
  const sign = q => (q > 0 ? `+${fmtQty(q)}` : `−${fmtQty(-q)}`);
  const m = openModal({ title: dn(item), autofocus: false,
    body: `<form id="ixf">
      <div class="row">
        <label class="field"><span>${esc(t('fix.stockLabel'))}</span><input class="input" name="stock" inputmode="decimal" value="${fmtQty(item.stock)}" ${item.trackStock ? '' : 'disabled'}></label>
        <label class="field"><span>${esc(t('items.lowStockAlert'))}</span><input class="input" name="lowStock" inputmode="decimal" value="${item.lowStock ?? 5}"></label>
      </div>
      <label class="check" style="margin:-4px 0 6px"><input type="checkbox" name="trackStock" ${item.trackStock ? 'checked' : ''}> ${esc(t('items.trackStock'))}</label>
      ${item.trackStock ? `<p class="muted small" style="margin:0 0 14px">${esc(t('fix.stockHint'))}</p>` : ''}
    </form>
    ${item.trackStock ? `<h3 class="modal-sub">${esc(t('fix.moves'))}</h3>
    <div class="fix-moves">
      ${unknown > 0 ? `<button type="button" class="fix-move" data-unk><span><b>${esc(t('stock.noDate'))} <span class="pos-val">+${fmtQty(unknown)}</span></b><small>${esc(t('fix.unkHint'))}</small></span>${icon('edit')}</button>` : ''}
      ${moves.map(e => `<button type="button" class="fix-move ${e.countId ? 'locked' : ''}" data-mv="${e.id}">
        <span><b>${esc(kindOf(e))} <span class="${e.qty < 0 ? 'neg-val' : 'pos-val'}">${sign(e.qty)}</span>${e.reason === 'loss' || e.reason === 'break' ? ` <span class="badge ${e.justified ? '' : 'danger'} just-tog" data-just="${e.id}">${esc(t(e.justified ? 'adj.isJustified' : 'adj.notJustified'))}</span>` : ''}</b><small>${esc(fmtEntryDate(e.date))}${e.note ? ` · ${esc(e.note)}` : ''}${e.type === 'in' && e.cost != null ? ` · ${money(e.cost)}` : ''}</small></span>
        ${e.countId ? '' : e.open ? icon('undo') : icon('edit')}</button>`).join('') || `<div class="empty">${esc(t('stock.none'))}</div>`}
    </div>` : ''}`,
    footer: `${item.trackStock ? `<button class="btn" data-add>+ ${esc(t('fix.addMove'))}</button>` : ''}${item.trackStock && item.opensInto && Store.find('items', item.opensInto) ? `<button class="btn" data-open>${icon('layers')} ${esc(t('pack.open'))}</button>` : ''}<button class="btn primary" data-ok>${esc(t('common.save'))}</button>` });
  if (back) onModalClose(m, back);
  const openBtn = $('[data-open]', m);
  if (openBtn) openBtn.onclick = () => openPackModal(itemId, again);
  $$('[data-just]', m).forEach(b => b.addEventListener('click', ev => {
    ev.stopPropagation();
    guard(() => { const e = Store.find('stockEntries', b.dataset.just); Store.setJustified(e.id, !e.justified); toast(t(e.justified ? 'adj.isJustified' : 'adj.notJustified')); render(); again(); });
  }));
  $$('[data-mv]', m).forEach(b => b.addEventListener('click', () => {
    const e = Store.find('stockEntries', b.dataset.mv);
    if (e.countId) return toast(t('fix.fromCount'), true);
    if (e.open) return openUndoModal(e.open, again);
    return entryEditModal(e.id, again);
  }));
  const unk = $('[data-unk]', m);
  if (unk) unk.addEventListener('click', () => unknownStockModal(itemId, unknown, again));
  const add = $('[data-add]', m);
  if (add) add.onclick = () => stockEntryModal({ itemId, type: 'in', back: again });
  $('[data-ok]', m).onclick = () => guard(() => {
    const f = formObj($('#ixf', m));
    if (item.trackStock && (String(f.stock || '').trim() === '' || num(f.stock) < 0)) return toast(t('err.invalidQty'), true);
    Store.upsert('items', Object.assign({}, item, { lowStock: round2(num(f.lowStock)), trackStock: !!f.trackStock }));
    if (item.trackStock && f.trackStock) {
      const d = round2(num(f.stock) - Store.find('items', itemId).stock);
      if (d !== 0) Store.addStockEntry({ itemId, type: 'adjust', reason: 'manual', qty: d, date: dayKey(new Date()), note: t('fix.note') }, App.user.id);
    }
    toast(t('fix.savedStock')); App.stale = true; render();
    if (back) back(); else closeModal();
    return undefined;
  });
}

// Juntar produtos repetidos: cada repetido escolhe o produto com que se junta (ou fica como está).
function duplicatesModal() {
  const dups = Store.findDuplicates();
  const desc = i => `${catLabelOf(i)} · ${t('stock.inStock')}: ${i.trackStock ? fmtQty(i.stock) : '—'} · ${money(i.price)}`;
  const m = openModal({
    title: t('dup.title'),
    autofocus: false,
    body: dups.length ? `<p class="muted small">${esc(t('dup.hint'))}</p>
      ${dups.map((x, k) => `<div class="dup-row">
        <label class="check" style="margin:0"><input type="checkbox" data-k="${k}" checked> <b>${esc(x.drop.name)}</b></label>
        <div class="muted small">${esc(desc(x.drop))}</div>
        <label class="field" style="margin:8px 0 0"><span>${esc(t('dup.into'))}</span><select class="input" data-t="${k}">
          ${x.targets.map(tg => `<option value="${tg.id}">${esc(tg.name)} — ${esc(desc(tg))}</option>`).join('')}</select></label>
      </div>`).join('')}` : `<p class="muted">${esc(t('dup.none'))}</p>`,
    footer: dups.length ? `<button class="btn primary" data-ok>${esc(t('dup.merge'))}</button>` : '',
  });
  if (!dups.length) return;
  $('[data-ok]', m).onclick = async () => {
    const picks = $$('[data-k]', m).filter(b => b.checked).map(b => [dups[+b.dataset.k].drop.id, $(`[data-t="${b.dataset.k}"]`, m).value]);
    if (!picks.length) return closeModal();
    if (!await confirmDialog(t('dup.confirm', { n: picks.length }), t('dup.merge'))) return duplicatesModal();
    guard(() => { for (const [drop, keep] of picks) if (Store.find('items', drop)) Store.mergeItems(keep, drop); });
    render(); toast(t('dup.done', { n: picks.length }));
  };
}

// Caixa aberta (os dois lados: −caixa e +lâminas). Desfazer apaga os dois e repõe o stock.
function openUndoModal(group, back) {
  if (!need('fixStock') || !need('editData')) return;
  const lines = Store.data.stockEntries.filter(x => x.open === group);
  if (!lines.length) return;
  const who = (Store.find('employees', lines[0].employeeId) || {}).name;
  const sign = q => (q > 0 ? `+${fmtQty(q)}` : `−${fmtQty(-q)}`);
  const m = openModal({ title: t('pack.opened'), autofocus: false,
    body: `<div class="stat-rows">${lines.map(x => { const it = Store.find('items', x.itemId); return `<div class="s-row"><span>${esc(it ? dn(it) : '?')}</span><span class="num ${x.qty < 0 ? 'neg-val' : 'pos-val'}">${sign(x.qty)}</span></div>`; }).join('')}</div>
      <p class="muted small" style="margin:10px 2px 0">${esc(fmtEntryDate(lines[0].date))}${who ? ` · ${esc(who)}` : ''}</p>
      <p class="muted small" style="margin:6px 2px 0">${esc(t('pack.undoHint'))}</p>`,
    footer: `<button class="btn danger" data-undo>${icon('undo')} ${esc(t('pack.undo'))}</button>` });
  if (back) onModalClose(m, back);
  $('[data-undo]', m).onclick = async () => {
    if (!await confirmDialog(t('pack.undoQ'), t('pack.undo'), true)) { openUndoModal(group, back); return; }
    guard(() => { Store.removeStockEntry(lines[0].id); toast(t('pack.undone')); App.stale = true; render(); if (back) back(); else closeModal(); });
  };
}

// Abrir caixas: −n na caixa e +n × (lâminas por caixa) no produto ligado.
function openPackModal(boxId, back) {
  const box = Store.find('items', boxId);
  const target = box && Store.find('items', box.opensInto);
  if (!target) return;
  const per = Number(box.opensQty) || 1;
  const m = openModal({
    title: `${t('pack.open')} · ${box.name}`,
    body: `
      <p class="muted">${esc(t('pack.openHint', { per, target: Store.find('categories', target.categoryId) ? `${target.name} (${Store.find('categories', target.categoryId).name})` : target.name }))}</p>
      <label class="field"><span>${esc(t('pack.howMany'))}</span><input class="input" id="pn" inputmode="numeric" value="1"></label>
      <div class="change-box"><span id="pr"></span></div>`,
    footer: `<button class="btn primary" data-ok>${esc(t('pack.open'))}</button>`,
  });
  const n = () => Math.round(num($('#pn', m).value));
  const label = i => { const c = Store.find('categories', i.categoryId); return c ? `${i.name} (${c.name})` : i.name; };
  const paint = () => { $('#pr', m).textContent = t('pack.result', { box: label(box), boxLeft: fmtQty(round2(box.stock - n())), target: label(target), targetNew: fmtQty(round2(target.stock + n() * per)) }); };
  $('#pn', m).addEventListener('input', paint); paint();
  onModalClose(m, () => (back ? back() : closeModal()));
  $('[data-ok]', m).onclick = () => guard(() => {
    const r = Store.openPack(box.id, n(), App.user.id);
    toast(t('pack.done', { n: n(), qty: fmtQty(r.qty), target: target.name }));
    render(); back ? back() : closeModal();
  });
}

// Ligar as caixas às lâminas pelo nome: mostra as ligações sugeridas para confirmar.
function packLinksModal() {
  const sug = Store.suggestPackLinks();
  const catName = i => (Store.find('categories', i.categoryId) || {}).name || '';
  const m = openModal({
    title: t('pack.linkTitle'),
    autofocus: false,
    body: sug.length ? `
      <p class="muted small">${esc(t('pack.linkHint'))}</p>
      <label class="field" style="max-width:220px"><span>${esc(t('pack.qty'))}</span><input class="input" id="lq" inputmode="numeric" value="4"></label>
      ${sug.map((x, k) => `<label class="check cat-check"><input type="checkbox" data-k="${k}" checked>
        <span>${esc(x.box.name)} <span class="muted small">(${esc(catName(x.box))})</span> → ${esc(x.target.name)} <span class="muted small">(${esc(catName(x.target))})</span>${x.linked ? ` <span class="badge">${esc(t('pack.linked'))}</span>` : ''}</span></label>`).join('')}`
      : `<p class="muted">${esc(t('pack.noSuggestions'))}</p>`,
    footer: sug.length ? `<button class="btn primary" data-ok>${esc(t('pack.linkSave'))}</button>` : '',
  });
  if (!sug.length) return;
  $('[data-ok]', m).onclick = () => {
    const per = Math.max(1, Math.round(num($('#lq', m).value)) || 4);
    let n = 0;
    $$('[data-k]', m).forEach(b => { if (!b.checked) return; const x = sug[+b.dataset.k]; Object.assign(x.box, { opensInto: x.target.id, opensQty: per }); n++; });
    Store.save(); closeModal(); render(); toast(t('pack.linkedN', { n }));
  };
}

// Registar uma entrada (com data) ou um ajuste de stock.
function stockEntryModal({ itemId = '', type = 'in', back = false }) {
  if (!can('stockIn') && !can('fixStock')) { toast(t('perm.denied'), true); return; }
  if (type === 'adjust' && !can('fixStock')) type = 'in';
  if (type === 'in' && !can('stockIn')) type = 'adjust';
  const tracked = Store.data.items.filter(i => i.trackStock).sort((a, b) => a.name.localeCompare(b.name, 'pt'));
  if (!tracked.length) { toast(t('stock.noTracked'), true); return; }
  let kind = type;
  const today = dayKey(new Date());
  const costOf = id => { const it = Store.find('items', id); return it ? it.cost : ''; };
  const m = openModal({
    title: t('stock.add'),
    autofocus: false,
    body: `<form id="sf">
      <label class="field"><span>${esc(t('stock.item'))} *</span><select class="input" name="itemId" required>
        <option value="">${esc(t('stock.chooseItem'))}</option>
        ${tracked.map(i => `<option value="${i.id}" ${i.id === itemId ? 'selected' : ''}>${esc(dn(i))} (${fmtQty(i.stock)})</option>`).join('')}
      </select></label>
      <div class="field"><span>${esc(t('stock.type'))}</span>
        <div class="seg">${can('stockIn') ? `<button type="button" data-k="in">${esc(t('stock.in'))}</button>` : ''}${can('fixStock') ? `<button type="button" data-k="adjust">${esc(t('stock.adjust'))}</button>` : ''}</div>
      </div>
      <div class="row">
        <label class="field"><span>${esc(t('stock.qty'))} *</span><input class="input" name="qty" inputmode="decimal" required></label>
        <label class="field"><span>${esc(t('stock.entryDate'))} *</span><input class="input" type="date" name="date" value="${today}" max="${today}" required></label>
      </div>
      <label class="field" id="reason-field"><span>${esc(t('adj.reason'))}</span><select class="input" name="reason">
        ${ADJUST_REASONS.filter(r => r !== 'internal').map(r => `<option value="${r}" ${r === 'manual' ? 'selected' : ''}>${esc(t(`adj.${r}`))}</option>`).join('')}</select></label>
      <label class="check" id="just-field"><input type="checkbox" name="justified"> ${esc(t('adj.justified'))}</label>
      <p class="muted small" id="adj-hint"></p>
      <label class="field cost-only" id="cost-field"><span>${esc(t('stock.unitCost'))}</span><input class="input" name="cost" inputmode="decimal" value="${costOf(itemId)}"></label>
      <label class="field"><span>${esc(t('stock.note'))}</span><input class="input" name="note" placeholder="${esc(t('stock.notePlaceholder'))}"></label>
    </form>`,
    footer: `<button class="btn primary" data-ok>${esc(t('common.save'))}</button>`,
  });
  const form = $('#sf', m);
  const paint = () => {
    $$('[data-k]', m).forEach(b => b.classList.toggle('active', b.dataset.k === kind));
    $('#adj-hint', m).hidden = kind !== 'adjust';
    $('#reason-field', m).hidden = kind !== 'adjust';
    $('#just-field', m).hidden = kind !== 'adjust' || !['loss', 'break'].includes(form.reason.value);
    $('#adj-hint', m).textContent = t(form.reason.value === 'manual' ? 'stock.adjustHint' : 'adj.outHint');
    $('#cost-field', m).hidden = kind !== 'in';
  };
  $$('[data-k]', m).forEach(b => b.addEventListener('click', () => { kind = b.dataset.k; paint(); }));
  form.itemId.addEventListener('change', () => { form.cost.value = costOf(form.itemId.value); });
  form.reason.addEventListener('change', paint);
  paint();
  const leave = () => { if (typeof back === 'function') back(); else if (back && itemId) itemStockModal(itemId); else closeModal(); };
  onModalClose(m, leave);
  const ok = () => guard(() => {
    const f = formObj(form);
    if (!f.itemId) { toast(t('stock.chooseItem'), true); return; }
    Store.addStockEntry({ itemId: f.itemId, type: kind, qty: num(f.qty), date: f.date, cost: kind === 'in' && f.cost !== '' ? num(f.cost) : null, note: f.note, reason: kind === 'adjust' ? f.reason : null, justified: !!f.justified }, App.user.id);
    toast(t('stock.saved'));
    render();
    if (typeof back === 'function') back(); else if (back) itemStockModal(f.itemId); else closeModal();
  });
  $('[data-ok]', m).onclick = ok;
  form.addEventListener('submit', e => { e.preventDefault(); ok(); });
}

// ================= Balanço (contagem física do stock) =================

// Valor a descontar: "−50,00", mas zero sem sinal.
const minus = v => (v ? `−${money(v)}` : money(0));
const signed = n => `${n > 0 ? '+' : ''}${fmtQty(n)}`;

// O menu Balanço tem dois separadores: contagem do stock e balanço financeiro.
// Separadores do menu Stock: Produtos · Stock · Contagem · Fecho (ou Financeiro sem consignação).
function stockTabList() {
  // Produtos (com Categorias dentro) · Stock · Contagem (com Balanço e Fecho dentro).
  return [['itens', 'oBox', 'stock.tabItems'], ['stock', 'oWarehouse', 'stock.tab'], ['count', 'oCount', 'stock.tabCount']];
}
function stockTabs(active) {
  const tabs = stockTabList();
  return `<div class="seg bal-tabs stock-tabs" role="tablist">${tabs.map(([k, ic, label]) =>
    `<button role="tab" data-st="${k}" class="${active === k ? 'active' : ''}" aria-selected="${active === k}">${icon(active === k && ic === 'oMoney' ? 'oDollar' : ic)}<span>${esc(t(label))}</span></button>`).join('')}</div>`;
}
// Ícones do topo (Gestão de stock): tocar e manter e arrastar muda a ordem dentro do grupo;
// o sino pode ainda sair do grupo para a esquerda ou para a direita (e voltar a entrar).
function topIconsDrag(top) {
  if (top.dataset.drag) return;
  top.dataset.drag = '1';
  const S = () => $('.stock-tabs', top) || top;
  let seg = S();
  let timer = null, drag = null, sx = 0, sy = 0;
  const save = () => {
    Layout.set('order.topIcons', [...seg.querySelectorAll('[data-tk]')].map(x => x.dataset.tk));
    const b = $('#top-bell', top);
    Layout.set('top.bellPos', !b || seg.contains(b) ? 'in' : b.nextElementSibling === seg ? 'before' : 'after');
  };
  top.addEventListener('pointerdown', e => {
    seg = S();
    const item = e.target.closest('[data-tk]');
    if (!item || e.button > 0) return;
    sx = e.clientX; sy = e.clientY; clearTimeout(timer);
    timer = setTimeout(() => {
      drag = { item };
      item.classList.add('dragging'); seg.classList.add('sorting');
      try { item.setPointerCapture(e.pointerId); } catch (er) { /* sem captura */ }
      if (navigator.vibrate) navigator.vibrate(15);
    }, e.pointerType === 'mouse' ? 250 : 450);
  });
  const move = e => {
    if (!drag) { if (timer && Math.hypot(e.clientX - sx, e.clientY - sy) > 10) { clearTimeout(timer); timer = null; } return; }
    e.preventDefault();
    const it = drag.item, r = seg.getBoundingClientRect();
    if (it.id === 'top-bell' && e.clientX < r.left - 6) { if (it.nextElementSibling !== seg) top.insertBefore(it, seg); return; }
    if (it.id === 'top-bell' && e.clientX > r.right + 6) { if (it.parentNode !== top || it.previousElementSibling !== seg) top.appendChild(it); return; }
    if (!seg.contains(it)) { // volta a entrar no grupo, do lado de onde vem
      if (e.clientX < r.left + r.width / 2) seg.insertBefore(it, seg.firstChild); else seg.appendChild(it);
      return;
    }
    const over = [...seg.querySelectorAll('[data-tk]')].find(x => { if (x === it) return false; const q = x.getBoundingClientRect(); return e.clientX >= q.left && e.clientX <= q.right; });
    if (!over) return;
    const list = [...seg.querySelectorAll('[data-tk]')];
    seg.insertBefore(it, list.indexOf(over) < list.indexOf(it) ? over : over.nextSibling);
  };
  window.addEventListener('pointermove', move); // na janela: ao mudar de sítio o ícone perde o "capture"
  const end = () => {
    clearTimeout(timer); timer = null;
    if (!drag) return;
    const { item } = drag; drag = null;
    item.classList.remove('dragging'); seg.classList.remove('sorting');
    const swallow = ev => { if (item.contains(ev.target)) { ev.stopPropagation(); ev.preventDefault(); } };
    window.addEventListener('click', swallow, { capture: true, once: true });
    setTimeout(() => window.removeEventListener('click', swallow, { capture: true }), 400);
    save();
  };
  window.addEventListener('pointerup', end);
  window.addEventListener('pointercancel', end);
  window.addEventListener('touchmove', e => { if (drag) e.preventDefault(); }, { passive: false });
  top.addEventListener('contextmenu', e => { if (drag || timer) e.preventDefault(); });
}

function bindStockTabs(root) {
  $$('[data-st]', root).forEach(b => b.addEventListener('click', () => {
    const k = b.dataset.st;
    if (['itens', 'stock', 'categorias'].includes(k)) { location.hash = `#${k}`; return; }
    App.balTab = 'stock'; App.sbPage = false;
    if (location.hash === '#balanco') render(); else location.hash = '#balanco';
  }));
}
function addStockTabs(main, active) {
  const page = $('.page', main);
  if (!page) return;
  // Produtos e Categorias partilham o ícone de Produtos: interruptor no topo da página.
  if (active === 'itens' || active === 'categorias') {
    page.insertAdjacentHTML('afterbegin', `<div class="cnt-tabs" role="tablist">${[['itens', 'stock.tabItems'], ['categorias', 'nav.categories']].map(([k, l]) =>
      `<button role="tab" data-pc="${k}" class="${k === active ? 'on' : ''}" aria-selected="${k === active}">${esc(t(l))}</button>`).join('')}</div>`);
    $$('[data-pc]', page).forEach(b => b.addEventListener('click', () => { location.hash = `#${b.dataset.pc}`; }));
    active = 'itens';
  }
  if (active === 'supplier' || active === 'finance') active = 'count';
  // Produtos repetidos baralham os números em todos os separadores: avisa logo por baixo.
  const n = Store.findDuplicates().length;
  // Separadores no cabeçalho (só ícones); o título passa a ser o nome do separador ativo.
  const top = $('#top-tabs');
  top.innerHTML = stockTabs(active);
  $$('[data-st]', top).forEach(b => { const lb = $('span', b).textContent; b.title = lb; b.setAttribute('aria-label', lb); b.dataset.tk = b.dataset.st; });
  bindStockTabs(top);
  // O sino entra no mesmo grupo; tocar e manter num ícone deixa mudar a ordem (fica guardada).
  const seg = $('.stock-tabs', top), bell = $('#top-bell');
  if (seg && bell) { bell.dataset.tk = 'bell'; seg.appendChild(bell); }
  if (seg) {
    byLayout([...seg.children].filter(x => x.dataset.tk), 'order.topIcons', x => x.dataset.tk).forEach(x => seg.appendChild(x));
    // O sino também pode sair do grupo (antes ou depois dele).
    const pos = Layout.get('top.bellPos');
    if (bell && pos === 'before') top.insertBefore(bell, seg); else if (bell && pos === 'after') top.appendChild(bell);
    topIconsDrag(top);
  }
  const cur = stockTabList().find(x => x[0] === active);
  if (cur) setTitle(t(cur[2]));
  if (n) page.insertAdjacentHTML('afterbegin', `<div class="notice warn">${icon('layers')}<div>${esc(t('dup.notice', { n }))} <a href="#" id="dup-open">${esc(t('dup.open'))}</a></div></div>`);
  const dup = $('#dup-open', page);
  if (dup) dup.addEventListener('click', e => { e.preventDefault(); duplicatesModal(); });
}

function viewCount(main) {
  // Venda à consignação: Stock (contagem) e Fecho (com o fornecedor). Sem ela: Stock e Financeiro.
  const tabs = CONSIGN() ? [['stock', 'clipboard', 'bal.tabStock'], ['supplier', 'credit', 'bal.tabClosing']]
    : [['stock', 'clipboard', 'bal.tabStock'], ['finance', 'wallet', 'bal.tabFinance']];
  let tab = App.balTab || 'stock';
  if (!tabs.some(x => x[0] === tab)) tab = 'stock';
  if (tab === 'finance') viewFinance(main); else if (tab === 'supplier') viewSupplier(main); else viewStockCount(main);
  addStockTabs(main, 'count');
  // Fecho/Financeiro abrem a partir dos passos da Contagem: a seta volta lá.
  if (tab !== 'stock') setBack(t(tab === 'supplier' ? 'bal.tabClosing' : 'bal.tabFinance'), () => { App.balTab = 'stock'; render(); });
}

const COUNT_SITS = ['todo', 'done', 'diff'];

// Contagem: "Com fornecedor/gestor" (balanço normal, conta no Fecho) ou "Sozinho" (verificação à parte).
const countKind = () => 'normal';

function viewStockCount(main) {
  const kind = countKind();
  const c = Store.currentCount(kind);
  if (!c) return viewCountHome(main);
  // Filtros: várias categorias e várias situações (vazio = todas).
  const cats = validCats(App.countCats);
  const sits = (App.countSits || []).filter(k => COUNT_SITS.includes(k));
  const q = (App.countQ || '').trim().toLowerCase();
  const rows = c.lines.map(l => ({ l, item: Store.find('items', l.itemId) })).filter(r => r.item && r.item.trackStock)
    .sort((a, b) => a.item.name.localeCompare(b.item.name, 'pt'));
  const done = rows.filter(r => r.l.counted != null).length;
  const sysOf = item => Store.countStock(c, item);
  const diffOf = r => (r.l.counted == null ? null : round2(r.l.counted - sysOf(r.item)));
  // Sobra numa lâmina com caixa ligada: sugere abrir caixa(s).
  const packHint = (item, d) => {
    const box = d > 0 ? Store.countPackSource(c, item.id) : null;
    if (!box) return '';
    const n = Math.max(1, Math.min(Math.ceil(d / (Number(box.opensQty) || 1)), Math.floor(sysOf(box))));
    return t('pack.countHint', { n });
  };
  const inSit = { todo: r => r.l.counted == null, done: r => r.l.counted != null, diff: r => diffOf(r) != null && diffOf(r) !== 0 };
  const shown = rows.filter(r => (!q || r.item.name.toLowerCase().includes(q))
    && (!cats.length || cats.includes(catKey(r.item)))
    && (!sits.length || sits.some(k => inSit[k](r))));
  const sitText = !sits.length ? t('count.filter.all') : sits.length === 1 ? t(`count.filter.${sits[0]}`) : t('stock.sitsN', { n: sits.length });
  main.innerHTML = `
    <div class="page count-page">
      <div class="card card-pad count-head">
        <div class="grow"><b>${esc(t(kind === 'check' ? 'chk.inProgress' : 'count.inProgress'))}</b>
          <div class="muted small">${c.day ? `<b>${esc(t('cb.countOf', { date: fmtEntryDate(c.day) }))}</b> · ` : ''}${esc(t('count.startedBy', { name: empName(c.employeeId), date: fmtDate(c.startedAt) }))}</div></div>
        <div class="count-progress"><b class="num">${done}</b><span class="muted">/ ${rows.length}</span></div>
        <div class="progress"><div style="width:${rows.length ? done / rows.length * 100 : 0}%"></div></div>
      </div>
      ${countToolsHtml(c)}
      <div class="page-head stock-head">
        <input class="input grow" id="cq" type="search" placeholder="${esc(t('stock.searchPlaceholder'))}" value="${esc(App.countQ || '')}">
        <button class="btn stock-dates ${cats.length ? 'on' : ''}" id="ccat" title="${esc(t('items.category'))}">${icon('layers')}<span>${esc(catLabel(cats))}</span></button>
      </div>
      <div class="page-head stock-head stock-filters">
        <button class="btn stock-dates ${sits.length ? 'on' : ''}" id="csit" title="${esc(t('stock.situation'))}">${icon('check')}<span>${esc(sitText)}</span></button>
        <span class="muted small count-shown">${esc(t('count.shownN', { n: shown.length, total: rows.length }))}</span>
      </div>
      <div class="card count-list">${shown.length ? shown.map(r => {
        const d = diffOf(r);
        return `<div class="count-row" data-id="${r.item.id}">
          <div class="count-name"><span class="swatch" style="background:${esc(r.item.color)}"></span>${esc(dn(r.item))}
            <div class="muted small">${esc(catLabelOf(r.item))} · ${esc(t('count.system'))}: <b class="num">${fmtQty(sysOf(r.item))}</b></div></div>
          <button class="btn small same" data-same title="${esc(t('count.same'))}" aria-label="${esc(t('count.same'))}">${icon('check')}</button>
          <input class="input count-input" inputmode="decimal" aria-label="${esc(t('count.counted'))}" placeholder="—" value="${r.l.counted == null ? '' : fmtQty(r.l.counted)}">
          <span class="diff ${d == null ? '' : d === 0 ? 'ok' : d < 0 ? 'neg' : 'pos'}">${d == null ? '' : d === 0 ? '✓' : signed(d)}</span>
          <span class="line-acts"><button class="icon-btn" data-line-del title="${esc(t('count.lineDel'))}" aria-label="${esc(t('count.lineDel'))}">${icon('trash')}</button></span>
          <button type="button" class="open-hint" data-openbox ${packHint(r.item, d) ? '' : 'hidden'}>${icon('layers')}<span>${esc(packHint(r.item, d))}</span></button>
        </div>`;
      }).join('') : `<div class="empty">${esc(t('count.noneShown'))}</div>`}</div>
      <div class="count-actions">
        <button class="btn danger" id="cancel-count">${esc(t(kind === 'check' ? 'chk.cancel' : 'count.cancel'))}</button>
        <button class="btn primary" id="finish-count">${esc(t(kind === 'check' ? 'chk.finish' : 'count.finish'))}</button>
      </div>
    </div>`;
  bindCountTools(main, c, null);
  const cq = $('#cq');
  cq.addEventListener('input', () => {
    App.countQ = cq.value; const pos = cq.selectionStart; render();
    const again = $('#cq'); again.focus(); again.setSelectionRange(pos, pos);
  });
  $('#ccat').addEventListener('click', () => multiPickModal({
    title: t('items.category'), allLabel: t('stock.allCats'), options: catOptions(), selected: cats,
    onApply: v => { App.countCats = v; render(); },
  }));
  $('#csit').addEventListener('click', () => multiPickModal({
    title: t('stock.situation'), allLabel: t('count.filter.all'), selected: sits,
    options: COUNT_SITS.map(k => ({ id: k, name: t(`count.filter.${k}`) })),
    onApply: v => { App.countSits = v; render(); },
  }));
  // Guardar cada contagem logo ao escrever, sem redesenhar a lista (o teclado não fecha).
  const paintRow = row => {
    const item = Store.find('items', row.dataset.id);
    const line = Store.currentCount(kind).lines.find(l => l.itemId === item.id);
    const d = line && line.counted != null ? round2(line.counted - sysOf(item)) : null;
    const el = $('.diff', row);
    const hint = packHint(item, d), hb = $('[data-openbox]', row);
    hb.hidden = !hint; $('span', hb).textContent = hint;
    el.className = `diff ${d == null ? '' : d === 0 ? 'ok' : d < 0 ? 'neg' : 'pos'}`;
    el.textContent = d == null ? '' : d === 0 ? '✓' : signed(d);
    const cur = Store.currentCount(kind);
    const n = cur.lines.filter(l => l.counted != null).length;
    $('.count-progress b').textContent = n;
    $('.progress div').style.width = `${rows.length ? n / rows.length * 100 : 0}%`;
  };
  $$('.count-row', main).forEach(row => {
    const input = $('.count-input', row);
    input.addEventListener('input', () => guard(() => {
      const v = input.value.trim();
      Store.setCounted(c.id, row.dataset.id, v === '' ? null : num(v));
      paintRow(row);
    }));
    $('[data-line-del]', row).addEventListener('click', () => guard(() => {
      Store.removeCountLine(c.id, row.dataset.id); toast(t('count.lineRemoved')); render();
    }));
    $('[data-openbox]', row).addEventListener('click', () => countOpenBoxModal(c, Store.find('items', row.dataset.id)));
    $('[data-same]', row).addEventListener('click', () => {
      const item = Store.find('items', row.dataset.id);
      input.value = fmtQty(sysOf(item));
      Store.setCounted(c.id, item.id, sysOf(item));
      paintRow(row);
    });
  });
  $('#cancel-count').addEventListener('click', async () => {
    if (!await confirmDialog(t(kind === 'check' ? 'chk.cancelConfirm' : 'count.cancelConfirm'), t(kind === 'check' ? 'chk.cancel' : 'count.cancel'), true)) return;
    Store.cancelCount(c.id); render();
  });
  $('#finish-count').addEventListener('click', () => countFinishModal(c));
}

// ================= Balanço de stock (período) =================
// Stock inicial + Entradas − Stock final = Saídas. Vive em Contagem → "Com fornecedor/gestor".

const SB_PERIODS = ['today', 'week', 'month', 'lastMonth', 'sinceClose', 'custom'];
const SB_OUT = ['sold', 'loss', 'break', 'internal', 'manual', 'diff', 'opened'];
const sbState = () => App.sb || (App.sb = { key: 'month', from: '', to: '', cats: [], q: '' });

function sbRange() {
  const p = sbState(), now = new Date(), today = dayKey(now);
  const day = (y, m, d) => dayKey(new Date(y, m, d));
  switch (p.key) {
    case 'today': return [today, today];
    case 'week': { const x = new Date(now); x.setDate(x.getDate() - ((x.getDay() + 6) % 7)); return [dayKey(x), today]; }
    case 'lastMonth': return [day(now.getFullYear(), now.getMonth() - 1, 1), day(now.getFullYear(), now.getMonth(), 0)];
    case 'sinceClose': { const s = Store.lastSettlement(); return [s ? dayKey(new Date(s.to)) : day(now.getFullYear(), now.getMonth(), 1), today]; }
    case 'custom': return [p.from || today, p.to && p.to >= (p.from || today) ? p.to : (p.from || today)];
    default: return [day(now.getFullYear(), now.getMonth(), 1), today];
  }
}
const sbDay = k => fmtEntryDate(k);
const sbPeriodText = (from, to) => (from === to ? sbDay(from) : `${sbDay(from)} → ${sbDay(to)}`);

// Dados do período com os filtros (categorias e pesquisa por produto).
function sbData() {
  const [from, to] = sbRange();
  const p = sbState();
  const bal = Store.stockBalance(from, to);
  const cats = validCats(p.cats);
  const q = norm((p.q || '').trim());
  const lines = bal.lines.filter(l => {
    const item = Store.find('items', l.itemId);
    return (!cats.length || (item && cats.includes(catKey(item)))) && (!q || norm(l.name).includes(q));
  });
  return { from, to, byCost: bal.byCost, lines, T: Store.balanceTotals(lines), cats };
}

const SB_CARDS = ['opening', 'in', 'available', 'final', 'out', 'diff'];
const sbCardsOn = () => (Layout.get('sb.cards') || SB_CARDS).filter(k => SB_CARDS.includes(k));
const sbRowsOn = () => (Layout.get('sb.rows') || SB_OUT).filter(k => SB_OUT.includes(k));
const sbCls = v => (v > 0 ? 'pos-val' : v < 0 ? 'neg-val' : '');
const sbSigned = v => (v > 0 ? `+${money(v)}` : v < 0 ? `−${money(-v)}` : money(0));

// Cartões + saídas por tipo (o mesmo HTML serve para o ecrã e para os balanços guardados).
function sbSummaryHtml(T, live) {
  const cardsOn = sbCardsOn(), rowsOn = sbRowsOn();
  const card = (id, k, label, value, qty, cls = '') => (!cardsOn.includes(id) ? '' : `<div class="card kpi sb-kpi ${live && k ? 'clickable' : ''}" ${live && k ? `data-mv="${k}"` : ''}>
    <div class="k-label">${esc(label)}</div><div class="k-value num ${cls}">${value}</div><div class="k-sub">${esc(t('sb.units', { n: fmtQty(qty) }))}</div></div>`);
  const outRow = k => {
    if (!rowsOn.includes(k)) return '';
    const v = k === 'diff' || k === 'opened' ? -T[`${k}Value`] : T[`${k}Value`];
    const q = k === 'diff' || k === 'opened' ? -T[k] : T[k];
    if (k !== 'sold' && !q && !v) return '';
    return `<div class="s-row ${live ? 'clickable' : ''}" ${live ? `data-mv="${k}"` : ''}><span>${esc(t(`sb.out.${k}`))} <small class="muted">${esc(t('sb.units', { n: fmtQty(q) }))}</small></span><span class="num ${k === 'diff' ? sbCls(T.diffValue) : ''}">${money(v)}</span></div>`;
  };
  return `<div class="kpis sb-kpis">
      ${card('opening', '', t('sb.opening'), money(T.openingValue), T.opening)}
      ${card('in', 'in', t('sb.in'), money(T.inValue), T.in, T.inValue > 0 ? 'pos-val' : '')}
      ${card('available', '', t('sb.available'), money(T.availableValue), T.available)}
      ${card('final', '', t('sb.final'), money(T.finalValue), T.final)}
      ${card('out', 'out', t('sb.out'), money(T.outValue), T.out, T.outValue < 0 ? 'neg-val' : '')}
      ${card('diff', 'diff', t('sb.diff'), sbSigned(T.diffValue), T.diff, sbCls(T.diffValue))}
    </div>
    <div class="sb-formula num">${money(T.openingValue)} + ${money(T.inValue)} − ${money(T.finalValue)} = <b>${money(T.outValue)}</b></div>
    <h4 class="sb-sub">${esc(t('sb.outBy'))}</h4>
    <div class="stat-rows sb-out">${SB_OUT.map(outRow).join('')}
      <div class="s-row strong"><span>= ${esc(t('sb.out'))}</span><span class="num">${money(T.outValue)}</span></div></div>`;
}

// Tabela por produto: quantidades; tocar numa linha mostra o detalhe com valores.
function sbTableHtml(lines, T) {
  const q = v => fmtQty(v);
  return `<div class="table-wrap"><table class="table fit vtbl sb-tbl">
    <thead><tr><th>${esc(t('stock.item'))}</th><th class="right">${esc(t('sb.colOpening'))}</th><th class="right">${esc(t('sb.colIn'))}</th><th class="right">${esc(t('sb.colOut'))}</th><th class="right">${esc(t('sb.colFinal'))}</th><th class="right">${esc(t('sb.colDiff'))}</th></tr></thead>
    <tbody>${lines.map(l => `<tr class="clickable" data-id="${l.itemId}"><td class="wrap">${esc(nameOf(l.itemId, l.name))}</td><td class="right num">${q(l.opening)}</td><td class="right num">${q(l.in)}</td>
      <td class="right num">${q(l.out)}</td><td class="right num">${q(l.final)}</td><td class="right num ${sbCls(l.diff)}">${l.diff ? signed(l.diff) : '—'}</td></tr>`).join('')}</tbody>
    <tfoot><tr class="total-row"><td>${esc(t('totals.total'))}</td><td class="right num">${q(T.opening)}</td><td class="right num">${q(T.in)}</td><td class="right num">${q(T.out)}</td><td class="right num">${q(T.final)}</td><td class="right num ${sbCls(T.diff)}">${T.diff ? signed(T.diff) : '—'}</td></tr></tfoot>
  </table></div>`;
}

function sbLineModal(l, back) {
  const row = (label, qty, strong = false, cls = '') => `<div class="s-row ${strong ? 'strong' : ''}"><span>${esc(label)} <small class="muted">${esc(t('sb.units', { n: fmtQty(qty) }))}</small></span><span class="num ${cls}">${money(qty * l.unit)}</span></div>`;
  const m = openModal({
    title: nameOf(l.itemId, l.name), autofocus: false,
    body: `<div class="stat-rows">${row(t('sb.opening'), l.opening)}${row(`+ ${t('sb.in')}`, l.in)}${row(`− ${t('sb.final')}`, l.final)}${row(`= ${t('sb.out')}`, l.out, true)}</div>
      <h4 class="sb-sub">${esc(t('sb.outBy'))}</h4>
      <div class="stat-rows">${SB_OUT.map(k => { const qn = k === 'diff' || k === 'opened' ? -l[k] : l[k]; return k === 'sold' || qn ? row(t(`sb.out.${k}`), qn, false, k === 'diff' ? sbCls(l.diff) : '') : ''; }).join('')}</div>
      <p class="muted small" style="margin:8px 0 0">${esc(t('sb.unitNote', { v: money(l.unit), kind: t(Store.showCost() ? 'sb.atCost' : 'sb.atPrice') }))}</p>`,
  });
  if (back) onModalClose(m, back);
}

function sbProductsModal(d) {
  const m = openModal({ title: `${t('sb.byProduct')} · ${sbPeriodText(d.from, d.to)}`, wide: true, autofocus: false,
    body: d.lines.length ? sbTableHtml(d.lines, d.T) : `<div class="empty">${esc(t('sb.none'))}</div>` });
  $$('tr[data-id]', m).forEach(tr => tr.addEventListener('click', () => sbLineModal(d.lines.find(l => l.itemId === tr.dataset.id), () => sbProductsModal(d))));
}

// Movimentos que dão um número (para conferir): data, produto, quantidade, valor, quem registou.
function sbMovesModal(d, kind) {
  const ids = d.lines.map(l => l.itemId);
  const unit = Object.fromEntries(d.lines.map(l => [l.itemId, l.unit]));
  if (kind === 'out') return sbProductsModal(d);
  const moves = Store.balanceMovements(d.from, d.to, kind, ids);
  const total = round2(moves.reduce((a, x) => a + x.qty, 0));
  const totalV = round2(moves.reduce((a, x) => a + x.qty * (unit[x.itemId] || 0), 0));
  const label = kind === 'in' ? t('sb.in') : t(`sb.out.${kind}`);
  const dateOf = x => (String(x.date).length > 10 ? fmtDate(x.date) : sbDay(x.date));
  const m = openModal({ title: `${label} · ${sbPeriodText(d.from, d.to)}`, wide: true, autofocus: false,
    body: moves.length ? `<div class="table-wrap"><table class="table fit vtbl sb-mv">
      <thead><tr><th>${esc(t('common.date'))}</th><th>${esc(t('stock.item'))}</th><th class="right">${esc(t('stock.qty'))}</th><th class="right">${esc(t('sb.value'))}</th></tr></thead>
      <tbody>${moves.map(x => `<tr><td>${esc(dateOf(x))}${x.ref ? `<div class="muted small">#${esc(String(x.ref))}</div>` : ''}</td>
        <td class="wrap">${esc(nameOf(x.itemId, x.name || ''))}<div class="muted small">${esc([x.note, empName(x.employeeId)].filter(Boolean).join(' · '))}</div></td>
        <td class="right num ${kind === 'diff' ? sbCls(x.qty) : ''}">${kind === 'diff' ? signed(x.qty) : fmtQty(x.qty)}</td><td class="right num">${money(x.qty * (unit[x.itemId] || 0))}</td></tr>`).join('')}</tbody>
      <tfoot><tr class="total-row"><td colspan="2">${esc(t('totals.total'))} <span class="muted small">(${moves.length})</span></td><td class="right num">${kind === 'diff' ? signed(total) : fmtQty(total)}</td><td class="right num">${money(totalV)}</td></tr></tfoot>
    </table></div>` : `<div class="empty">${esc(t('sb.noMoves'))}</div>` });
}

function sbExport(d, title) {
  const cols = ['stock.item', 'sb.colOpening', 'sb.colIn', 'sb.out.sold', 'sb.out.loss', 'sb.out.break', 'sb.out.internal', 'sb.out.manual', 'sb.colDiff', 'sb.out.opened', 'sb.colFinal', 'sb.colOut', 'sb.colOutValue'].map(k => t(k));
  const r = l => [nameOf(l.itemId, l.name), l.opening, l.in, l.sold, l.loss, l.break, l.internal, l.manual, l.diff, l.opened, l.final, l.out, round2(l.out * l.unit)];
  const T = d.T;
  exportModal({
    title: title || t('sb.title'), subtitle: `${sbPeriodText(d.from, d.to)} · ${t(d.byCost ? 'sb.atCost' : 'sb.atPrice')}`, file: 'balanco_stock', notes: [],
    columns: cols, numeric: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12], rows: d.lines.map(r),
    totals: [t('totals.total'), T.opening, T.in, T.sold, T.loss, T.break, T.internal, T.manual, T.diff, T.opened, T.final, T.out, T.outValue],
    summary: [[t('sb.opening'), money(T.openingValue)], [t('sb.in'), money(T.inValue)], [t('sb.available'), money(T.availableValue)],
      [t('sb.final'), money(T.finalValue)], [t('sb.out'), money(T.outValue), true], [t('sb.diff'), sbSigned(T.diffValue)]],
  });
}

function sbFilterModal() {
  const p = sbState();
  const [from, to] = sbRange();
  const cats = validCats(p.cats);
  const cardsOn = sbCardsOn(), rowsOn = sbRowsOn();
  let key = p.key;
  const chk = (attr, id, name, on, color = '') => `<label class="check cat-check"><input type="checkbox" ${attr}="${esc(id)}" ${on ? 'checked' : ''}>${color ? `<span class="swatch" style="background:${esc(color)}"></span>` : ''} ${esc(name)}</label>`;
  const m = openModal({ title: t('sb.filter'), autofocus: false,
    body: `<h4 class="pick-sec" style="margin-top:0">${esc(t('sb.period'))}</h4>
      <div class="chip-row sb-chips">${SB_PERIODS.map(k => `<button class="chip ${k === key ? 'on' : ''}" data-p="${k}">${esc(t(`sb.p.${k}`))}</button>`).join('')}</div>
      <div class="row" id="sb-custom" ${key === 'custom' ? '' : 'hidden'}>
        <label class="field"><span>${esc(t('sb.from'))}</span><input class="input" type="date" name="from" value="${from}" max="${dayKey(new Date())}"></label>
        <label class="field"><span>${esc(t('sb.to'))}</span><input class="input" type="date" name="to" value="${to}" max="${dayKey(new Date())}"></label></div>
      <h4 class="pick-sec">${esc(t('items.category'))}</h4>
      <label class="check cat-check cat-all"><input type="checkbox" id="sb-ca" ${cats.length ? '' : 'checked'}> <b>${esc(t('stock.allCats'))}</b></label>
      <div id="sb-cb">${catOptions().map(o => chk('data-cat', o.id, o.name, cats.includes(o.id), o.color)).join('')}</div>
      <h4 class="pick-sec">${esc(t('kpi.cards'))}</h4>
      <div class="cards-pick">${SB_CARDS.map(k => chk('data-card', k, t(`sb.${k}`), cardsOn.includes(k))).join('')}</div>
      <h4 class="pick-sec">${esc(t('sb.outBy'))}</h4>
      <div class="cards-pick">${SB_OUT.map(k => chk('data-row', k, t(`sb.out.${k}`), rowsOn.includes(k))).join('')}</div>`,
    footer: `<button class="btn primary" data-ok>${esc(t('common.apply'))}</button>` });
  $$('[data-p]', m).forEach(b => b.addEventListener('click', () => {
    key = b.dataset.p; $$('[data-p]', m).forEach(x => x.classList.toggle('on', x === b)); $('#sb-custom', m).hidden = key !== 'custom';
  }));
  const all = $('#sb-ca', m), boxes = $$('#sb-cb input', m);
  all.addEventListener('change', () => { if (all.checked) boxes.forEach(b => { b.checked = false; }); else if (!boxes.some(b => b.checked)) all.checked = true; });
  boxes.forEach(b => b.addEventListener('change', () => { all.checked = !boxes.some(x => x.checked); }));
  $('[data-ok]', m).onclick = () => {
    const picked = boxes.filter(b => b.checked).map(b => b.dataset.cat);
    Object.assign(p, { key, from: $('[name=from]', m).value, to: $('[name=to]', m).value, cats: picked.length === boxes.length ? [] : picked });
    Layout.set('sb.cards', $$('[data-card]', m).filter(b => b.checked).map(b => b.dataset.card));
    Layout.set('sb.rows', $$('[data-row]', m).filter(b => b.checked).map(b => b.dataset.row));
    sbBack();
  };
}

// Volta à página do balanço depois de uma janela (filtro, guardar, apagar).
const sbBack = () => { closeModal(); render(); };

// Página do balanço de stock (dentro da Contagem): filtro, cartões, saídas por tipo e balanços guardados.
// ---------- Balanço entre contagens (como no caderno) ----------
const CB_TABS = ['opening', 'in', 'final', 'out'];
const cbState = () => App.cb || (App.cb = { from: null, to: null, tab: 'opening', all: false });
const cbNum = v => (v ? Number(v).toLocaleString('pt-PT', { maximumFractionDigits: 2 }) : '');

// Junta a caixa e a lâmina/unidade da mesma marca numa linha (pela ligação caixa→lâmina ou pelo nome).
// Nome da marca sem o tipo de embalagem escrito no fim: "Heineken Shot (lâmina)" → "Heineken Shot".
const CB_PACK_WORD = /\s*\((l[aâ]mina|laminas|l[aâ]minas|caixa|caixas|grade|pack|unid(ade)?s?|garrafa|garrafas)\)\s*$/i;
const cbBaseName = n => String(n || '').replace(CB_PACK_WORD, '').trim();

function cbGroups(lines, field) {
  // 1) junta as linhas da mesma marca (ligação caixa→lâmina, ou o mesmo nome)
  const byKey = new Map();
  for (const l of lines) {
    const it = Store.find('items', l.itemId) || {};
    const base = it.opensInto ? Store.find('items', it.opensInto) : it;
    const name = cbBaseName((base && base.name) || l.name);
    const key = norm(name);
    if (!byKey.has(key)) byKey.set(key, { key, name, list: [] });
    byKey.get(key).list.push({ l, it });
  }
  // 2) em cada marca, uma caixa e uma unidade/lâmina. Se não se percebe pela ligação ou pela
  //    categoria, a de preço mais alto é a caixa. Sobras (3.º produto com o mesmo nome) ficam à parte.
  const rows = [];
  // Caixa: abre noutro produto, ou a categoria/nome diz "caixa"; "lâmina" no nome ou na categoria é unidade.
  const isBoxOf = ({ it }) => {
    const txt = norm(`${((it.categoryId && Store.find('categories', it.categoryId)) || {}).name || ''} ${it.name || ''}`);
    if (it.opensInto) return true;
    if (/lamina/.test(txt)) return false;
    return /caixa|grade/.test(txt);
  };
  for (const g of byKey.values()) {
    let { list } = g;
    let box = null, unit = null;
    if (list.length >= 2) {
      const sorted = list.slice().sort((a, b) => (isBoxOf(b) - isBoxOf(a)) || ((b.l.price || 0) - (a.l.price || 0)));
      [box, unit] = sorted;
      list = sorted.slice(2);
    } else if (isBoxOf(list[0])) { box = list[0]; list = []; } else { unit = list[0]; list = []; }
    rows.push({ key: g.key, name: g.name, box: box && box.l, unit: unit && unit.l });
    for (const x of list) rows.push({ key: `${g.key}#${x.l.itemId}`, name: x.l.name, box: isBoxOf(x) ? x.l : null, unit: isBoxOf(x) ? null : x.l });
  }
  return rows.map(g => ({
    key: g.key, name: g.name, ids: [g.box && g.box.itemId, g.unit && g.unit.itemId].filter(Boolean),
    un: g.unit ? g.unit[field] : 0, cx: g.box ? g.box[field] : 0,
    pun: g.unit ? g.unit.price : 0, pcx: g.box ? g.box.price : 0,
    value: round2((g.unit ? g.unit[field] * g.unit.price : 0) + (g.box ? g.box[field] * g.box.price : 0)),
  })).filter(r => r.un || r.cx).sort((a, b) => a.name.localeCompare(b.name, 'pt'));
}

function cbTableHtml(rows, total, limit, open = false) {
  const shown = limit ? rows.slice(0, limit) : rows;
  return `<table class="bx-tbl">
    <thead><tr><th>${esc(t('stock.item'))}</th><th>${esc(t('cb.colUn'))}</th><th>${esc(t('cb.colCx'))}</th><th>${esc(t('cb.colPun'))}</th><th>${esc(t('cb.colPcx'))}</th><th>${esc(t('cb.colValue'))}</th></tr></thead>
    <tbody>${shown.map(r => `<tr ${open ? `class="clickable cb-open" data-ids="${esc((r.ids || []).join(','))}"` : ''}><td>${esc(r.name)}${open ? ' <span class="cb-chev">›</span>' : ''}</td><td>${cbNum(r.un)}</td><td>${cbNum(r.cx)}</td><td>${r.un ? cbNum(r.pun) : ''}</td><td>${r.cx ? cbNum(r.pcx) : ''}</td><td>${cbNum(r.value)}</td></tr>`).join('')
      || `<tr><td colspan="6" class="muted">${esc(t('sb.noMoves'))}</td></tr>`}</tbody>
    <tfoot><tr><td>${esc(t('totals.total'))}</td><td colspan="5">${cbNum(total) || '0'}</td></tr></tfoot></table>`;
}

function cbSummaryHtml(b, live = false) {
  const T = b.totals;
  const row = (l, v, cls = '', k = '') => `<div class="s-row ${cls} ${live && k ? 'clickable cb-line' : ''}" ${live && k ? `data-cbk="${k}"` : ''}><span>${l}</span><span class="num">${v}</span></div>`;
  return `<div class="stat-rows bx-calc">
      ${row(`${esc(t('sb.opening'))} <small class="muted">(${esc(t('cb.countedOn', { date: fmtEntryDate(b.from) }))})</small>`, money(T.opening), '', 'opening')}
      ${row(`+ ${esc(t('sb.in'))}`, money(T.in), '', 'in')}
      ${row(`= ${esc(t('sb.available'))}`, money(T.available), 'strong')}
      ${row(`− ${esc(t('sb.final'))} <small class="muted">(${esc(t('cb.countedOn', { date: fmtEntryDate(b.to) }))})</small>`, money(T.final), '', 'final')}
      ${row(`= ${esc(t('sb.out'))}`, money(T.out), 'tot', 'out')}
    </div>
    ${T.posSold ? `<div class="stat-rows" style="margin-top:8px">${row(esc(t('cb.posSold')), money(T.posSold))}${row(esc(t('cb.unexplained')), `<span class="${T.unexplained > 0 ? 'neg-val' : T.unexplained < 0 ? 'pos-val' : ''}">${money(T.unexplained)}</span>`)}</div>` : ''}
`;
}

// PDF/foto do balanço entre contagens: igual à janela — a conta e as quatro tabelas
// (Inicial, Entradas, Final, Saídas) com Produto · Un · Cx · P. un · P. cx · Valor.
const CB_DOC_CSS = `.cbd .cbd-sum{width:100%;border-collapse:collapse;margin:6px 0 4px}
  .cbd .cbd-sum td{padding:6px 2px;border-bottom:1px solid #eef0f3;font-size:13px}.cbd .cbd-sum td:last-child{text-align:right;font-variant-numeric:tabular-nums}
  .cbd .cbd-sum small{color:#6b7280}.cbd .cbd-sum .strong td{font-weight:700}
  .cbd .cbd-sum .tot td{font-weight:800;background:#e8f5e9;border-bottom:none}.cbd .cbd-sum .tot td:last-child{color:#1d4ed8}
  .cbd h4{font-size:14px;margin:16px 0 4px}
  .cbd .cbd-t th{text-transform:none;font-size:10.5px}.cbd .cbd-t td,.cbd .cbd-t th{padding:4px 4px}
  .cbd .cbd-t tfoot td{font-weight:800;background:#e8f5e9;color:#1b5e20;border-bottom:none}
  .cbd .cbd-t{table-layout:fixed}.cbd .cbd-t th:nth-child(1){width:34%}.cbd .cbd-t th:nth-child(2),.cbd .cbd-t th:nth-child(3){width:10%}
  .cbd .cbd-t th:nth-child(4),.cbd .cbd-t th:nth-child(5){width:14%}.cbd .cbd-t th:nth-child(6){width:18%}`;
const cbRowsFor = (b, k) => cbGroups(b.lines, k);
function cbDocHtml(b) {
  const T = b.totals;
  const sr = (l, v, cls = '') => `<tr class="${cls}"><td>${l}</td><td>${v}</td></tr>`;
  const tbl = k => {
    const rows = cbRowsFor(b, k);
    return `<h4>${esc(t(`cb.tab.${k}`))}</h4><table class="cbd-t"><thead><tr><th>${esc(t('stock.item'))}</th><th class="r">${esc(t('cb.colUn'))}</th><th class="r">${esc(t('cb.colCx'))}</th><th class="r">${esc(t('cb.colPun'))}</th><th class="r">${esc(t('cb.colPcx'))}</th><th class="r">${esc(t('cb.colValue'))}</th></tr></thead>
      <tbody>${rows.map(r => `<tr><td>${esc(r.name)}</td><td class="r">${cbNum(r.un)}</td><td class="r">${cbNum(r.cx)}</td><td class="r">${r.un ? cbNum(r.pun) : ''}</td><td class="r">${r.cx ? cbNum(r.pcx) : ''}</td><td class="r">${cbNum(r.value)}</td></tr>`).join('')}</tbody>
      <tfoot><tr><td>${esc(t('totals.total'))}</td><td></td><td></td><td></td><td></td><td class="r">${cbNum(T[k]) || '0'}</td></tr></tfoot></table>`;
  };
  return `<style>${CB_DOC_CSS}</style><div class="doc cbd">
    <h1>${esc(Store.settings.storeName)}</h1>
    <div class="meta">${esc(t('cb.docTitle'))} · ${esc(fmtEntryDate(b.from))} → ${esc(fmtEntryDate(b.to))}</div>
    <table class="cbd-sum">
      ${sr(`${esc(t('sb.opening'))} <small>(${esc(t('cb.countedOn', { date: fmtEntryDate(b.from) }))})</small>`, money(T.opening))}
      ${sr(`+ ${esc(t('sb.in'))}`, money(T.in))}
      ${sr(`= ${esc(t('sb.available'))}`, money(T.available), 'strong')}
      ${sr(`− ${esc(t('sb.final'))} <small>(${esc(t('cb.countedOn', { date: fmtEntryDate(b.to) }))})</small>`, money(T.final))}
      ${sr(`= ${esc(t('sb.out'))}`, money(T.out), 'tot')}
    </table>
    ${CB_TABS.map(k => `<div class="avoid">${tbl(k)}</div>`).join('')}
  </div>`;
}

// A mesma folha desenhada numa imagem (para enviar no WhatsApp).
function cbImage(b) {
  const T = b.totals;
  const W = 1080, P = 48, RH = 44;
  const font = (w, sz) => `${w} ${sz}px system-ui, -apple-system, "Segoe UI", Roboto, Arial, sans-serif`;
  const secs = CB_TABS.map(k => ({ k, rows: cbRowsFor(b, k) }));
  const H = P + 110 + 5 * 50 + 30 + secs.reduce((a, x) => a + 70 + RH * (x.rows.length + 2) + 20, 0) + P;
  const cv = document.createElement('canvas'); cv.width = W; cv.height = H;
  const g = cv.getContext('2d');
  g.fillStyle = '#fff'; g.fillRect(0, 0, W, H);
  let y = P;
  g.fillStyle = '#111827'; g.font = font(800, 40); g.fillText(Store.settings.storeName, P, y + 36); y += 60;
  g.fillStyle = '#6b7280'; g.font = font(400, 24);
  g.fillText(`${t('cb.docTitle')} · ${fmtEntryDate(b.from)} → ${fmtEntryDate(b.to)}`, P, y + 24); y += 50;
  const sum = [[t('sb.opening'), T.opening, '', b.from], [`+ ${t('sb.in')}`, T.in, ''], [`= ${t('sb.available')}`, T.available, 'strong'], [`− ${t('sb.final')}`, T.final, '', b.to], [`= ${t('sb.out')}`, T.out, 'tot']];
  for (const [l, v, cls, day] of sum) {
    if (cls === 'tot') { g.fillStyle = '#e8f5e9'; g.fillRect(P, y, W - P * 2, 46); }
    g.fillStyle = '#111827'; g.font = font(cls ? 800 : 400, 26);
    g.textAlign = 'left'; g.fillText(l, P + 10, y + 32);
    if (day) { const w = g.measureText(l).width; g.font = font(400, 20); g.fillStyle = '#6b7280'; g.fillText(`(${t('cb.countedOn', { date: fmtEntryDate(day) })})`, P + 20 + w, y + 32);  g.font = font(cls ? 800 : 400, 26); }
    g.textAlign = 'right'; g.fillStyle = cls === 'tot' ? '#1d4ed8' : '#111827'; g.fillText(money(v), W - P - 10, y + 32);
    g.textAlign = 'left';
    if (!cls || cls === 'strong') { g.fillStyle = '#eef0f3'; g.fillRect(P, y + 48, W - P * 2, 2); }
    y += 50;
  }
  y += 30;
  const cols = [P + 8, 470, 560, 700, 840, W - P - 8]; // x: nome (esq.), resto (dir.)
  for (const sec of secs) {
    g.fillStyle = '#111827'; g.font = font(800, 30); g.fillText(t(`cb.tab.${sec.k}`), P, y + 34); y += 56;
    const head = [t('stock.item'), t('cb.colUn'), t('cb.colCx'), t('cb.colPun'), t('cb.colPcx'), t('cb.colValue')];
    const line = (vals, f, color) => {
      g.font = f; g.fillStyle = color;
      vals.forEach((v, i) => { g.textAlign = i ? 'right' : 'left'; g.fillText(String(v), cols[i], y + 30); });
      g.textAlign = 'left';
    };
    line(head, font(600, 21), '#6b7280'); g.fillStyle = '#e5e7eb'; g.fillRect(P, y + RH - 2, W - P * 2, 2); y += RH;
    for (const r of sec.rows) {
      line([r.name, cbNum(r.un), cbNum(r.cx), r.un ? cbNum(r.pun) : '', r.cx ? cbNum(r.pcx) : '', cbNum(r.value)], font(400, 23), '#111827');
      g.fillStyle = '#f1f2f4'; g.fillRect(P, y + RH - 1, W - P * 2, 1); y += RH;
    }
    g.fillStyle = '#e8f5e9'; g.fillRect(P, y, W - P * 2, RH);
    line([t('totals.total'), '', '', '', '', cbNum(T[sec.k]) || '0'], font(800, 23), '#1b5e20'); y += RH + 20;
  }
  return cv;
}

// Excel do balanço entre contagens (modelo C): uma folha, uma linha por produto com Inicial,
// Entradas, Final e Saídas lado a lado (Un, Cx, Valor), os totais e, no fim, a conta.
function cbSheets(b) {
  const T = b.totals;
  const by = new Map();
  for (const k of CB_TABS) for (const r of cbRowsFor(b, k)) {
    if (!by.has(r.key)) by.set(r.key, { name: r.name });
    by.get(r.key)[k] = r;
  }
  const prods = [...by.values()].sort((a, c) => a.name.localeCompare(c.name, 'pt'));
  const bars = { opening: XS.barGc, in: XS.barBc, final: XS.barPc, out: XS.barRc };
  const L = n => { let x = n + 1, s2 = ''; while (x) { const m = (x - 1) % 26; s2 = String.fromCharCode(65 + m) + s2; x = Math.floor((x - 1) / 26); } return s2; };
  const rows = [
    [{ v: Store.settings.storeName, s: XS.title }],
    [{ v: `${t('cb.docTitle')} · ${fmtEntryDate(b.from)} → ${fmtEntryDate(b.to)}`, s: XS.sub }],
    [],
    [{ v: t('stock.item'), s: XS.dark }, ...CB_TABS.flatMap(k => [{ v: t(`cb.tab.${k}`), s: bars[k] }, { v: '', s: bars[k] }, { v: '', s: bars[k] }])],
    [{ v: '', s: XS.headL }, ...CB_TABS.flatMap(() => [{ v: t('cb.colUn'), s: XS.head }, { v: t('cb.colCx'), s: XS.head }, { v: t('cb.colValue'), s: XS.head }])],
    ...prods.map(p => [{ v: p.name, s: XS.txt }, ...CB_TABS.flatMap(k => {
      const r = p[k];
      return [{ v: r && r.un ? r.un : '', s: XS.num }, { v: r && r.cx ? r.cx : '', s: XS.num }, { v: r ? r.value : '', s: XS.num }];
    })]),
    [{ v: t('totals.total'), s: XS.totL }, ...CB_TABS.flatMap(k => [{ v: '', s: XS.totE }, { v: '', s: XS.totE }, { v: T[k], s: XS.totN }])],
    [],
  ];
  const merges = CB_TABS.map((_, gi) => `${L(1 + gi * 3)}4:${L(3 + gi * 3)}4`);
  // a conta: texto na coluna A (estende-se para a direita), valor em D:F
  const sumRow = (label, v, ls, ms) => {
    const r = rows.length + 1;
    merges.push(`D${r}:F${r}`);
    rows.push([{ v: label, s: ls }, { v: '', s: ls }, { v: '', s: ls }, { v: v, s: ms }, { v: '', s: ms }, { v: '', s: ms }]);
  };
  sumRow(`${t('sb.opening')} (${t('cb.countedOn', { date: fmtEntryDate(b.from) })})`, T.opening, XS.sumL, XS.sumM);
  sumRow(`+ ${t('sb.in')}`, T.in, XS.sumL, XS.sumM);
  sumRow(`= ${t('sb.available')}`, T.available, XS.sumSL, XS.sumSM);
  sumRow(`− ${t('sb.final')} (${t('cb.countedOn', { date: fmtEntryDate(b.to) })})`, T.final, XS.sumL, XS.sumM);
  sumRow(`= ${t('sb.out')}`, T.out, XS.sumTL, XS.sumTM);
  return [{ name: t('cb.docTitle'), cols: [24, 7, 7, 12, 7, 7, 12, 7, 7, 12, 7, 7, 12], freeze: 5, landscape: true, merges, rows }];
}

function cbExport(b) {
  const head = [t('stock.item'), t('cb.colUn'), t('cb.colCx'), t('cb.colPun'), t('cb.colPcx'), t('cb.colValue')];
  // CSV: as quatro secções uma a seguir à outra, com as mesmas colunas.
  const rows = [];
  for (const k of CB_TABS) {
    rows.push([`— ${t(`cb.tab.${k}`)} —`, '', '', '', '', '']);
    for (const r of cbRowsFor(b, k)) rows.push([r.name, r.un || '', r.cx || '', r.un ? r.pun : '', r.cx ? r.pcx : '', r.value]);
    rows.push([t('totals.total'), '', '', '', '', b.totals[k]]);
  }
  exportModal({
    title: t('cb.docTitle'), subtitle: `${fmtEntryDate(b.from)} → ${fmtEntryDate(b.to)}`, file: 'contagem_de_stock', notes: [],
    text: () => cbText(b),
    columns: head, numeric: [1, 2, 3, 4, 5], rows,
    pdfHtml: () => cbDocHtml(b),
    imageCanvas: () => cbImage(b),
    xlsxSheets: () => cbSheets(b),
  });
}

// Texto para o WhatsApp: as contas do balanço e as saídas por produto.
function cbText(b) {
  const T = b.totals;
  const part = (n, u) => `${fmtQty(Math.abs(n))} ${t(u).toLowerCase()}`;
  const qty = r => [r.cx ? `${r.cx < 0 ? '−' : ''}${part(r.cx, 'cb.colCx')}` : '', r.un ? `${!r.cx && r.un < 0 ? '−' : ''}${part(r.un, 'cb.colUn')}` : '']
    .filter(Boolean).reduce((acc, x, i, arr) => (i === 0 ? x : `${acc} ${(i === 1 && r.un < 0) ? '−' : '+'} ${x}`), '');
  const out = cbRowsFor(b, 'out').filter(r => r.value);
  return [
    Store.settings.storeName,
    `${t('cb.docTitle')} · ${fmtEntryDate(b.from)} → ${fmtEntryDate(b.to)}`,
    '',
    `${t('sb.opening')} (${fmtEntryDate(b.from)}): ${money(T.opening)}`,
    `+ ${t('sb.in')}: ${money(T.in)}`,
    `= ${t('sb.available')}: ${money(T.available)}`,
    `− ${t('sb.final')} (${fmtEntryDate(b.to)}): ${money(T.final)}`,
    `= ${t('sb.out')}: ${money(T.out)}`,
    ...(out.length ? ['', `${t('sb.out')} ${t('sb.byProduct').toLowerCase()}:`, ...out.map(r => `• ${r.name}: ${qty(r)} · ${money(r.value)}`)] : []),
  ].join('\n');
}

function cbPickModal(which) {
  const st = cbState();
  const list = Store.doneCounts().slice().reverse();
  const m = openModal({ title: t(which === 'from' ? 'cb.pickFrom' : 'cb.pickTo'), autofocus: false,
    body: `<div class="stat-rows">${list.map(c => `<button type="button" class="s-row cb-pick ${st[which] === c.id ? 'on' : ''}" data-c="${c.id}"><span>${esc(fmtEntryDate(Store.countDay(c)))}<small class="muted"> · ${esc(t('count.countedOf', { n: c.totals.counted, total: c.totals.items }))}</small></span><span class="num">${money(Store.countValue(c))}</span></button>`).join('')}</div>` });
  $$('[data-c]', m).forEach(b => b.addEventListener('click', () => { st[which] = b.dataset.c; st.manual = true; closeModal(); render(); }));
}

function cbView(main, head) {
  const st = cbState();
  const counts = Store.doneCounts();
  const ids = counts.map(c => c.id);
  if (!ids.includes(st.to)) st.to = ids[ids.length - 1] || null;
  if (!ids.includes(st.from) || ids.indexOf(st.from) >= ids.indexOf(st.to)) st.from = ids[ids.indexOf(st.to) - 1] || null;
  if (!st.from || !st.to) {
    main.innerHTML = `<div class="page sb-page">${head}<div class="notice warn">${icon('clipboard')}<div>${esc(t('cb.needTwo'))}</div></div>${sbHistoryHtml()}</div>`;
    return;
  }
  // O último balanço já foi guardado: a contagem final passa a inicial e mostra-se o período em curso.
  const last = counts[counts.length - 1];
  const savedLast = Store.data.stockBalances.some(x => x.mode === 'counts' && x.toId === last.id);
  if (!st.manual && savedLast) { cbNextView(main, head, last); return; }
  const b = Store.countBalance(st.from, st.to);
  const a = Store.find('stockCounts', st.from), z = Store.find('stockCounts', st.to);
  main.innerHTML = `<div class="page sb-page">${head}
    <div class="bx-pick">
      <button class="btn" data-pick="from"><small>${esc(t('cb.from'))}</small><b>${esc(fmtEntryDate(b.from))}</b><i>${money(Store.countValue(a))}</i></button>
      <button class="btn" data-pick="to"><small>${esc(t('cb.to'))}</small><b>${esc(fmtEntryDate(b.to))}</b><i>${money(Store.countValue(z))}</i></button>
    </div>
    <div class="card card-pad">${cbSummaryHtml(b, true)}
      ${b.noFinal ? `<p class="bx-note neg-val">${esc(t('cb.noFinal', { n: b.noFinal }))}</p>` : ''}</div>
    <div class="sup-actions"><button class="btn" data-cbxp>${icon('download')} ${esc(t('xp.title'))}</button><button class="btn primary" data-cbsave>${icon('check')} ${esc(t('cb.save'))}</button></div>
    ${sbHistoryHtml()}
  </div>`;
  $$('[data-pick]', main).forEach(x => x.addEventListener('click', () => cbPickModal(x.dataset.pick)));
  // Tocar numa linha da conta mostra os produtos dessa linha (para conferir com o caderno).
  const showLine = k => {
    const m = openModal({ title: `${t(`cb.tab.${k}`)} · ${money(b.totals[k])}`, wide: true, autofocus: false,
      body: cbTableHtml(cbGroups(b.lines, k), b.totals[k], 0, k === 'in'),
      footer: k === 'in' ? `<button class="btn primary" data-pull>${esc(t('cb.pullBtn'))}</button>` : '' });
    $$('.cb-open', m).forEach(tr => tr.addEventListener('click', () => cbEntriesModal(tr.dataset.ids.split(',').filter(Boolean), a, z, () => { App.cbReopen = 'in'; render(); })));
    const pl = $('[data-pull]', m);
    if (pl) pl.onclick = () => cbPullModal(a, z, () => { App.cbReopen = 'in'; render(); });
  };
  $$('[data-cbk]', main).forEach(x => x.addEventListener('click', () => showLine(x.dataset.cbk)));
  // Voltou de uma janela que mudou as entradas: reabre a lista já com as contas novas.
  if (App.cbReopen) { const k = App.cbReopen; App.cbReopen = null; setTimeout(() => showLine(k), 0); }
  $('[data-cbxp]', main).onclick = () => cbExport(b);
  $('[data-cbsave]', main).onclick = () => guard(() => {
    Store.saveStockBalance(Object.assign({ mode: 'counts', byCost: false }, b), App.user.id, '');
    st.manual = false;
    toast(t('sb.saved')); render();
  });
}

// Entradas de um produto (caixa e lâmina) entre duas contagens: apagar, ou dizer que veio de caixa aberta.
function cbEntriesModal(ids, a, z, back) {
  if (!need('editData')) return;
  const list = Store.data.stockEntries.filter(e => e.type === 'in' && ids.includes(e.itemId) && Store.inCountPeriod(e, a, z))
    .sort((x, y) => String(x.createdAt).localeCompare(String(y.createdAt)));
  const name = ids.map(id => (Store.find('items', id) || {}).name).filter(Boolean)[0] || '';
  const m = openModal({ title: t('cb.entTitle', { name }), autofocus: false,
    body: list.length ? `<p class="muted small" style="margin:0 0 10px">${esc(t('cb.entHint'))}</p>${list.map(e => {
      const it = Store.find('items', e.itemId);
      return `<div class="cb-ent"><div class="cb-ent-h"><span><b>+${fmtQty(e.qty)} ${esc(it ? dn(it) : '')}</b><small>${esc([fmtEntryDate(e.date), e.note, e.employeeId ? empName(e.employeeId) : ''].filter(Boolean).join(' · '))}</small></span>${e.dated ? `<i class="cb-tag">${esc(t('cb.entUndated'))}</i>` : ''}</div>
        ${Store.data.items.some(bx => bx.opensInto === e.itemId) ? `<button class="btn cb-ok" data-open="${e.id}">${esc(t('cb.entFromOpen'))}</button>` : ''}<button class="btn cb-ok" data-out="${e.id}">${esc(t('cb.entOut'))}</button><button class="btn danger" data-del="${e.id}">${esc(t('cb.entDel'))}</button></div>`;
    }).join('')}<p class="muted small" style="margin:8px 0 0">${esc(t('cb.entNote'))}</p>` : `<p class="muted">${esc(t('sb.noMoves'))}</p>` });
  if (back) onModalClose(m, back);
  $$('[data-open]', m).forEach(x => x.addEventListener('click', () => guard(() => { Store.entryFromOpen(x.dataset.open, App.user.id); App.stale = true; toast(t('cb.entFromOpenDone')); closeModal(); if (back) back(); })));
  $$('[data-out]', m).forEach(x => x.addEventListener('click', () => guard(() => { Store.excludeEntry(x.dataset.out, z, App.user.id); App.stale = true; toast(t('cb.entOutDone')); closeModal(); if (back) back(); })));
  $$('[data-del]', m).forEach(x => x.addEventListener('click', async () => {
    if (!await confirmDialog(t('cb.entDelQ'), t('cb.entDel'), true)) { cbEntriesModal(ids, a, z, back); return; }
    guard(() => { Store.removeStockEntry(x.dataset.del); App.stale = true; toast(t('cb.entDelDone')); if (back) back(); });
  }));
}

// Procurar entradas: as que existem no Stock mas ficaram fora deste balanço, cada uma com "Incluir".
function cbPullModal(a, z, back) {
  if (!need('editData')) return;
  const { late, opened } = Store.entriesOutside(a, z);
  const hm = iso => { const d = new Date(iso); return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`; };
  const card = e => {
    const it = Store.find('items', e.itemId);
    return `<div class="cb-pull"><span><b>${esc(it ? dn(it) : '?')} · +${fmtQty(e.qty)}</b><small>${esc([fmtEntryDate(e.date).slice(0, 5), e.createdAt ? hm(e.createdAt) : '', e.employeeId ? empName(e.employeeId) : ''].filter(Boolean).join(' · '))}</small></span><button class="btn cb-ok" data-inc="${e.id}">${esc(t('cb.pullInc'))}</button></div>`;
  };
  const m = openModal({ title: t('cb.pullTitle'), autofocus: false,
    body: `<p class="muted small" style="margin:0 0 10px">${esc(t('cb.pullHint', { from: fmtEntryDate(Store.countDay(a)).slice(0, 5), to: fmtEntryDate(Store.countDay(z)).slice(0, 5) }))}</p>
      ${late.length ? `<div class="cb-grp">${esc(t('cb.pullLate'))}</div>${late.map(card).join('')}` : ''}
      ${opened.length ? `<div class="cb-grp">${esc(t('cb.pullOpened'))}</div>${opened.map(card).join('')}` : ''}
      ${late.length || opened.length ? '' : `<p class="muted">${esc(t('cb.pullNone'))}</p>`}` });
  if (back) onModalClose(m, back);
  $$('[data-inc]', m).forEach(x => x.addEventListener('click', () => guard(() => {
    const e = Store.includeEntry(x.dataset.inc, z, App.user.id);
    const it = Store.find('items', e.itemId);
    App.stale = true; toast(t('cb.pullDone', { name: it ? dn(it) : '' })); closeModal(); if (back) back();
  })));
}

// Período em curso: desde a última contagem (a final do balanço guardado) até à próxima contagem.
function cbNextView(main, head, c) {
  const st = cbState();
  const o = Store.openPeriod(c);
  const day = fmtEntryDate(Store.countDay(c)), at = new Date(c.finishedAt);
  const hm = `${String(at.getHours()).padStart(2, '0')}:${String(at.getMinutes()).padStart(2, '0')}`;
  const cur = Store.currentCount('normal');
  main.innerHTML = `<div class="page sb-page">${head}
    <div class="bx-pick">
      <button class="btn" data-pick="from"><small>${esc(t('cb.from'))}</small><b>${esc(day)}</b><i>${money(o.opening)}</i></button>
      <button class="btn bx-todo" data-cbstart><small>${esc(t('cb.to'))}</small><b>${esc(t(cur ? 'cb.nextOn' : 'cb.nextTodo'))}</b><i>${esc(t('cb.nextSub'))}</i></button>
    </div>
    <div class="card card-pad"><div class="stat-rows">
      <div class="s-row"><span>${esc(t('sb.opening'))} <span class="muted small">(${esc(t('cb.countedAt', { d: day, h: hm }))})</span></span><b class="num">${money(o.opening)}</b></div>
      <div class="s-row"><span>+ ${esc(t('sb.in'))} <span class="muted small">${esc(t('cb.since', { d: day }))}</span></span><b class="num">${money(o.entries)}</b></div>
      <div class="s-row strong cb-hl"><span>= ${esc(t('sb.available'))}</span><span class="num">${money(o.available)}</span></div>
      <div class="s-row"><span>− ${esc(t('cb.posSold'))} <span class="muted small">${esc(t('cb.since', { d: day }))}</span></span><b class="num">${money(o.sold)}</b></div>
      <div class="s-row strong cb-hl blue"><span>= ${esc(t('cb.expectedNow'))}</span><span class="num">${money(o.expected)}</span></div>
    </div><p class="bx-note muted">${esc(t('cb.nextNote'))}</p></div>
    <div class="sup-actions"><button class="btn" disabled>${icon('download')} ${esc(t('xp.title'))}</button><button class="btn primary" data-cbstart>${esc(t(cur ? 'cb.continueCount' : 'cb.newCount'))}</button></div>
    ${sbHistoryHtml()}
  </div>`;
  $('[data-pick="from"]', main).addEventListener('click', () => { st.manual = true; st.to = c.id; render(); });
  $$('[data-cbstart]', main).forEach(x => x.addEventListener('click', () => {
    if (!Store.currentCount('normal')) Store.startCount(App.user.id);
    App.countKind = 'normal'; App.countSits = []; App.countCats = []; App.countQ = ''; App.sbPage = false; App.balTab = 'stock'; render();
  }));
}

function sbPageView(main) {
  const p = sbState();
  // Sempre entre contagens (o modo "Por período" saiu; os balanços já guardados continuam na lista).
  const mode = 'counts';
  const modeHead = '';
  if (mode === 'counts') {
    setBack(t('sb.title'), () => { App.sbPage = false; render(); });
    cbView(main, modeHead);
    $$('[data-sbmode]', main).forEach(x => x.addEventListener('click', () => { App.sbMode = x.dataset.sbmode; render(); }));
    $$('[data-sbh]', main).forEach(tr => tr.addEventListener('click', () => sbSavedModal(tr.dataset.sbh)));
    return;
  }
  const cats = validCats(p.cats);
  const [from, to] = sbRange();
  setBack(t('sb.title'), () => { App.sbPage = false; render(); });
  main.innerHTML = `<div class="page sb-page">${modeHead}
    <div class="card card-pad sb">
      <p class="muted small" style="margin:0 0 10px">${esc(t('sb.intro', { kind: t(Store.showCost() ? 'sb.atCost' : 'sb.atPrice') }))}</p>
      <div class="sb-filters">
        <button class="btn stock-dates on" id="sb-filter">${icon('calendar')}<span>${esc([p.key === 'custom' ? t('sb.p.custom') : t(`sb.p.${p.key}`), catLabel(cats)].join(' · '))}</span></button>
        <input class="input" id="sb-q" type="search" placeholder="${esc(t('stock.searchPlaceholder'))}" value="${esc(p.q || '')}">
      </div>
      <div class="muted small sb-range">${esc(sbPeriodText(from, to))}</div>
      <div id="sb-body"></div>
      ${footer3([['', 'data-sb-items', 'list', t('sb.byProductShort')], ['', 'data-sb-xp', 'download', t('xp.title')], ['primary', 'data-sb-save', 'check', t('sb.save')]])}
    </div>
    ${sbHistoryHtml()}
  </div>`;
  let d;
  const paint = () => {
    d = sbData();
    $('#sb-body', main).innerHTML = sbSummaryHtml(d.T, true);
    $$('[data-mv]', main).forEach(el => el.addEventListener('click', () => sbMovesModal(d, el.dataset.mv)));
  };
  paint();
  $('#sb-filter', main).addEventListener('click', sbFilterModal);
  $$('[data-sbmode]', main).forEach(x => x.addEventListener('click', () => { App.sbMode = x.dataset.sbmode; render(); }));
  $('#sb-q', main).addEventListener('input', e => { sbState().q = e.target.value; paint(); });
  $('[data-sb-items]', main).onclick = () => sbProductsModal(d);
  $('[data-sb-xp]', main).onclick = () => sbExport(d);
  $('[data-sb-save]', main).onclick = () => guard(() => {
    const label = [validCats(p.cats).length ? catLabel(validCats(p.cats), true) : '', (p.q || '').trim()].filter(Boolean).join(' · ');
    Store.saveStockBalance({ from: d.from, to: d.to, byCost: d.byCost, lines: d.lines, totals: d.T }, App.user.id, label);
    toast(t('sb.saved')); render();
  });
  $$('[data-sbh]', main).forEach(tr => tr.addEventListener('click', () => sbSavedModal(tr.dataset.sbh)));
}

function sbHistoryHtml() {
  const list = Store.data.stockBalances.slice().sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  if (!list.length) return '';
  return `<h3 style="margin:24px 0 2px">${esc(t('sb.history'))}</h3><p class="muted small" style="margin:0 0 10px">${esc(t('sb.historySub'))}</p>
    <div class="card table-wrap"><table class="table fit">
      <thead><tr><th>${esc(t('sb.period'))}</th><th class="right">${esc(t('sb.out'))}</th><th class="right">${esc(t('sb.diff'))}</th></tr></thead>
      <tbody>${list.map(b => `<tr class="clickable" data-sbh="${b.id}"><td>${esc(sbPeriodText(b.from, b.to))}<div class="muted small">${esc([b.label, fmtDate(b.createdAt), empName(b.employeeId)].filter(Boolean).join(' · '))}</div></td>
        <td class="right num">${money(b.mode === 'counts' ? b.totals.out : b.totals.outValue)}</td><td class="right num ${b.mode === 'counts' ? '' : sbCls(b.totals.diffValue)}">${b.mode === 'counts' ? esc(t('cb.short')) : sbSigned(b.totals.diffValue)}</td></tr>`).join('')}</tbody>
    </table></div>`;
}

function sbSavedModal(id) {
  const b = Store.find('stockBalances', id);
  if (!b) return;
  if (b.mode === 'counts') {
    const m = openModal({ title: `${t('sb.title')} · ${fmtEntryDate(b.from)} → ${fmtEntryDate(b.to)}`, wide: true, autofocus: false,
      body: `<p class="muted small" style="margin:0 0 8px">${esc(t('sb.savedOn', { date: fmtDate(b.createdAt) }))}</p>${cbSummaryHtml(b)}
        ${CB_TABS.map(k => `<h4 class="sb-sub">${esc(t(`cb.tab.${k}`))}</h4>${cbTableHtml(cbGroups(b.lines, k), b.totals[k], 0)}`).join('')}`,
      footer: footer3([['danger', 'data-del', 'trash', t('common.delete')], ['', 'data-xp', 'download', t('xp.title')]]) });
    $('[data-xp]', m).onclick = () => cbExport(b);
    $('[data-del]', m).onclick = async () => {
      if (!await confirmDialog(t('sb.deleteConfirm'), t('common.delete'), true)) return sbSavedModal(id);
      Store.deleteStockBalance(id); toast(t('sb.deleted')); sbBack();
    };
    return;
  }
  const d = { from: b.from, to: b.to, byCost: b.byCost, lines: b.lines, T: b.totals };
  const m = openModal({ title: `${t('sb.title')} · ${sbPeriodText(b.from, b.to)}`, wide: true, autofocus: false,
    body: `<p class="muted small" style="margin:0 0 8px">${esc([b.label, t('sb.savedOn', { date: fmtDate(b.createdAt) }), t(b.byCost ? 'sb.atCost' : 'sb.atPrice')].filter(Boolean).join(' · '))}</p>
      ${sbSummaryHtml(b.totals, false)}<h4 class="sb-sub">${esc(t('sb.byProduct'))}</h4>${sbTableHtml(b.lines, b.totals)}`,
    footer: footer3([['danger', 'data-del', 'trash', t('common.delete')], ['', 'data-xp', 'download', t('xp.title')]]) });
  $$('tr[data-id]', m).forEach(tr => tr.addEventListener('click', () => sbLineModal(b.lines.find(l => l.itemId === tr.dataset.id), () => sbSavedModal(id))));
  $('[data-xp]', m).onclick = () => sbExport(d);
  $('[data-del]', m).onclick = async () => {
    if (!await confirmDialog(t('sb.deleteConfirm'), t('common.delete'), true)) return sbSavedModal(id);
    Store.deleteStockBalance(id); toast(t('sb.deleted')); sbBack();
  };
}

// ---------- Ferramentas da contagem: copiar de outra, colar lista, data ----------
// Caixa ou unidade/lâmina (mesma regra do balanço entre contagens).
function cbIsBox(it) {
  const txt = norm(`${((it.categoryId && Store.find('categories', it.categoryId)) || {}).name || ''} ${it.name || ''}`);
  if (it.opensInto) return true;
  if (/lamina/.test(txt)) return false;
  return /caixa|grade/.test(txt);
}

// Marcas: { key, name, box, unit, all } a partir dos produtos com stock.
function countBrands() {
  const map = new Map();
  for (const it of Store.data.items.filter(i => i.trackStock)) {
    const base = it.opensInto ? Store.find('items', it.opensInto) : it;
    const name = cbBaseName((base && base.name) || it.name);
    const key = norm(name);
    if (!map.has(key)) map.set(key, { key, name, all: [] });
    map.get(key).all.push(it);
  }
  for (const b of map.values()) {
    const sorted = b.all.slice().sort((x, y) => (cbIsBox(y) - cbIsBox(x)) || ((y.price || 0) - (x.price || 0)));
    if (sorted.length >= 2) { b.box = sorted[0]; b.unit = sorted[1]; } else if (cbIsBox(sorted[0])) b.box = sorted[0]; else b.unit = sorted[0];
  }
  return [...map.values()];
}

const CL_BOX = /^(cx|cxs|caixa|caixas|c|grade|grades)$/;
const CL_UNIT = /^(l|lam|lams|lamina|laminas|un|und|unid|unidade|unidades|u|garrafa|garrafas|g|grf|lata|latas)$/;
// Título de secção: "Para Lâminas:", "Garrafas:", "Para caixas" …
const CL_SECTION = /^(para\s+)?(as\s+|os\s+)?(caixas?|grades?|l[aâ]minas?|garrafas?|unidades?|latas?)\s*:?$/i;

// Lê uma lista colada: "12x Corona", "13x Txilar Lata + 3l", "Brutal 3", "23 Amarula",
// com títulos "Para Lâminas:" / "Para Garrafas:" / "Para Caixas:" que dizem a embalagem das linhas seguintes.
function parseCountList(text) {
  const brands = countBrands();
  const out = [];
  let section = null; // 'box' | 'unit' | null
  let sectionCat = null; // categoria da secção ("Garrafas:", "Caixas:", "Lâminas:" = nome de uma categoria)
  // "Lâminas" ↔ "Lâmina", "Caixas" ↔ "Caixa": compara sem o "s" final.
  const sing = x => norm(x).replace(/^(para|as|os)\s+/, '').replace(/s$/, '');
  const catOf = title => Store.data.categories.find(c => sing(c.name) === sing(title)) || null;
  for (const raw of String(text || '').split(/\r?\n/)) {
    const line = raw.trim();
    if (!line) continue;
    const sec = line.match(CL_SECTION);
    const head = /:\s*$/.test(line) && !/\d/.test(line) ? line.replace(/:\s*$/, '') : null;
    const hc = sec || head ? catOf((head || line).replace(/:\s*$/, '')) : null;
    if (sec || hc) {
      section = sec ? (/caixa|grade/i.test(sec[3]) ? 'box' : 'unit') : (hc && /caixa|grade/i.test(hc.name) ? 'box' : 'unit');
      sectionCat = hc ? hc.id : null;
      continue;
    }
    // quantidades: número + (x | unidade) — o resto é o nome
    const nums = [];
    const namePart = norm(line.replace(/(\d+(?:[.,]\d+)?)(\s*)(x(?![a-zA-ZÀ-ÿ])|[a-zA-ZÀ-ÿ]+)?/g, (all, n, sp, u, at) => {
      const unit = norm(u || '');
      const push = kind => nums.push({ qty: num(n.replace(',', '.')), kind });
      if (unit === 'x' || CL_BOX.test(unit) || CL_UNIT.test(unit)) { push(CL_BOX.test(unit) ? 'box' : CL_UNIT.test(unit) ? 'unit' : null); return ' '; }
      if (!unit) { push(null); return ' '; }
      // "23 Amarula": número no início da linha é quantidade; "Bond 7 Grande", "4th Street": faz parte do nome
      if (at === 0 && sp) { push(null); return ` ${u}`; }
      return all;
    }).replace(/[+:=\-–·,]+/g, ' ').replace(/\s+/g, ' ').trim());
    let cands = brands.filter(b => b.key === namePart);
    if (!cands.length && namePart) cands = brands.filter(b => b.key.startsWith(namePart) || namePart.startsWith(b.key));
    if (cands.length > 1) { const exact = cands.filter(b => b.key.length === namePart.length); if (exact.length === 1) cands = exact; }
    // Dentro de uma secção, fica a marca que tem produto nessa categoria.
    if (cands.length > 1 && sectionCat) { const inCat = cands.filter(b => b.all.some(i => i.categoryId === sectionCat)); if (inCat.length === 1) cands = inCat; }
    let brand = cands.length === 1 ? cands[0] : null;
    const values = [];
    // Título de categoria e o produto não existe nessa categoria: não adivinha, pede para escolher.
    let catMiss = null;
    if (brand && sectionCat && !brand.all.some(i => i.categoryId === sectionCat)) {
      catMiss = (Store.find('categories', sectionCat) || {}).name || '';
      cands = [brand]; brand = null;
    }
    if (brand) {
      const single = [brand.box, brand.unit].filter(Boolean);
      let free = single.slice();
      // "3x Savana (lâmina)" é lâmina; "2 caixas de Gold" é caixa; senão manda a secção; sem nada, caixas
      const lineKind = /l[aâ]minas?/i.test(line) ? 'unit' : /\b(caixas?|grades?)\b/i.test(line) ? 'box' : null;
      const dflt = lineKind || section || 'box';
      for (const n of nums) {
        const kind = n.kind || dflt;
        let it = single.length === 1 ? single[0] : kind === 'box' ? brand.box : brand.unit;
        // A secção diz a categoria: o produto dessa categoria ganha (só no primeiro número sem embalagem).
        const catIt = sectionCat && !n.kind ? brand.all.find(i => i.categoryId === sectionCat && free.includes(i)) : null;
        if (catIt) it = catIt;
        if (!it || !free.includes(it)) it = free[0];
        if (!it) continue;
        free = free.filter(x => x !== it);
        values.push({ itemId: it.id, qty: n.qty, item: it });
      }
    }
    out.push({ raw: line, brand, cands, values, nums, catMiss });
  }
  return out;
}

// Janela "Colar lista": colar ou escrever, ver o que a app percebeu e aplicar.
function countPasteModal(c, back) {
  const m = openModal({ title: t('cl.title'), wide: true, autofocus: false,
    body: `<p class="muted small" style="margin:0 0 8px">${esc(t('cl.hint'))}</p>
      <textarea class="input cl-text" id="cl-text" rows="7" placeholder="Garrafas:&#10;12x Amarula&#10;5x Caravela&#10;&#10;Caixas:&#10;12x Corona&#10;4x Mayfair&#10;&#10;Lâminas:&#10;3x Brutal&#10;2x Txilar Lata"></textarea>
      <div id="cl-res"></div>`,
    footer: `<div class="cl-foot"><button class="btn primary" data-ok disabled>${esc(t('cl.apply'))}</button><small class="muted" id="cl-open"></small></div>` });
  if (back) onModalClose(m, back);
  const all = Store.data.items.filter(i => i.trackStock).sort((a, b) => dn(a).localeCompare(dn(b), 'pt'));
  let rows = [], sugs = [];
  const off = new Set(); // caixas cuja sugestão de abrir foi desmarcada
  // Lâminas a mais do que o sistema e caixas a menos: foi aberta uma caixa sem registar.
  // Se as caixas nem estão na lista (só vieram lâminas), ficam a 0.
  const packSugs = () => {
    const sum = new Map(), rowOf = new Map();
    rows.forEach((r, i) => r.values.forEach(v => { sum.set(v.itemId, round2((sum.get(v.itemId) || 0) + v.qty)); if (!rowOf.has(v.itemId)) rowOf.set(v.itemId, i); }));
    const out = [];
    if (c.status !== 'draft') return out; // contagem já fechada: só corrige números
    for (const [uid, uCnt] of sum) {
      const unit = Store.find('items', uid);
      const box = unit && Store.data.items.find(b => b.opensInto === uid && b.trackStock);
      if (!box) continue;
      const per = Number(box.opensQty) || 1, sysB = Store.countStock(c, box), sysU = Store.countStock(c, unit);
      const bCnt = sum.has(box.id) ? sum.get(box.id) : null;
      const extra = round2(uCnt - sysU);
      const room = Math.floor(round2(sysB - (bCnt == null ? 0 : bCnt)));
      if (!(extra > 0) || room < 1) continue;
      const k = Math.min(Math.ceil(extra / per), room);
      out.push({ box, unit, k, per, sysB, sysU, bCnt, sold: Math.max(0, room - k), row: rowOf.get(uid) });
    }
    return out;
  };
  const sugHtml = (g, i) => `<label class="cl-sug"><input type="checkbox" data-sg="${i}" ${off.has(g.box.id) ? '' : 'checked'}><span><b>${esc(t(g.bCnt == null ? 'cl.sugZero' : 'cl.sugOpen', { n: g.k, cx: t(g.k === 1 ? 'cl.cx1' : 'cl.cxN'), name: dn(g.box) }))}</b><small>${esc(t('cl.sugWhy', { b: fmtQty(g.sysB), u: fmtQty(g.sysU) }))} ${esc(t(g.bCnt == null ? 'cl.sugMissing' : 'cl.sugFound', { n: g.k, cx: t(g.k === 1 ? 'cl.cx1' : 'cl.cxN'), q: fmtQty(g.k * g.per) }))}${g.sold ? ` ${esc(t('cl.sugSold', { n: g.sold }))}` : ''}</small></span></label>`;
  const countOk = () => rows.reduce((a, r) => a + r.values.length, 0) + sugs.filter(g => g.bCnt == null && !off.has(g.box.id)).length;
  const paintFoot = () => {
    const ok = countOk(), boxes = sugs.filter(g => !off.has(g.box.id)).reduce((a, g) => a + g.k, 0);
    $('[data-ok]', m).disabled = !ok;
    $('[data-ok]', m).textContent = ok ? t('cl.applyN', { n: ok }) : t('cl.apply');
    $('#cl-open', m).textContent = ok && boxes ? t('cl.andOpen', { n: boxes, cx: t(boxes === 1 ? 'cl.cx1' : 'cl.cxN') }) : '';
  };
  const paint = () => {
    rows = parseCountList($('#cl-text', m).value);
    sugs = packSugs();
    const ok = rows.reduce((a, r) => a + r.values.length, 0);
    // O mesmo produto em duas linhas: as quantidades somam-se (ex.: prateleira + armazém).
    const seen = new Map();
    rows.forEach((r, i) => r.values.forEach(v => { if (seen.has(v.itemId)) r.dup = seen.get(v.itemId) + 1; else seen.set(v.itemId, i); }));
    $('#cl-res', m).innerHTML = rows.length ? `<div class="stat-rows cl-rows">${rows.map((r, i) => [r, i]).reverse().map(([r, i]) => `<div class="s-row ${r.values.length ? '' : 'cl-bad'}">
        <span>${esc(r.raw)}${r.values.length ? `<small class="muted">${esc(r.values.map(v => `${dn(v.item)}: ${fmtQty(v.qty)}`).join(' · '))}</small>` : ''}${r.catMiss ? `<small class="neg-val">${esc(t('cl.notInCat', { cat: r.catMiss }))}</small>` : ''}${r.dup ? `<small class="warn-val">${esc(t('cl.dup', { n: r.dup }))}</small>` : ''}${sugs.map((g, k) => (g.row === i ? sugHtml(g, k) : '')).join('')}</span>
        ${r.values.length ? `<b class="pos-val">✓</b>` : `<select class="input cl-pick" data-i="${i}"><option value="">${esc(t(r.cands.length > 1 || r.catMiss ? 'cl.which' : 'cl.notFound'))}</option>${(r.cands.length > 1 || r.catMiss ? r.cands.flatMap(b => b.all) : all).map(it => `<option value="${it.id}">${esc(dn(it))}</option>`).join('')}</select>`}</div>`).join('')}</div>` : '';
    $$('.cl-pick', m).forEach(sel => sel.addEventListener('change', () => {
      const r = rows[Number(sel.dataset.i)];
      const it = Store.find('items', sel.value);
      r.values = it && r.nums.length ? [{ itemId: it.id, qty: r.nums[0].qty, item: it }] : [];
      sugs = packSugs(); paintFoot();
    }));
    $$('[data-sg]', m).forEach(cb => cb.addEventListener('change', () => { const g = sugs[Number(cb.dataset.sg)]; if (cb.checked) off.delete(g.box.id); else off.add(g.box.id); paintFoot(); }));
    paintFoot();
    void ok;
  };
  $('#cl-text', m).addEventListener('input', paint);
  $('[data-ok]', m).onclick = () => guard(() => {
    const sum = new Map();
    rows.flatMap(r => r.values).forEach(v => sum.set(v.itemId, round2((sum.get(v.itemId) || 0) + v.qty)));
    // Primeiro abre as caixas marcadas (a caixa sai, as lâminas entram); caixas que não vieram na lista ficam a 0.
    for (const g of sugs) {
      if (off.has(g.box.id)) continue;
      Store.countOpenPack(c.id, g.box.id, g.k, App.user.id);
      if (g.bCnt == null) sum.set(g.box.id, 0);
    }
    const vals = [...sum].map(([itemId, value]) => ({ itemId, value }));
    const n = Store.setCountValues(c.id, vals, App.user.id);
    closeModal(); App.stale = true; toast(t('cl.done', { n })); if (back) back(); else render();
  });
}

// Copiar os números de outra contagem concluída para esta.
// Números contados como texto, por categoria, no formato que o "Colar lista" lê:
// "Garrafas:\n5x 4th Street\n…"
function countAsText(c) {
  const by = new Map();
  for (const l of c.lines) {
    if (l.counted == null) continue;
    const it = Store.find('items', l.itemId);
    if (!it) continue;
    const cat = (Store.find('categories', it.categoryId) || {}).name || t('items.noCategory');
    if (!by.has(cat)) by.set(cat, []);
    by.get(cat).push([it.name, l.counted]);
  }
  return [...by].map(([cat, rows]) => `${cat}:\n${rows.sort((a, b) => a[0].localeCompare(b[0], 'pt')).map(([n, q]) => `${fmtQty(q)}x ${n}`).join('\n')}`).join('\n\n');
}

// Copiar: os números desta contagem como texto (copiar ou partilhar) e, por baixo,
// trazer os números de outra contagem concluída.
function countCopyModal(c, back) {
  const list = Store.data.stockCounts.filter(x => x.status === 'done' && x.id !== c.id).sort((a, b) => b.finishedAt.localeCompare(a.finishedAt));
  const text = countAsText(c);
  const day = fmtEntryDate(Store.countDay(c.status === 'done' ? c : Object.assign({}, c, { finishedAt: new Date().toISOString() }))).slice(0, 5);
  const m = openModal({ title: t('cpy.titleThis', { date: day }), autofocus: false, keepFoot: true,
    body: `<p class="muted small" style="margin:0 0 8px">${esc(t('cpy.thisHint'))}</p>
      ${text ? `<textarea class="input cl-text" id="cpy-text" rows="10" readonly>${esc(text)}</textarea>` : `<div class="empty">${esc(t('cpy.nothing'))}</div>`}
      <div class="cpy-other"><b>${esc(t('cpy.other'))}</b>
      ${list.length ? `<p class="muted small" style="margin:4px 0 8px">${esc(t('cpy.hint'))}</p><div class="stat-rows">${list.map(x => `<button type="button" class="s-row cb-pick" data-c="${x.id}"><span>${esc(fmtEntryDate(Store.countDay(x)))}${Store.isCheck(x) ? ` <small class="muted">· ${esc(t('chk.title'))}</small>` : ''}<small class="muted"> · ${esc(t('count.countedOf', { n: x.totals.counted, total: x.totals.items }))}</small></span><span class="num">${money(Store.countValue(x))}</span></button>`).join('')}</div>`
        : `<p class="muted small" style="margin:4px 0 0">${esc(t('cpy.none'))}</p>`}</div>`,
    footer: text ? `<button class="btn" data-share>${esc(t('cpy.share'))}</button><button class="btn primary" data-copy>${esc(t('cpy.copyText'))}</button>` : '' });
  if (back) onModalClose(m, back);
  const copy = $('[data-copy]', m);
  if (copy) copy.onclick = async () => {
    try { await navigator.clipboard.writeText(text); toast(t('xp.copied')); }
    catch (e) {
      const ta = $('#cpy-text', m);
      ta.readOnly = false; ta.select();
      let ok = false;
      try { ok = document.execCommand('copy'); } catch (e2) { ok = false; }
      ta.readOnly = true;
      toast(t(ok ? 'xp.copied' : 'xp.copyFailed'), !ok);
    }
  };
  const share = $('[data-share]', m);
  if (share) share.onclick = async () => {
    const name = `contagem_${day.replace('/', '-')}.txt`;
    try {
      if (NativePrint.available()) await NativePrint.share(name, 'text/plain', text);
      else if (navigator.share) await navigator.share({ title: t('cpy.titleThis', { date: day }), text });
      else { await navigator.clipboard.writeText(text); toast(t('xp.copied')); }
    } catch (e) { /* partilha cancelada */ }
  };
  $$('[data-c]', m).forEach(b => b.addEventListener('click', async () => {
    const src = Store.find('stockCounts', b.dataset.c);
    if (!await confirmDialog(t('cpy.confirm', { date: fmtEntryDate(Store.countDay(src)) }), t('cpy.ok'))) return back ? back() : undefined;
    guard(() => { const n = Store.copyCountFrom(c.id, src.id, App.user.id); App.stale = true; toast(t('cpy.done', { n })); if (back) back(); else render(); });
    return undefined;
  }));
}

// Mudar a data de uma contagem (em curso ou concluída).
function countDayModal(c, back) {
  const today = dayKey(new Date());
  const m = openModal({ title: t('cb.countDate'), autofocus: false,
    body: `<label class="field"><span>${esc(t('cb.countDate'))}</span><input class="input" type="date" id="cdd" value="${Store.countDay(c.status === 'done' ? c : Object.assign({}, c, { finishedAt: new Date().toISOString() }))}" max="${today}"></label>
      <p class="muted small">${esc(t(c.status === 'done' ? 'cdd.hintDone' : 'cb.countDateHint'))}</p>`,
    footer: `<button class="btn primary" data-ok>${esc(t('common.save'))}</button>` });
  if (back) onModalClose(m, back);
  $('[data-ok]', m).onclick = () => guard(() => {
    Store.setCountDay(c.id, $('#cdd', m).value, App.user.id);
    closeModal(); App.stale = true; toast(t('cdd.done')); if (back) back(); else render();
  });
}

const countToolsHtml = c => `<div class="count-tools">
    <button type="button" class="btn small" data-ct="day">${icon('calendar')}<span>${esc(fmtEntryDate(Store.countDay(c.status === 'done' ? c : Object.assign({}, c, { finishedAt: new Date().toISOString() }))).slice(0, 5))}</span></button>
    <button type="button" class="btn small" data-ct="copy">${icon('copy')}<span>${esc(t('cpy.btn'))}</span></button>
    <button type="button" class="btn small" data-ct="paste">${icon('text')}<span>${esc(t('cl.btn'))}</span></button>
    ${c.status === 'draft' ? `<button type="button" class="btn small ct-fill" data-ct="fill">${icon('refresh')}<span>${esc(t('count.refreshShort'))}</span></button>` : ''}
  </div>`;
const bindCountTools = (root, c, back) => {
  $$('[data-ct]', root).forEach(b => b.addEventListener('click', () => {
    const k = b.dataset.ct;
    if (k === 'day') countDayModal(c, back); else if (k === 'copy') countCopyModal(c, back); else if (k === 'fill') countFillModal(c, back); else countPasteModal(c, back);
  }));
};

// Abrir caixa(s) durante a contagem, quando há lâminas a mais: mostra o antes e o depois.
function countOpenBoxModal(c, sheet) {
  const box = Store.countPackSource(c, sheet.id);
  if (!box) return;
  const per = Number(box.opensQty) || 1;
  const check = Store.isCheck(c);
  const countedOf = item => { const l = c.lines.find(x => x.itemId === item.id); return l && l.counted != null ? l.counted : null; };
  const sys = item => Store.countStock(c, item);
  const max = Math.floor(sys(box));
  const d0 = round2((countedOf(sheet) || 0) - sys(sheet));
  let n = Math.max(1, Math.min(Math.ceil(d0 / per), max));
  const diffTxt = v => (v == null ? '—' : v === 0 ? '✓' : signed(v));
  const diffCls = v => (v == null || v === 0 ? '' : v < 0 ? 'neg-val' : 'pos-val');
  const m = openModal({
    title: t('pack.countTitle'), autofocus: false,
    body: `<p class="muted small" style="margin:0 0 10px">${esc(t('pack.countIntro', { box: dn(box), per: fmtQty(per), sheet: dn(sheet) }))}</p>
      <div class="field"><span>${esc(t('pack.countBoxes'))}</span>
        <div class="qty-step"><button type="button" class="btn" data-n="-1">−</button><b class="num" id="ob-n"></b><button type="button" class="btn" data-n="1">+</button></div></div>
      <div class="table-wrap"><table class="table fit vtbl ob-tbl">
        <thead><tr><th>${esc(t('stock.item'))}</th><th class="right">${esc(t('count.system'))}</th><th class="right">${esc(t('count.counted'))}</th><th class="right">${esc(t('sb.colDiff'))}</th></tr></thead>
        <tbody id="ob-rows"></tbody></table></div>
      <p class="muted small" style="margin:8px 0 0">${esc(t(check ? 'pack.countSim' : 'pack.countReal'))}</p>`,
    footer: `<button class="btn primary" data-ok>${esc(t('pack.countOk'))}</button>`,
  });
  const paint = () => {
    $('#ob-n', m).textContent = n;
    const row = (item, delta) => {
      const before = sys(item), after = round2(before + delta), cnt = countedOf(item);
      const db = cnt == null ? null : round2(cnt - before), da = cnt == null ? null : round2(cnt - after);
      return `<tr><td class="wrap">${esc(dn(item))}</td><td class="right num">${fmtQty(before)} → <b>${fmtQty(after)}</b></td>
        <td class="right num">${cnt == null ? '—' : fmtQty(cnt)}</td>
        <td class="right num"><span class="${diffCls(db)}">${diffTxt(db)}</span> → <b class="${diffCls(da)}">${diffTxt(da)}</b></td></tr>`;
    };
    $('#ob-rows', m).innerHTML = row(box, -n) + row(sheet, n * per);
    $('[data-n="-1"]', m).disabled = n <= 1; $('[data-n="1"]', m).disabled = n >= max;
  };
  $$('[data-n]', m).forEach(b => b.addEventListener('click', () => { n = Math.max(1, Math.min(max, n + Number(b.dataset.n))); paint(); }));
  $('[data-ok]', m).onclick = () => guard(() => {
    Store.countOpenPack(c.id, box.id, n, App.user.id);
    closeModal(); App.stale = true; render(); toast(t(check ? 'pack.countDoneSim' : 'pack.countDone', { n }));
  });
  paint();
}

// ================= Fecho com o fornecedor =================

// Venda à consignação: no dia combinado, o fornecedor confere as vendas e o stock e recolhe o dinheiro.
// Período do fecho: por defeito, desde o último fecho até agora; ou as datas escolhidas.
// O Fecho puxa do Balanço: as mesmas duas contagens (por defeito, as duas últimas).
// Só com datas escolhidas à mão (ou sem duas contagens) faz as contas pelo caixa, como antes.
function cbPair() {
  const st = cbState();
  const ids = Store.doneCounts().map(c => c.id);
  if (!ids.includes(st.to)) st.to = ids[ids.length - 1] || null;
  if (!ids.includes(st.from) || ids.indexOf(st.from) >= ids.indexOf(st.to)) st.from = ids[ids.indexOf(st.to) - 1] || null;
  return st.from && st.to ? { fromId: st.from, toId: st.to } : null;
}
const supPreview = () => (!App.supFrom && !App.supTo && cbPair()
  ? Store.settlementPreview(null, null, cbPair())
  : Store.settlementPreview(
    App.supFrom ? new Date(`${App.supFrom}T00:00:00`).toISOString() : null,
    App.supTo ? new Date(`${App.supTo}T23:59:59.999`).toISOString() : null));
const supPeriodLabel = p => {
  const day = iso => fmtEntryDate(dayKey(new Date(iso))).slice(0, 5);
  if (p.byCounts) return `${fmtEntryDate(p.byCounts.from).slice(0, 5)} → ${fmtEntryDate(p.byCounts.to).slice(0, 5)}`;
  return `${day(p.from)} – ${dayKey(new Date(p.to)) === dayKey(new Date()) ? t('sup.today') : day(p.to)}`;
};

// Este período (as mesmas duas contagens) já tem um fecho confirmado: não se confirma outra vez.
const supAlreadyClosed = p => !!(p.byCounts && Store.data.settlements.some(x => x.byCounts && x.byCounts.fromId === p.byCounts.fromId && x.byCounts.toId === p.byCounts.toId));

// Fecho entre contagens: a conta do total a entregar e a conferência com o caixa.
function supCountsHtml(b) {
  const row = (l, v, sub = '', cls = '') => `<div class="s-row" style="gap:12px"><span>${esc(l)}${sub ? `<small class="muted" style="display:block">${esc(sub)}</small>` : ''}</span><span class="num ${cls}">${v}</span></div>`;
  return `<div class="stat-rows">
      ${row(t('sfc.out'), money(b.out), t('sfc.outSub', { from: fmtEntryDate(b.from).slice(0, 5), to: fmtEntryDate(b.to).slice(0, 5) }))}
      ${row(`− ${t('sfc.justified')}`, money(b.justified), t('sfc.justifiedSub'))}
      ${row(`− ${t('sfc.credit')}`, money(b.creditSales), t('sfc.creditSub'))}
      ${row(`+ ${t('sfc.debt')}`, money(b.debtReceived))}
      ${row(`− ${t('sfc.expenses')}`, money(b.expensesDeducted), t('sfc.expensesSub'))}
    </div>
    <div class="sup-total"><span>= ${esc(t('sup.total'))}</span><b class="num">${money(b.total)}</b></div>
    <h4 style="margin:16px 0 4px">${esc(t('sfc.cashTitle'))}</h4>
    <div class="stat-rows">
      ${row(t('sfc.cashIn'), money(b.cashIn))}
      ${row(t('sfc.cashExpected'), money(b.cashExpected))}
      ${row(t('sfc.cashDiff'), money(b.cashDiff), b.cashDiff < 0 ? t('sfc.cashShort') : b.cashDiff > 0 ? t('sfc.cashOver') : t('sfc.cashOk'), b.cashDiff < 0 ? 'neg-val' : b.cashDiff > 0 ? 'pos-val' : '')}
    </div>`;
}
function supCountsModal() {
  const st = cbState();
  const lbl = id => { const c = Store.find('stockCounts', id); return c ? fmtEntryDate(Store.countDay(c)) : '—'; };
  const m = openModal({ title: t('sfc.pickTitle'), autofocus: false,
    body: `<div class="stat-rows">
      <button type="button" class="s-row cb-pick" data-w="from"><span>${esc(t('cb.from'))}</span><b>${esc(lbl(st.from))} ›</b></button>
      <button type="button" class="s-row cb-pick" data-w="to"><span>${esc(t('cb.to'))}</span><b>${esc(lbl(st.to))} ›</b></button>
    </div>
    <p class="muted small" style="margin-top:10px">${esc(t('sfc.pickHint'))}</p>
    <button type="button" class="btn" data-dates style="width:100%;margin-top:6px">${icon('calendar')} ${esc(t('sfc.byDates'))}</button>` });
  $$('[data-w]', m).forEach(b => b.addEventListener('click', () => cbPickModal(b.dataset.w)));
  $('[data-dates]', m).onclick = () => supPeriodModal(supPreview());
}

function supPeriodModal(p) {
  const last = Store.lastSettlement();
  const m = openModal({
    title: t('sup.period'),
    autofocus: false,
    body: `
      <div class="row">
        <label class="field"><span>${esc(t('reports.from'))}</span><input class="input" type="date" id="pf" value="${dayKey(new Date(p.from))}" max="${dayKey(new Date())}"></label>
        <label class="field"><span>${esc(t('reports.to'))}</span><input class="input" type="date" id="pt" value="${dayKey(new Date(p.to))}" max="${dayKey(new Date())}"></label>
      </div>
      ${last ? `<p class="muted small">${esc(t('sup.lastWas', { date: fmtDate(last.to) }))}</p>` : ''}`,
    footer: `<button class="btn" data-reset>${esc(t(last ? 'sup.sinceLastBtn' : 'sup.fromStart'))}</button><button class="btn primary" data-ok>${esc(t('common.apply'))}</button>`,
  });
  $('[data-reset]', m).onclick = () => { App.supFrom = App.supTo = null; closeModal(); render(); };
  $('[data-ok]', m).onclick = () => {
    let f = $('#pf', m).value, tt = $('#pt', m).value || dayKey(new Date());
    if (!f) { toast(t('reports.needDates'), true); return; }
    if (f > tt) [f, tt] = [tt, f];
    App.supFrom = f; App.supTo = tt === dayKey(new Date()) ? null : tt;
    closeModal(); render();
  };
}

// Secções do fecho que se podem mostrar ou esconder (filtro "Mostrar").
const SUP_SECTIONS = ['control', 'received', 'sold', 'entries', 'missing', 'products', 'credit', 'expenses', 'stock'];

// Cartões do topo do fecho: os quatro principais por defeito, ou os escolhidos em "Mostrar".
const SUP_KPIS = ['stockSales', 'missing', 'total', 'openDebt', 'registered', 'expenses', 'unitsIn', 'unitsOut'];
const SUP_KPIS_DEFAULT = ['stockSales', 'missing', 'total', 'openDebt'];
const supKpis = () => (Layout.get('kpi.sup') || SUP_KPIS_DEFAULT).filter(k => SUP_KPIS.includes(k));

// Categoria (ou 'none') de uma linha do fecho, pelo produto.
const lineCat = l => catKey(Store.find('items', l.itemId) || {});

// O fecho só com os produtos das categorias escolhidas. As contas passam a sair dos produtos
// (vendido ao preço de venda), porque o dinheiro de cada recibo não se divide por categoria.
function filterSettlement(p, cats) {
  if (!cats.length) return p;
  const lines = p.lines.filter(l => cats.includes(lineCat(l)));
  const sum = f => round2(lines.reduce((a, l) => a + f(l), 0));
  const soldValue = sum(l => l.sold * l.price);
  const missingValue = sum(l => (l.diff < 0 ? -l.diff * l.price : 0));
  const totals = Object.assign({}, p.totals, {
    received: {}, toDeliver: soldValue, soldValue,
    missingQty: sum(l => (l.diff < 0 ? -l.diff : 0)), missingValue, surplusQty: sum(l => (l.diff > 0 ? l.diff : 0)),
    unjustQty: sum(l => l.unjust || 0), unjustValue: sum(l => (l.unjust || 0) * l.price),
    total: round2(soldValue + missingValue + sum(l => (l.unjust || 0) * l.price)), stockSalesValue: round2(soldValue + missingValue),
    soldQty: sum(l => l.sold), inQty: sum(l => l.in), stockSalesQty: sum(l => (l.out != null ? l.out : l.sold)),
  });
  return Object.assign({}, p, { lines, entries: (p.entries || []).filter(e => cats.includes(lineCat(e))), totals, cats });
}

// Controlo de mercadoria por categoria: início, entrou, saiu (vendido + saídas sem registo) e ficou.
function controlRows(p) {
  const out = l => (l.out != null ? l.out : l.sold);
  const left = l => (l.counted != null ? l.counted : l.expected);
  const groups = new Map();
  for (const l of p.lines) {
    const k = lineCat(l);
    const g = groups.get(k) || { name: k === 'none' ? t('items.noCategory') : Store.find('categories', k).name, opening: 0, in: 0, out: 0, left: 0, outValue: 0, leftValue: 0 };
    // Caixas abertas: saem da caixa e entram na lâmina.
    const op = l.opened || 0;
    g.opening += l.opening; g.in += l.in + Math.max(op, 0); g.out += out(l) + Math.max(-op, 0); g.left += left(l);
    g.outValue += out(l) * l.price; g.leftValue += left(l) * l.price;
    groups.set(k, g);
  }
  const rows = [...groups.values()].sort((a, b) => a.name.localeCompare(b.name, 'pt'));
  const total = rows.reduce((a, g) => { for (const f of ['opening', 'in', 'out', 'left', 'outValue', 'leftValue']) a[f] += g[f]; return a; },
    { name: t('totals.total'), opening: 0, in: 0, out: 0, left: 0, outValue: 0, leftValue: 0 });
  for (const g of [...rows, total]) for (const f of ['opening', 'in', 'out', 'left', 'outValue', 'leftValue']) g[f] = round2(g[f]);
  return { rows, total };
}

// Filtro do fecho: categorias de produtos e métricas, cada grupo com o seu "Todas".
function supFilterModal() {
  const cats = validCats(App.supCats), show = App.supShow || [];
  const box = (grp, o, on) => `<label class="check cat-check"><input type="checkbox" data-g="${grp}" value="${esc(o.id)}" ${on ? 'checked' : ''}>${o.color ? `<span class="swatch" style="background:${esc(o.color)}"></span>` : ''}${esc(o.name)}</label>`;
  const m = openModal({
    title: t('sup.showTitle'),
    autofocus: false,
    body: `
      <h3 class="modal-sub" style="margin-top:0">${esc(t('sup.filterCats'))}</h3>
      <label class="check cat-check cat-all"><input type="checkbox" data-all="c" ${cats.length ? '' : 'checked'}> <b>${esc(t('stock.allCats'))}</b></label>
      ${catOptions().map(o => box('c', o, cats.includes(o.id))).join('')}
      <h3 class="modal-sub">${esc(t('sup.filterCards'))}</h3>
      ${SUP_KPIS.map(k => box('k', { id: k, name: t(`sup.kpi.${k}`) }, supKpis().includes(k))).join('')}
      <h3 class="modal-sub">${esc(t('sup.filterMetrics'))}</h3>
      <label class="check cat-check cat-all"><input type="checkbox" data-all="s" ${show.length ? '' : 'checked'}> <b>${esc(t('sup.showAll'))}</b></label>
      ${SUP_SECTIONS.map(k => box('s', { id: k, name: t(`sup.sec.${k}`) }, show.includes(k))).join('')}`,
    footer: `<button class="btn primary" data-ok>${esc(t('common.apply'))}</button>`,
  });
  for (const g of ['c', 's']) {
    const all = $(`[data-all="${g}"]`, m), boxes = $$(`[data-g="${g}"]`, m);
    all.addEventListener('change', () => { if (all.checked) boxes.forEach(b => { b.checked = false; }); else if (!boxes.some(b => b.checked)) all.checked = true; });
    boxes.forEach(b => b.addEventListener('change', () => { all.checked = !boxes.some(x => x.checked); }));
  }
  $('[data-ok]', m).onclick = () => {
    const pick = g => { const all = $$(`[data-g="${g}"]`, m); const v = all.filter(b => b.checked).map(b => b.value); return v.length === all.length ? [] : v; };
    App.supCats = pick('c'); App.supShow = pick('s');
    Layout.set('kpi.sup', $$('[data-g="k"]', m).filter(b => b.checked).map(b => b.value));
    closeModal(); render();
  };
}
const supShown = () => { const v = (App.supShow || []).filter(k => SUP_SECTIONS.includes(k)); return v.length ? v : SUP_SECTIONS; };

function viewSupplier(main) {
  const cats = validCats(App.supCats);
  const p = filterSettlement(supPreview(), cats);
  const x = p.totals;
  const show = supShown();
  const on = k => show.includes(k);
  const history = Store.data.settlements.slice().sort((a, b) => b.to.localeCompare(a.to));
  const moved = p.lines.filter(l => l.in || l.sold || l.adjust || l.diff);
  const lines = moved;
  // Vendidos pelo stock: o que saiu (caixa + saídas sem registo). Fechos antigos não têm "out".
  const outOf = l => (l.out != null ? l.out : l.sold);
  const sold = p.lines.filter(l => outOf(l) > 0).sort((a, b) => outOf(b) * b.price - outOf(a) * a.price);
  const stockSalesValue = x.stockSalesValue != null ? x.stockSalesValue : x.soldValue;
  const soldValue = round2(sold.reduce((a, l) => a + outOf(l) * l.price, 0));
  const soldQty = round2(sold.reduce((a, l) => a + outOf(l), 0));
  const missing = p.lines.filter(l => l.diff < 0);
  const debtors = Store.data.customers.filter(c => (c.debt || 0) > 0).sort((a, b) => b.debt - a.debt);
  const stock = cats.length ? Store.data.items.filter(i => i.trackStock && i.stock > 0 && cats.includes(catKey(i)))
    .reduce((a, i) => ({ units: round2(a.units + i.stock), retail: round2(a.retail + i.stock * (i.price || 0)) }), { units: 0, retail: 0 }) : Store.stockValue();
  const ctl = controlRows(p);
  const diffCell = l => (l.diff == null ? '<span class="muted">—</span>' : l.diff === 0 ? '<span class="pos-val">✓</span>' : `<b class="${l.diff < 0 ? 'neg-val' : 'pos-val'}">${signed(l.diff)}</b>`);
  // Movimento de produtos: Entradas · Contado · Saídas (o que saiu de verdade = vendas + faltas).
  const realOut = l => round2(l.out != null ? l.out : (Number(l.sold) || 0) - (Number(l.diff) || 0));
  const outCell = l => { const o = realOut(l); return o > 0 ? `<b class="neg-val">−${fmtQty(o)}</b>` : o < 0 ? `<b class="pos-val">+${fmtQty(-o)}</b>` : '<span class="pos-val">✓</span>'; };
  const kpisChanged = supKpis().join() !== SUP_KPIS_DEFAULT.join();
  const showLabel = [cats.length ? catLabel(cats) : '', kpisChanged ? t('sup.cardsN', { n: supKpis().length }) : '', App.supShow && App.supShow.length ? t('sup.metricsN', { n: show.length }) : ''].filter(Boolean).join(' · ') || t('sup.showAll');
  // Painéis longos ficam minimizados (só título + resumo); tocar no título abre/fecha. Guardado por dispositivo.
  const opened = Layout.get('open.sup') || [];
  const foldHead = (k, title, sum) => `<button type="button" class="fold-head" data-fold="${k}" aria-expanded="${opened.includes(k)}"><h3>${esc(title)}</h3><span class="fold-sum num">${esc(sum)}</span><span class="fold-chev">${icon('chevron')}</span></button>`;
  const card = (k, title, body, extra = '', sum) => (!on(k) ? '' : sum == null
    ? `<div class="card card-pad" data-sec="${k}"><div class="chart-head"><h3>${esc(title)}</h3>${extra}</div>${body}</div>`
    : `<div class="card card-pad fold ${opened.includes(k) ? 'open' : ''}" data-sec="${k}">${foldHead(k, title, sum)}<div class="fold-body">${body}</div></div>`);
  const empty = msg => `<div class="empty">${esc(msg)}</div>`;
  main.innerHTML = `
    <div class="page">
      <div class="page-head stock-head sup-filters">
        <button class="btn stock-dates ${p.custom ? 'on' : ''}" id="sup-period" title="${esc(t('sup.period'))}">${icon('calendar')}<span>${esc(supPeriodLabel(p))}</span></button>
        <button class="btn stock-dates ${(App.supShow && App.supShow.length) || cats.length || kpisChanged ? 'on' : ''}" id="sup-show" title="${esc(t('sup.showTitle'))}">${icon('check')}<span>${esc(showLabel)}</span></button>
      </div>
      ${(() => {
        // Cartões do topo, escolhidos no filtro "Mostrar" (por defeito, os quatro principais).
        const kpi = (label, value, cls = '', sub = '') => `<div class="card kpi" data-kid="__ID__"><div class="k-label">${esc(label)}</div><div class="k-value num ${cls}">${value}</div>${sub ? `<div class="k-sub">${esc(sub)}</div>` : ''}</div>`;
        const cards = {
          stockSales: () => kpi(t('sup.stockSales'), money(stockSalesValue), '', p.countId ? '' : t('sup.stockSalesNoCount')),
          // Saídas, com o que saiu de cada categoria (unidades e valor). A barra é pelo valor.
          missing: () => {
            const base = kpi(t('sup.missing'), p.countId ? money(x.missingValue) : '—', x.missingValue ? 'neg-val' : '');
            let parts = p.countId ? ctl.rows.filter(g => g.out > 0 && g.outValue > 0).sort((a, b) => b.outValue - a.outValue) : [];
            // No máximo 3 categorias; o resto junta-se em "Outras".
            if (parts.length > 4) {
              const rest = parts.slice(3);
              parts = parts.slice(0, 3).concat({ name: t('sup.kOther'), out: round2(rest.reduce((a, g) => a + g.out, 0)), outValue: round2(rest.reduce((a, g) => a + g.outValue, 0)) });
            }
            const all = parts.reduce((a, g) => a + g.outValue, 0);
            if (!all) return base;
            const C = ['#1f6f3a', '#d97706', '#2563eb', '#7c3aed', '#0891b2', '#db2777'];
            const meter = `<div class="kmeter">${parts.map((g, i) => `<i style="width:${(g.outValue / all) * 100}%;background:${C[i % C.length]}"></i>`).join('')}</div>
              <div class="klegend kcol">${parts.map((g, i) => `<span><b style="background:${C[i % C.length]}"></b>${esc(g.name)} ${fmtQty(g.out)} · <em class="nw">${money(g.outValue)}</em></span>`).join('')}</div>`;
            return base.replace('</div></div>', `</div>${meter}</div>`);
          },
          // Total a entregar, com a proporção entre vendas e despesas descontadas.
          total: () => {
            const sales = Math.max(0, stockSalesValue || 0), exp = Math.max(0, x.expensesDeducted || 0), all = sales + exp;
            const meter = all > 0 ? `<div class="kmeter"><i style="width:${(sales / all) * 100}%"></i><i class="neg" style="width:${(exp / all) * 100}%"></i></div>
              <div class="klegend"><span><b></b>${esc(t('sup.kSales'))} ${money(sales)}</span>${exp ? `<span><b class="neg"></b>${esc(t('sup.kExp'))} ${money(exp)}</span>` : ''}</div>` : '';
            return kpi(t('sup.total'), money(x.total), 'pos-val').replace('</div></div>', `</div>${meter}</div>`).replace('class="card kpi"', 'class="card kpi kpi-wide"');
          },
          openDebt: () => kpi(t('sup.openDebtShort'), money(x.openDebt), x.openDebt ? 'neg-val' : ''),
          registered: () => kpi(t('sup.toDeliver'), money(x.toDeliver)),
          expenses: () => kpi(t('sup.expDeducted'), money(x.expensesDeducted || 0)),
          unitsIn: () => kpi(t('sup.kpi.unitsIn'), fmtQty(ctl.total.in)),
          unitsOut: () => kpi(t('sup.kpi.unitsOut'), fmtQty(ctl.total.out)),
        };
        return `<div class="kpis fin-kpis" data-kpis="sup">${SUP_KPIS.map(k => cards[k]().replace('__ID__', k)).join('')}</div>`;
      })()}
      ${p.countInProgress ? `<div class="notice warn">${icon('clipboard')}<div>${esc(t('sup.countOpen'))} <a href="#" id="go-count">${esc(t('sup.continueCount'))}</a></div></div>`
        : p.byCounts ? `<div class="notice ok">${icon('check')}<div>${esc(t('sfc.notice', { from: fmtEntryDate(p.byCounts.from), to: fmtEntryDate(p.byCounts.to) }))}</div></div>`
        : p.countId ? `<div class="notice ok">${icon('check')}<div>${esc(t('sup.countDone', { date: fmtDate(p.countAt), n: missing.length }))}</div></div>`
        : `<div class="notice warn">${icon('clipboard')}<div>${esc(t('sup.countNone'))} <a href="#" id="go-count">${esc(t('sup.doCount'))}</a></div></div>`}
      <div class="sup-actions sup-top-actions">
        <button class="btn" id="sup-xp">${icon('download')} ${esc(t('xp.title'))}</button>
        <button class="btn primary" id="sup-ok" ${p.countInProgress || supAlreadyClosed(p) ? 'disabled' : ''}>${icon('check')} ${esc(t(supAlreadyClosed(p) ? 'sfc.closed' : 'sup.confirm'))}</button>
      </div>
      <div class="grid-2" data-sort="sup">
        ${on('control') ? `<div class="card card-pad sup-control" data-sec="control"><h3>${esc(t('sup.sec.control'))}</h3>
          ${ctl.rows.length ? `<div class="table-wrap"><table class="table fit sup-table">
            <thead><tr><th>${esc(t('items.category'))}</th><th class="right">${esc(t('sup.colOpening'))}</th><th class="right">${esc(t('sup.colIn'))}</th><th class="right">${esc(t('sup.colOut'))}</th><th class="right">${esc(t('sup.colLeft'))}</th></tr></thead>
            <tbody>${ctl.rows.map(g => `<tr><td class="wrap">${esc(g.name)}</td><td class="right num">${fmtQty(g.opening)}</td><td class="right num">${g.in ? `+${fmtQty(g.in)}` : '0'}</td><td class="right num">${fmtQty(g.out)}</td><td class="right num"><b>${fmtQty(g.left)}</b></td></tr>`).join('')}</tbody>
            <tfoot><tr class="total-row"><td>${esc(ctl.total.name)}</td><td class="right num">${fmtQty(ctl.total.opening)}</td><td class="right num">+${fmtQty(ctl.total.in)}</td><td class="right num">${fmtQty(ctl.total.out)}</td><td class="right num">${fmtQty(ctl.total.left)}</td></tr></tfoot></table></div>
          <div class="stat-rows" style="margin-top:10px">
            <div class="s-row"><span>${esc(t('sup.outValue'))}</span><b class="num">${money(ctl.total.outValue)}</b></div>
            <div class="s-row"><span>${esc(t('sup.leftValue'))}</span><b class="num">${money(ctl.total.leftValue)}</b></div></div>
          <p class="muted small" style="margin-top:8px">${esc(t(p.countId ? 'sup.controlHint' : 'sup.controlHintNoCount'))}</p>` : empty(t('sup.noMoves'))}</div>` : ''}
        ${p.byCounts && !p.cats ? card('received', t('sup.total'), supCountsHtml(p.byCounts)) : ''}
        ${p.byCounts && !p.cats ? '' : card('received', t('sup.money'), `${p.cats ? `<p class="muted small" style="margin:0 0 8px">${esc(t('sup.catsMoneyHint'))}</p>` : ''}<div class="stat-rows">
            ${p.cats ? `<div class="s-row"><span>${esc(t('sup.soldAtPrice'))}</span><span class="num">${money(x.soldValue)}</span></div>` : ''}
            ${p.cats ? '' : Object.entries(x.received).map(([k, v]) => `<div class="s-row"><span>${esc(payLabel(k))}</span><span class="num">${money(v)}</span></div>`).join('') || `<div class="s-row"><span class="muted">${esc(t('reports.noSales'))}</span><span class="num">${money(0)}</span></div>`}
            ${p.cats ? '' : `<div class="s-row"><span>+ ${esc(t('sup.debtPaid'))}</span><span class="num">${money(x.debtReceived)}</span></div>`}
            <div class="s-row strong"><span>= ${esc(t('sup.toDeliver'))}</span><span class="num">${money(x.toDeliver)}</span></div>
            <div class="s-row"><span>+ ${esc(t('sup.missingRow'))}${x.missingQty ? ` <span class="muted small">(${esc(t('sup.missingN', { n: fmtQty(x.missingQty) }))})</span>` : ''}</span><span class="num ${x.missingValue ? 'neg-val' : ''}">${p.countId ? money(x.missingValue) : '—'}</span></div>
          </div>
          ${x.unjustValue ? `<div class="stat-rows"><div class="s-row"><span>+ ${esc(t('sup.unjustRow'))} <span class="muted small">(${esc(t('sup.missingN', { n: fmtQty(x.unjustQty) }))})</span></span><span class="num neg-val">${money(x.unjustValue)}</span></div></div>` : ''}
          ${x.expensesDeducted && !p.cats ? `<div class="stat-rows"><div class="s-row"><span>− ${esc(t('sup.expDeducted'))}</span><span class="num">${money(x.expensesDeducted)}</span></div></div>` : ''}
          <div class="sup-total"><span>${esc(t('sup.total'))}</span><b class="num">${money(x.total)}</b></div>`)}
        ${card('sold', t('sup.soldTitle'), sold.length ? `<div class="stat-rows">
            ${sold.map(l => `<div class="s-row"><span>${fmtQty(outOf(l))}× ${esc(l.name)}${outOf(l) > l.sold ? ` <span class="muted small">${esc(t('sup.ofWhichOut', { n: fmtQty(round2(outOf(l) - l.sold)) }))}</span>` : ''}</span><span class="num">${money(outOf(l) * l.price)}</span></div>`).join('')}
            <div class="s-row strong"><span>${esc(t('sup.soldTotal', { n: fmtQty(soldQty) }))}</span><span class="num">${money(soldValue)}</span></div></div>
            ${x.creditSales ? `<p class="muted small" style="margin-top:8px">${esc(t('sup.soldHint', { v: money(x.creditSales) }))}</p>` : ''}` : empty(t('reports.noSales')), '', sold.length ? `${t('sup.unitsN', { n: fmtQty(soldQty) })} · ${money(soldValue)}` : '—')}
        ${card('entries', t('sup.entriesTitle'), p.entries.length ? `<div class="stat-rows">
            ${p.entries.map(e => `<div class="s-row"><span>+${fmtQty(e.qty)} ${esc(e.name)} <span class="muted small">${esc(fmtEntryDate(e.date))}</span></span><span class="num">${money(e.qty * e.price)}</span></div>`).join('')}
            <div class="s-row strong"><span>${esc(t('sup.entriesTotal', { n: fmtQty(x.inQty) }))}</span><span class="num">${money(p.entries.reduce((a, e) => a + e.qty * e.price, 0))}</span></div></div>` : empty(t('sup.noEntries')), '', p.entries.length ? `${t('sup.unitsN', { n: fmtQty(x.inQty) })} · ${money(p.entries.reduce((a, e) => a + e.qty * e.price, 0))}` : '—')}
        ${card('missing', t('sup.missing'), !p.countId ? empty(t('sup.countNone')) : missing.length ? `<div class="stat-rows">
            ${missing.map(l => `<div class="s-row"><span>${fmtQty(-l.diff)}× ${esc(l.name)}</span><span class="num neg-val">${money(-l.diff * l.price)}</span></div>`).join('')}
            <div class="s-row strong"><span>${esc(t('sup.missingTotal'))}</span><span class="num neg-val">${money(x.missingValue)}</span></div>
            ${x.surplusQty ? `<div class="s-row sur-row" role="button" tabindex="0" aria-expanded="false" data-surplus><span>${esc(t('sup.surplus'))} <span class="muted small">(${esc(t('sup.surplusHint'))})</span></span><span class="num pos-val">+${fmtQty(x.surplusQty)} <span class="chev">›</span></span></div>
            <div class="sur-list" hidden>${p.lines.filter(l => l.diff > 0).map(l => `<div class="sur-item"><span>${esc(l.name)}<small>${esc(t('sup.surplusLine', { counted: fmtQty(l.counted), expected: fmtQty(l.expected) }))}</small></span><b class="num">+${fmtQty(l.diff)}</b></div>`).join('')}
              <p class="sur-note">${esc(t('sup.surplusNote', { date: p.countAt ? fmtDate(p.countAt) : '' }))}</p></div>` : ''}</div>` : empty(t('sup.noMissing')), '', !p.countId ? '—' : missing.length ? `${t('sup.unitsN', { n: fmtQty(x.missingQty) })} · ${money(x.missingValue)}` : '0')}
        ${card('credit', t('sup.creditTitle'), `<div class="stat-rows">
            <div class="s-row"><span>${esc(t('fia.given'))}</span><span class="num">${money(p.byCounts ? p.byCounts.creditSales : x.creditSales)}</span></div>
            <div class="s-row"><span>${esc(t('fia.received'))}</span><span class="num">${money(p.byCounts ? p.byCounts.debtReceived : x.debtReceived)}</span></div>
            <div class="s-row strong"><span>${esc(t('fin.openDebt'))}</span><span class="num ${x.openDebt ? 'neg-val' : ''}">${money(x.openDebt)}</span></div></div>
            ${debtors.length ? `<ul class="pick-list">${debtors.map(c => `<li data-debtor="${c.id}"><div class="grow"><b>${esc(c.name)}</b>${c.phone ? `<div class="small muted">${esc(c.phone)}</div>` : ''}</div>
              <span class="num neg-val">${money(c.debt)}</span><button class="btn small" data-pay-debt="${c.id}">${esc(t('debt.receiveShort'))}</button></li>`).join('')}</ul>` : ''}
            <p class="muted small" style="margin-top:8px">${esc(t('fia.hint'))}</p>`, `<button class="btn primary small" id="new-credit">+ ${esc(t('fia.btn'))}</button>`)}
        ${card('expenses', t('fin.expenses'), `${p.expenseList.length ? `<ul class="pick-list exp-list">${p.expenseList.map(e => `<li>
            <div class="grow"><b>${esc(t(`exp.cat.${e.category}`))}</b>${e.description ? ` · ${esc(e.description)}` : ''}<div class="small muted">${fmtEntryDate(e.date)}</div>
              <label class="check exp-deduct"><input type="checkbox" data-deduct="${e.id}" ${e.supplierPays ? 'checked' : ''}> ${esc(t('exp.supplierPaysShort'))}</label></div>
            <span class="num">${money(e.amount)}</span></li>`).join('')}</ul>
            <div class="stat-rows"><div class="s-row strong"><span>${esc(t('totals.total'))}</span><span class="num">${money(x.expenses)}</span></div>
              <div class="s-row"><span>${esc(t('sup.expDeductedLong'))}</span><span class="num">${money(x.expensesDeducted || 0)}</span></div></div>` : empty(t('exp.none'))}
            <p class="muted small" style="margin-top:8px">${esc(t('sup.expensesHint'))}</p>`, `<button class="btn primary small" id="new-expense">+ ${esc(t('exp.add'))}</button>`)}
        ${card('stock', t('sup.stockTitle'), `<div class="stat-rows">
            <div class="s-row"><span>${esc(t('count.units'))}</span><b class="num">${fmtQty(stock.units)}</b></div>
            ${stockByCatRows(cats)}
            <div class="s-row"><span>${esc(t('count.valueRetail'))}</span><b class="num">${money(stock.retail)}</b></div></div>`)}
      </div>
      ${on('products') ? `<div class="card fold sup-products ${opened.includes('products') ? 'open' : ''}" style="margin-top:16px">${foldHead('products', t('sup.summary'), t('sup.productsN', { n: lines.length }))}
      <div class="fold-body table-wrap">${lines.length ? `<table class="table fit sup-table">
        <thead><tr><th>${esc(t('stock.item'))}</th><th class="right">${esc(t('sup.colIn'))}</th><th class="right">${esc(t('sup.colCounted'))}</th><th class="right">${esc(t('sup.colOut'))}</th></tr></thead>
        <tbody>${lines.map(l => `<tr>
          <td class="wrap">${esc(l.name)}</td><td class="right num">${l.in ? `+${fmtQty(l.in)}` : '0'}</td>
          <td class="right num">${l.counted == null ? '<span class="muted">—</span>' : fmtQty(l.counted)}</td><td class="right num">${outCell(l)}</td></tr>`).join('')}</tbody>
        <tfoot><tr class="total-row"><td>${esc(t('totals.total'))}</td>${(() => { const sm = f => fmtQty(round2(lines.reduce((a, l) => a + (Number(l[f]) || 0), 0)));
          const tot = round2(lines.reduce((a, l) => a + realOut(l), 0));
          return `<td class="right num">+${sm('in')}</td><td class="right num">${sm('counted')}</td><td class="right num">${tot > 0 ? `−${fmtQty(tot)}` : fmtQty(-tot)}</td>`; })()}</tr></tfoot></table>`
        : empty(t('sup.noMoves'))}</div></div>` : ''}
      <h3 style="margin:24px 0 2px">${esc(t('sup.history'))}</h3><p class="muted small" style="margin:0 0 10px">${esc(t('sup.historySub'))}</p>
      <div class="card table-wrap">${history.length ? `<table class="table fit">
        <thead><tr><th>${esc(t('sup.periodCol'))}</th><th class="right">${esc(t('sup.missing'))}</th><th class="right">${esc(t('sup.totalShort'))}</th></tr></thead>
        <tbody>${history.map(h => `<tr class="clickable" data-sid="${h.id}">
          <td>${esc(fmtEntryDate(h.from.slice(0, 10)))} – ${esc(fmtDate(h.to))}<div class="muted small">${esc(empName(h.employeeId))}</div></td>
          <td class="right num ${h.totals.missingValue ? 'neg-val' : ''}">${money(h.totals.missingValue)}</td>
          <td class="right num"><b>${money(h.totals.total)}</b></td></tr>`).join('')}</tbody>
        <tfoot><tr class="total-row"><td>${esc(t('totals.total'))} <span class="muted small">(${history.length})</span></td><td class="right num">${money(round2(history.reduce((a, h) => a + (h.totals.missingValue || 0), 0)))}</td><td class="right num">${money(round2(history.reduce((a, h) => a + h.totals.total, 0)))}</td></tr></tfoot></table>` : empty(t('sup.noHistory'))}</div>
    </div>`;
  arrangeKpis(main, 'sup', SUP_KPIS_DEFAULT);
  arrangeSections($('[data-sort="sup"]', main), 'sec.sup');
  // Pré-visualização: só as primeiras linhas (o total fica sempre); "Ver tudo" mostra a lista completa.
  const PREVIEW = 3;
  $$('.fold', main).forEach(box => {
    const k = $('[data-fold]', box).dataset.fold;
    const rows = [...$$('.fold-body .stat-rows:first-of-type > .s-row:not(.strong), .fold-body tbody > tr', box)];
    rows.forEach((r, i) => r.classList.toggle('fold-more', i >= PREVIEW));
    if (rows.length > PREVIEW) {
      $('.fold-body', box).insertAdjacentHTML('beforeend', `<button type="button" class="fold-toggle" data-fold="${k}"><span class="fold-all">${esc(t('sup.seeAll', { n: rows.length }))}</span><span class="fold-less">${esc(t('sup.seeLess'))}</span></button>`);
    } else box.classList.add('fold-small');
  });
  $$('[data-fold]', main).forEach(b => b.addEventListener('click', () => {
    const k = b.dataset.fold, box = b.closest('.fold'), open = !box.classList.contains('open');
    if (box.classList.contains('fold-small')) return;
    box.classList.toggle('open', open); $$('.fold-head', box).forEach(h => h.setAttribute('aria-expanded', open));
    const cur = (Layout.get('open.sup') || []).filter(x => x !== k);
    Layout.set('open.sup', open ? cur.concat(k) : cur);
  }));
  const goCount = $('#go-count', main);
  if (goCount) goCount.addEventListener('click', e => { e.preventDefault(); if (!Store.currentCount()) Store.startCount(App.user.id); App.countKind = 'normal'; App.countSits = []; App.countCats = []; App.balTab = 'stock'; render(); });
  $('#sup-period', main).addEventListener('click', () => (p.byCounts ? supCountsModal() : supPeriodModal(p)));
  $('#sup-show', main).addEventListener('click', supFilterModal);
  // Sobras: tocar mostra os produtos com unidades a mais e de onde vêm.
  $$('[data-surplus]', main).forEach(r => {
    const toggle = () => { const list = r.nextElementSibling; list.hidden = !list.hidden; r.classList.toggle('open', !list.hidden); r.setAttribute('aria-expanded', String(!list.hidden)); };
    r.addEventListener('click', e => { e.stopPropagation(); toggle(); });
    r.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); toggle(); } });
  });
  $$('[data-deduct]', main).forEach(b => b.addEventListener('change', () => guard(() => { Store.setExpenseSupplierPays(b.dataset.deduct, b.checked); render(); })));
  const newExp = $('#new-expense', main);
  if (newExp) newExp.addEventListener('click', () => expenseModal());
  $$('[data-pay-debt]', main).forEach(b => b.addEventListener('click', e => { e.stopPropagation(); debtPaymentModal(b.dataset.payDebt); }));
  const nc = $('#new-credit', main);
  if (nc) nc.addEventListener('click', () => creditModal());
  $$('[data-debtor]', main).forEach(li => li.addEventListener('click', () => customerFormModal(Store.find('customers', li.dataset.debtor))));
  $('#sup-xp', main).addEventListener('click', () => settlementExport(p, show, (Layout.get('kpi.sup') || SUP_KPIS_DEFAULT).filter(k => SUP_KPIS.includes(k))));
  $('#sup-ok', main).addEventListener('click', async () => {
    if (!need('close') || !need('editData')) return;
    if (!await confirmDialog(t('sup.confirmQ', { total: money(x.total) }), t('sup.confirm'))) return;
    guard(() => {
      const saved = Store.saveSettlement(supPreview(), App.user.id);
      App.supFrom = App.supTo = null;
      render(); toast(t('sup.done'));
      settlementExport(saved);
    });
  });
  $$('tr[data-sid]', main).forEach(tr => tr.addEventListener('click', () => settlementDetailModal(tr.dataset.sid)));
}

// Texto do fecho em forma de mensagem (para o WhatsApp), com as secções escolhidas em "Mostrar".
function settlementNotes(p, show = SUP_SECTIONS) {
  const x = p.totals;
  const n = v => fmtNum(v);
  const on = k => show.includes(k);
  const notes = [{ h: t('xn.supTitle', { date: `${dayMonth(p.from)} – ${dayMonth(p.to)}` }) }];
  if (p.cats) notes.push(t('xn.supCats', { cats: catLabel(p.cats, true) }));
  if (x.stockSalesValue != null) notes.push(t('xn.supStockSales', { v: n(x.stockSalesValue) }));
  if (on('control')) {
    const ctl = controlRows(p);
    if (ctl.rows.length) {
      notes.push({ h: `${t('xn.supControl')}:` });
      ctl.rows.forEach(g => notes.push(t('xn.supControlLine', { name: g.name, in: n(g.in), out: n(g.out), left: n(g.left) })));
      notes.push(t('xn.supControlTotal', { in: n(ctl.total.in), out: n(ctl.total.out), left: n(ctl.total.left) }));
    }
  }
  if (on('received') && !p.cats) {
    notes.push({ h: `${t('xn.supSales')}:` });
    Object.entries(x.received).forEach(([k, v]) => notes.push(`${payLabel(k)} ${n(v)}`));
    if (x.debtReceived) notes.push(t('xn.supDebt', { v: n(x.debtReceived) }));
    notes.push(t('xn.supSalesTotal', { v: n(x.toDeliver) }));
  }
  const missing = p.lines.filter(l => l.diff < 0);
  if (on('missing') || on('received')) {
    if (!p.countId) notes.push({ h: `${t('xn.supMissing')}:` }, t('xn.supNoCount'));
    else if (missing.length) {
      notes.push({ h: `${t('xn.supMissing')}:` });
      missing.forEach(l => notes.push(`${n(-l.diff)}x ${l.name} ${n(-l.diff * l.price)}`));
      notes.push(t('xn.supMissingTotal', { v: n(x.missingValue) }));
    }
    const sur = p.lines.filter(l => l.diff > 0);
    if (sur.length) {
      notes.push({ h: `${t('xn.supSurplus')}:` });
      sur.forEach(l => notes.push(t('xn.supSurplusLine', { n: n(l.diff), name: l.name, counted: n(l.counted), expected: n(l.expected) })));
      notes.push(t('xn.supSurplusNote'));
    }
  }
  if (x.expensesDeducted && !p.cats) {
    notes.push({ h: `${t('xn.supExpDeducted')}:` });
    (p.expenseList || []).filter(e => e.supplierPays).forEach(e => notes.push(`${e.description || t(`exp.cat.${e.category}`)} (${fmtEntryDate(e.date).slice(0, 5)}) ${n(e.amount)}`));
    notes.push(t('xn.supExpDeductedTotal', { v: n(x.expensesDeducted) }));
  }
  notes.push({ h: t('xn.supTotal', { v: n(x.total) }) });
  const outOf = l => (l.out != null ? l.out : l.sold);
  const sold = p.lines.filter(l => outOf(l) > 0);
  if (on('sold') && sold.length) { notes.push({ h: `${t('xn.supSold')}:` }); sold.forEach(l => notes.push(`${n(outOf(l))}x ${l.name} ${n(outOf(l) * l.price)}`)); }
  if (on('entries') && p.entries && p.entries.length) { notes.push({ h: `${t('xn.supEntries')}:` }); p.entries.forEach(e => notes.push(`${n(e.qty)}x ${e.name} (${fmtEntryDate(e.date).slice(0, 5)})`)); }
  if (on('credit') && (x.creditSales || x.openDebt)) notes.push({ h: `${t('xn.supCredit')}:` }, t('xn.supCreditLine', { sold: n(x.creditSales), paid: n(x.debtReceived), open: n(x.openDebt) }));
  if (on('expenses') && x.expenses) notes.push({ h: `${t('xn.supExpenses')}:` }, ...(p.expenseList || []).map(e => `${t(`exp.cat.${e.category}`)}${e.description ? ` (${e.description})` : ''} ${n(e.amount)}`), t('xn.supExpensesTotal', { v: n(x.expenses) }));
  return notes;
}

// Fecho anterior: resumo, exportar, corrigir (datas e nota; as contas refazem-se) ou apagar.
function settlementDetailModal(id) {
  const h = Store.find('settlements', id);
  if (!h) return;
  const x = h.totals;
  const row = (k, v, cls = '') => `<div class="s-row ${cls}"><span>${esc(k)}</span><b class="num">${v}</b></div>`;
  // Fiado aberto: no fecho entre contagens é descontado do total (vendido a crédito − recebido), por isso vem com "−" antes do Total.
  const bc = h.byCounts;
  const fiado = bc ? round2((bc.creditSales || 0) - (bc.debtReceived || 0)) : null;
  const fiadoRow = bc ? (fiado ? [`− ${t('sup.openDebtAberto')}`, money(fiado)] : null) : null;
  const m = openModal({
    title: `${t('sup.title')}`,
    body: `
      <p class="sup-period"><b>${esc(fmtDate(h.from))} – ${esc(fmtDate(h.to))}</b></p>
      <div class="stat-rows">
        ${x.stockSalesValue != null ? row(t('sup.stockSales'), money(x.stockSalesValue)) : ''}
        ${row(t('sup.toDeliver'), money(x.toDeliver))}
        ${row(t('sup.missingRow'), money(x.missingValue))}
        ${x.unjustValue ? row(t('sup.unjustRow'), money(x.unjustValue)) : ''}
        ${x.expensesDeducted ? row(`− ${t('sup.expDeducted')}`, money(x.expensesDeducted)) : ''}
        ${fiadoRow ? row(fiadoRow[0], fiadoRow[1]) : ''}
        ${row(t('sup.total'), money(x.total), 'strong')}
        ${bc ? '' : row(t('sup.openDebtShort'), money(x.openDebt))}
      </div>
      ${h.note ? `<p class="small" style="margin-top:12px"><b>${esc(t('sup.note'))}:</b> ${esc(h.note)}</p>` : ''}
      <p class="muted small" style="margin-top:12px">${esc(empName(h.employeeId))}${h.editedAt ? ` · ${esc(t('sup.editedAt', { date: fmtDate(h.editedAt) }))}` : ''}</p>`,
    footer: footer3([['danger', 'data-del', 'trash', t('common.delete')], ['', 'data-xp', 'download', t('xp.title')], ['', 'data-chat', 'send', t('al.sendChat')], ['primary', 'data-edit', 'edit', t('count.edit')]]),
  });
  $('[data-xp]', m).onclick = () => settlementExport(h, SUP_SECTIONS);
  // Enviar o resumo do fecho no chat (cartão que abre o resumo, ou texto na mensagem).
  $('[data-chat]', m).onclick = () => {
    const rows = [...(x.stockSalesValue != null ? [[t('sup.stockSales'), money(x.stockSalesValue)]] : []), [t('sup.toDeliver'), money(x.toDeliver)], [t('sup.missingRow'), money(x.missingValue)],
      ...(x.unjustValue ? [[t('sup.unjustRow'), money(x.unjustValue)]] : []), ...(x.expensesDeducted ? [[`− ${t('sup.expDeducted')}`, money(x.expensesDeducted)]] : []), ...(bc ? (fiadoRow ? [fiadoRow] : []) : [[t('sup.openDebtShort'), money(x.openDebt)]])];
    const per = `${fmtDate(h.from).split(',')[0]} – ${fmtDate(h.to).split(',')[0]}`;
    const card = { v: 1, type: 'snap', title: t('sup.title'), sub: per, cols: ['', ''], rows: [...rows.slice(0, 3), [t('sup.total'), money(x.total)]].slice(-4), more: 0,
      snap: { cols: [per, ''], rows, foot: [t('sup.total'), money(x.total)] } };
    const text = [`*${t('sup.title')}*`, per, ...rows.map(r => `${r[0]}: ${r[1]}`), `*${t('sup.total')}: ${money(x.total)}*`].join('\n');
    sendTableToChat(card, text, () => settlementDetailModal(id));
  };
  $('[data-edit]', m).onclick = () => settlementEditModal(h.id);
  $('[data-del]', m).onclick = async () => {
    if (!await confirmDialog(t('sup.deleteConfirm', { from: fmtDate(h.from), to: fmtDate(h.to) }), t('common.delete'), true)) return settlementDetailModal(id);
    Store.deleteSettlement(h.id); render(); toast(t('sup.deleted'));
  };
}

function settlementEditModal(id) {
  const h = Store.find('settlements', id);
  if (!h) return;
  const fromDay = dayKey(new Date(h.from)), toDay = dayKey(new Date(h.to));
  const m = openModal({
    title: t('sup.editTitle'),
    autofocus: false,
    body: `<form id="sef">
      <div class="row">
        <label class="field"><span>${esc(t('reports.from'))}</span><input class="input" type="date" name="from" value="${fromDay}" max="${dayKey(new Date())}" required></label>
        <label class="field"><span>${esc(t('reports.to'))}</span><input class="input" type="date" name="to" value="${toDay}" max="${dayKey(new Date())}" required></label>
      </div>
      <label class="field"><span>${esc(t('sup.note'))}</span><textarea class="input" name="note" rows="2" placeholder="${esc(t('sup.notePlaceholder'))}">${esc(h.note || '')}</textarea></label>
      <p class="muted small">${esc(t('sup.editHint'))}</p>
    </form>`,
    footer: `<button class="btn primary" data-ok>${esc(t('common.save'))}</button>`,
  });
  onModalClose(m, () => settlementDetailModal(id));
  $('[data-ok]', m).onclick = () => guard(() => {
    const f = formObj($('#sef', m));
    if (!f.from || !f.to) { toast(t('reports.needDates'), true); return; }
    // Datas por mudar ficam com a hora exata de antes (o fim do fecho anterior, a hora do fecho).
    const from = f.from === fromDay ? h.from : new Date(`${f.from}T00:00:00`).toISOString();
    const to = f.to === toDay ? h.to : new Date(`${f.to}T23:59:59.999`).toISOString();
    Store.updateSettlement(id, { from, to, note: f.note }, App.user.id);
    render(); toast(t('sup.saved'));
    settlementDetailModal(id);
  });
}

// Valores dos cartões do Fecho (iguais aos do ecrã), para o resumo da exportação.
function supKpiValues(p) {
  const x = p.totals, ctl = controlRows(p);
  const stockSalesValue = x.stockSalesValue != null ? x.stockSalesValue : x.soldValue;
  return {
    stockSales: [t('sup.stockSales'), money(stockSalesValue)],
    missing: [t('sup.missing'), p.countId ? money(x.missingValue) : '—'],
    total: [t('sup.total'), money(x.total), true],
    openDebt: [t('sup.openDebtShort'), money(x.openDebt)],
    registered: [t('sup.toDeliver'), money(x.toDeliver)],
    expenses: [t('sup.expDeducted'), money(x.expensesDeducted || 0)],
    unitsIn: [t('sup.kpi.unitsIn'), fmtQty(ctl.total.in)],
    unitsOut: [t('sup.kpi.unitsOut'), fmtQty(ctl.total.out)],
  };
}

function settlementExport(p, show = supShown(), kpis = null) {
  const moved = p.lines.filter(l => l.in || l.sold || l.adjust || l.diff);
  const keep = [0, 3, 4, 5, 6, 7]; // Produto, Entrou, Vendido, Devia haver, Contado, Falta
  const pick = r => keep.map(i => r[i]);
  // Vendido = tudo o que saiu do stock (registado na caixa + saídas sem registo), como no ecrã do Fecho.
  const outOf = l => (l.out != null ? l.out : l.sold);
  const sumOf = f => round2(moved.reduce((a, l) => a + (Number(f(l)) || 0), 0));
  const row = l => [l.name, l.price, l.opening, l.in, outOf(l), l.expected, l.counted == null ? '—' : l.counted, l.diff == null ? '—' : round2(-l.diff), round2(outOf(l) * l.price)];
  const totals = [t('totals.total'), '', sumOf(l => l.opening), sumOf(l => l.in), sumOf(outOf), sumOf(l => l.expected), p.countId ? sumOf(l => l.counted) : '', p.countId ? sumOf(l => (l.diff == null ? 0 : -l.diff)) : '', sumOf(l => outOf(l) * l.price)];
  const x = p.totals;
  // Resumo = os mesmos cartões escolhidos no filtro (e pela mesma ordem). Fechos guardados usam o resumo completo.
  const kv = supKpiValues(p);
  const summary = kpis ? kpis.filter(k => kv[k]).map(k => kv[k])
    : [
      ...(x.stockSalesValue != null ? [[t('sup.stockSales'), money(x.stockSalesValue)]] : []),
      [t('sup.toDeliver'), money(x.toDeliver)],
      [t('sup.missingRow'), p.countId ? money(x.missingValue) : '—'],
      ...(x.unjustValue ? [[t('sup.unjustRow'), money(x.unjustValue)]] : []),
      ...(x.expensesDeducted && !p.cats ? [[`− ${t('sup.expDeducted')}`, money(x.expensesDeducted)]] : []),
      [t('sup.total'), money(x.total), true],
      [t('sup.openDebtShort'), money(x.openDebt)],
    ];
  const subtitle = [`${fmtDate(p.from)} – ${fmtDate(p.to)}`, p.cats ? catLabel(p.cats) : ''].filter(Boolean).join(' · ');
  const base = { summary, title: t('sup.title'), subtitle, file: 'fecho-fornecedor', notes: settlementNotes(p, show) };
  // Tabela: o Movimento de produtos (como no ecrã); se estiver escondido, o Controlo de mercadoria; senão, só o resumo.
  if (show.includes('products')) {
    exportModal(Object.assign(base, {
      tableTitle: t('sup.summary'),
      image: { columns: pick([t('stock.item'), '', '', t('sup.colIn'), t('sup.colSold'), t('sup.colExpected'), t('sup.colCounted'), t('sup.colDiff')]), rows: moved.map(l => pick(row(l))), totals: pick(totals), numeric: [1, 2, 3, 4, 5] },
      columns: [t('stock.item'), t('items.price'), t('sup.colOpening'), t('sup.colIn'), t('sup.colSold'), t('sup.colExpected'), t('sup.colCounted'), t('sup.colDiff'), t('sup.colValue')],
      numeric: [1, 2, 3, 4, 5, 6, 7, 8],
      rows: moved.map(row),
      totals,
    }));
  } else if (show.includes('control')) {
    const ctl = controlRows(p);
    const r = g => [g.name, round2(g.opening), round2(g.in), round2(g.out), round2(g.left)];
    exportModal(Object.assign(base, {
      tableTitle: t('sup.sec.control'),
      columns: [t('items.category'), t('sup.colOpening'), t('sup.colIn'), t('sup.colOut'), t('sup.colLeft')],
      numeric: [1, 2, 3, 4], rows: ctl.rows.map(r), totals: r(ctl.total),
    }));
  } else {
    exportModal(Object.assign(base, { columns: [t('common.name'), t('totals.total')], numeric: [1], rows: summary.map(s2 => [s2[0], s2[1]]) }));
  }
}

// Lista dos não contados: mostra 4 e "+ N produtos" abre o resto (e "Ver menos" volta a fechar).
const ucList = (unc, right) => unc.map((u, i) => `<div class="uc-li ${i >= 4 ? 'uc-x' : ''}"><span>${esc(dn(u.item))}</span>${right(u)}</div>`).join('')
  + (unc.length > 4 ? `<button type="button" class="uc-more" onclick="const l=this.parentNode;const o=l.classList.toggle('uc-open');this.textContent=o?this.dataset.less:this.dataset.more" data-more="${esc(t('count.moreN', { n: unc.length - 4 }))}" data-less="${esc(t('today.less'))}">${esc(t('count.moreN', { n: unc.length - 4 }))}</button>` : '');
// Atualizar: preencher os não contados com o Sistema; numa contagem concluída também
// "Atualizar o Sistema com o stock de agora" (o que o botão fazia antes).
function countFillModal(c, back) {
  const unc = c.lines.filter(l => l.counted == null).map(l => {
    const item = Store.find('items', l.itemId);
    return item && item.trackStock ? { item, sys: Math.max(0, round2(c.status === 'draft' ? Store.countStock(c, item) : l.expected)) } : null;
  }).filter(Boolean);
  const canSys = c.status === 'done' && !Store.isCheck(c);
  let pick = unc.length ? 'fill' : canSys ? 'sys' : 'fill';
  const list = ucList(unc, u => `<b class="pos-val">— → ${fmtQty(u.sys)}</b>`);
  const m = openModal({
    title: t('count.refreshShort'),
    autofocus: false,
    body: `<p class="muted small" style="margin:0 0 10px">${esc(t('count.fillPick'))}</p>
      <button type="button" class="uc-opt" data-pick="fill" ${unc.length ? '' : 'disabled'}><b>${esc(t('count.fillTitle', { n: unc.length }))}</b><small>${esc(t(unc.length ? 'count.fillSub' : 'count.fillNone'))}</small></button>
      ${unc.length ? `<div class="uc-list">${list}</div>` : ''}
      ${canSys ? `<button type="button" class="uc-opt" data-pick="sys"><b>${esc(t('count.sysTitle'))}</b><small>${esc(t('count.sysSub'))}</small></button>` : ''}`,
    footer: `<button class="btn primary" data-ok></button>`,
  });
  if (back) onModalClose(m, back);
  const ok = $('[data-ok]', m);
  const paintBtn = () => {
    ok.textContent = pick === 'fill' ? t('count.fillBtn', { n: unc.length }) : t('count.refreshShort');
    ok.disabled = pick === 'fill' && !unc.length;
    $$('[data-pick]', m).forEach(b => b.classList.toggle('on', b.dataset.pick === pick));
  };
  $$('[data-pick]', m).forEach(b => b.addEventListener('click', () => { pick = b.dataset.pick; paintBtn(); }));
  paintBtn();
  ok.onclick = () => guard(() => {
    if (pick === 'fill') { const n = Store.fillUncounted(c.id, App.user.id); toast(t('count.filled', { n })); } else { Store.refreshCount(c.id, App.user.id); toast(t('count.refreshed')); }
    App.stale = true; closeModal(); if (!back) render();
  });
}

// Concluir: se ficaram produtos com stock por contar, avisa que vão a 0 (não contado = 0).
function countFinishModal(c) {
  const unc = Store.uncountedWithStock(c);
  if (!unc.length) { countFinishModalMain(c); return; }
  const list = ucList(unc, u => `<b class="neg-val">${fmtQty(u.sys)} → 0</b>`);
  const m = openModal({
    title: t('count.uncTitle', { n: unc.length }),
    autofocus: false,
    body: `<p class="small" style="margin:0 0 10px">${esc(t('count.uncText'))}</p><div class="uc-list">${list}</div>`,
    footer: `<div class="uc-foot"><button class="btn danger" data-zero>${esc(t('count.uncZero'))}</button><button class="btn ghost" data-back>${esc(t('count.uncBack'))}</button></div>`,
  });
  $('[data-back]', m).onclick = () => closeModal();
  $('[data-zero]', m).onclick = () => guard(() => {
    Store.setCountValues(c.id, unc.map(u => ({ itemId: u.item.id, value: 0 })), App.user.id);
    closeModal();
    countFinishModalMain(c);
  });
}

function countFinishModalMain(c) {
  if (!need('count')) return;
  let counted = 0, withDiff = 0, diffValue = 0;
  for (const l of c.lines) {
    const item = Store.find('items', l.itemId);
    if (!item || l.counted == null) continue;
    counted++;
    const d = round2(l.counted - item.stock);
    if (d !== 0) { withDiff++; diffValue += d * unitValue(item); }
  }
  const total = c.lines.length;
  const check = Store.isCheck(c);
  const m = openModal({
    title: t(check ? 'chk.finish' : 'count.finish'),
    autofocus: false,
    body: `<div class="stat-rows">
        <div class="s-row"><span>${esc(t('count.countedItems'))}</span><b>${counted} / ${total}</b></div>
        <div class="s-row"><span>${esc(t('count.withDiff'))}</span><b>${withDiff}</b></div>
        <div class="s-row strong"><span>${esc(diffValueLabel())}</span><span class="num ${diffValue < 0 ? 'neg-val' : diffValue > 0 ? 'pos-val' : ''}">${money(diffValue)}</span></div>
      </div>
      ${counted < total ? `<p class="muted small" style="margin-top:12px">${esc(t('count.uncountedNote', { n: total - counted }))}</p>` : ''}
      <p class="small" style="margin-top:12px">${esc(t(check ? 'chk.finishNote' : 'count.finishNote'))}</p>`,
    footer: `<button class="btn primary" data-ok ${counted ? '' : 'disabled'}>${esc(t(check ? 'chk.finish' : 'count.finish'))}</button>`,
  });
  $('[data-ok]', m).onclick = () => guard(() => {
    const done = Store.finishCount(c.id, App.user.id, `${t('count.title')} ${fmtDay(new Date())}`);
    closeModal(); render(); toast(t(check ? 'chk.done' : 'count.done'));
    App.cdFrom = null;
    if (check) checkDetailModal(done.id); else countDetailModal(done.id);
  });
}

function viewCountHome(main) {
  const v = Store.stockValue();
  const tracked = Store.data.items.filter(i => i.trackStock).length;
  // Produtos em stock sem preço de compra: o valor a custo e as diferenças ficam incompletos.
  const noCost = Store.data.items.filter(i => i.trackStock && i.stock > 0 && !(i.cost > 0));
  const kind = countKind();
  if (App.sbPage && kind === 'normal') return sbPageView(main);
  const history = Store.data.stockCounts.filter(c => c.status === 'done' && !Store.isCheck(c)).sort((a, b) => b.finishedAt.localeCompare(a.finishedAt));
  const lastC = history[0];
  const top = countStepsHtml(history, tracked);
  const kpi = (id, label, value, cls = '', sub = '') => `<div class="card kpi" data-kid="${id}"><div class="k-label">${esc(label)}</div><div class="k-value num ${cls}">${value}</div>${sub ? `<div class="k-sub">${esc(sub)}</div>` : ''}</div>`;
  main.innerHTML = `
    <div class="page">
      ${top}
      <div class="grid-2" data-sort="count">
        <div class="card card-pad" data-sec="value">
          <h3>${esc(t('count.valueTitle'))}</h3>
          <div class="stat-rows">
            <div class="s-row"><span>${esc(t('count.units'))}</span><b class="num">${fmtQty(v.units)}</b></div>
            ${stockByCatRows()}
            <div class="s-row cost-only"><span>${esc(t('count.valueCost'))}</span><b class="num">${money(v.cost)}</b></div>
            <div class="s-row"><span>${esc(t('count.valueRetail'))}</span><b class="num">${money(v.retail)}</b></div>
            <div class="s-row cost-only"><span>${esc(t('count.potentialProfit'))}</span><b class="num pos-val">${money(v.retail - v.cost)}</b></div>
          </div>
          ${noCost.length && !NOCOST() ? `<div class="notice warn" style="margin-top:12px">${icon('tag')}<div>${esc(t('count.noCostWarn', { n: noCost.length, names: noCost.slice(0, 3).map(i => i.name).join(', ') + (noCost.length > 3 ? '…' : '') }))} <a href="#itens">${esc(t('rep.openItems'))}</a></div></div>` : ''}
        </div>
      </div>
      <h3 style="margin:24px 0 10px">${esc(t('count.history'))}</h3>
      <div class="card table-wrap">${history.length ? `<table class="table fit">
        <thead><tr><th>${esc(t('common.date'))}</th><th class="right">${esc(t('count.withDiffShort'))}</th><th class="right">${esc(diffValueLabel())}</th><th class="hide-sm">${esc(t('receipts.employee'))}</th></tr></thead>
        <tbody>${history.map(c => `<tr class="clickable" data-id="${c.id}">
          <td>${fmtDate(c.finishedAt)}<div class="muted small">${esc(t('count.countedOf', { n: c.totals.counted, total: c.totals.items }))}</div></td>
          <td class="right">${c.totals.withDiff}</td>
          <td class="right num ${countDiffValue(c) < 0 ? 'neg-val' : countDiffValue(c) > 0 ? 'pos-val' : ''}">${money(countDiffValue(c))}</td>
          <td class="hide-sm">${esc(empName(c.finishedBy))}</td></tr>`).join('')}</tbody>
        <tfoot><tr class="total-row"><td>${esc(t('totals.total'))} <span class="muted small">(${history.length})</span></td><td class="right">${history.reduce((a, c) => a + c.totals.withDiff, 0)}</td><td class="right num">${money(round2(history.reduce((a, c) => a + countDiffValue(c), 0)))}</td><td class="hide-sm"></td></tr></tfoot></table>` : `<div class="empty">${esc(t('count.noHistory'))}</div>`}</div>
    </div>`;
  bindCountSteps(main);
  $$('[data-step="count"]', main).forEach(b => b.addEventListener('click', e => {
    e.stopPropagation();
    if (!tracked) return toast(t('stock.noTracked'), true);
    const today = dayKey(new Date());
    const m = openModal({ title: t('steps.newCount'), autofocus: false,
      body: `<p class="muted" style="margin:0 0 12px">${esc(t('steps.newCountHint'))}</p>
        <label class="field"><span>${esc(t('cb.countDate'))}</span><input class="input" type="date" id="cd-day" value="${today}" max="${today}"></label>
        <p class="muted small">${esc(t('cb.countDateHint'))}</p>`,
      footer: `<button class="btn primary" data-ok>${esc(t('cb.startCounting'))}</button>` });
    $('[data-ok]', m).onclick = () => guard(() => {
      Store.startCount(App.user.id, 'normal', $('#cd-day', m).value || today);
      closeModal(); App.countSits = []; App.countCats = []; App.countQ = ''; render();
    });
    return undefined;
  }));
  $$('tr[data-id]', main).forEach(tr => tr.addEventListener('click', () => { App.cdFrom = null; countDetailModal(tr.dataset.id); }));
  const rb = $('#rebase', main);
  if (rb) rb.addEventListener('click', rebaseModal);
}

// Passos do fecho: 1 Contar · 2 Ver o balanço · 3 Fazer o fecho. Cada passo sabe se já foi feito
// para a última contagem; o primeiro que falta fica em destaque com o botão "Abrir".
// Passos do fecho: 1 Contar (as duas contagens do período) · 2 Ver o balanço · 3 Fazer o fecho.
// Depois de confirmar um fecho, os passos voltam a zero: o período seguinte precisa de duas contagens novas.
function countSteps(history) {
  const short = iso => fmtEntryDate(iso).slice(0, 5);
  const day = c => Store.countDay(c);
  const ls = Store.lastSettlement();
  // Contagens do período: só as feitas depois do último fecho confirmado (as duas mais recentes).
  const period = history.filter(c => !ls || c.finishedAt > ls.to).slice(0, 2).reverse();
  const have = period.length;
  const first = period[0], second = period[1];
  const balDone = have === 2 && Store.data.stockBalances.some(b => b.mode === 'counts' && b.toId === second.id);
  const countSub = have === 2 ? t('steps.countBoth', { a: short(day(first)), b: short(day(second)) })
    : have === 1 ? t('steps.countOne', { date: short(day(first)) }) : t('steps.countNone');
  const steps = [
    { key: 'count', title: t('steps.count'), done: have === 2, sub: countSub, have },
    // Sem as duas contagens novas, o balanço e o fecho continuam a abrir para consultar os últimos.
    { key: 'balance', title: t('steps.balance'), done: balDone, off: history.length < 2,
      sub: have === 2 ? t('steps.balanceSub', { from: short(day(first)), to: short(day(second)) })
        : history.length >= 2 ? t('steps.lastBalance', { from: short(day(history[1])), to: short(day(history[0])) }) : t('steps.balanceNeed2') },
    { key: 'close', title: t(CONSIGN() ? 'steps.close' : 'steps.finance'), done: false, off: history.length < 2,
      sub: have < 2 && ls ? t('steps.lastClose', { date: fmtEntryDate(dayKey(new Date(ls.to))).slice(0, 5) }) : t(CONSIGN() ? 'steps.closeSub' : 'steps.financeSub') },
  ];
  // O passo em destaque: o primeiro por fazer (enquanto faltam contagens, é o 1).
  const next = have < 2 ? steps[0] : steps.find(x => !x.done && !x.off);
  if (next) next.next = true;
  return steps;
}
function countStepsHtml(history, tracked) {
  const steps = countSteps(history);
  const n = steps.filter(x => x.done).length;
  const bars = h => `<span class="step-bars">${[0, 1].map(k => `<i class="${k < h ? 'on' : ''}"></i>`).join('')}</span>`;
  const right = x => (x.key === 'count' && !x.done ? (tracked ? `<b class="step-go">${esc(t('steps.countGo'))} ›</b>` : '')
    : x.next ? `<button class="btn primary small" type="button">${esc(t('steps.open'))}</button>`
      : x.done ? `<span class="step-ok">${esc(t('steps.done'))}</span>` : '');
  return `<div class="card steps-card">
    <h3 class="steps-title">${esc(t('steps.title'))}</h3>
    <div class="steps" style="--fill:${n >= 2 ? 75 : n === 1 ? 25 : 0}%">
      ${steps.map((x, i) => `<div class="step ${x.done ? 'done' : x.next ? 'next' : 'todo'} ${x.off ? 'off' : ''}" ${x.off ? '' : `data-step="${x.key}"`}>
        <span class="step-dot">${x.done ? icon('check') : i + 1}</span>
        <span class="step-txt"><b>${esc(x.title)}</b><small>${esc(x.sub)}</small>${x.key === 'count' ? bars(x.have) : ''}</span>
        ${right(x)}
      </div>`).join('')}
    </div>
  </div>`;
}
function bindCountSteps(main) {
  const go = { balance: () => { App.sbPage = true; render(); }, close: () => { App.balTab = CONSIGN() ? 'supplier' : 'finance'; render(); } };
  $$('.step[data-step]', main).forEach(el => { if (go[el.dataset.step]) el.addEventListener('click', go[el.dataset.step]); });
}

// Acertar o stock pela última contagem: mostra o que muda e aplica.
function rebaseModal() {
  const list = Store.rebasePreview();
  const m = openModal({ title: t('rb.title'), wide: true, autofocus: false,
    body: `<p class="muted small" style="margin:0 0 10px">${esc(t('rb.hint'))}</p>
      ${list.length ? `<div class="table-wrap"><table class="table fit vtbl">
        <thead><tr><th>${esc(t('stock.item'))}</th><th class="right">${esc(t('rb.count'))}</th><th class="right">${esc(t('rb.now'))}</th><th class="right">${esc(t('rb.target'))}</th></tr></thead>
        <tbody>${list.map(x => `<tr><td class="wrap">${esc(x.name)}</td><td class="right">${esc(fmtEntryDate(x.day).slice(0, 5))}</td><td class="right num neg-val">${fmtQty(x.now)}</td><td class="right num"><b>${fmtQty(x.target)}</b></td></tr>`).join('')}</tbody>
      </table></div>` : `<div class="notice ok">${icon('check')}<div>${esc(t('rb.none'))}</div></div>`}`,
    footer: list.length ? `<button class="btn primary" data-ok>${esc(t('rb.apply', { n: list.length }))}</button>` : '' });
  const ok = $('[data-ok]', m);
  if (ok) ok.onclick = () => guard(() => { const n = Store.rebaseFromLastCount(App.user.id); closeModal(); App.stale = true; render(); toast(t('rb.done', { n })); });
}

// Botão "Vendas" e separadores do topo da Contagem.
function bindCountTop(main) {
  $('#count-sales', main).addEventListener('click', salesSinceModal);
  const sbBtn = $('#count-sb', main);
  if (sbBtn) sbBtn.addEventListener('click', () => { App.sbPage = true; render(); });
  $$('.cnt-tabs [data-kind]', main).forEach(b => b.addEventListener('click', () => {
    App.countKind = b.dataset.kind; App.countSits = []; App.countCats = []; App.countQ = ''; render();
  }));
}

const startCheck = () => { App.countKind = 'check'; Store.startCount(App.user.id, 'check'); App.countSits = []; App.countCats = []; App.countQ = ''; render(); };

// Vendas desde o último balanço: só os produtos contados. Agora = Contado + Entrou − Vendido.
function salesSinceModal() {
  const s = Store.salesSinceCount();
  if (!s) return toast(t('chk.noCount'), true);
  const tt = s.totals;
  const sign = n => (n > 0 ? `+${fmtQty(n)}` : fmtQty(n));
  const m = openModal({
    title: t('chk.salesTitle'), wide: true, autofocus: false,
    body: `<p class="muted small" style="margin:0 0 8px">${esc(t('chk.salesSub', { date: fmtDate(s.from) }))}</p>
      ${s.lines.length ? `<div class="table-wrap"><table class="table fit vtbl">
        <thead><tr><th>${esc(t('stock.item'))}</th><th class="right">${esc(t('chk.colCounted'))}</th><th class="right">${esc(t('chk.colIn'))}</th><th class="right">${esc(t('chk.colSold'))}</th><th class="right">${esc(t('chk.colNow'))}</th></tr></thead>
        <tbody>${s.lines.map(l => `<tr><td class="wrap">${esc(nameOf(l.itemId, l.name))}</td><td class="right num">${fmtQty(l.counted)}</td>
          <td class="right num">${sign(l.in)}</td><td class="right num"><b>${fmtQty(l.sold)}</b></td><td class="right num">${fmtQty(l.now)}</td></tr>`).join('')}</tbody>
        <tfoot><tr class="total-row"><td>${esc(t('totals.total'))}</td><td class="right num">${fmtQty(tt.counted)}</td><td class="right num">${sign(tt.in)}</td><td class="right num">${fmtQty(tt.sold)}</td><td class="right num">${fmtQty(tt.now)}</td></tr></tfoot>
      </table></div>` : `<div class="empty">${esc(t('chk.noLines'))}</div>`}
      <div class="stat-rows" style="margin-top:10px"><div class="s-row strong"><span>${esc(t('chk.posSold'))}</span><span class="num">${money(s.posTotal)}</span></div></div>
      <p class="muted small" style="margin:8px 0 0">${esc(t('chk.nowHint'))}</p>`,
    footer: `<button class="btn" data-xp>${icon('download')} ${esc(t('xp.title'))}</button>`,
  });
  $('[data-xp]', m).onclick = () => exportModal({
    title: t('chk.salesTitle'), subtitle: t('chk.since', { date: fmtDate(s.from) }), file: 'vendas_desde_balanco', notes: [],
    columns: [t('stock.item'), t('chk.colCounted'), t('chk.colIn'), t('chk.colSold'), t('chk.colNow')], numeric: [1, 2, 3, 4],
    rows: s.lines.map(l => [nameOf(l.itemId, l.name), l.counted, l.in, l.sold, l.now]),
    totals: [t('totals.total'), tt.counted, tt.in, tt.sold, tt.now],
    summary: [[t('chk.posSold'), money(s.posTotal), true]],
  });
}

// Resultado de uma verificação: Certo / Falta (com valor) / Sobra, só dos produtos contados.
function checkResultHtml(c) {
  const lines = c.lines.filter(l => l.counted != null)
    .sort((a, b) => (a.diff || 0) - (b.diff || 0) || a.name.localeCompare(b.name, 'pt'));
  const tt = c.totals;
  const pill = l => (!l.diff ? `<span class="pill ok">${esc(t('chk.ok'))}</span>`
    : l.diff < 0 ? `<span class="pill red">${esc(t('chk.miss', { n: fmtQty(-l.diff), v: money(-l.diff * unitValue(l)) }))}</span>`
      : `<span class="pill sur">${esc(t('chk.sur', { n: fmtQty(l.diff) }))}</span>`);
  const result = tt.missValue > 0 ? `<span class="num neg-val">${esc(t('chk.resMiss', { v: money(tt.missValue) }))}</span>`
    : `<span class="num pos-val">${esc(t('chk.resOk'))}</span>`;
  return `<div class="chk-list">${lines.map(l => `<div class="chk"><span>${esc(nameOf(l.itemId, l.name))}<small>${esc(t('chk.line', { counted: fmtQty(l.counted), expected: fmtQty(l.expected) }))}</small></span>${pill(l)}</div>`).join('')}</div>
    <div class="stat-rows" style="margin-top:6px">
      ${tt.surQty ? `<div class="s-row"><span>${esc(t('chk.surTotal'))}</span><b class="num">+${fmtQty(tt.surQty)}</b></div>` : ''}
      <div class="s-row strong"><span>${esc(t('chk.result'))}</span>${result}</div>
    </div>`;
}

function viewCheckHome(main, top, tracked) {
  const checks = Store.data.stockCounts.filter(c => c.status === 'done' && Store.isCheck(c)).sort((a, b) => b.finishedAt.localeCompare(a.finishedAt));
  const last = checks[0];
  main.innerHTML = `
    <div class="page">
      ${top}
      <div class="grid-2">
        <div class="card card-pad">
          <h3>${esc(t('chk.newTitle'))}</h3>
          <p class="muted">${esc(t('chk.intro'))}</p>
          <button class="btn primary" id="start-check" ${tracked ? '' : 'disabled'}>${esc(t('chk.start'))}</button>
        </div>
        ${last ? `<div class="card card-pad chk-last" data-id="${last.id}">
          <h3>${esc(t('chk.lastTitle', { date: fmtDate(last.finishedAt) }))}</h3>
          ${checkResultHtml(last)}
          <div class="acts">${last.saved ? `<span class="muted small chk-saved">${icon('check')} ${esc(t('chk.savedApart'))}</span>`
            : `<button class="btn" data-save>${esc(t('chk.save'))}</button>`}<button class="btn primary" data-apply>${esc(t('chk.apply'))}</button></div>
          <p class="muted small" style="margin:8px 0 0">${esc(t('chk.applyHint'))}</p>
        </div>` : ''}
      </div>
      <h3 style="margin:24px 0 10px">${esc(t('chk.history'))}</h3>
      <div class="card table-wrap">${checks.length ? `<table class="table fit">
        <thead><tr><th>${esc(t('common.date'))}</th><th class="right">${esc(t('chk.colMiss'))}</th><th class="right">${esc(t('chk.colSur'))}</th><th class="right">${esc(t('chk.colValue'))}</th></tr></thead>
        <tbody>${checks.map(c => `<tr class="clickable" data-id="${c.id}">
          <td>${fmtDate(c.finishedAt)}<div class="muted small">${esc(t('count.countedOf', { n: c.totals.counted, total: c.totals.items }))}</div></td>
          <td class="right">${fmtQty(c.totals.missQty || 0)}</td><td class="right">${fmtQty(c.totals.surQty || 0)}</td>
          <td class="right num ${c.totals.missValue > 0 ? 'neg-val' : ''}">${money(-(c.totals.missValue || 0))}</td></tr>`).join('')}</tbody>
      </table>` : `<div class="empty">${esc(t('chk.none'))}</div>`}</div>
    </div>`;
  bindCountTop(main);
  $('#count-show', main).addEventListener('click', () => {
    const m = openModal({ title: t('kpi.showTitle'), autofocus: false, body: cardsSectionHtml('count'), footer: `<button class="btn primary" data-ok>${esc(t('common.apply'))}</button>` });
    $('[data-ok]', m).onclick = () => { saveCardsSection(m, 'count'); closeModal(); App.countKind = 'normal'; render(); };
  });
  $('#start-check', main).addEventListener('click', () => guard(startCheck));
  if (last) {
    const card = $('.chk-last', main);
    const save = $('[data-save]', card);
    if (save) save.addEventListener('click', () => guard(() => { Store.saveCheck(last.id); toast(t('chk.savedToast')); render(); }));
    $('[data-apply]', card).addEventListener('click', () => applyCheckAsk(last.id));
  }
  $$('tr[data-id]', main).forEach(tr => tr.addEventListener('click', () => checkDetailModal(tr.dataset.id)));
}

async function applyCheckAsk(id) {
  if (!await confirmDialog(t('chk.applyConfirm'), t('chk.apply'))) return;
  guard(() => { const c = Store.applyCheck(id, App.user.id); App.stale = true; toast(t('chk.applied')); render(); countDetailModal(c.id); });
}

function checkDetailModal(id) {
  const c = Store.find('stockCounts', id);
  if (!c) return;
  const m = openModal({
    title: `${t('chk.title')} · ${fmtDate(c.finishedAt)}`, autofocus: false,
    body: `<p class="muted small" style="margin:0 0 8px">${esc(t('chk.apartNote'))}</p>${checkResultHtml(c)}`,
    footer: footer3([['danger', 'data-del', 'trash', t('common.delete')], ['', 'data-save', 'check', t(c.saved ? 'chk.savedShort' : 'chk.saveShort')], ['primary', 'data-apply', 'refresh', t('chk.applyShort')]]),
  });
  $('[data-save]', m).onclick = () => guard(() => { Store.saveCheck(c.id); closeModal(); toast(t('chk.savedToast')); render(); });
  $('[data-apply]', m).onclick = () => { closeModal(); applyCheckAsk(c.id); };
  $('[data-del]', m).onclick = async () => {
    if (!await confirmDialog(t('chk.deleteConfirm', { date: fmtDate(c.finishedAt) }), t('common.delete'), true)) return checkDetailModal(id);
    Store.deleteCount(c.id); render(); toast(t('count.deleted'));
  };
}

function countDetailHtml(c, forPrint, only = null) {
  const lines = only || c.lines.slice().sort((a, b) => Math.abs(b.diff || 0) * unitValue(b) - Math.abs(a.diff || 0) * unitValue(a) || a.name.localeCompare(b.name, 'pt'));
  const v = c.totals.value;
  const cls = n => (forPrint ? 'r' : `right num ${n < 0 ? 'neg-val' : n > 0 ? 'pos-val' : ''}`);
  // Só os produtos mostrados (filtro ou seleção): os totais são calculados sobre eles.
  const part = !!only && only.length !== c.lines.length;
  const sum = f => round2(lines.reduce((a, l) => a + f(l), 0));
  const T = part ? { counted: lines.filter(l => l.counted != null).length, items: lines.length, withDiff: lines.filter(l => l.diff).length,
    diffV: sum(l => (l.diff || 0) * unitValue(l)), val: sum(l => (l.counted != null ? l.counted : 0) * unitValue(l)) }
    : { counted: c.totals.counted, items: c.totals.items, withDiff: c.totals.withDiff, diffV: countDiffValue(c), val: NOCOST() ? v.retail : v.cost };
  return `
    ${forPrint ? `<h1>${esc(Store.settings.storeName)}</h1><div class="meta">${esc(t('count.title'))} · ${esc(fmtDate(c.finishedAt))} · ${esc(empName(c.finishedBy))}</div>` : ''}
    <div class="${forPrint ? 'kpi-grid' : 'stat-rows'}">
      ${[[t('count.countedItems'), `${T.counted} / ${T.items}`], [t('count.withDiff'), T.withDiff],
         [diffValueLabel(), money(T.diffV)], [t(NOCOST() ? 'count.valueRetail' : 'count.valueCost'), money(T.val)]]
        .map(([k, val]) => (forPrint ? `<div><span>${esc(k)}</span><b>${esc(String(val))}</b></div>` : `<div class="s-row"><span>${esc(k)}</span><b class="num">${esc(String(val))}</b></div>`)).join('')}
    </div>
    ${forPrint ? '<h2>' : '<h3 class="modal-sub">'}${esc(t('count.lines'))}${forPrint ? '</h2>' : '</h3>'}
    <div class="table-wrap"><table class="table fit lots-table">
      <thead><tr><th>${esc(t('stock.item'))}</th><th class="${forPrint ? 'r' : 'right'}">${esc(t('count.system'))}</th><th class="${forPrint ? 'r' : 'right'}">${esc(t('count.counted'))}</th><th class="${forPrint ? 'r' : 'right'}" title="${esc(t('count.diff'))}">${esc(t(forPrint ? 'count.diff' : 'count.diffShort'))}</th><th class="${forPrint ? 'r' : 'right hide-sm'}">${esc(t('count.value'))}</th></tr></thead>
      <tbody>${lines.map(l => `<tr class="${l.counted == null ? 'spent' : ''}"${forPrint ? '' : ` data-cid="${esc(l.itemId)}"`}>
        <td class="wrap">${esc(nameOf(l.itemId, l.name))}</td>
        <td class="${forPrint ? 'r' : 'right num'}">${fmtQty(l.expected)}</td>
        <td class="${forPrint ? 'r' : 'right num'}">${l.counted == null ? '—' : fmtQty(l.counted)}</td>
        <td class="${cls(l.diff || 0)}" title="${l.diff == null ? esc(t('count.notCounted')) : ''}">${l.diff == null ? '—' : l.diff === 0 ? '✓' : signed(l.diff)}</td>
        <td class="${forPrint ? 'r' : `${cls(l.diff || 0)} hide-sm`}">${l.diff ? money(l.diff * unitValue(l)) : ''}</td></tr>`).join('')}</tbody>
      <tfoot><tr class="total-row"><td>${esc(t('totals.total'))}</td>
        <td class="${forPrint ? 'r' : 'right num'}">${fmtQty(round2(lines.reduce((a, l) => a + (l.expected || 0), 0)))}</td>
        <td class="${forPrint ? 'r' : 'right num'}">${fmtQty(round2(lines.reduce((a, l) => a + (l.counted || 0), 0)))}</td>
        <td class="${forPrint ? 'r' : 'right num'}">${signed(round2(lines.reduce((a, l) => a + (l.diff || 0), 0)))}</td>
        <td class="${forPrint ? 'r' : 'right num hide-sm'}">${money(T.diffV)}</td></tr></tfoot>
    </table></div>`;
}

// Filtros do detalhe de uma contagem (guardados enquanto a app está aberta).
const CD_COLS = () => [t('stock.item'), t('count.system'), t('count.counted'), t('count.diffShort'), t('count.value')];
const CD_SITS = ['diff', 'miss', 'sur', 'ok', 'none'];
const CD_MINS = [1000, 5000, 10000];
const CD_SORTS = ['missv', 'diffu', 'name', 'cat'];
const CD_STK = ['in', 'low', 'out'];
// Situação e stock aceitam várias escolhas (lista vazia = todos).
function cdFilter() {
  const f = App.cdf || (App.cdf = { cats: [], sit: [], min: 0, sort: 'missv', stk: [], hide: [], q: '' });
  f.min = 0; // o filtro por valor da diferença foi retirado
  if (f.sort === 'diffu') f.sort = 'missv';
  if (!Array.isArray(f.hide)) f.hide = [];
  if (typeof f.q !== 'string') f.q = '';
  if (!Array.isArray(f.sit)) f.sit = f.sit ? [f.sit] : [];
  if (!Array.isArray(f.stk)) f.stk = f.stk ? [f.stk] : [];
  return f;
}
function cdLines(c, f) {
  const val = l => Math.abs((l.diff || 0) * unitValue(l));
  const inSit = { diff: l => l.diff != null && l.diff !== 0, miss: l => l.diff < 0, sur: l => l.diff > 0, ok: l => l.diff === 0, none: l => l.counted == null };
  const catName = l => { const k = lineCat(l); return k === 'none' ? '' : ((Store.find('categories', k) || {}).name || ''); };
  const sorts = {
    missv: (a, b) => val(b) - val(a), diffu: (a, b) => Math.abs(b.diff || 0) - Math.abs(a.diff || 0),
    name: (a, b) => a.name.localeCompare(b.name, 'pt'), cat: (a, b) => catName(a).localeCompare(catName(b), 'pt'),
  };
  // Stock na contagem: o contado (ou o do sistema, se não foi contado) comparado com o alerta de stock baixo.
  const qty = l => (l.counted != null ? l.counted : l.expected || 0);
  const low = l => { const it = Store.find('items', l.itemId); return it ? (it.lowStock || 0) : 0; };
  const inStk = { out: l => qty(l) <= 0, low: l => qty(l) > 0 && qty(l) <= low(l), in: l => qty(l) > low(l) };
  const q = tblNorm((f.q || '').trim());
  return c.lines.filter(l => (!q || tblNorm(nameOf(l.itemId, l.name)).includes(q)) && (!f.cats.length || f.cats.includes(lineCat(l))) && (!f.sit.length || f.sit.some(k => inSit[k](l))) && (!f.stk.length || f.stk.some(k => inStk[k](l))) && (!f.min || val(l) >= f.min))
    .sort((a, b) => (sorts[f.sort] || sorts.missv)(a, b) || a.name.localeCompare(b.name, 'pt'));
}
function cdTags(f) {
  const out = f.cats.map(k => ({ k: `cat:${k}`, label: k === 'none' ? t('items.noCategory') : ((Store.find('categories', k) || {}).name || '') }));
  f.sit.forEach(k => out.push({ k: `sit:${k}`, label: t(`cdf.sit.${k}`) }));
  f.stk.forEach(k => out.push({ k: `stk:${k}`, label: t(`cdf.stk.${k}`) }));
  if (f.min) out.push({ k: 'min', label: t('cdf.min', { v: money(f.min) }) });
  if (f.sort !== 'missv') out.push({ k: 'sort', label: t(`cdf.sort.${f.sort}`) });
  return out;
}

function countDetailModal(id) {
  const viaChat = !!(App.cdFrom && App.cdFrom.id === id); // aberto a partir do chat: sem mostrar o filtro
  const c = Store.find('stockCounts', id);
  if (!c) return;
  const f = cdFilter();
  const present = new Set(c.lines.map(lineCat));
  f.cats = f.cats.filter(k => present.has(k));
  const lines = viaChat && App.cdFrom.ids ? cdLines(c, f).filter(l => App.cdFrom.ids.includes(l.itemId)) : cdLines(c, f);
  const allLines = lines;
  const tags = cdTags(f);
  const miss = lines.filter(l => l.diff < 0);
  const missQty = round2(miss.reduce((a, l) => a - l.diff, 0)), missVal = round2(miss.reduce((a, l) => a - l.diff * unitValue(l), 0));
  const d = new Date(c.finishedAt);
  // Seleção múltipla (guardada enquanto a janela está aberta, mesmo ao mudar o filtro).
  if (!App.cdSel || App.cdSel.id !== id) App.cdSel = { id, on: false, ids: new Set() };
  const sel = App.cdSel.on;
  const head = `<div class="sheet-head cd-head">
      <div class="sheet-title"><b>${esc(t('count.title'))} · ${esc(fmtEntryDate(Store.countDay(c)))}</b><small>${esc(d.toLocaleTimeString(dateLocale(), { hour: '2-digit', minute: '2-digit' }))} · ${esc(t('cdf.by', { name: empName(c.finishedBy) }))}</small></div>
      <div class="cd-icons">
        ${viaChat ? '' : `<button type="button" class="cd-ic" data-cdf title="${esc(t('flt.title'))}" aria-label="${esc(t('flt.title'))}">${thinIcon('filter')}${tags.length || f.hide.length || f.q ? '<i class="cd-dot"></i>' : ''}</button>`}
        ${canShare() ? `<button type="button" class="cd-ic" data-send title="${esc(t('al.sendChat'))}" aria-label="${esc(t('al.sendChat'))}">${thinIcon('send')}</button>
        <button type="button" class="cd-ic" data-xp title="${esc(t('xp.title'))}" aria-label="${esc(t('xp.title'))}">${thinIcon('download')}</button>` : ''}
        ${can('fixStock') ? `<button type="button" class="cd-ic" data-edit title="${esc(t('count.edit'))}" aria-label="${esc(t('count.edit'))}">${thinIcon('pen')}</button>
        <button type="button" class="cd-ic red" data-del title="${esc(t('common.delete'))}" aria-label="${esc(t('common.delete'))}">${thinIcon('trash')}</button>` : ''}
      </div>
    </div>`;
  const body = `${countDetailHtml(c, false, lines).replace(/(<h3 class="modal-sub">[^<]*<\/h3>)/, `$1
      ${tags.length && !viaChat ? `<div class="fchips cd-chips">${tags.map(x => `<button type="button" class="fchip on" data-untag="${x.k}">${esc(x.label)} ✕</button>`).join('')}<button type="button" class="fchip clear" data-untag="all">${esc(t('flt.clear'))}</button></div>` : ''}
      <p class="muted small" style="margin:0 0 6px">${esc(viaChat ? t('stock.itemsN', { n: lines.length }) : t('cdf.summary', { n: lines.length, total: c.lines.length }))}${miss.length ? ` · ${esc(t('cdf.missSum', { q: fmtQty(missQty), v: money(-missVal) }))}` : ''}</p>`)}`;
  const fromChat = App.cdFrom && App.cdFrom.id === id ? App.cdFrom.html : '';
  const m = openModal({ title: `${t('count.title')} · ${fmtDate(c.finishedAt)}`, wide: true, autofocus: false, sheet: true, head, body: fromChat + body });
  if ($('[data-cdf]', m)) $('[data-cdf]', m).onclick = () => cdFilterModal(c);
  if (f.hide.length) { const tb = $('.modal-body table', m); if (tb) [...tb.rows].forEach(r => { if (r.cells.length === 5) [...r.cells].forEach((cl, i) => { if (f.hide.includes(i)) cl.style.display = 'none'; }); }); }
  // Selecionar: tocar e manter numa linha pinta-a de verde; depois cada toque junta ou tira;
  // tocar fora da tabela limpa. O número fica no ícone Enviar, e Enviar / Exportar usam só esses.
  const shown = new Set(lines.map(l => l.itemId));
  const paintSel = () => {
    const S = App.cdSel.ids;
    $$('tr[data-cid]', m).forEach(tr => tr.classList.toggle('tt-sel', S.has(tr.dataset.cid)));
    const b = $('[data-send]', m) || document.createElement('i');
    const n = [...S].filter(x => shown.has(x)).length;
    App.cdSel.on = n > 0;
    let badge = $('.cd-n', b);
    if (n) { if (!badge) { b.insertAdjacentHTML('beforeend', '<i class="cd-n"></i>'); badge = $('.cd-n', b); } badge.textContent = n; } else if (badge) badge.remove();
    window.ttClear = n ? () => { App.cdSel.ids.clear(); paintSel(); window.ttClear = null; } : null;
  };
  const tbl = $('.modal-body table', m);
  if (tbl) {
    tbl.dataset.ttOwn = '1';
    let timer = null, sx = 0, sy = 0, picked = false, upAt = 0;
    tbl.addEventListener('pointerdown', e => {
      const tr = e.target.closest('tr[data-cid]'); if (!tr) return;
      sx = e.clientX; sy = e.clientY; picked = false; clearTimeout(timer);
      timer = setTimeout(() => { timer = null; picked = true; const S = App.cdSel.ids, k = tr.dataset.cid; if (S.has(k)) S.delete(k); else S.add(k); if (navigator.vibrate) navigator.vibrate(18); paintSel(); }, 480);
    });
    tbl.addEventListener('pointermove', e => { if (timer && Math.hypot(e.clientX - sx, e.clientY - sy) > 10) { clearTimeout(timer); timer = null; } });
    ['pointerup', 'pointercancel', 'pointerleave'].forEach(ev => tbl.addEventListener(ev, () => { clearTimeout(timer); timer = null; if (ev === 'pointerup') upAt = Date.now(); }));
    tbl.addEventListener('contextmenu', e => { if (e.target.closest('tr[data-cid]')) e.preventDefault(); });
    tbl.addEventListener('click', e => {
      const tr = e.target.closest('tr[data-cid]'); if (!tr) return;
      if (picked && Date.now() - upAt < 400) { picked = false; e.stopPropagation(); return; }
      if (!App.cdSel.ids.size) return;
      e.stopPropagation();
      const S = App.cdSel.ids, k = tr.dataset.cid; if (S.has(k)) S.delete(k); else S.add(k); paintSel();
    }, true);
    $('.modal-body', m).addEventListener('click', e => { if (App.cdSel.ids.size && !tbl.contains(e.target) && !(picked && Date.now() - upAt < 400)) { App.cdSel.ids.clear(); paintSel(); } });
    paintSel();
  }
  if ($('[data-send]', m)) $('[data-send]', m).onclick = () => cdSendToChat(c, App.cdSel.ids.size ? lines.filter(l => App.cdSel.ids.has(l.itemId)) : lines, f, tags);
  $$('[data-untag]', m).forEach(b => b.addEventListener('click', () => {
    const k = b.dataset.untag;
    if (k === 'all') Object.assign(f, { cats: [], sit: [], min: 0, sort: 'missv', stk: [], hide: [], q: '' });
    else if (k.startsWith('cat:')) f.cats = f.cats.filter(x => x !== k.slice(4));
    else if (k.startsWith('sit:')) f.sit = f.sit.filter(x => x !== k.slice(4));
    else if (k.startsWith('stk:')) f.stk = f.stk.filter(x => x !== k.slice(4));
    else if (k === 'sort') f.sort = 'missv'; else f[k] = k === 'min' ? 0 : '';
    countDetailModal(id);
  }));
  if ($('[data-xp]', m)) $('[data-xp]', m).onclick = () => {
    const lines = App.cdSel.ids.size ? allLines.filter(l => App.cdSel.ids.has(l.itemId)) : allLines;
    const catName = l => { const k = lineCat(l); return k === 'none' ? t('items.noCategory') : ((Store.find('categories', k) || {}).name || ''); };
    const map = [0, 2, 3, 4, 5], drop = new Set(f.hide.map(i => map[i]));
    const kp = a => a.filter((_, i) => !drop.has(i));
    exportModal({
      title: `${t('count.title')} ${fmtEntryDate(Store.countDay(c))}`, subtitle: t('stock.itemsN', { n: lines.length }),
      file: `contagem_${Store.countDay(c)}`, notes: [],
      columns: kp([t('stock.item'), t('items.category'), t('count.system'), t('count.counted'), t('count.diff'), t('count.value')]), numeric: kp([0, 1, 2, 3, 4, 5]).map((x, i) => (x >= 2 ? i : -1)).filter(i => i >= 0),
      rows: lines.map(l => kp([nameOf(l.itemId, l.name), catName(l), l.expected, l.counted == null ? '—' : l.counted, l.diff == null ? '—' : l.diff, l.diff ? round2(l.diff * unitValue(l)) : ''])),
      totals: kp([t('totals.total'), '', round2(lines.reduce((a, l) => a + (l.expected || 0), 0)), round2(lines.reduce((a, l) => a + (l.counted || 0), 0)), round2(lines.reduce((a, l) => a + (l.diff || 0), 0)), round2(lines.reduce((a, l) => a + (l.diff || 0) * unitValue(l), 0))]),
      text: () => cdMessage(c, lines, f).replace(/\*/g, ''),
    });
  };
  if ($('[data-edit]', m)) $('[data-edit]', m).onclick = () => countEditModal(c.id);
  if ($('[data-del]', m)) $('[data-del]', m).onclick = async () => {
    if (!await confirmDialog(t('count.deleteConfirm', { date: fmtDate(c.finishedAt) }), t('common.delete'), true)) return countDetailModal(id);
    Store.deleteCount(c.id); render(); toast(t('count.deleted'));
    return undefined;
  };
}
// Ícones de traço fino (cabeçalho do balanço).
const THIN = {
  filter: '<path d="M3 5h18l-7 8.5V19l-4 2v-7.5z"/>',
  check: '<rect x="3" y="3" width="18" height="18" rx="4"/><path d="m8 12 3 3 5-6"/>',
  send: '<path d="M22 2 11 13M22 2l-7 20-4-9-9-4z"/>',
  download: '<path d="M12 3v12M7 10l5 5 5-5M5 21h14"/>',
  pen: '<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/>',
  trash: '<path d="M3 6h18M8 6V4h8v2M6 6l1 14a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-14"/><path d="M10 11v6M14 11v6"/>',
  print: '<path d="M6 9V3h12v6"/><rect x="3" y="9" width="18" height="8" rx="2"/><path d="M6 14h12v7H6z"/>',
  undo: '<path d="M9 14 4 9l5-5"/><path d="M4 9h11a5 5 0 0 1 0 10h-3"/>',
  drop: '<path d="M12 2.7s7 7.3 7 12.3a7 7 0 0 1-14 0c0-5 7-12.3 7-12.3z"/><path d="M9 15a3 3 0 0 0 3 3"/>',
  gallery: '<rect x="7" y="7" width="14" height="14" rx="3"/><path d="M3 15V6a3 3 0 0 1 3-3h9"/><circle cx="12" cy="12" r="1.5"/><path d="m21 17-3-3-6 7"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/>',
  copy: '<rect x="8" y="8" width="13" height="13" rx="2"/><path d="M16 8V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h3"/>',
  up: '<path d="m6 15 6-6 6 6"/>', down: '<path d="m6 9 6 6 6-6"/>', x: '<path d="M6 6l12 12M18 6 6 18"/>',
  share: '<circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="m8.6 13.5 6.8 4M15.4 6.5l-6.8 4"/>',
};
const thinIcon = k => `<svg class="thin" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${THIN[k]}</svg>`;

// Mensagem de uma contagem: título com a data (e as categorias do filtro) e, se o filtro tiver
// situações (Falta, Sobra…), um bloco por situação, cada um por baixo do outro.
function cdMessage(c, lines, f) {
  if (f.hide && f.hide.length) {
    const cc = CD_COLS();
    const vals = l => [null, fmtQty(l.expected), l.counted == null ? '—' : fmtQty(l.counted), l.diff == null ? '—' : signed(l.diff), l.diff ? money(l.diff * unitValue(l)) : ''];
    const title = t('cd.msgCount', { date: fmtEntryDate(Store.countDay(c)) }).toUpperCase();
    const row = l => { const v = vals(l); const parts = [1, 2, 3, 4].filter(i => !f.hide.includes(i) && v[i]).map(i => `${cc[i]} ${v[i]}`); return parts.length ? `${nameOf(l.itemId, l.name)}: ${parts.join(' · ')}` : nameOf(l.itemId, l.name); };
    const sum = g => round2(lines.reduce((a, l) => a + g(l), 0));
    const tv = [null, fmtQty(sum(l => l.expected || 0)), fmtQty(sum(l => l.counted || 0)), signed(sum(l => l.diff || 0)), money(sum(l => (l.diff || 0) * unitValue(l)))];
    const tl = [1, 2, 3, 4].filter(i => !f.hide.includes(i)).map(i => `${cc[i]} ${tv[i]}`).join(' · ');
    return [`*${title}*`, ...lines.map(row), ...(tl ? [`*${t('totals.total')}: ${tl}*`] : [])].join('\n');
  }
  const cats = f.cats.map(k => (k === 'none' ? t('items.noCategory') : ((Store.find('categories', k) || {}).name || ''))).filter(Boolean);
  const title = [t('cd.msgCount', { date: fmtEntryDate(Store.countDay(c)) }), ...cats].join(' · ').toUpperCase();
  const name = l => nameOf(l.itemId, l.name);
  const fmt = l => {
    if (l.counted == null) return `${name(l)} (${t('cd.msgSys', { n: fmtQty(l.expected) })})`;
    if (l.diff < 0) return `${name(l)}: ${fmtQty(l.counted)} (${t(-l.diff === 1 ? 'cd.msgMiss1' : 'cd.msgMiss', { n: fmtQty(-l.diff) })})`;
    if (l.diff > 0) return `${name(l)}: ${fmtQty(l.counted)} (${t(l.diff === 1 ? 'cd.msgSur1' : 'cd.msgSur', { n: fmtQty(l.diff) })})`;
    return `${name(l)}: ${fmtQty(l.counted)}`;
  };
  const inSit = { diff: l => l.diff != null && l.diff !== 0, miss: l => l.diff < 0, sur: l => l.diff > 0, ok: l => l.diff === 0, none: l => l.counted == null };
  const out = [`*${title}*`];
  const sits = CD_SITS.filter(k => f.sit.includes(k));
  if (!sits.length) { out.push(...lines.map(fmt)); return out.join('\n'); }
  for (const k of sits) {
    const g = lines.filter(inSit[k]);
    if (!g.length) continue;
    out.push('', `*${t(`cd.grp.${k}`)} (${g.length}):*`, ...g.map(fmt));
  }
  return out.join('\n');
}
function cdSendToChat(c, lines, f, tags) {
  if (!lines.length) { toast(t('cd.nothing'), true); return; }
  const d = new Date(c.finishedAt);
  const by = t('tc.by', { name: empName(c.finishedBy), time: d.toLocaleTimeString(dateLocale(), { hour: '2-digit', minute: '2-digit' }) });
  const sel = App.cdSel && App.cdSel.id === c.id && App.cdSel.on;
  const card = { v: 1, type: 'count', ref: c.id, title: `${t('count.title')} · ${new Date(`${Store.countDay(c)}T12:00`).toLocaleDateString(dateLocale(), { day: '2-digit', month: '2-digit' })}`,
    sub: by, // o filtro aplicado não aparece a quem recebe
    cols: [t('tc.prod'), t('tc.sys'), t('tc.cnt'), t('tc.dif')].filter((_, i) => !(f.hide || []).includes(i)),
    rows: lines.slice(0, 4).map(l => [nameOf(l.itemId, l.name).slice(0, 40), fmtQty(l.expected), l.counted == null ? '—' : fmtQty(l.counted), l.diff == null ? '—' : signed(l.diff).replace(/^-/, '−')].filter((_, i) => !(f.hide || []).includes(i))),
    more: Math.max(0, lines.length - 4),
    f: { cats: f.cats.slice(), sit: f.sit.slice(), min: f.min, sort: f.sort, stk: f.stk.slice(), hide: (f.hide || []).slice(), q: f.q || '' },
    ids: sel ? lines.map(l => l.itemId) : null };
  sendTableToChat(card, cdMessage(c, lines, f), () => countDetailModal(c.id));
}
// Enviar uma tabela para o chat: como cartão (toca e abre a tabela) ou como texto no rascunho.
function sendTableToChat(card, text, back) {
  if (typeof Chat === 'undefined' || !Chat.available()) { toast(t('chat.needCloud'), true); return; }
  const openChat = room => () => { closeModal(); Chat.room = room; if (location.hash === '#chat') render(); else location.hash = '#chat'; };
  const m = openModal({ title: t('tc.how'), autofocus: false, body: `<div class="sx-list">
    <button type="button" class="sx-row" data-how="card"><span class="sx-ic" style="background:#0891b2">${thinIcon('check')}</span><span class="sx-t"><b>${esc(t('tc.asCard'))}</b><small>${esc(t('tc.asCardSub'))}</small></span></button>
    <button type="button" class="sx-row" data-how="text"><span class="sx-ic" style="background:#64748b">${icon('chat')}</span><span class="sx-t"><b>${esc(t('tc.asText'))}</b><small>${esc(t('tc.asTextSub'))}</small></span></button></div>` });
  if (back) onModalClose(m, back);
  $$('[data-how]', m).forEach(b => b.addEventListener('click', () => {
    const how = b.dataset.how;
    closeModal();
    Chat.pickRoom(t('chat.sendTo'), room => {
      if (how === 'card') Chat.setCard(room, card); else Chat.addToDraft(room, text);
      if (back) back();
      showAlertBar(t(how === 'card' ? 'tc.ready' : 'al.draftAdded', { room: Chat.roomName(room) }), t('al.openChat'), openChat(room));
    });
  }));
}
// Tocar num cartão de tabela no chat: abre a tabela verdadeira com o mesmo filtro (contagens)
// ou a cópia das linhas que foi enviada (outras listas).
function openTableCard(m) {
  const c = m.card;
  const from = `<div class="tc-from">${icon('chat')}<span>${esc(t('tc.from', { name: m.name }))}</span></div>`;
  if (c.type === 'count') {
    if (!canAny(['count', 'close'])) { toast(t('tc.noPerm'), true); return; }
    if (!Store.find('stockCounts', c.ref)) { toast(t('tc.gone'), true); return; }
    App.cdf = { cats: (c.f && c.f.cats) || [], sit: (c.f && c.f.sit) || [], min: (c.f && c.f.min) || 0, sort: (c.f && c.f.sort) || 'missv', stk: (c.f && c.f.stk) || [], hide: (c.f && c.f.hide) || [], q: (c.f && c.f.q) || '' };
    App.cdSel = { id: c.ref, on: false, ids: new Set() }; // nada pintado: só aparecem os enviados
    App.cdFrom = { id: c.ref, html: from, ids: c.ids || null };
    countDetailModal(c.ref);
    return;
  }
  const s = c.snap || { cols: c.cols, rows: c.rows };
  openModal({ title: c.title, wide: true, autofocus: false, sheet: true,
    head: `<div class="sheet-head"><div class="sheet-title"><b>${esc(c.title)}</b>${c.sub ? `<small>${esc(c.sub)}</small>` : ''}</div></div>`,
    body: `${from}<div class="table-wrap"><table class="table"><thead><tr>${s.cols.map((x, i) => `<th class="${i ? 'right' : ''}">${esc(x)}</th>`).join('')}</tr></thead>
      ${s.foot ? `<tfoot><tr class="total-row">${s.cols.map((_, i) => `<td class="${i ? 'right num' : ''}">${esc((s.foot[i] || ''))}</td>`).join('')}</tr></tfoot>` : ''}
      <tbody>${s.rows.map(tcRow).map(r => `<tr>${s.cols.map((_, i) => `<td class="${i ? 'right num' : ''}">${esc(r[i] || '')}</td>`).join('')}</tr>`).join('')}</tbody></table></div>` });
}
function cdFilterModal(c) {
  const f = cdFilter();
  const d = { cats: f.cats.slice(), sit: f.sit.slice(), min: f.min, sort: f.sort, stk: f.stk.slice(), hide: (f.hide || []).slice(), q: f.q || '' };
  const present = new Set(c.lines.map(lineCat));
  const cats = catOptions().filter(o => present.has(o.id));
  const m = openModal({ title: t('cdf.title'), autofocus: false, sheet: true,
    head: `<div class="sheet-head"><div class="sheet-title"><b>${esc(t('cdf.title'))}</b></div></div>`,
    body: '<div id="fbody"></div>',
    footer: `<button class="btn left" data-clear>${esc(t('flt.clear'))}</button><button class="btn primary" data-ok></button>` });
  const paint = () => {
    const cc = CD_COLS();
    $('#fbody', m).innerHTML = `<div class="fgroup"><div class="flabel">${esc(t('tt.cols'))}</div><div class="tt-cols">${cc.map((n, i) => `<button type="button" class="${d.hide.includes(i) ? '' : 'on'}" data-col="${i}">${esc(n)}</button>`).join('')}</div></div>
      <div class="tbl-q" style="margin:0 0 14px">${icon('search')}<input class="input" id="cdq" placeholder="${esc(t('tbl.search'))}" value="${esc(d.q)}"></div>`
      + chipGroup(t('items.category'), 'cats', [['', t('flt.all')], ...cats.map(o => [o.id, o.name])], d.cats.length ? d.cats : [''], true)
      + chipGroup(t('cdf.sit'), 'sit', [['', t('flt.all')], ...CD_SITS.map(k => [k, t(`cdf.sit.${k}`)])], d.sit.length ? d.sit : [''], true)
      + chipGroup(t('cdf.stk'), 'stk', [['', t('flt.all')], ...CD_STK.map(k => [k, t(`cdf.stk.${k}`)])], d.stk.length ? d.stk : [''], true)
      + chipGroup(t('flt.sort'), 'sort', ['name', 'cat'].map(k => [k, t(`cdf.sort.${k}`)]), d.sort); // sem escolher: maior diferença primeiro
    $('[data-ok]', m).textContent = t('flt.showN', { n: cdLines(c, d).length });
    $$('[data-col]', m).forEach(b => b.addEventListener('click', () => {
      const i = Number(b.dataset.col);
      if (!d.hide.includes(i) && cc.length - d.hide.length <= 1) { toast(t('tt.oneCol'), true); return; }
      if (i === 0 && !d.hide.includes(0)) { toast(t('tt.keepName'), true); return; } // o nome do produto fica sempre
      d.hide = d.hide.includes(i) ? d.hide.filter(x => x !== i) : [...d.hide, i];
      b.classList.toggle('on', !d.hide.includes(i));
    }));
    const qi = $('#cdq', m);
    qi.addEventListener('input', () => { d.q = qi.value; $('[data-ok]', m).textContent = t('flt.showN', { n: cdLines(c, d).length }); });
    $$('.fchip[data-g]', m).forEach(b => b.addEventListener('click', () => {
      const g = b.dataset.g, v = b.dataset.v;
      if (g === 'cats' || g === 'sit' || g === 'stk') d[g] = !v ? [] : d[g].includes(v) ? d[g].filter(x => x !== v) : [...d[g], v];
      else if (g === 'sort') d.sort = d.sort === v ? 'missv' : v; else d[g] = v;
      paint();
    }));
  };
  paint();
  onModalClose(m, () => countDetailModal(c.id));
  $('[data-clear]', m).onclick = () => { Object.assign(d, { cats: [], sit: [], min: 0, sort: 'missv', stk: [], hide: [], q: '' }); paint(); };
  $('[data-ok]', m).onclick = () => { Object.assign(f, d); countDetailModal(c.id); };
}

// Rodapé de janela com botões do mesmo tamanho numa só linha: [classe, atributo, ícone, texto].
const footer3 = btns => `<div class="foot-row" style="--n:${btns.length}">${btns.map(([cls, attr, ic, label]) => `<button class="btn ${cls}" ${attr}>${icon(ic)}<span>${esc(label)}</span></button>`).join('')}</div>`;

// Corrigir um balanço concluído: muda o contado de cada produto; o stock acompanha a diferença.
function countEditModal(id) {
  if (!need('editData')) return;
  const c = Store.find('stockCounts', id);
  if (!c) return;
  let q = '';
  // Categorias escolhidas (vazio = todas); só as que têm produtos neste balanço.
  let cats = [];
  const present = new Set(c.lines.map(lineCat));
  const catOpts = catOptions().filter(o => present.has(o.id));
  const diffHtml = l => (l.diff == null ? '' : l.diff === 0 ? '✓' : signed(l.diff));
  const diffCls = l => `diff ${l.diff == null ? '' : l.diff === 0 ? 'ok' : l.diff < 0 ? 'neg' : 'pos'}`;
  const m = openModal({
    title: `${t('count.edit')} · ${fmtDate(c.finishedAt)}`,
    wide: true,
    autofocus: false,
    body: `
      <p class="muted small" style="margin:0 0 10px">${esc(t('count.editHint'))}</p>
      ${countToolsHtml(c)}
      <div class="page-head stock-head" style="margin-bottom:10px">
        <input class="input grow" id="ceq" type="search" placeholder="${esc(t('stock.searchPlaceholder'))}">
        <button class="btn refresh-btn" id="cer" title="${esc(t('count.refresh'))}">${icon('refresh')}<span>${esc(t('count.refreshShort'))}</span></button>
      </div>
      ${catOpts.length > 1 ? `<div class="chip-row" id="cec">
        <button class="chip on" data-cat="">${esc(t('stock.allCats'))}</button>
        ${catOpts.map(o => `<button class="chip" data-cat="${o.id}">${o.color ? `<span class="swatch" style="background:${esc(o.color)}"></span>` : ''}${esc(o.name)}</button>`).join('')}
      </div>` : ''}
      <div class="stat-rows count-edit-sum"></div>
      <div class="card count-list count-edit" id="cel"></div>`,
    footer: `<button class="btn primary" data-done>${esc(t('count.editDone'))}</button>`,
  });
  const paintSum = () => {
    $('.count-edit-sum', m).innerHTML = `
      <div class="s-row"><span>${esc(t('count.countedItems'))}</span><b>${c.totals.counted} / ${c.totals.items}</b></div>
      <div class="s-row"><span>${esc(t('count.withDiff'))}</span><b>${c.totals.withDiff}</b></div>
      <div class="s-row strong"><span>${esc(diffValueLabel())}</span><span class="num ${countDiffValue(c) < 0 ? 'neg-val' : ''}">${money(countDiffValue(c))}</span></div>`;
  };
  const paint = () => {
    const qq = norm(q.trim());
    const lines = c.lines.slice().sort((a, b) => a.name.localeCompare(b.name, 'pt'))
      .filter(l => (!qq || norm(l.name).includes(qq)) && (!cats.length || cats.includes(lineCat(l))));
    const catName = l => { const k = lineCat(l); return k === 'none' ? t('items.noCategory') : (Store.find('categories', k) || {}).name || ''; };
    $('#cel', m).innerHTML = lines.length ? lines.map(l => `<div class="count-row" data-id="${l.itemId}">
        <div class="count-name">${esc(nameOf(l.itemId, l.name))}<div class="muted small">${esc(catName(l))} · ${esc(t('count.system'))}: <b class="num">${fmtQty(l.expected)}</b></div></div>
        <input class="input count-input" inputmode="decimal" aria-label="${esc(t('count.counted'))}" placeholder="—" value="${l.counted == null ? '' : fmtQty(l.counted)}">
        <span class="${diffCls(l)}">${diffHtml(l)}</span>
        <span class="line-acts"><button class="icon-btn" data-line-sync title="${esc(t('count.lineSync'))}" aria-label="${esc(t('count.lineSync'))}">${icon('refresh')}</button><button class="icon-btn" data-line-del title="${esc(t('count.lineDel'))}" aria-label="${esc(t('count.lineDel'))}">${icon('trash')}</button></span></div>`).join('') : `<div class="empty">${esc(t('count.noneShown'))}</div>`;
    $$('.count-row', m).forEach(row => {
      const input = $('.count-input', row);
      input.addEventListener('change', () => guard(() => {
        const v = input.value.trim();
        Store.editCountLine(c.id, row.dataset.id, v === '' ? null : num(v), App.user.id);
        const l = c.lines.find(x => x.itemId === row.dataset.id);
        const d = $('.diff', row); d.className = diffCls(l); d.textContent = diffHtml(l);
        paintSum(); App.stale = true;
      }));
      $('[data-line-sync]', row).addEventListener('click', () => guard(() => {
        Store.refreshCount(c.id, App.user.id, row.dataset.id);
        App.stale = true; paintSum(); paint(); toast(t('count.lineSynced'));
      }));
      $('[data-line-del]', row).addEventListener('click', () => guard(() => {
        Store.removeCountLine(c.id, row.dataset.id);
        App.stale = true; paintSum(); paint(); toast(t('count.lineRemoved'));
      }));
    });
  };
  $('#ceq', m).addEventListener('input', e => { q = e.target.value; paint(); });
  bindCountTools(m, c, () => countEditModal(id));
  $('#cer', m).addEventListener('click', async () => {
    countFillModal(c, () => countEditModal(id));
  });
  // Seletor de categorias: toca para marcar/desmarcar; "Todas" limpa a escolha.
  $$('#cec .chip', m).forEach(b => b.addEventListener('click', () => {
    const k = b.dataset.cat;
    cats = !k ? [] : cats.includes(k) ? cats.filter(x => x !== k) : [...cats, k];
    $$('#cec .chip', m).forEach(x => x.classList.toggle('on', x.dataset.cat ? cats.includes(x.dataset.cat) : !cats.length));
    paint();
  }));
  $('[data-done]', m).onclick = () => { closeModal(); toast(t('count.edited')); };
  paintSum(); paint();
}

// ================= Dívidas de clientes =================

function debtBlock(c) {
  const hist = Store.debtHistory(c.id).slice(0, 15);
  if (!(c.debt > 0) && !hist.length) return '';
  return `<div class="debt-block">
    <div class="stock-summary">
      <div><span class="muted small">${esc(t('debt.current'))}</span><b class="num ${c.debt > 0 ? 'neg-val' : ''}">${money(c.debt || 0)}</b></div>
      ${c.debt > 0 ? `<button class="btn primary small" type="button" data-receive>${esc(t('debt.receive'))}</button>` : ''}
    </div>
    ${hist.length ? `<h3 class="modal-sub">${esc(t('debt.history'))}</h3><ul class="pick-list">${hist.map(h => `<li ${h.receipt ? `data-r="${h.receipt.id}"` : ''}>
      <div class="grow">${esc(t(`debt.kind.${h.kind}`))}${h.receipt ? ` · ${esc(t('receipt.number'))} ${esc(receiptNo(h.receipt))}` : h.credit ? ` · ${esc(t('fia.btn'))}${h.credit.note ? ` · ${esc(h.credit.note)}` : ''}` : ` · ${esc(payLabel(h.payment.payType))}`}
        <div class="small muted">${fmtDate(h.date)}${h.payment && h.payment.note ? ` · ${esc(h.payment.note)}` : ''}</div></div>
      <span class="num ${h.kind === 'sale' ? 'neg-val' : 'pos-val'}">${h.kind === 'sale' ? '+' : '−'}${money(h.amount)}</span></li>`).join('')}</ul>` : ''}
  </div>`;
}

// Registar um pagamento (total ou parcial) da dívida de um cliente.
// Registar fiado à mão: cliente (ou novo), valor, data e o que levou.
function creditModal() {
  if (!need('credit')) return;
  const today = dayKey(new Date());
  const custs = Store.data.customers.slice().sort((a, b) => a.name.localeCompare(b.name, 'pt'));
  const m = openModal({ title: t('fia.title'), autofocus: false,
    body: `<label class="field"><span>${esc(t('fia.customer'))}</span><select class="input" id="fc">
        ${custs.map(c => `<option value="${c.id}">${esc(c.name)}${c.debt > 0 ? ` · ${esc(t('debt.owes', { value: money(c.debt) }))}` : ''}</option>`).join('')}
        <option value="__new">+ ${esc(t('fia.newCustomer'))}</option></select></label>
      <label class="field" id="fc-new-f" hidden><span>${esc(t('fia.newName'))}</span><input class="input" id="fc-new"></label>
      <div class="row">
        <label class="field"><span>${esc(t('common.amount'))} *</span><input class="input" id="fa" inputmode="decimal"></label>
        <label class="field"><span>${esc(t('common.date'))}</span><input class="input" type="date" id="fd" value="${today}" max="${today}"></label>
      </div>
      <label class="field"><span>${esc(t('fia.note'))}</span><input class="input" id="fn" placeholder="${esc(t('fia.notePh'))}"></label>
      <p class="muted small">${esc(t('fia.modalHint'))}</p>`,
    footer: `<button class="btn primary" data-ok>${esc(t('fia.save'))}</button>` });
  const sel = $('#fc', m);
  const sync = () => { $('#fc-new-f', m).hidden = sel.value !== '__new'; };
  if (!custs.length) sel.value = '__new';
  sel.addEventListener('change', sync); sync();
  $('[data-ok]', m).onclick = () => guard(() => {
    let id = sel.value;
    if (id === '__new') {
      const name = $('#fc-new', m).value.trim();
      if (!name) { toast(t('common.needName'), true); return; }
      id = Store.upsert('customers', { name, phone: '', email: '', points: 0, debt: 0 }).id;
    }
    Store.addCredit({ customerId: id, amount: num($('#fa', m).value), date: $('#fd', m).value, note: $('#fn', m).value }, App.user.id);
    closeModal(); App.stale = true; render(); toast(t('fia.saved'));
  });
}

function debtPaymentModal(customerId, after) {
  const c = Store.find('customers', customerId);
  if (!c) return;
  let type = 'cash';
  const m = openModal({
    title: t('debt.receive'),
    body: `
      <p>${esc(c.name)} · ${esc(t('debt.owes', { value: money(c.debt || 0) }))}</p>
      <label class="field"><span>${esc(t('common.amount'))} *</span><input class="input" id="da" inputmode="decimal" value="${round2(c.debt || 0)}"></label>
      <div class="field"><span>${esc(t('receipts.payment'))}</span>
        <div class="seg">${['cash', 'card', 'mobile', 'other'].map(k => `<button type="button" data-pt="${k}">${esc(payLabel(k))}</button>`).join('')}</div></div>
      <label class="field"><span>${esc(t('stock.note'))}</span><input class="input" id="dn"></label>
      ${Store.currentShift() ? '' : `<p class="muted small">${esc(t('debt.noShiftNote'))}</p>`}`,
    footer: `<button class="btn primary" data-ok>${esc(t('debt.confirm'))}</button>`,
  });
  const paint = () => $$('[data-pt]', m).forEach(b => b.classList.toggle('active', b.dataset.pt === type));
  $$('[data-pt]', m).forEach(b => b.addEventListener('click', () => { type = b.dataset.pt; paint(); }));
  paint();
  onModalClose(m, () => (after ? after() : closeModal()));
  $('[data-ok]', m).onclick = () => guard(() => {
    Store.receiveDebtPayment({ customerId, amount: num($('#da', m).value), payType: type, note: $('#dn', m).value }, App.user.id);
    toast(t('debt.received'));
    render();
    if (after) after(); else closeModal();
  });
}

// ================= Balanço financeiro =================

function viewFinance(main) {
  const [from, to] = rangeDates();
  const f = Store.financialReport(from, to);
  const r = App.reportRange;
  const cls = v => (v < 0 ? 'neg-val' : v > 0 ? 'pos-val' : '');
  const catRows = Object.entries(f.byCategory).sort((a, b) => b[1] - a[1]).map(([k, v]) => ({ label: t(`exp.cat.${k}`), value: v }));
  main.innerHTML = `
    <div class="page">
      <div class="report-head">
        <button class="btn period-btn" id="period" aria-haspopup="dialog">
          ${icon('calendar')}
          <span class="period-text">${r.preset === 'custom' ? '' : `<b>${esc(t(`reports.range.${r.preset}`))}</b>`}<span class="${r.preset === 'custom' ? '' : 'muted'}">${esc(periodDates(from, to, true))}</span></span>
          <span class="caret" aria-hidden="true">▾</span>
        </button>
        <button class="btn icon-only" id="print-fin" title="${esc(t('reports.print'))}" aria-label="${esc(t('reports.print'))}">${icon('print')}</button>
      </div>
      <div class="kpis fin-kpis">
        <div class="card kpi"><div class="k-label">${esc(t('fin.netSales'))}</div><div class="k-value num">${money(f.netSales)}</div></div>
        <div class="card kpi"><div class="k-label">${esc(t('fin.expenses'))}</div><div class="k-value num">${money(f.totalExpenses)}</div></div>
        ${CONSIGN() ? `<div class="card kpi"><div class="k-label">${esc(t('rep.toDeliver'))}</div><div class="k-value num">${money(f.totalReceived)}</div></div>`
          : NOCOST() ? '' : `<div class="card kpi"><div class="k-label">${esc(t('fin.result'))}</div><div class="k-value num ${cls(f.result)}">${money(f.result)}</div></div>`}
        <div class="card kpi"><div class="k-label">${esc(t('fin.openDebt'))}</div><div class="k-value num ${f.totalDebt > 0 ? 'neg-val' : ''}">${money(f.totalDebt)}</div></div>
      </div>
      <div class="grid-2">
        <div class="card card-pad cost-only"><h3>${esc(t('fin.resultTitle'))}</h3>
          <div class="stat-rows">
            <div class="s-row"><span>${esc(t('fin.netSales'))}</span><span class="num">${money(f.netSales)}</span></div>
            <div class="s-row"><span>− ${esc(t('fin.cogs'))}</span><span class="num">${money(f.cost)}</span></div>
            <div class="s-row strong"><span>= ${esc(t('reports.grossProfit'))}</span><span class="num">${money(f.grossProfit)}</span></div>
            <div class="s-row"><span>− ${esc(t('fin.expenses'))}</span><span class="num">${money(f.totalExpenses)}</span></div>
            <div class="s-row strong"><span>= ${esc(t('fin.result'))}</span><span class="num ${cls(f.result)}">${money(f.result)}</span></div>
          </div>
          <p class="muted small" style="margin-top:10px">${esc(t('fin.resultHint'))}</p>
        </div>
        <div class="card card-pad"><h3>${esc(t('fin.cashTitle'))}</h3>
          <div class="stat-rows">
            ${Object.entries(f.received).filter(([, v]) => v).map(([k, v]) => `<div class="s-row"><span>${esc(payLabel(k))}</span><span class="num">${money(v)}</span></div>`).join('')}
            <div class="s-row strong"><span>${esc(t('fin.totalReceived'))}</span><span class="num">${money(f.totalReceived)}</span></div>
            <div class="s-row"><span class="muted">${esc(t('fin.ofWhichDebt'))}</span><span class="num muted">${money(f.debtReceived)}</span></div>
            <div class="s-row"><span>− ${esc(t('fin.expensesPaid'))}</span><span class="num">${money(f.totalExpenses)}</span></div>
            <div class="s-row strong"><span>= ${esc(t('fin.cashBalance'))}</span><span class="num ${cls(f.cashBalance)}">${money(f.cashBalance)}</span></div>
          </div>
        </div>
        <div class="card card-pad">
          <div class="chart-head"><h3>${esc(t('fin.expenses'))}</h3><button class="btn primary small" id="new-expense">+ ${esc(t('exp.add'))}</button></div>
          ${catRows.length ? barList(catRows) : ''}
          ${f.expenses.length ? `<ul class="pick-list exp-list">${f.expenses.map(e => `<li>
            <div class="grow"><b>${esc(t(`exp.cat.${e.category}`))}</b>${e.description ? ` · ${esc(e.description)}` : ''}
              <div class="small muted">${fmtEntryDate(e.date)} · ${esc(payLabel(e.payType))}${e.movementId ? ` · ${esc(t('exp.fromDrawerShort'))}` : ''}</div></div>
            <span class="num">${money(e.amount)}</span>
            <button class="icon-btn" data-del-exp="${e.id}" title="${esc(t('common.delete'))}">${icon('trash')}</button></li>`).join('')}</ul>` : `<div class="empty empty-hint"><b>${esc(t('exp.none'))}</b><p>${esc(t('exp.hint'))}</p></div>`}
        </div>
        <div class="card card-pad"><h3>${esc(t('fin.debtTitle'))}</h3>
          <div class="stat-rows">
            <div class="s-row"><span>${esc(t('fin.creditSales'))}</span><span class="num">${money(f.creditSales)}</span></div>
            <div class="s-row"><span>${esc(t('fin.debtReceived'))}</span><span class="num">${money(f.debtReceived)}</span></div>
            <div class="s-row strong"><span>${esc(t('fin.openDebt'))}</span><span class="num ${f.totalDebt > 0 ? 'neg-val' : ''}">${money(f.totalDebt)}</span></div>
          </div>
          ${f.debtors.length ? `<ul class="pick-list">${f.debtors.map(c => `<li data-debtor="${c.id}"><div class="grow"><b>${esc(c.name)}</b>${c.phone ? `<div class="small muted">${esc(c.phone)}</div>` : ''}</div>
            <span class="num neg-val">${money(c.debt)}</span><button class="btn small" data-pay-debt="${c.id}">${esc(t('debt.receiveShort'))}</button></li>`).join('')}</ul>` : `<div class="empty empty-hint"><b>${esc(t('debt.none'))}</b><p>${esc(t('debt.hint'))}</p></div>`}
        </div>
        <div class="card card-pad"><h3>${esc(t('count.valueTitle'))}</h3>
          <div class="stat-rows">
            <div class="s-row cost-only"><span>${esc(t('count.valueCost'))}</span><span class="num">${money(f.stock.cost)}</span></div>
            <div class="s-row"><span>${esc(t('count.valueRetail'))}</span><span class="num">${money(f.stock.retail)}</span></div>
          </div>
        </div>
      </div>
    </div>`;
  $('#period').addEventListener('click', () => periodModal(['today', 'yesterday', '7d', '30d', 'month', 'custom'], from, to));
  $('#new-expense').addEventListener('click', () => expenseModal());
  $$('[data-del-exp]', main).forEach(b => b.addEventListener('click', async () => {
    const e = Store.find('expenses', b.dataset.delExp);
    if (e && await confirmDialog(t('exp.deleteConfirm', { value: money(e.amount) }), t('common.delete'), true)) { Store.removeExpense(e.id); render(); }
  }));
  $$('[data-pay-debt]', main).forEach(b => b.addEventListener('click', e => { e.stopPropagation(); debtPaymentModal(b.dataset.payDebt); }));
  const nc = $('#new-credit', main);
  if (nc) nc.addEventListener('click', () => creditModal());
  $$('[data-debtor]', main).forEach(li => li.addEventListener('click', () => customerFormModal(Store.find('customers', li.dataset.debtor))));
  $('#print-fin').addEventListener('click', () => printDocument(`${t('bal.tabFinance')} ${periodDates(from, to)}`, financePrintHtml(f, from, to, catRows)));
}

function financePrintHtml(f, from, to, catRows) {
  const row = (k, v, bold) => `<tr${bold ? ' class="total-row"' : ''}><td>${esc(k)}</td><td class="r">${money(v)}</td></tr>`;
  return `<div class="doc">
    <h1>${esc(Store.settings.storeName)}</h1>
    <div class="meta">${esc(t('bal.tabFinance'))} · ${esc(periodDates(from, to))} · ${esc(t('reports.generated', { date: fmtDate(new Date().toISOString()) }))}</div>
    <div class="two">
      ${NOCOST() ? '' : `<div class="avoid"><h2>${esc(t('fin.resultTitle'))}</h2><table>
        ${row(t('fin.netSales'), f.netSales)}${row(`− ${t('fin.cogs')}`, f.cost)}${row(`= ${t('reports.grossProfit')}`, f.grossProfit, true)}
        ${row(`− ${t('fin.expenses')}`, f.totalExpenses)}${row(`= ${t('fin.result')}`, f.result, true)}</table></div>`}
      <div class="avoid"><h2>${esc(t('fin.cashTitle'))}</h2><table>
        ${Object.entries(f.received).filter(([, v]) => v).map(([k, v]) => row(payLabel(k), v)).join('')}
        ${row(t('fin.totalReceived'), f.totalReceived, true)}${row(`− ${t('fin.expensesPaid')}`, f.totalExpenses)}${row(`= ${t('fin.cashBalance')}`, f.cashBalance, true)}</table></div>
    </div>
    <div class="avoid"><h2>${esc(t('fin.expenses'))}</h2>${f.expenses.length ? `<table>
      <tr><th>${esc(t('common.date'))}</th><th>${esc(t('exp.category'))}</th><th>${esc(t('exp.description'))}</th><th class="r">${esc(t('common.amount'))}</th></tr>
      ${f.expenses.map(e => `<tr><td>${fmtEntryDate(e.date)}</td><td>${esc(t(`exp.cat.${e.category}`))}</td><td>${esc(e.description)}</td><td class="r">${money(e.amount)}</td></tr>`).join('')}
      <tr class="total-row"><td colspan="3">${esc(t('totals.total'))}${catRows.length ? ` (${catRows.map(c => `${esc(c.label)}: ${money(c.value)}`).join(' · ')})` : ''}</td><td class="r">${money(f.totalExpenses)}</td></tr></table>` : `<p>${esc(t('exp.none'))}</p>`}</div>
    <div class="avoid"><h2>${esc(t('fin.debtTitle'))}</h2><table>
      ${row(t('fin.creditSales'), f.creditSales)}${row(t('fin.debtReceived'), f.debtReceived)}${row(t('fin.openDebt'), f.totalDebt, true)}
      ${f.debtors.map(c => row(`${c.name}${c.phone ? ` (${c.phone})` : ''}`, c.debt)).join('')}</table></div>
    <div class="avoid"><h2>${esc(t('count.valueTitle'))}</h2><table>${NOCOST() ? '' : row(t('count.valueCost'), f.stock.cost)}${row(t('count.valueRetail'), f.stock.retail)}</table></div>
  </div>`;
}

function expenseModal() {
  if (!need('expenses')) return;
  const today = dayKey(new Date());
  const shift = Store.currentShift();
  let type = 'cash';
  const m = openModal({
    title: t('exp.add'),
    autofocus: false,
    body: `<form id="ef">
      <div class="row">
        <label class="field"><span>${esc(t('common.amount'))} *</span><input class="input" name="amount" inputmode="decimal" required></label>
        <label class="field"><span>${esc(t('common.date'))} *</span><input class="input" type="date" name="date" value="${today}" max="${today}" required></label>
      </div>
      <label class="field"><span>${esc(t('exp.category'))}</span><select class="input" name="category">
        ${EXPENSE_CATEGORIES.map(k => `<option value="${k}">${esc(t(`exp.cat.${k}`))}</option>`).join('')}</select></label>
      <label class="field"><span>${esc(t('exp.description'))}</span><input class="input" name="description" placeholder="${esc(t('exp.descPlaceholder'))}"></label>
      <div class="field"><span>${esc(t('exp.paidWith'))}</span>
        <div class="seg">${['cash', 'card', 'mobile', 'other'].map(k => `<button type="button" data-pt="${k}">${esc(payLabel(k))}</button>`).join('')}</div></div>
      <label class="check" id="drawer-row"><input type="checkbox" name="fromDrawer" ${shift ? 'checked' : 'disabled'}> ${esc(t(shift ? 'exp.fromDrawer' : 'exp.fromDrawerNoShift'))}</label>
      ${CONSIGN() ? `<label class="check check-hint"><input type="checkbox" name="supplierPays"> <span>${esc(t('exp.supplierPays'))}<small class="muted">${esc(t('exp.supplierPaysHint'))}</small></span></label>` : ''}
    </form>`,
    footer: `<button class="btn primary" data-ok>${esc(t('common.save'))}</button>`,
  });
  const form = $('#ef', m);
  const paint = () => {
    $$('[data-pt]', m).forEach(b => b.classList.toggle('active', b.dataset.pt === type));
    $('#drawer-row', m).hidden = type !== 'cash';
  };
  $$('[data-pt]', m).forEach(b => b.addEventListener('click', () => { type = b.dataset.pt; paint(); }));
  paint();
  const ok = () => guard(() => {
    const f = formObj(form);
    Store.addExpense({ date: f.date, category: f.category, amount: num(f.amount), description: f.description, payType: type, fromDrawer: type === 'cash' && !!f.fromDrawer, supplierPays: !!f.supplierPays }, App.user.id);
    closeModal(); render(); toast(t('exp.saved'));
  });
  $('[data-ok]', m).onclick = ok;
  form.addEventListener('submit', e => { e.preventDefault(); ok(); });
}

// ================= Categorias =================

function viewCategories(main) {
  const f = App.catFilter || (App.catFilter = { q: '', show: '', sort: 'order' });
  const nItems = c => Store.data.items.filter(i => i.categoryId === c.id).length;
  const value = c => round2(Store.data.items.filter(i => i.categoryId === c.id && i.trackStock).reduce((a, i) => a + Math.max(0, i.stock) * (i.price || 0), 0));
  const list = over => {
    const g = Object.assign({}, f, over);
    const q = (g.q || '').trim().toLowerCase();
    const all = byLayout(Store.data.categories, 'order.cats').filter(c => (!q || c.name.toLowerCase().includes(q))
      && (g.show !== 'with' || nItems(c) > 0) && (g.show !== 'empty' || nItems(c) === 0));
    if (g.sort === 'name') all.sort((a, b) => a.name.localeCompare(b.name, 'pt'));
    if (g.sort === 'count') all.sort((a, b) => nItems(b) - nItems(a));
    if (g.sort === 'value') all.sort((a, b) => value(b) - value(a));
    return all;
  };
  main.innerHTML = `
    <div class="page">
      ${listBarHtml('cq', t('flt.catSearch'), f.q, t('flt.newCat'), false)}
      <div class="fchips" id="fchips"></div>
      <div class="card table-wrap" id="cl"></div>
    </div>`;
  const paint = () => {
    const cats = list();
    const tags = [f.show ? { k: 'show', label: t(`flt.show.${f.show}`) } : null, f.sort !== 'order' ? { k: 'sort', label: t(`flt.csort.${f.sort}`) } : null].filter(Boolean);
    const btn = $('#cq-f');
    btn.classList.toggle('on', tags.length > 0);
    $('.fbadge', btn).textContent = tags.length || '';
    $('#fchips').innerHTML = tags.length ? `${tags.map(x => `<button type="button" class="fchip on" data-untag="${x.k}">${esc(x.label)} ✕</button>`).join('')}<button type="button" class="fchip clear" data-untag="all">${esc(t('flt.clear'))}</button>` : '';
    $$('[data-untag]', main).forEach(b => b.addEventListener('click', () => {
      const k = b.dataset.untag;
      if (k === 'all' || k === 'show') f.show = '';
      if (k === 'all' || k === 'sort') f.sort = 'order';
      paint();
    }));
    $('#cl').innerHTML = cats.length ? `<table class="table">
        <thead><tr><th>${esc(t('common.name'))}</th><th class="right">${esc(t('common.products'))}</th></tr></thead>
        <tbody>${cats.map(c => `<tr class="clickable" data-id="${c.id}"><td><span class="swatch" style="background:${esc(c.color)}"></span>${esc(c.name)}</td>
          <td class="right">${nItems(c)}</td></tr>`).join('')}</tbody>
        <tfoot><tr class="total-row"><td>${esc(t('totals.total'))} <span class="muted small">(${cats.length})</span></td><td class="right">${cats.reduce((a, c) => a + nItems(c), 0)}</td></tr></tfoot></table>` : `<div class="empty">${esc(t('categories.none'))}</div>`;
    $$('#cl tr[data-id]').forEach(tr => tr.addEventListener('click', () => categoryFormModal(Store.find('categories', tr.dataset.id))));
    // Arrastar para ordenar só na ordem própria e sem filtros.
    if (f.sort === 'order' && !f.show && !f.q.trim()) makeSortable($('#cl tbody'), 'tr[data-id]', 'data-id', ids => Layout.set('order.cats', ids));
  };
  $('#cq').addEventListener('input', e => { f.q = e.target.value; paint(); });
  $('#new').addEventListener('click', () => categoryFormModal(null));
  $('#cq-f').addEventListener('click', () => {
    const d = { show: f.show, sort: f.sort };
    const m = openModal({ title: t('flt.catsTitle'), autofocus: false, body: '<div id="fbody"></div>',
      footer: `<button class="btn left" data-clear>${esc(t('flt.clear'))}</button><button class="btn primary" data-ok></button>` });
    const pm = () => {
      $('#fbody', m).innerHTML = chipGroup(t('flt.show'), 'show', [['', t('flt.all')], ['with', t('flt.show.with')], ['empty', t('flt.show.empty')]], d.show)
        + chipGroup(t('flt.sort'), 'sort', ['order', 'name', 'count', 'value'].map(v => [v, t(`flt.csort.${v}`)]), d.sort);
      $('[data-ok]', m).textContent = t('flt.showCats', { n: list(d).length });
      $$('.fchip[data-g]', m).forEach(b => b.addEventListener('click', () => { d[b.dataset.g] = b.dataset.v; pm(); }));
    };
    pm();
    $('[data-clear]', m).onclick = () => { d.show = ''; d.sort = 'order'; pm(); };
    $('[data-ok]', m).onclick = () => { Object.assign(f, d); closeModal(); paint(); };
  });
  paint();
}

function categoryFormModal(cat) {
  const isNew = !cat;
  const c = cat || { name: '', color: COLORS[4] };
  const m = openModal({
    title: isNew ? t('categories.newTitle') : t('categories.editTitle'),
    body: `<form id="cf">
      <label class="field"><span>${esc(t('common.name'))} *</span><input class="input" name="name" required value="${esc(c.name)}"></label>
      <div class="field"><span>${esc(t('categories.color'))}</span>${colorPicker('color', c.color)}</div>
      ${isNew ? '' : `<label class="check"><input type="checkbox" name="applyColor"> ${esc(t('categories.applyColor'))}</label>`}
    </form>`,
    footer: `${isNew ? '' : `<button class="btn danger left" data-del>${esc(t('common.delete'))}</button>`}<button class="btn primary" data-ok>${esc(t('common.save'))}</button>`,
  });
  const form = $('#cf', m);
  const ok = () => {
    const f = formObj(form);
    if (!f.name.trim()) return toast(t('common.needName'), true);
    const saved = Store.upsert('categories', { id: c.id, name: f.name.trim(), color: f.color || COLORS[4] });
    if (f.applyColor) {
      Store.data.items.filter(i => i.categoryId === saved.id).forEach(i => { i.color = saved.color; });
      Store.save();
    }
    closeModal(); render(); toast(t('categories.saved'));
    return undefined;
  };
  $('[data-ok]', m).onclick = ok;
  form.addEventListener('submit', e => { e.preventDefault(); ok(); });
  if (!isNew) $('[data-del]', m).onclick = async () => {
    if (await confirmDialog(t('categories.deleteConfirm', { name: c.name }), t('common.delete'), true)) {
      Store.data.items.filter(i => i.categoryId === c.id).forEach(i => { i.categoryId = null; });
      Store.remove('categories', c.id); render();
    }
  };
}

// ================= Clientes =================

function viewCustomers(main) {
  main.innerHTML = `
    <div class="page">
      <div class="page-head">
        <input class="input grow" id="cq" type="search" placeholder="${esc(t('customers.searchPlaceholder'))}" value="${esc(App.customersQ)}">
        <button class="btn primary" id="new">+ ${esc(t('customers.add'))}</button>
      </div>
      <div class="card table-wrap" id="cl"></div>
    </div>`;
  const paint = () => {
    const q = App.customersQ.trim().toLowerCase();
    const list = Store.data.customers
      .filter(c => !q || [c.name, c.phone, c.email].some(v => String(v || '').toLowerCase().includes(q)))
      .sort((a, b) => a.name.localeCompare(b.name, 'pt'));
    $('#cl').innerHTML = list.length ? `<table class="table">
      <thead><tr><th>${esc(t('common.name'))}</th><th class="hide-sm">${esc(t('customers.contact'))}</th><th class="right">${esc(t('customers.visits'))}</th><th class="right hide-sm">${esc(t('customers.totalSpent'))}</th><th class="right">${esc(t('customers.points'))}</th></tr></thead>
      <tbody>${list.map(c => `<tr class="clickable" data-id="${c.id}">
        <td class="wrap">${esc(c.name)}${c.debt > 0 ? ` <span class="badge danger">${esc(t('debt.owes', { value: money(c.debt) }))}</span>` : ''}${c.note ? `<div class="small muted">${esc(c.note)}</div>` : ''}</td>
        <td class="hide-sm">${esc(c.phone || '')}${c.email ? `<div class="small muted">${esc(c.email)}</div>` : ''}</td>
        <td class="right">${c.visits}</td><td class="right num hide-sm">${money(c.totalSpent)}</td><td class="right num">${fmtQty(c.points)}</td>
      </tr>`).join('')}</tbody>
      <tfoot><tr class="total-row"><td>${esc(t('totals.total'))} <span class="muted small">(${list.length})</span>${(d => (d > 0 ? `<div class="small neg-val">${esc(t('fin.openDebt'))}: ${money(d)}</div>` : ''))(round2(list.reduce((a, c) => a + (c.debt || 0), 0)))}</td><td class="hide-sm"></td>
        <td class="right">${list.reduce((a, c) => a + c.visits, 0)}</td><td class="right num hide-sm">${money(round2(list.reduce((a, c) => a + c.totalSpent, 0)))}</td><td class="right num">${fmtQty(round2(list.reduce((a, c) => a + c.points, 0)))}</td></tr></tfoot></table>` : `<div class="empty">${esc(t('customers.noneFound'))}</div>`;
    $$('#cl tr[data-id]').forEach(tr => tr.addEventListener('click', () => customerFormModal(Store.find('customers', tr.dataset.id))));
  };
  $('#cq').addEventListener('input', e => { App.customersQ = e.target.value; paint(); });
  $('#new').addEventListener('click', () => customerFormModal(null));
  paint();
}

function customerFormModal(cust, onSaved) {
  const isNew = !cust;
  const c = cust || { name: '', phone: '', email: '', note: '', points: 0, visits: 0, totalSpent: 0 };
  const history = isNew ? [] : Store.data.receipts.filter(r => r.customerId === c.id).slice(0, 10);
  const m = openModal({
    title: isNew ? t('customers.new') : c.name,
    wide: !isNew,
    body: `<form id="cf">
      <label class="field"><span>${esc(t('common.name'))} *</span><input class="input" name="name" required value="${esc(c.name)}"></label>
      <div class="row">
        <label class="field"><span>${esc(t('common.phone'))}</span><input class="input" name="phone" type="tel" value="${esc(c.phone)}"></label>
        <label class="field"><span>${esc(t('common.email'))}</span><input class="input" name="email" type="email" value="${esc(c.email)}"></label>
      </div>
      <label class="field"><span>${esc(t('customers.note'))}</span><textarea class="input" name="note">${esc(c.note)}</textarea></label>
      ${isNew ? '' : `<label class="field"><span>${esc(t('customers.pointsAdjust'))}</span><input class="input" name="points" inputmode="decimal" value="${c.points}"></label>
        <p class="muted small">${esc(t('customers.summary', { visits: c.visits, spent: money(c.totalSpent) }))}</p>
        ${debtBlock(c)}
        ${history.length ? `<h3 style="margin:14px 0 8px;font-size:14px">${esc(t('customers.lastPurchases'))}</h3><ul class="pick-list">${history.map(r => `<li data-r="${r.id}"><div class="grow">${esc(t('receipt.number'))} ${esc(receiptNo(r))} <span class="small muted">${fmtDate(r.date)}</span></div><span class="num ${r.type === 'refund' ? 'neg-val' : ''}">${r.type === 'refund' ? '−' : ''}${money(r.total)}</span></li>`).join('')}</ul>` : ''}`}
    </form>`,
    footer: `${isNew ? '' : `<button class="btn danger left" data-del>${esc(t('common.delete'))}</button>`}<button class="btn primary" data-ok>${esc(t('common.save'))}</button>`,
  });
  const form = $('#cf', m);
  $$('[data-r]', m).forEach(li => li.addEventListener('click', () => receiptModal(Store.find('receipts', li.dataset.r))));
  const recv = $('[data-receive]', m);
  if (recv) recv.onclick = () => debtPaymentModal(c.id, () => customerFormModal(Store.find('customers', c.id), onSaved));
  const ok = () => {
    const f = formObj(form);
    if (!f.name.trim()) return toast(t('common.needName'), true);
    const saved = Store.upsert('customers', {
      id: c.id, name: f.name.trim(), phone: f.phone.trim(), email: f.email.trim(), note: f.note.trim(),
      points: isNew ? 0 : Math.max(0, round2(num(f.points))), visits: c.visits, totalSpent: c.totalSpent,
    });
    closeModal();
    if (onSaved) onSaved(saved); else render();
    toast(t('customers.saved'));
    return undefined;
  };
  $('[data-ok]', m).onclick = ok;
  form.addEventListener('submit', e => { e.preventDefault(); ok(); });
  if (!isNew) $('[data-del]', m).onclick = async () => {
    if (await confirmDialog(t('common.deleteConfirm', { name: c.name }), t('common.delete'), true)) { Store.remove('customers', c.id); render(); }
  };
}

// ================= Turnos =================

function viewShifts(main) {
  const s = Store.currentShift();
  const closed = Store.data.shifts.filter(x => x.closedAt).slice(0, 30);
  const multiDevice = Store.data.shifts.some(x => x.deviceNo);
  let top;
  if (!s) {
    top = `<div class="card card-pad">
      <h3>${esc(t('shift.open'))}</h3>
      <p class="muted">${esc(t('shift.openHint'))}</p>
      <label class="field"><span>${esc(t('shift.startCash'))}</span><input class="input" id="sc" inputmode="decimal" value="0"></label>
      <button class="btn primary" id="open">${esc(t('shift.open'))}</button>
    </div>`;
  } else {
    const sum = Store.shiftSummary(s);
    top = `<div class="grid-2">
      <div class="card card-pad">
        <h3>${esc(t('shift.current'))} <span class="badge">${esc(t('shift.openBadge'))}</span></h3>
        <p class="muted small">${esc(t('shift.openedBy', { name: empName(s.openedBy), date: fmtDate(s.openedAt) }))}</p>
        <div class="stat-rows">
          <div class="s-row"><span>${esc(t('shift.startCash'))}</span><span class="num">${money(s.startCash)}</span></div>
          <div class="s-row"><span>${esc(t('shift.cashPayments'))}</span><span class="num">${money(sum.cashSales)}</span></div>
          <div class="s-row"><span>${esc(t('shift.cashRefunds'))}</span><span class="num">${minus(sum.cashRefunds)}</span></div>
          ${sum.debtCash ? `<div class="s-row"><span>${esc(t('debt.cashReceived'))}</span><span class="num">${money(sum.debtCash)}</span></div>` : ''}
          <div class="s-row"><span>${esc(t('shift.payIns'))}</span><span class="num">${money(sum.payIns)}</span></div>
          <div class="s-row"><span>${esc(t('shift.payOuts'))}</span><span class="num">${minus(sum.payOuts)}</span></div>
          <div class="s-row strong"><span>${esc(t('shift.expected'))}</span><span class="num">${money(sum.expected)}</span></div>
        </div>
        <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:14px">
          <button class="btn" data-mv="in">${esc(t('shift.payIn'))}</button>
          <button class="btn" data-mv="out">${esc(t('shift.payOut'))}</button>
          <button class="btn primary" id="close">${esc(t('shift.close'))}</button>
        </div>
      </div>
      <div class="card card-pad">
        <h3>${esc(t('shift.salesSummary'))}</h3>
        <div class="stat-rows">
          <div class="s-row"><span>${esc(t('nav.receipts'))}</span><span>${sum.receipts}</span></div>
          <div class="s-row"><span>${esc(t('reports.grossSales'))}</span><span class="num">${money(sum.grossSales)}</span></div>
          <div class="s-row"><span>${esc(t('reports.refunds'))}</span><span class="num">${minus(sum.refunds)}</span></div>
          <div class="s-row strong"><span>${esc(t('reports.netSales'))}</span><span class="num">${money(sum.netSales)}</span></div>
          ${Object.entries(sum.byPayment).map(([k, v]) => `<div class="s-row"><span class="muted">${esc(payLabel(k))}</span><span class="num">${money(v)}</span></div>`).join('')}
        </div>
        ${s.movements.length ? `<h3 style="margin-top:16px">${esc(t('shift.movements'))}</h3><div class="stat-rows">${s.movements.map(mv => `<div class="s-row"><span>${fmtTime(mv.date)} · ${esc(mv.type === 'in' ? t('shift.in') : t('shift.out'))}${mv.note ? ` — ${esc(mv.note)}` : ''}</span><span class="num ${mv.type === 'in' ? 'pos-val' : 'neg-val'}">${mv.type === 'in' ? '+' : '−'}${money(mv.amount)}</span></div>`).join('')}</div>` : ''}
      </div>
    </div>`;
  }
  main.innerHTML = `
    <div class="page">
      ${top}
      <h3 style="margin:24px 0 10px">${esc(t('shift.previous'))}</h3>
      <div class="card table-wrap">${closed.length ? `<table class="table">
        <thead><tr><th>${esc(t('shift.openedAt'))}</th><th>${esc(t('shift.closedAt'))}</th>${multiDevice ? `<th>${esc(t('shift.device'))}</th>` : ''}<th class="hide-sm">${esc(t('receipts.employee'))}</th><th class="right">${esc(t('reports.netSales'))}</th><th class="right">${esc(t('shift.expectedShort'))}</th><th class="right">${esc(t('shift.actual'))}</th><th class="right">${esc(t('shift.difference'))}</th></tr></thead>
        <tbody>${closed.map(x => `<tr>
          <td>${fmtDate(x.openedAt)}</td><td>${fmtDate(x.closedAt)}</td>${multiDevice ? `<td>${x.deviceNo || '—'}</td>` : ''}<td class="hide-sm">${esc(empName(x.openedBy))}</td>
          <td class="right num">${money(x.summary.netSales)}</td><td class="right num">${money(x.summary.expected)}</td><td class="right num">${money(x.actualCash)}</td>
          <td class="right num ${x.summary.difference < 0 ? 'neg-val' : x.summary.difference > 0 ? 'pos-val' : ''}">${money(x.summary.difference)}</td>
        </tr>`).join('')}</tbody>
        <tfoot>${(sm => `<tr class="total-row"><td colspan="${multiDevice ? 3 : 2}">${esc(t('totals.total'))} <span class="muted small">(${closed.length})</span></td><td class="hide-sm"></td>
          <td class="right num">${money(sm(x => x.summary.netSales))}</td><td class="right num">${money(sm(x => x.summary.expected))}</td><td class="right num">${money(sm(x => x.actualCash))}</td><td class="right num">${money(sm(x => x.summary.difference))}</td></tr>`)(f => round2(closed.reduce((a, x) => a + (Number(f(x)) || 0), 0)))}</tfoot></table>` : `<div class="empty">${esc(t('shift.noneClosed'))}</div>`}</div>
    </div>`;
  if (!s) {
    $('#open').addEventListener('click', () => guard(() => {
      Store.openShift(num($('#sc').value), App.user.id);
      toast(t('shift.opened')); render();
    }));
    return;
  }
  $$('[data-mv]', main).forEach(b => b.addEventListener('click', () => {
    const type = b.dataset.mv;
    const m = openModal({
      title: type === 'in' ? t('shift.payIn') : t('shift.payOut'),
      body: `<label class="field"><span>${esc(t('common.amount'))}</span><input class="input" id="mv" inputmode="decimal"></label>
        <label class="field"><span>${esc(t('shift.reason'))}</span><input class="input" id="mn" placeholder="${esc(t('shift.reasonPlaceholder'))}"></label>`,
      footer: `<button class="btn primary" data-ok>${esc(t('shift.register'))}</button>`,
    });
    $('[data-ok]', m).onclick = () => guard(() => {
      Store.addCashMovement(type, num($('#mv', m).value), $('#mn', m).value.trim(), App.user.id);
      closeModal(); render();
    });
  }));
  $('#close').addEventListener('click', () => {
    const sum = Store.shiftSummary(s);
    const m = openModal({
      title: t('shift.close'),
      body: `<p>${esc(t('shift.expectedShort'))}: <b class="num">${money(sum.expected)}</b></p>
        <label class="field"><span>${esc(t('shift.counted'))}</span><input class="input" id="ac" inputmode="decimal" value="${sum.expected}"></label>
        <div class="change-box"><span>${esc(t('shift.difference'))}</span><strong class="num" id="df">${money(0)}</strong></div>`,
      footer: `<button class="btn primary" data-ok>${esc(t('shift.close'))}</button>`,
    });
    const ac = $('#ac', m);
    ac.addEventListener('input', () => { $('#df', m).textContent = money(num(ac.value) - sum.expected); });
    $('[data-ok]', m).onclick = () => guard(() => {
      Store.closeShift(num(ac.value), App.user.id);
      closeModal(); toast(t('shift.closed')); render();
    });
  });
}

// ================= Relatórios =================

const fmtDay = d => d.toLocaleDateString(dateLocale(), { day: '2-digit', month: '2-digit', year: 'numeric' });

// "30/10/2026" para um só dia, "24/10/2026 – 30/10/2026" para vários.
// Com short, omite o ano quando o período é todo no ano atual (para caber no botão do telemóvel).
function periodDates(from, to, short = false) {
  const last = new Date(to.getTime() - 1);
  const year = new Date().getFullYear();
  const omitYear = short && from.getFullYear() === year && last.getFullYear() === year;
  const f = d => (omitYear ? d.toLocaleDateString(dateLocale(), { day: '2-digit', month: '2-digit' }) : fmtDay(d));
  return dayKey(from) === dayKey(last) ? f(from) : `${f(from)} – ${f(last)}`;
}

// Escolha do período numa só janela: períodos rápidos ou datas personalizadas.
function periodModal(presets, from, to) {
  const r = App.reportRange;
  const lastDay = dayKey(new Date(to.getTime() - 1));
  const m = openModal({
    title: t('reports.period'),
    autofocus: false,
    body: `
      <ul class="pick-list period-list">${presets.filter(k => k !== 'custom').map(k => `
        <li data-preset="${k}" class="${k === r.preset ? 'on' : ''}"><span class="grow">${esc(t(`reports.range.${k}`))}</span>${k === r.preset ? icon('check') : ''}</li>`).join('')}
      </ul>
      <h3 class="period-custom-title">${esc(t('reports.range.custom'))}</h3>
      <div class="row">
        <label class="field"><span>${esc(t('reports.from'))}</span><input class="input" type="date" id="pf" value="${r.preset === 'custom' ? r.from : dayKey(from)}"></label>
        <label class="field"><span>${esc(t('reports.to'))}</span><input class="input" type="date" id="pt" value="${r.preset === 'custom' ? r.to : lastDay}"></label>
      </div>
      ${cardsSectionHtml('rep')}`,
    footer: `<button class="btn primary" data-ok>${esc(t('common.apply'))}</button>`,
  });
  $$('[data-preset]', m).forEach(li => li.addEventListener('click', () => {
    saveCardsSection(m, 'rep');
    r.preset = li.dataset.preset;
    closeModal(); render();
  }));
  const f0 = $('#pf', m).value, t0 = $('#pt', m).value;
  $('[data-ok]', m).onclick = () => {
    let f = $('#pf', m).value, tt = $('#pt', m).value;
    // Só mudaram os cartões: mantém o período escolhido.
    if (f === f0 && tt === t0) { saveCardsSection(m, 'rep'); closeModal(); render(); return; }
    if (!f || !tt) { toast(t('reports.needDates'), true); return; }
    if (f > tt) [f, tt] = [tt, f];
    saveCardsSection(m, 'rep');
    Object.assign(r, { preset: 'custom', from: f, to: tt });
    closeModal(); render();
  };
}

// Desenha o gráfico à largura de uma página A4, fora do ecrã, para o documento impresso.
function printChart(series, kind) {
  const box = document.createElement('div');
  box.style.cssText = 'position:absolute;left:-10000px;top:0;width:700px';
  document.body.appendChild(box);
  drawTimeChart(box, series, kind);
  const svg = $('svg', box);
  box.remove();
  return svg;
}

// Números do topo dos relatórios: vendas em destaque e, sem repetições, entradas e saídas de stock,
// despesas, descontos, fiado e lucro.
function reportKpis(f) {
  let kid = 0;
  const ids = ['stockIn', 'toDeliver', 'expenses', 'discounts', 'credit', 'stockValue', 'salesCount', 'average', 'refunds'];
  const card = (label, value, sub, cls = '') => `<div class="card kpi" data-kid="${ids[kid++]}"><div class="k-label">${esc(label)}</div>
    <div class="k-value num ${cls}">${value}</div>${sub ? `<div class="k-sub">${esc(sub)}</div>` : ''}</div>`;
  const extras = [
    f.refunds ? t('rep.refundsSub', { value: money(f.refunds) }) : '',
    f.tax ? t('rep.taxSub', { value: money(f.tax) }) : '',
  ].filter(Boolean).join(' · ');
  const names = f.uncosted.slice(0, 3).join(', ') + (f.uncosted.length > 3 ? '…' : '');
  return `
    <div class="card kpi sales-hero">
      <div class="k-label">${esc(t('rep.sales'))}</div>
      <div class="k-value num">${money(f.netSales)}</div>
      <div class="k-sub">${esc(t('rep.salesSub', { n: f.salesCount, avg: money(f.average) }))}${extras ? ` · ${esc(extras)}` : ''}</div>
    </div>
    <div class="kpis kpi-six" data-kpis="rep">
      ${NOCOST() ? card(t('rep.stockIn'), money(f.stockIn.retail), `${fmtQty(f.stockIn.qty)} ${t('rep.stockInSale')}`) : card(t('rep.stockIn'), money(f.stockIn.value), t('rep.stockInSub', { n: fmtQty(f.stockIn.qty) }))}
      ${CONSIGN() ? card(t('rep.toDeliver'), money(f.totalReceived), t('rep.toDeliverSub')) : NOCOST() ? '' : card(t('rep.stockOut'), money(f.cost), t('rep.stockOutSub'))}
      ${card(t('fin.expenses'), money(f.totalExpenses), '')}
      ${card(t('reports.discounts'), money(f.discounts), '')}
      ${card(t('rep.credit'), money(f.creditSales), t('rep.creditSub', { value: money(f.totalDebt) }), f.creditSales ? 'neg-val' : '')}
      ${NOCOST() ? card(t('count.valueRetail'), money(f.stock.retail), '') : card(t('rep.profit'), money(f.result), t('rep.profitSub'), f.result < 0 ? 'neg-val' : 'pos-val')}
      ${card(t('rep.kpiSalesCount'), f.salesCount, '')}
      ${card(t('rep.kpiAverage'), money(f.average), '')}
      ${card(t('reports.refunds'), money(f.refunds), '', f.refunds ? 'neg-val' : '')}
    </div>
    ${f.uncosted.length && !NOCOST() ? `<div class="notice warn">${icon('tag')}<div>${esc(t('rep.uncosted', { n: f.uncosted.length, names }))} <a href="#itens">${esc(t('rep.openItems'))}</a></div></div>` : ''}`;
}

// Relatório em formato de documento (A4), com os gráficos e as tabelas.
function reportPrintHtml(c) {
  const s = Store.settings;
  const f = c.fin;
  const kpis = [
    [t('rep.sales'), money(f.netSales)], [t('rep.stockIn'), money(NOCOST() ? f.stockIn.retail : f.stockIn.value)],
    CONSIGN() ? [t('rep.toDeliver'), money(f.totalReceived)] : NOCOST() ? null : [t('rep.stockOut'), money(f.cost)], [t('fin.expenses'), money(f.totalExpenses)],
    [t('reports.discounts'), money(f.discounts)], [t('rep.credit'), money(f.creditSales)],
    NOCOST() ? [t('count.valueRetail'), money(f.stock.retail)] : [t('rep.profit'), money(f.result)], [t('nav.receipts'), `${f.salesCount} · ${t('rep.avg')} ${money(f.average)}`],
  ];
  const svg = c.chartSvg ? c.chartSvg.outerHTML : '';
  const donutBlock = (title, html) => {
    if (!html) return `<div class="avoid"><h2>${esc(title)}</h2><p>${esc(t('reports.noSales'))}</p></div>`;
    const tmp = document.createElement('div');
    tmp.innerHTML = html;
    const d = tmp.firstElementChild;
    const rows = $$('.legend li', d).map(li => `<tr><td><span class="sw" style="background:${$('.sw', li).style.background}"></span>${esc($('.lg-label', li).textContent)}</td><td class="r">${esc($('.lg-pct', li).textContent)}</td><td class="r">${esc($('.lg-val', li).textContent)}</td></tr>`).join('');
    return `<div class="avoid donut"><h2>${esc(title)}</h2>${$('svg', d).outerHTML}<table>${rows}</table></div>`;
  };
  const simple = (title, rows, empty) => `<div class="avoid"><h2>${esc(title)}</h2>${rows.length ? `<table>${rows.join('')}</table>` : `<p>${esc(empty)}</p>`}</div>`;
  return `<div class="doc">
    <h1>${esc(s.storeName)}</h1>
    <div class="meta">${esc(t('reports.printTitle'))} · ${esc(periodDates(c.from, c.to))} · ${esc(t('reports.generated', { date: fmtDate(new Date().toISOString()) }))}</div>
    <div class="kpi-grid">${kpis.filter(Boolean).map(([k, v]) => `<div><span>${esc(k)}</span><b>${esc(String(v))}</b></div>`).join('')}</div>
    ${c.notes && c.notes.length ? `<div class="avoid notes">${notesHtml(c.notes)}</div>` : ''}
    <div class="avoid"><h2>${esc(c.chartTitle)}</h2>${svg}</div>
    <div class="two">${donutBlock(t('reports.byCategory'), c.catDonut)}${donutBlock(t('reports.byPayment'), c.payDonut)}</div>
    <div class="avoid"><h2>${esc(t('reports.topItems'))}</h2>${c.topItems.length ? `<table><tr><th>${esc(t('reports.item'))}</th><th class="r">${esc(t('reports.qty'))}</th><th class="r">${esc(t('reports.sales'))}</th>${NOCOST() ? '' : `<th class="r">${esc(t('reports.profit'))}</th>`}</tr>
      ${c.topItems.map(i => `<tr><td>${esc(i.name)}</td><td class="r">${fmtQty(round2(i.qty))}</td><td class="r">${money(i.net)}</td>${NOCOST() ? '' : `<td class="r">${money(i.net - i.cost)}</td>`}</tr>`).join('')}
      <tr class="total-row"><td>${esc(t('totals.total'))}${c.allCount > c.topItems.length ? ` (${esc(t('reports.allItemsN', { n: c.allCount }))})` : ''}</td><td class="r">${fmtQty(round2(c.itemsTotal.qty))}</td><td class="r">${money(c.itemsTotal.net)}</td>${NOCOST() ? '' : `<td class="r">${money(c.itemsTotal.net - c.itemsTotal.cost)}</td>`}</tr></table>` : `<p>${esc(t('reports.noSales'))}</p>`}</div>
    <div class="two">
      ${simple(t('reports.byEmployee'), c.emps.map(e => `<tr><td>${esc(e.label)}</td><td class="r">${money(e.value)}</td></tr>`), t('reports.noSales'))}
      ${simple(t('items.lowStock'), c.lowStock.map(i => `<tr><td>${esc(i.name)}</td><td class="r">${fmtQty(i.stock)}</td></tr>`), t('reports.noLowStock'))}
    </div>
  </div>`;
}

function rangeDates() {
  const r = App.reportRange;
  const today = new Date(); today.setHours(0, 0, 0, 0);
  const add = (d, n) => { const x = new Date(d); x.setDate(x.getDate() + n); return x; };
  switch (r.preset) {
    case 'yesterday': return [add(today, -1), today];
    case '7d': return [add(today, -6), add(today, 1)];
    case '30d': return [add(today, -29), add(today, 1)];
    case 'month': return [new Date(today.getFullYear(), today.getMonth(), 1), add(today, 1)];
    case 'custom': {
      const f = r.from ? new Date(`${r.from}T00:00:00`) : today;
      const to = r.to ? add(new Date(`${r.to}T00:00:00`), 1) : add(today, 1);
      return [f, to];
    }
    default: return [today, add(today, 1)];
  }
}

// ---------- Gráficos ----------

// Série temporal: por hora quando o período é um só dia, senão por dia.
function timeSeries(from, to, rep) {
  const oneDay = to - from <= 864e5 + 3600e3;
  if (oneDay) {
    const key = dayKey(from);
    const vals = Array.from({ length: 24 }, (_, h) => rep.byHour[`${key} ${String(h).padStart(2, '0')}`] || 0);
    const active = vals.map((v, h) => (v ? h : -1)).filter(h => h >= 0);
    const start = Math.min(8, ...active), end = Math.max(20, ...active);
    const pts = [];
    for (let h = start; h <= end; h++) pts.push({ label: `${String(h).padStart(2, '0')}h`, tip: `${String(h).padStart(2, '0')}:00–${String(h).padStart(2, '0')}:59`, value: vals[h] });
    return { title: t('reports.netByHour'), pts };
  }
  const pts = [];
  for (let d = new Date(from); d < to; d.setDate(d.getDate() + 1)) {
    const k = dayKey(d);
    pts.push({ label: `${k.slice(8)}/${k.slice(5, 7)}`, tip: fmtDate(d.toISOString()).split(/[ ,]+/)[0], value: rep.byDay[k] || 0 });
  }
  return { title: t('reports.netByDay'), pts };
}

let compactFmt = null;
const compact = n => {
  if (!compactFmt) compactFmt = new Intl.NumberFormat(dateLocale(), { notation: 'compact', maximumFractionDigits: 1 });
  return compactFmt.format(n);
};

// Valores "redondos" para as linhas de grelha (0, 50, 100, …).
function niceTicks(max) {
  if (max <= 0) return [0, 1];
  const raw = max / 4;
  const mag = 10 ** Math.floor(Math.log10(raw));
  const step = [1, 2, 2.5, 5, 10].map(m => m * mag).find(s => s >= raw);
  const ticks = [];
  for (let v = 0; v <= max + step * 0.001; v += step) ticks.push(round2(v));
  if (ticks[ticks.length - 1] < max) ticks.push(round2(ticks[ticks.length - 1] + step));
  return ticks;
}

function showTip(html, x, y) {
  const tip = $('#chart-tip');
  tip.innerHTML = html;
  tip.hidden = false;
  const r = tip.getBoundingClientRect();
  const left = Math.min(Math.max(8, x - r.width / 2), innerWidth - r.width - 8);
  const top = y - r.height - 12 < 8 ? y + 16 : y - r.height - 12;
  tip.style.left = `${left}px`;
  tip.style.top = `${top}px`;
}
function hideTip() { const tip = $('#chart-tip'); if (tip) tip.hidden = true; }

// Colunas ou linha, desenhado à largura real do cartão (o texto nunca fica esticado).
function drawTimeChart(box, series, kind) {
  const W = Math.max(260, box.clientWidth), H = 220;
  const padL = 44, padR = 12, padT = 12, padB = 26;
  const pts = series.pts;
  const ticks = niceTicks(Math.max(0, ...pts.map(p => p.value)));
  const top = ticks[ticks.length - 1] || 1;
  const iw = W - padL - padR, ih = H - padT - padB;
  const y = v => padT + ih - Math.max(0, v) / top * ih;
  const slot = iw / pts.length;
  const cx = i => padL + slot * i + slot / 2;
  const every = Math.ceil(pts.length / Math.max(2, Math.floor(iw / 44)));
  const grid = ticks.map(v => `<line class="grid" x1="${padL}" x2="${W - padR}" y1="${y(v)}" y2="${y(v)}"/><text class="ylab" x="${padL - 6}" y="${y(v) + 4}" text-anchor="end">${compact(v)}</text>`).join('');
  const xlabs = pts.map((p, i) => (i % every === 0 ? `<text x="${cx(i)}" y="${H - 8}" text-anchor="middle">${esc(p.label)}</text>` : '')).join('');
  let marks;
  if (kind === 'line') {
    const line = pts.map((p, i) => `${i ? 'L' : 'M'}${cx(i).toFixed(1)},${y(p.value).toFixed(1)}`).join('');
    const area = `${line}L${cx(pts.length - 1).toFixed(1)},${y(0)}L${cx(0).toFixed(1)},${y(0)}Z`;
    const last = pts.length - 1;
    marks = `<path class="area" d="${area}"/><path class="line" d="${line}"/>
      <circle class="dot end" cx="${cx(last)}" cy="${y(pts[last].value)}" r="4"/>
      <line class="cross" x1="0" x2="0" y1="${padT}" y2="${y(0)}" hidden/><circle class="dot hover" r="5" hidden/>`;
  } else {
    const bw = Math.max(2, Math.min(40, slot - 2 - slot * 0.2));
    marks = pts.map((p, i) => {
      const h = y(0) - y(p.value);
      if (h <= 0) return '';
      const r = Math.min(4, bw / 2, h);
      const x0 = cx(i) - bw / 2, x1 = cx(i) + bw / 2, yb = y(0), yt = y(p.value);
      return `<path class="col" data-i="${i}" d="M${x0},${yb}V${yt + r}Q${x0},${yt} ${x0 + r},${yt}H${x1 - r}Q${x1},${yt} ${x1},${yt + r}V${yb}Z"/>`;
    }).join('');
  }
  box.innerHTML = `<svg class="chart" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" role="img" aria-label="${esc(series.title)}">
    ${grid}<line class="axis" x1="${padL}" x2="${W - padR}" y1="${y(0)}" y2="${y(0)}"/>${marks}${xlabs}
    <rect class="hit" x="${padL}" y="${padT}" width="${iw}" height="${ih}"/></svg>`;
  const svg = $('svg', box);
  const hit = $('.hit', svg);
  const pick = e => {
    const rect = svg.getBoundingClientRect();
    const i = Math.min(pts.length - 1, Math.max(0, Math.floor((e.clientX - rect.left - padL) / slot)));
    const p = pts[i];
    $$('.col', svg).forEach(c => c.classList.toggle('on', +c.dataset.i === i));
    if (kind === 'line') {
      const cr = $('.cross', svg), dot = $('.dot.hover', svg);
      cr.setAttribute('x1', cx(i)); cr.setAttribute('x2', cx(i)); cr.removeAttribute('hidden');
      dot.setAttribute('cx', cx(i)); dot.setAttribute('cy', y(p.value)); dot.removeAttribute('hidden');
    }
    showTip(`<div class="tt-label">${esc(p.tip)}</div><div class="tt-value">${money(p.value)}</div>`, rect.left + cx(i), rect.top + y(p.value));
  };
  const leave = () => {
    hideTip();
    $$('.col', svg).forEach(c => c.classList.remove('on'));
    $$('.cross, .dot.hover', svg).forEach(n => n.setAttribute('hidden', ''));
  };
  hit.addEventListener('pointermove', pick);
  hit.addEventListener('pointerdown', pick);
  hit.addEventListener('pointerleave', e => { if (e.pointerType === 'mouse') leave(); });
}

// Gráfico de rosca: parte do todo, no máximo 6 fatias (o resto junta-se em "Outros").
function donut(rows, slotOf) {
  const pos = rows.filter(r => r.value > 0).sort((a, b) => b.value - a.value);
  let segs = pos;
  if (pos.length > 6) {
    const rest = pos.slice(5).reduce((a, r) => a + r.value, 0);
    segs = [...pos.slice(0, 5), { label: t('reports.others'), value: rest, other: true }];
  }
  const total = segs.reduce((a, r) => a + r.value, 0);
  if (!total) return '';
  const R = 70, r0 = 46, C = 80;
  let ang = -Math.PI / 2;
  const pct = v => `${Math.round(v / total * 100)}%`;
  const color = s => (s.other ? 'var(--c-other)' : `var(--c${slotOf(s)})`);
  const arcs = segs.map((s, i) => {
    const a0 = ang, a1 = ang + s.value / total * Math.PI * 2;
    ang = a1;
    if (segs.length === 1) return `<circle class="slice" data-i="${i}" cx="${C}" cy="${C}" r="${(R + r0) / 2}" fill="none" stroke="${color(s)}" stroke-width="${R - r0}"/>`;
    const p = (rad, a) => `${(C + rad * Math.cos(a)).toFixed(2)},${(C + rad * Math.sin(a)).toFixed(2)}`;
    const large = a1 - a0 > Math.PI ? 1 : 0;
    return `<path class="slice" data-i="${i}" fill="${color(s)}" d="M${p(R, a0)}A${R},${R} 0 ${large} 1 ${p(R, a1)}L${p(r0, a1)}A${r0},${r0} 0 ${large} 0 ${p(r0, a0)}Z"/>`;
  }).join('');
  return `<div class="donut" data-segs='${esc(JSON.stringify(segs.map(s => ({ label: s.label, value: s.value }))))}'>
    <svg viewBox="0 0 160 160" class="donut-svg" role="img" aria-label="${esc(segs.map(s => `${s.label} ${pct(s.value)}`).join(', '))}">
      ${arcs}
      <text class="d-total" x="${C}" y="${C - 2}" text-anchor="middle">${esc(compact(total))}</text>
      <text class="d-sub" x="${C}" y="${C + 16}" text-anchor="middle">${esc(t('totals.total'))}</text>
    </svg>
    <ul class="legend">${segs.map((s, i) => `<li data-i="${i}"><span class="sw" style="background:${color(s)}"></span><span class="lg-label">${esc(s.label)}</span><span class="lg-pct">${pct(s.value)}</span><span class="lg-val num">${money(s.value)}</span></li>`).join('')}</ul>
  </div>`;
}

function wireDonuts(root) {
  $$('.donut', root).forEach(d => {
    const segs = JSON.parse(d.dataset.segs);
    const total = segs.reduce((a, s) => a + s.value, 0);
    const focus = (i, e) => {
      d.classList.toggle('focus', i != null);
      $$('.slice, .legend li', d).forEach(n => n.classList.toggle('on', +n.dataset.i === i));
      if (i == null || !e) { hideTip(); return; }
      const s = segs[i];
      showTip(`<div class="tt-label">${esc(s.label)}</div><div class="tt-value">${money(s.value)} · ${Math.round(s.value / total * 100)}%</div>`, e.clientX, e.clientY);
    };
    $$('.slice', d).forEach(n => {
      n.addEventListener('pointermove', e => focus(+n.dataset.i, e));
      n.addEventListener('pointerdown', e => focus(+n.dataset.i, e));
      n.addEventListener('pointerleave', e => { if (e.pointerType === 'mouse') focus(null); });
    });
    $$('.legend li', d).forEach(li => {
      li.addEventListener('pointerenter', () => focus(+li.dataset.i));
      li.addEventListener('pointerleave', () => focus(null));
    });
  });
}

function barList(rows) {
  const max = Math.max(1e-9, ...rows.map(r => Math.abs(r.value)));
  return `<div class="bar-list">${rows.map(r => `<div class="bl-row">
    <div class="bl-head"><span>${esc(r.label)}${r.sub ? ` <span class="muted small">${esc(r.sub)}</span>` : ''}</span><span class="num">${money(r.value)}</span></div>
    <div class="bl-track"><div class="bl-fill" style="width:${Math.max(0, r.value) / max * 100}%"></div></div></div>`).join('')}</div>`;
}

function viewReports(main) {
  const r = App.reportRange;
  const [from, to] = rangeDates();
  const rep = Store.report(from, to);
  const fin = Store.financialReport(from, to);
  const presets = ['today', 'yesterday', '7d', '30d', 'month', 'custom'];
  const allItems = Object.values(rep.byItem);
  const topItems = allItems.slice().sort((a, b) => b.net - a.net).slice(0, 10);
  // Total de todos os itens do período (não só dos 10 mostrados): coincide com as vendas líquidas.
  const itemsTotal = allItems.reduce((a, i) => ({ qty: a.qty + i.qty, net: a.net + i.net, cost: a.cost + i.cost }), { qty: 0, net: 0, cost: 0 });
  // A cor segue a categoria (pela ordem em que foram criadas), nunca a posição no ranking.
  const catOrder = Store.data.categories.map(c => c.id);
  const cats = Object.entries(rep.byCategory).map(([id, v]) => ({ id, label: (Store.find('categories', id) || { name: t('items.noCategory') }).name, value: v.net }));
  const catSlot = s => (catOrder.indexOf(s.id) < 0 ? '-none' : (catOrder.indexOf(s.id) % 6) + 1);
  const pays = Object.entries(rep.byPayment).map(([k, v]) => ({ id: k, label: payLabel(k), value: v }));
  const paySlot = s => PAY_TYPES.indexOf(s.id) + 1;
  const series = timeSeries(from, to, rep);
  const kind = App.reportChart || 'bar';
  const catDonut = donut(cats, catSlot);
  const payDonut = donut(pays, paySlot);
  const emps = Object.entries(rep.byEmployee).map(([id, v]) => ({ label: empName(id), value: v })).sort((a, b) => b.value - a.value);
  const kpi = (label, value, cls = '') => `<div class="card kpi"><div class="k-label">${esc(label)}</div><div class="k-value num ${cls}">${value}</div></div>`;
  const lowStock = Store.data.items.filter(i => i.trackStock && i.stock <= (i.lowStock || 0));
  const none = `<div class="empty">${esc(t('reports.noSales'))}</div>`;

  main.innerHTML = `
    <div class="page">
      <div class="report-head">
        <button class="btn period-btn" id="period" aria-haspopup="dialog">
          ${icon('calendar')}
          <span class="period-text">${r.preset === 'custom' ? '' : `<b>${esc(t(`reports.range.${r.preset}`))}</b>`}<span class="${r.preset === 'custom' ? '' : 'muted'}">${esc(periodDates(from, to, true))}</span></span>
          <span class="caret" aria-hidden="true">▾</span>
        </button>
        <button class="btn icon-only" id="print-report" title="${esc(t('reports.print'))}" aria-label="${esc(t('reports.print'))}">${icon('print')}</button>
        <button class="btn icon-only" id="csv" title="${esc(t('xp.title'))}" aria-label="${esc(t('xp.title'))}">${icon('download')}</button>
      </div>
      ${reportKpis(fin)}
      <div class="card card-pad" style="margin-bottom:16px">
        <div class="chart-head"><h3>${esc(series.title)}</h3>
          <div class="seg" role="group" aria-label="${esc(t('reports.chartType'))}">
            <button data-kind="bar" class="${kind === 'bar' ? 'active' : ''}" aria-pressed="${kind === 'bar'}">${esc(t('reports.chartColumns'))}</button>
            <button data-kind="line" class="${kind === 'line' ? 'active' : ''}" aria-pressed="${kind === 'line'}">${esc(t('reports.chartLine'))}</button>
          </div></div>
        <div class="chart-box" id="time-chart"></div>
      </div>
      <div class="grid-2" data-sort="rep">
        <div class="card card-pad" data-sec="top"><h3>${esc(t('reports.topItems'))}</h3>${topItems.length ? `<div class="table-wrap"><table class="table"><thead><tr><th>${esc(t('reports.item'))}</th><th class="right">${esc(t('reports.qty'))}</th><th class="right">${esc(t('reports.sales'))}</th><th class="right hide-sm cost-only">${esc(t('reports.profit'))}</th></tr></thead>
          <tbody>${topItems.map(i => `<tr><td class="wrap">${esc(i.name)}</td><td class="right">${fmtQty(round2(i.qty))}</td><td class="right num">${money(i.net)}</td><td class="right num hide-sm cost-only">${money(i.net - i.cost)}</td></tr>`).join('')}</tbody>
          <tfoot><tr class="total-row"><td class="wrap">${esc(t('totals.total'))}${allItems.length > topItems.length ? `<div class="muted small">${esc(t('reports.allItemsN', { n: allItems.length }))}</div>` : ''}</td><td class="right">${fmtQty(round2(itemsTotal.qty))}</td><td class="right num">${money(itemsTotal.net)}</td><td class="right num hide-sm cost-only">${money(itemsTotal.net - itemsTotal.cost)}</td></tr></tfoot></table></div>` : none}</div>
        <div class="card card-pad" data-sec="cat"><h3>${esc(t('reports.byCategory'))}</h3>${catDonut || none}</div>
        <div class="card card-pad" data-sec="pay"><h3>${esc(t('reports.byPayment'))}</h3>${payDonut || none}</div>
        <div class="card card-pad" data-sec="emp"><h3>${esc(t('reports.byEmployee'))}</h3>${emps.length ? barList(emps) : none}</div>
        <div class="card card-pad" data-sec="low"><h3>${esc(t('items.lowStock'))} ${lowStock.length ? `<span class="badge danger">${lowStock.length}</span>` : ''}</h3>${lowStock.length ? `<div class="stat-rows">${lowStock.map(i => `<div class="s-row"><span>${esc(i.name)}</span><span class="num">${fmtQty(i.stock)}</span></div>`).join('')}</div>` : `<div class="empty">${esc(t('reports.noLowStock'))}</div>`}</div>
      </div>
    </div>`;
  const box = $('#time-chart');
  drawTimeChart(box, series, kind);
  $$('[data-kind]', main).forEach(b => b.addEventListener('click', () => {
    App.reportChart = b.dataset.kind;
    $$('[data-kind]', main).forEach(x => { x.classList.toggle('active', x === b); x.setAttribute('aria-pressed', x === b); });
    drawTimeChart(box, series, App.reportChart);
  }));
  App.onResize = () => { if (document.body.contains(box)) drawTimeChart(box, series, App.reportChart || 'bar'); };
  wireDonuts(main);
  arrangeKpis(main, 'rep', ['stockIn', 'toDeliver', 'expenses', 'discounts', 'credit', 'stockValue']);
  arrangeSections($('[data-sort="rep"]', main), 'sec.rep');
  $('#period').addEventListener('click', () => periodModal(presets, from, to));
  $('#print-report').addEventListener('click', () => printDocument(`${t('reports.printTitle')} ${periodDates(from, to)}`,
    reportPrintHtml({ rep, fin, from, to, topItems, itemsTotal, allCount: allItems.length, cats, pays, emps, lowStock, catDonut, payDonut, chartTitle: series.title, chartSvg: printChart(series, App.reportChart || 'bar') })));
  $('#csv').addEventListener('click', () => {
    const notes = salesNotes(rep, fin, from, to);
    const sales = rep.receipts.slice().sort((a, b) => a.date.localeCompare(b.date));
    const sign = x => (x.type === 'refund' ? -x.total : x.total);
    exportModal({
      title: t('xp.salesTitle'), subtitle: periodDates(from, to), file: 'vendas', notes,
      columns: [t('receipts.no'), t('common.date'), t('receipt.customer'), t('receipts.payment'), t('totals.total')],
      numeric: [4],
      rows: sales.map(x => [receiptNo(x) + (x.type === 'refund' ? ` (${t('receipts.refundBadge')})` : ''), fmtDate(x.date), (Store.find('customers', x.customerId) || {}).name || '', payLabel(x.payment.type), round2(sign(x))]),
      totals: [t('totals.total'), '', '', '', round2(sales.reduce((a, x) => a + sign(x), 0))],
      // O PDF é o relatório completo (gráficos e tabelas) com as anotações no início.
      pdfHtml: n => reportPrintHtml({ rep, fin, from, to, topItems, itemsTotal, allCount: allItems.length, cats, pays, emps, lowStock, catDonut, payDonut, chartTitle: series.title, chartSvg: printChart(series, App.reportChart || 'bar'), notes: n }),
    });
  });
}

// ================= Funcionários =================

function viewEmployees(main) {
  if (App.empOpen && Store.find('employees', App.empOpen)) { employeePage(main, Store.find('employees', App.empOpen)); return; }
  App.empOpen = null;
  const list = Store.data.employees;
  const total = PERM_KEYS.length;
  const sub = e => {
    if (e.role === 'owner') return t('perm.ownerAll');
    const n = PERM_KEYS.filter(k => can(k, e)).length;
    const al = ['alStock', 'alCredit', 'alCount', 'alCost', 'alIdle'].filter(k => can(k, e));
    return [t('perm.nOf', { n, total }), al.length === 5 ? t('perm.allAlerts') : al.length ? t('perm.someAlerts', { list: al.map(k => t(`perm.short.${k}`)).join(', ') }) : t('perm.noAlerts')].join(' · ');
  };
  main.innerHTML = `<div class="page emp-page">
    <div class="sx-gt">${esc(t('nav.employees'))} · ${list.length}</div>
    <div class="sx-list">${list.map(e => `<button type="button" class="sx-row" data-id="${e.id}">
      <span class="emp-av" style="background:${e.role === 'owner' ? 'var(--primary-dark)' : Chat.color(e.id)}">${esc((e.name || '?').trim().charAt(0).toUpperCase())}</span>
      <span class="sx-t"><b>${esc(e.name)}${e.id === App.user.id ? ` <span class="badge grey">${esc(t('employees.you'))}</span>` : ''}</b><small>${esc(sub(e))}</small></span>
      <span class="role-b ${e.role === 'owner' ? 'own' : ''}">${esc(roleName(e))}</span></button>`).join('')}</div>
    <button class="btn primary emp-add" id="new" type="button">＋ ${esc(t('employees.add'))}</button>
  </div>`;
  $('#new').addEventListener('click', () => employeeFormModal(null));
  $$('[data-id]', main).forEach(b => b.addEventListener('click', () => { App.empOpen = b.dataset.id; render(); }));
}

// Página de um funcionário: nome e PIN, função e cada permissão.
function employeePage(main, e) {
  App.back = { title: e.name, fn: () => { App.empOpen = null; render(); } };
  const owner = e.role === 'owner';
  // Um só "Vendedor": o principal (acesso a tudo) e os outros vendedores diferem nas permissões.
  const preset = owner ? 'seller' : isCustom(e) ? 'custom' : e.role === 'cashier' ? 'seller' : e.role;
  const seg = [['seller', 'role.cashier'], ['manager', 'role.manager'], ['supplier', 'role.supplier'], ['custom', 'role.custom']];
  const tg = on => `<span class="tg ${on ? 'on' : ''}"><i></i></span>`;
  const sales = Store.data.receipts.filter(r => r.employeeId === e.id).reduce((a, r) => a + (r.type === 'refund' ? -r.total : r.total), 0);
  main.innerHTML = `<div class="page emp-page">
    <div class="sx-list"><button type="button" class="sx-row" id="emp-edit">
      <span class="emp-av big" style="background:${owner ? 'var(--primary-dark)' : Chat.color(e.id)}">${esc((e.name || '?').trim().charAt(0).toUpperCase())}</span>
      <span class="sx-t"><b class="emp-name">${esc(e.name)}</b><small>${esc(t('perm.pinSales', { sales: money(sales) }))}</small></span><span class="emp-link">${esc(t('common.edit'))}</span></button></div>
    <div class="sx-gt">${esc(t('employees.role'))}</div>
    <div class="seg4">${seg.map(([k, l]) => `<button type="button" data-preset="${k}" class="${preset === k ? 'on' : ''}">${esc(t(l))}</button>`).join('')}</div>
    ${preset === 'custom' ? `<div class="sx-list" style="margin-top:8px"><button type="button" class="sx-row" id="emp-rname"><span class="sx-t"><b>${esc(t('role.customName'))}</b><small>${esc(e.customName || t('role.customNameHint'))}</small></span><span class="emp-link">${esc(t('common.edit'))}</span></button></div>` : ''}
    ${owner ? `<p class="muted small emp-note">${esc(t('perm.ownerNote'))}</p>` : PERM_GROUPS.map(([g, keys]) => `<div class="sx-gt">${esc(t(g))}</div><div class="sx-list">${keys.map(([k, ic, col]) => {
      const always = PERM_ALWAYS.includes(k);
      const sub = always ? t('perm.always') : t(`perm.sub.${k}`) === `perm.sub.${k}` ? '' : t(`perm.sub.${k}`);
      return `<button type="button" class="sx-row ${always ? 'ro' : ''}" data-perm="${k}"><span class="sx-ic" style="background:${col}">${icon(ic)}</span>
        <span class="sx-t"><b>${esc(t(`perm.${k}`))}</b>${sub ? `<small>${esc(sub)}</small>` : ''}</span>${tg(can(k, e))}</button>`;
    }).join('')}</div>`).join('')}
    ${e.id === App.user.id ? '' : `<button type="button" class="btn emp-del" id="emp-del">${esc(t('perm.delete'))}</button>`}
  </div>`;
  // Guarda sem saltar para o topo; ao ligar/desligar uma permissão só muda o interruptor (sem redesenhar).
  const save = (data, quiet = false) => {
    const y = main.scrollTop;
    const saved = Store.upsert('employees', Object.assign({}, e, data));
    Object.assign(e, saved);
    if (saved.id === App.user.id) { App.user = saved; if (!quiet) renderShell(); }
    if (quiet) return;
    render(); main.scrollTop = y;
  };
  $$('[data-preset]', main).forEach(b => b.addEventListener('click', () => {
    const k = b.dataset.preset;
    if (k === preset) return;
    if (k === 'seller' && owner) return;
    const owners = Store.data.employees.filter(x => x.role === 'owner' && x.id !== e.id);
    if (owner && !owners.length) { toast(t('employees.needOwner'), true); return; }
    if (k === 'custom') {
      save({ role: owner ? 'cashier' : e.role, custom: true, perms: Object.fromEntries(PERM_KEYS.map(p => [p, can(p, e)])) });
      fieldModal({ title: t('role.customName'), value: e.customName || '', onSave: v => save({ custom: true, customName: String(v || '').trim().slice(0, 24) }) });
      return;
    }
    else save({ role: k === 'seller' ? 'cashier' : k, custom: false, perms: null });
  }));
  $$('[data-perm]', main).forEach(b => b.addEventListener('click', () => {
    const k = b.dataset.perm;
    if (PERM_ALWAYS.includes(k)) return;
    const perms = Object.assign(Object.fromEntries(PERM_KEYS.map(p => [p, can(p, e)])), e.perms || {});
    perms[k] = !can(k, e);
    save({ perms, custom: true }, true);
    const tgEl = b.querySelector('.tg');
    if (tgEl) tgEl.classList.toggle('on', can(k, e));
    const seg = main.querySelector('[data-preset].on');
    if (seg && seg.dataset.preset !== 'custom') { seg.classList.remove('on'); const c = main.querySelector('[data-preset="custom"]'); if (c) c.classList.add('on'); }
  }));
  $('#emp-edit', main).addEventListener('click', () => employeeFormModal(e));
  const rn = $('#emp-rname', main);
  if (rn) rn.addEventListener('click', () => fieldModal({ title: t('role.customName'), value: e.customName || '', onSave: v => save({ custom: true, customName: String(v || '').trim().slice(0, 24) }) }));
  const del = $('#emp-del', main);
  if (del) del.addEventListener('click', async () => {
    if (owner && Store.data.employees.filter(x => x.role === 'owner').length < 2) { toast(t('employees.cantDeleteOwner'), true); return; }
    if (!await confirmDialog(t('common.deleteConfirm', { name: e.name }), t('common.delete'), true)) return;
    Store.remove('employees', e.id); App.empOpen = null; render();
  });
}

// Nome e PIN (novo funcionário: também a função; depois abre a página dele).
function employeeFormModal(emp) {
  const isNew = !emp;
  const e = emp || { name: '', pin: '', role: 'cashier' };
  let role = e.role;
  const m = openModal({
    title: isNew ? t('employees.newTitle') : t('employees.editTitle'),
    body: `<form id="ef">
      <div class="row">
        <label class="field"><span>${esc(t('common.name'))} *</span><input class="input" name="name" required value="${esc(e.name)}"></label>
        <label class="field"><span>${esc(t('employees.pin'))} *</span><input class="input" name="pin" inputmode="numeric" maxlength="4" pattern="\\d{4}" value="${esc(e.pin)}"></label>
      </div>
      ${isNew ? `<h4 class="pick-sec">${esc(t('employees.role'))}</h4><div class="chip-row">${['cashier', 'manager', 'supplier'].map(k => `<button type="button" class="chip ${k === role ? 'on' : ''}" data-r="${k}">${esc(roleLabel(k))}</button>`).join('')}</div>
      <p class="muted small" style="margin:8px 0 0">${esc(t('perm.newHint'))}</p>` : ''}
    </form>`,
    footer: `<button class="btn primary" data-ok>${esc(t('common.save'))}</button>`,
  });
  const form = $('#ef', m);
  $$('[data-r]', m).forEach(b => b.addEventListener('click', () => { role = b.dataset.r; $$('[data-r]', m).forEach(x => x.classList.toggle('on', x === b)); }));
  const ok = () => {
    const f = formObj(form);
    if (!f.name.trim()) return toast(t('common.needName'), true);
    if (!/^\d{4}$/.test(f.pin)) return toast(t('employees.pinInvalid'), true);
    if (Store.data.employees.some(x => x.id !== e.id && x.pin === f.pin)) return toast(t('employees.pinTaken'), true);
    const saved = Store.upsert('employees', Object.assign({}, e, { name: f.name.trim(), pin: f.pin, role }));
    if (saved.id === App.user.id) { App.user = saved; renderShell(); }
    closeModal();
    if (isNew) App.empOpen = saved.id;
    render(); toast(t('employees.saved'));
    return undefined;
  };
  $('[data-ok]', m).onclick = ok;
  form.addEventListener('submit', ev => { ev.preventDefault(); ok(); });
}

// ================= Definições =================

function defaultServerUrl() {
  if (Printer.available()) return '';
  return /^https?:$/.test(location.protocol) ? location.origin : '';
}

const GOOGLE_G = '<svg class="g-logo" viewBox="0 0 48 48" aria-hidden="true"><path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3C33.7 32.7 29.2 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.8 1.2 7.9 3.1l5.7-5.7C34 6.1 29.3 4 24 4 12.9 4 4 12.9 4 24s8.9 20 20 20 20-8.9 20-20c0-1.3-.1-2.6-.4-3.5z"/><path fill="#FF3D00" d="m6.3 14.7 6.6 4.8C14.7 15.1 19 12 24 12c3.1 0 5.8 1.2 7.9 3.1l5.7-5.7C34 6.1 29.3 4 24 4 16.3 4 9.7 8.3 6.3 14.7z"/><path fill="#4CAF50" d="M24 44c5.2 0 9.9-2 13.4-5.2l-6.2-5.2C29.2 35.1 26.7 36 24 36c-5.2 0-9.6-3.3-11.3-8l-6.5 5C9.5 39.6 16.2 44 24 44z"/><path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3c-.8 2.2-2.2 4.2-4.1 5.6l6.2 5.2C37 39.2 44 34 44 24c0-1.3-.1-2.6-.4-3.5z"/></svg>';
// Força da senha: 0 a 3 tracinhos.
function pwStrength(v) { if (!v) return 0; if (v.length < 6) return 1; return Math.min(3, 1 + (v.length >= 10) + (/\d/.test(v) && /[a-zA-Z]/.test(v))); }
function cloudCard() {
  const hero = title => `<div class="cx-hero"><div class="cx-logo">${icon('cloud')}</div><h2>${esc(title)}</h2><p>${esc(t('cloud.hero'))}</p></div>`;
  const trust = Sync.usesFirebase() ? `<div class="cx-trust">${icon('shield')}${esc(t('cloud.trust'))}</div>` : '';
  if (Sync.enabled()) {
    const st = Sync.state;
    const s = Sync.status, pending = Sync.pendingCount();
    const bad = s === 'offline' || s === 'error';
    const label = s === 'syncing' ? t('cloud.syncing') : bad ? t(s === 'offline' ? 'cloud.offline' : 'cloud.error') : pending ? t('cloud.pending', { n: pending }) : t('cloud.synced');
    const who = st.storeName || Store.settings.storeName || st.email;
    const av = st.photo ? `<img src="${esc(st.photo)}" alt="" referrerpolicy="no-referrer">` : esc((who || '?').trim().charAt(0).toUpperCase());
    const needPw = st.fb && st.google && FB.auth && FB.auth.currentUser && !Sync.hasPassword();
    return `<div class="cx" id="cloud-card">${hero(t('cloud.linked'))}<div class="cx-card">
      <div class="cx-acc"><div class="cx-av">${av}${st.google ? `<i>${GOOGLE_G}</i>` : ''}</div><div><b>${esc(who)}</b><small>${esc(st.email)}</small></div></div>
      <div class="cx-ok ${bad ? 'warn' : ''}"><i></i>${esc(label)}${st.lastSync && !bad && s !== 'syncing' ? ` · ${esc(fmtDate(st.lastSync))}` : ''}</div>
      ${st.lastError && bad ? `<p class="small neg-val" style="margin:6px 2px 0">${esc(t(st.lastError))}</p>` : ''}
      <div class="cx-row"><span>${esc(t('cloud.thisDevice'))}</span><span>${esc(t('cloud.deviceN', { n: st.deviceNo || '—' }))}</span></div>
      <div class="cx-row"><span>${esc(t('cloud.pendingRow'))}</span><span>${pending}</span></div>
      ${!st.fb ? `<div class="cx-row"><span>${esc(t('cloud.server'))}</span><span class="small">${esc(st.url)}</span></div>` : ''}
      ${st.member ? `<div class="cx-row"><span>${esc(t('inv.access'))}</span><span>${esc(t('inv.byCode'))}</span></div>` : ''}
      ${needPw ? `<div class="cx-pw"><b>${esc(t('cloud.setPw'))}</b><small>${esc(t('cloud.setPwHint', { email: st.email }))}</small><button class="btn" id="cl-setpw" type="button">${icon('lock')} ${esc(t('cloud.setPwBtn'))}</button></div>` : ''}
      <div class="cx-btns"><button class="btn primary" id="cl-sync" type="button">${esc(t('cloud.syncNow'))}</button><button class="btn cx-out" id="cl-out" type="button">${esc(t('cloud.logout'))}</button></div>
    </div>
    ${st.fb ? `<div class="iv-h">${esc(t('inv.devices'))}</div><div class="cx-card iv-list" id="cl-devs"><p class="muted small" style="margin:6px 0">…</p></div>
      ${st.member ? '' : `<button class="cx-main" id="cl-invite" type="button">＋ ${esc(t('inv.invite'))}</button><p class="cx-note">${esc(t('inv.hint'))}</p>`}` : ''}
    ${trust}</div>`;
  }
  const reg = App.cloudTab === 'register';
  const google = Sync.usesFirebase() ? `<button class="cx-g" id="cl-google" type="button">${GOOGLE_G}<span>${esc(t(reg ? 'cloud.googleNew' : 'cloud.google'))}</span></button><div class="cx-or">${esc(t('cloud.orEmail'))}</div>` : '';
  return `<div class="cx">${hero(t('cloud.title'))}<form class="cx-card" id="cloud-card" novalidate>
    <div class="cx-seg" role="tablist"><button type="button" data-tab="login" class="${reg ? '' : 'on'}">${esc(t('cloud.login'))}</button><button type="button" data-tab="register" class="${reg ? 'on' : ''}">${esc(t('cloud.register'))}</button></div>
    ${google}
    ${Sync.usesFirebase() ? '<input type="hidden" name="url" id="cl-url" value="firebase">' : `<label class="field"><span>${esc(t('cloud.server'))}</span><input class="input" name="url" id="cl-url" type="url" placeholder="https://stoi-pos.up.railway.app" value="${esc(defaultServerUrl())}" required>
      <small class="muted field-hint">${esc(t('cloud.serverHint'))}</small></label>`}
    <label class="cx-lbl" for="cl-email">${esc(t(reg ? 'cloud.storeEmail' : 'common.email'))}</label>
    <div class="cx-f">${icon('mail')}<input name="email" id="cl-email" type="email" inputmode="email" autocomplete="username" placeholder="${esc(t('cloud.emailPh'))}" required></div>
    <label class="cx-lbl" for="cl-pass">${esc(t(reg ? 'cloud.pwMin' : 'cloud.password'))}</label>
    <div class="cx-f">${icon('lock')}<input name="password" id="cl-pass" type="password" autocomplete="${reg ? 'new-password' : 'current-password'}" minlength="6" required><button type="button" class="cx-eye" id="cl-eye" aria-label="${esc(t('cloud.showPw'))}">${icon('eye')}</button></div>
    ${reg ? '<div class="cx-str" id="cl-str"><i></i><i></i><i></i></div>' : Sync.usesFirebase() ? `<button type="button" class="cx-forgot" id="cl-forgot">${esc(t('cloud.forgot'))}</button>` : ''}
    <button class="cx-main" type="submit">${esc(t(reg ? 'cloud.registerBtn' : 'cloud.login'))}</button>
    <p class="cx-note">${esc(t(reg ? 'cloud.noteRegister' : 'cloud.noteLogin'))}</p>
    ${Sync.usesFirebase() && !reg ? `<button type="button" class="cx-code" id="cl-code">${icon('phone')}<span><b>${esc(t('inv.haveCode'))}</b><small>${esc(t('inv.haveCodeSub'))}</small></span>${icon('chevron')}</button>` : ''}
  </form>${trust}</div>`;
}

function printerCard() {
  if (!Printer.available()) {
    return `<div class="card card-pad"><h3>${esc(t('printer.title'))}</h3><p class="muted small">${esc(t('printer.onlyApp'))}</p></div>`;
  }
  const pr = Device.conf.printer || { width: 32, auto: false };
  return `<div class="card card-pad" id="printer-card">
    <h3>${esc(t('printer.title'))}</h3>
    <p class="muted small">${esc(t('printer.pairHint'))}</p>
    <label class="field"><span>${esc(t('printer.device'))}</span>
      <select class="input" id="pr-dev"><option value="">${esc(pr.name || t('printer.choose'))}</option></select></label>
    <p class="muted small printer-status" id="pr-status" hidden></p>
    <button class="btn small" id="pr-scan" type="button" style="margin:-6px 0 14px">${esc(t('printer.refresh'))}</button>
    <label class="field"><span>${esc(t('printer.paper'))}</span>
      <select class="input" id="pr-width"><option value="32" ${pr.width !== 48 ? 'selected' : ''}>58 mm</option><option value="48" ${pr.width === 48 ? 'selected' : ''}>80 mm</option></select></label>
    <label class="check"><input type="checkbox" id="pr-auto" ${pr.auto ? 'checked' : ''}> ${esc(t('printer.auto'))}</label>
    <div style="display:flex;gap:8px;flex-wrap:wrap">
      <button class="btn primary" id="pr-save" type="button">${esc(t('common.save'))}</button>
      <button class="btn" id="pr-test" type="button">${esc(t('printer.test'))}</button>
    </div>
  </div>`;
}

// Secções das Configurações (lista com resumo; cada uma abre a sua página).
const SET_GROUPS = [
  ['set.gStore', ['store', 'sales', 'alerts']],
  ['set.gLook', ['look', 'icons']],
  ['set.gData', ['cloud', 'chatfiles', 'data', 'updates']],
];
const SET_ICON = { alerts: ['bell', '#ea580c'], store: ['cart', '#2e7d32'], sales: ['cash', '#1d4ed8'], look: ['text', '#7c3aed'], icons: ['image', '#ea580c'], products: ['layers', '#0891b2'], terms: ['edit', '#db2777'], cloud: ['cloud', '#0284c7'], chatfiles: ['image', '#0891b2'], printer: ['print', '#475569'], data: ['download', '#b91c1c'], updates: ['refresh', '#16a34a'] };
function setSummary(k) {
  const s = Store.settings;
  const cats = byLayout(Store.data.categories, 'order.cats');
  const links = Store.data.items.filter(i => i.opensInto).length;
  const pr = Device.conf.printer;
  switch (k) {
    case 'store': return [s.storeName, s.phone || s.address].filter(Boolean).join(' · ') || t('set.sum.store');
    case 'sales': return [(CURRENCIES[s.currency] || {}).label, t('set.sum.tax', { n: s.taxRate }), s.consignment ? t('set.sum.consign') : '', Store.showCost() ? t('set.sum.cost') : ''].filter(Boolean).join(' · ');
    case 'look': return [t(`settings.fs.${Layout.get('fontSize') || 's'}`), LANGS[getLang()] || getLang(), validCats(s.tagCats).filter(c => c !== 'none').length ? catLabel(validCats(s.tagCats), true) : t('tag.auto')].join(' · ');
    case 'icons': return cats.length ? cats.slice(0, 3).map(c => c.name).join(', ') + (cats.length > 3 ? '…' : '') : t('items.noCategory');
    case 'products': return [validCats(s.tagCats).filter(c => c !== 'none').length ? catLabel(validCats(s.tagCats), true) : t('tag.auto'), t('set.sum.links', { n: links })].join(' · ');
    case 'alerts': return alertsSummary();
    case 'chatfiles': return chatFilesSummary();
    case 'terms': return termCount() ? t('set.sum.terms', { n: termCount() }) : t('set.sum.noTerms');
    case 'cloud': return Sync.enabled() ? [t('cloud.connected'), (Sync.state || {}).email].filter(Boolean).join(' · ') : t('set.sum.cloudOff');
    case 'printer': return !Printer.available() ? t('set.sum.printerApp') : pr && pr.address ? [pr.name || pr.address, pr.width === 48 ? '80 mm' : '58 mm'].join(' · ') : t('set.sum.printerNone');
    case 'updates': return [Upd.cur, t(Upd.auto() ? 'upd.sumOn' : 'upd.sumOff')].join(' · ');
    default: return t('set.sum.data');
  }
}

// Linhas das Configurações (estilo lista): título, descrição e, à direita, valor, interruptor ou seta.
const setVal = v => `${v ? `<span class="set-v">${esc(v)}</span>` : ''}<span class="sx-ch">${icon('chevron')}</span>`;
const setTg = on => `<span class="tg ${on ? 'on' : ''}"><i></i></span>`;
function setRow(k, title, sub, right, cls = '') {
  return `<button type="button" class="sx-row set-row ${cls}" data-setk="${k}"><span class="sx-t"><b>${esc(title)}</b>${sub ? `<small>${esc(sub)}</small>` : ''}</span>${right}</button>`;
}
// Janela pequena para mudar um valor (texto ou número).
function fieldModal({ title, value, multi = false, numeric = false, suffix = '', onSave }) {
  const m = openModal({ title, body: `<label class="field fm-field">${multi ? `<textarea class="input" id="fm-v" rows="3">${esc(value)}</textarea>` : `<input class="input" id="fm-v" ${numeric ? 'inputmode="decimal"' : ''} value="${esc(value)}">`}${suffix ? `<span class="fm-suf">${esc(suffix)}</span>` : ''}</label>`,
    footer: `<button class="btn primary" data-ok>${esc(t('common.save'))}</button>` });
  const ok = () => { const v = $('#fm-v', m).value; closeModal(); onSave(v); };
  $('[data-ok]', m).onclick = ok;
  if (!multi) $('#fm-v', m).addEventListener('keydown', e => { if (e.key === 'Enter') ok(); });
}
// Escolher uma opção de uma lista.
function choiceModal({ title, value, options, onPick }) {
  const m = openModal({ title, autofocus: false, body: `<div class="sx-list">${options.map(([k, l]) => `<button type="button" class="sx-row" data-v="${esc(k)}"><span class="sx-t"><b>${esc(l)}</b></span>${k === value ? `<span class="set-ok">${icon('check')}</span>` : ''}</button>`).join('')}</div>` });
  $$('[data-v]', m).forEach(b => b.addEventListener('click', () => { closeModal(); if (b.dataset.v !== value) onPick(b.dataset.v); }));
}
function viewSettings(main) {
  const s = Store.settings;
  if (App.setSec === 'products' || App.setSec === 'terms') App.setSec = 'look';
  if (App.setSec === 'printer') App.setSec = 'data';
  const sec = Object.keys(SET_ICON).includes(App.setSec) ? App.setSec : null;
  const row = k => `<button type="button" class="sx-row" data-sec-open="${k}"><span class="sx-ic" style="background:${SET_ICON[k][1]}">${icon(SET_ICON[k][0])}</span>
    <span class="sx-t"><b>${esc(t(`set.sec.${k}`))}</b><small>${esc(setSummary(k))}</small></span><span class="sx-ch">${icon('chevron')}</span></button>`;
  main.innerHTML = `
    <div class="page set-page ${sec ? 'set-open' : 'set-home'}">
      ${sec ? '' : `
      <div class="sx-prof"><div class="sx-av">${esc(initials(s.storeName || 'Stoi'))}</div><div class="sx-t"><b>${esc(s.storeName || 'Stoi')}</b><small>${esc(App.user.name)} · ${esc(roleLabel(App.user.role))}</small></div></div>
      ${SET_GROUPS.map(([g, keys]) => `<div class="sx-gt">${esc(t(g))}</div><div class="sx-list">${keys.filter(k => k !== 'updates' || (typeof Upd !== 'undefined' && Upd.plugin())).map(row).join('')}</div>`).join('')}`}
      <div class="set-detail sx-detail">
        <div data-set="store">
          <div class="sx-gt">${esc(t('set.gStoreName'))}</div><div class="sx-list">
            ${setRow('storeName', t('settings.storeName'), '', setVal(s.storeName))}
            ${setRow('address', t('settings.address'), '', setVal(s.address || '—'))}
            ${setRow('phone', t('common.phone'), '', setVal(s.phone || '—'))}</div>
          <div class="sx-gt">${esc(t('set.gReceipt'))}</div><div class="sx-list">
            ${setRow('receiptFooter', t('settings.receiptFooter'), s.receiptFooter || t('receipt.thanks'), setVal(''))}</div>
          <p class="muted small set-note">${esc(t('set.autoSaved'))}</p>
        </div>
        <div data-set="sales">
          <div class="sx-gt">${esc(t('set.gMoney'))}</div><div class="sx-list">
            ${setRow('currency', t('settings.currency'), '', setVal((CURRENCIES[s.currency] || {}).label || s.currency))}
            ${setRow('taxRate', t('set.tax'), '', setVal(`${s.taxRate || 0} %`))}
            ${setRow('taxMode', t('settings.taxMode'), '', setVal(t(s.taxMode === 'added' ? 'settings.taxAdded' : 'settings.taxIncluded')))}
            ${setRow('loyaltyRate', t('set.loyalty'), t('set.loyaltySub'), setVal(`${s.loyaltyRate || 0} %`))}</div>
          <div class="sx-gt">${esc(t('set.gShiftCost'))}</div><div class="sx-list">
            ${setRow('useShifts', t('settings.requireShift'), '', setTg(s.useShifts))}
            ${setRow('showCost', t('set.showCost'), t('set.showCostSub'), setTg(Store.showCost()))}
            ${setRow('consignment', t('set.consign'), t('set.consignSub'), setTg(s.consignment))}</div>
        </div>
        <div data-set="look">
          <div class="sx-gt">${esc(t('settings.fontSize'))}</div><div class="sx-list"><div class="fs-opts sx-fs">${FONT_SIZES.map(([k, f]) => `<button type="button" class="btn ${(Layout.get('fontSize') || 's') === k ? 'active' : ''}" data-fs="${k}"><b style="font-size:${Math.round(16 * f)}px">A</b><small>${esc(t(`settings.fs.${k}`))}</small></button>`).join('')}</div></div>
          <div class="sx-gt">${esc(t('settings.language'))}</div><div class="sx-list">
            ${setRow('lang', t('settings.language'), t('set.langSub'), setVal(LANGS[getLang()] || getLang()))}</div>
          <div class="sx-gt">${esc(t('set.gProducts'))}</div><div class="sx-list">
            ${setRow('tagCats', t('tag.title'), t('set.tagSub'), setVal(validCats(s.tagCats).filter(c => c !== 'none').length ? catLabel(validCats(s.tagCats), true) : t('tag.auto')))}
            ${setRow('packLinks', t('pack.title'), t('set.packSub'), setVal(t('set.nLinks', { n: Store.data.items.filter(i => i.opensInto).length })))}
            ${setRow('terms', t('terms.title'), t('set.termsSub'), setVal(termCount() ? t('set.sum.terms', { n: termCount() }) : t('set.none')))}</div>
        </div>
        <div class="card card-pad" data-set="icons">
          <h3>${esc(t('picon.catTitle'))}</h3>
          <p class="muted small">${esc(t('picon.catHint'))}</p>
          <div class="cat-icons">${Store.data.categories.length ? byLayout(Store.data.categories, 'order.cats').map(c => `<button type="button" class="cat-icon-row" data-cat-icon="${c.id}"></button>`).join('') : `<p class="muted small">${esc(t('categories.none'))}</p>`}</div>
        </div>
        <div data-set="alerts">${alertsSettingsHtml()}</div>
        <div data-set="cloud">${cloudCard()}</div>
        <div data-set="chatfiles">${chatFilesSettingsHtml()}</div>
        ${typeof Upd !== 'undefined' && Upd.plugin() ? `<div data-set="updates"><div class="sx-list">
            <label class="sx-row set-row"><span class="sx-t"><b>${esc(t('upd.auto'))}</b><small>${esc(t('upd.autoSub'))}</small></span><input type="checkbox" class="sw-in" id="upd-auto" ${Upd.auto() ? 'checked' : ''}></label>
            ${setRow('updCheck', t('upd.version'), [Upd.cur, Upd.versionSub()].filter(Boolean).join(' · '), `<span class="set-v upd-link">${esc(t('upd.check'))}</span>`)}
            ${setRow('updNotes', t('upd.notes'), '', setVal(''))}</div>
          <div class="sx-gt">${esc(t('upd.devTitle'))}</div><div class="sx-list">
            ${(() => { const d = Upd.device(); return `<div class="sx-row dev-grid"><span>${esc(t('upd.devModel'))}</span><b>${esc(d.model)}</b><span>Android</span><b>${esc(d.android)}</b><span>WebView</span><b>${esc(d.webview)}</b><span>${esc(t('upd.devApp'))}</span><b>${esc(d.app)}${d.apk ? ` · APK ${esc(String(d.apk))}` : ''}</b><span>${esc(t('upd.devScreen'))}</span><b>${esc(d.screen)}</b></div>`; })()}
            ${setRow('updCopyDev', t('upd.devCopy'), t('upd.devCopySub'), `<span class="sx-ch dev-copy">${icon('copy')}</span>`)}</div></div>` : ''}
        <div data-set="data">
          <div class="sx-gt">${esc(t('settings.backup'))}</div><div class="sx-list">
            ${setRow('export', t('settings.export'), t('set.exportSub'), setVal(''))}
            <label class="sx-row set-row">${'<span class="sx-t"><b>'}${esc(t('settings.import'))}</b><small>${esc(t('set.importSub'))}</small></span>${setVal('')}<input type="file" id="bk-imp" accept="application/json,.json" hidden></label></div>
          <div class="sx-gt">${esc(t('set.sec.printer'))}</div>
          <div class="set-printer">${printerCard()}</div>
          <div class="sx-gt">${esc(t('settings.reset'))}</div><div class="sx-list">
            ${setRow('rs-empty', t('settings.eraseAll'), t('set.eraseSub'), '', 'red')}
            ${setRow('rs-demo', t('settings.restoreDemo'), '', '', 'red')}</div>
        </div>
      </div>
    </div>`;
  // Mostra só os cartões (e partes do formulário) da secção aberta.
  $$('[data-set]', main).forEach(el => { el.hidden = !sec || !el.dataset.set.split(' ').includes(sec); });
  $$('[data-part]', main).forEach(el => { el.hidden = el.dataset.part !== sec; });
  // Título repetido: quando a secção tem um só cartão, o cabeçalho da página já diz o nome.
  const shown = $$('[data-set]', main).filter(el => !el.hidden);
  if (sec && shown.length === 1 && !['cloud', 'printer', 'alerts', 'store', 'sales', 'look', 'data', 'chatfiles'].includes(sec)) shown[0].classList.add('set-solo');
  $$('[data-sec-open]', main).forEach(b => b.addEventListener('click', () => { App.setSec = b.dataset.secOpen; render(); scrollTo(0, 0); }));
  if (sec) setBack(t(`set.sec.${sec}`), () => { App.setSec = null; render(); });
  // Cada linha guarda logo: texto e números numa janela pequena; interruptores mudam ao tocar.
  const save = patch => { Object.assign(s, patch); Store.save(); moneyFmt = null; renderShell(); render(); toast(t('settings.saved')); };
  const text = (k, title, multi) => fieldModal({ title, value: s[k] || '', multi, onSave: v => save({ [k]: k === 'storeName' ? (v.trim() || 'Stoi') : v.trim() }) });
  const pct = (k, title) => fieldModal({ title, value: String(s[k] || 0), numeric: true, suffix: '%', onSave: v => save({ [k]: Math.max(0, num(v)) }) });
  const acts = {
    storeName: () => text('storeName', t('settings.storeName')),
    address: () => text('address', t('settings.address')),
    phone: () => text('phone', t('common.phone')),
    receiptFooter: () => text('receiptFooter', t('settings.receiptFooter'), true),
    currency: () => choiceModal({ title: t('settings.currency'), value: s.currency, options: Object.entries(CURRENCIES).map(([k, v]) => [k, v.label]), onPick: v => save({ currency: v }) }),
    taxRate: () => pct('taxRate', t('set.tax')),
    taxMode: () => choiceModal({ title: t('settings.taxMode'), value: s.taxMode === 'added' ? 'added' : 'included', options: [['included', t('settings.taxIncluded')], ['added', t('settings.taxAdded')]], onPick: v => save({ taxMode: v }) }),
    loyaltyRate: () => pct('loyaltyRate', t('set.loyalty')),
    useShifts: () => save({ useShifts: !s.useShifts }),
    showCost: () => save({ showCost: !Store.showCost() }),
    consignment: () => save({ consignment: !s.consignment }),
    lang: () => choiceModal({ title: t('settings.language'), value: getLang(), options: Object.entries(LANGS), onPick: v => { setLang(v); renderShell(); render(); } }),
    tagCats: () => multiPickModal({ title: t('tag.title'), allLabel: t('tag.auto'), options: catOptions(false), selected: validCats(s.tagCats), onApply: v => save({ tagCats: v }) }),
    packLinks: () => packLinksModal(),
    terms: () => termsModal(),
    export: () => download(`stoi-backup-${dayKey(new Date())}.json`, JSON.stringify(Store.data, null, 2), 'application/json'),
  };
  acts.updCheck = () => Upd.check(true);
  acts.updNotes = () => Upd.notesModal();
  acts.updCopyDev = async () => { const ok = typeof copyText === 'function' ? await copyText(Upd.deviceText()) : false; toast(ok ? t('upd.devCopied') : t('err.server'), !ok); };
  const ua = $('#upd-auto', main);
  if (ua) ua.addEventListener('change', () => Upd.setAuto(ua.checked));
  $$('[data-setk]', main).forEach(r => r.addEventListener('click', () => { const f = acts[r.dataset.setk]; if (f) f(); }));
  $$('[data-fs]', main).forEach(b => b.addEventListener('click', () => { Layout.set('fontSize', b.dataset.fs); applyFontSize(); render(); }));
  wireAlertsSettings(main);
  wireChatFilesSettings(main);
  // Ícones das categorias: cada linha mostra o ícone atual; tocar abre a escolha.
  const paintCatIcon = row => {
    const c = Store.find('categories', row.dataset.catIcon);
    if (!c) return;
    const k = c.icon && PICONS[c.icon] ? c.icon : guessIcon({ name: '' }, c);
    row.innerHTML = `<span class="cat-ic" style="color:${esc(c.color || '#64748b')}">${PICONS[k]()}</span><span class="grow"><b>${esc(c.name)}</b><small>${esc(c.icon ? t(`picon.${c.icon}`) : `${t('picon.auto')} · ${t(`picon.${k}`)}`)}</small></span><span class="chev">›</span>`;
  };
  $$('[data-cat-icon]', main).forEach(row => {
    paintCatIcon(row);
    row.addEventListener('click', () => {
      const c = Store.find('categories', row.dataset.catIcon);
      if (!c) return;
      iconPickerModal({
        title: t('picon.forCat', { cat: c.name }), current: c.icon || '', color: c.color || '#64748b',
        autoLabel: t('picon.auto'), autoKey: guessIcon({ name: '' }, c),
        onPick: k => { Store.upsert('categories', { id: c.id, icon: k || null }); paintCatIcon(row); toast(t('picon.saved')); },
      });
    });
  });
  wireCloud();
  wirePrinter();
  $('#bk-imp').addEventListener('change', async e => {
    const file = e.target.files[0];
    if (!file) return;
    try {
      const data = JSON.parse(await file.text());
      if (!data || !Array.isArray(data.items) || !Array.isArray(data.employees)) throw new Error(t('settings.invalidFile'));
      if (!await confirmDialog(t('settings.importConfirm'), t('settings.import'), true)) return;
      if (Sync.enabled()) Sync.logout();
      Store.replaceAll(data); moneyFmt = null;
      toast(t('settings.imported')); showLogin();
    } catch (err) { toast(t('settings.importFailed', { error: err.message }), true); }
  });
  const reset = demo => async () => {
    if (!await confirmDialog(demo ? t('settings.restoreDemoConfirm') : t('settings.eraseAllConfirm'), t('common.delete'), true)) return;
    if (Sync.enabled()) Sync.logout();
    Store.reset(demo); App.ticket = newTicket(); saveTicket(); moneyFmt = null; showLogin();
  };
  $('[data-setk="rs-empty"]').addEventListener('click', reset(false));
  $('[data-setk="rs-demo"]').addEventListener('click', reset(true));
}

function wireCloud() {
  const repaint = () => render();
  if (Sync.enabled()) {
    $('#cl-sync').addEventListener('click', async e => {
      e.currentTarget.disabled = true;
      try { await Sync.syncNow(); toast(t('cloud.synced')); } catch (err) { toast(errText(err), true); }
      repaint();
    });
    $('#cl-out').addEventListener('click', async () => {
      if (!await confirmDialog(t('cloud.logoutConfirm'), t('cloud.logout'), true)) return;
      Sync.logout(); renderShell(); repaint();
    });
    if (Sync.state.fb) paintDevices();
    const inv = $('#cl-invite');
    if (inv) inv.addEventListener('click', inviteModal);
    const sp = $('#cl-setpw');
    if (sp) sp.addEventListener('click', () => {
      const m = openModal({ title: t('cloud.setPw'), body: `<p class="muted small" style="margin-top:0">${esc(t('cloud.setPwHint', { email: Sync.state.email }))}</p>
        <div class="cx-f">${icon('lock')}<input id="np-pass" type="password" autocomplete="new-password" minlength="6" placeholder="${esc(t('cloud.pwMin'))}"><button type="button" class="cx-eye" id="np-eye">${icon('eye')}</button></div>`,
        footer: `<button class="btn primary" id="np-ok" type="button">${esc(t('common.save'))}</button>` });
      eyeToggle($('#np-eye', m), $('#np-pass', m));
      $('#np-ok', m).addEventListener('click', async e => {
        const v = $('#np-pass', m).value;
        if (v.length < 6) { toast(t('err.passwordShort'), true); return; }
        e.currentTarget.disabled = true;
        try { await Sync.setPassword(v); closeModal(); toast(t('cloud.setPwDone')); repaint(); } catch (err) { toast(errText(err), true); e.target.disabled = false; }
      });
    });
    return;
  }
  const form = $('#cloud-card');
  $$('[data-tab]', form).forEach(b => b.addEventListener('click', () => { App.cloudTab = b.dataset.tab; repaint(); }));
  const pass = $('#cl-pass', form);
  eyeToggle($('#cl-eye', form), pass);
  const str = $('#cl-str', form);
  if (str) pass.addEventListener('input', () => { const n = pwStrength(pass.value); $$('i', str).forEach((x, i) => { x.className = i < n ? `on s${n}` : ''; }); });
  const forgot = $('#cl-forgot', form);
  if (forgot) forgot.addEventListener('click', async () => {
    const email = $('#cl-email', form).value.trim();
    if (!email) { toast(t('cloud.forgotNeedEmail'), true); $('#cl-email', form).focus(); return; }
    try { await Sync.resetPassword(email); await confirmDialog(t('cloud.forgotSent', { email }), 'OK'); } catch (err) { toast(errText(err), true); }
  });
  const busy = on => $$('button', form).forEach(b => { b.disabled = on; });
  const done = mode => {
    moneyFmt = null;
    toast(t('cloud.connectedToast'));
    if (mode === 'login') { App.ticket = newTicket(); saveTicket(); showLogin(); return; }
    renderShell(); render();
  };
  const cc = $('#cl-code', form);
  if (cc) cc.addEventListener('click', joinModal);
  const g = $('#cl-google', form);
  if (g) g.addEventListener('click', async () => {
    if (!Sync.googleReady()) { toast(t('cloud.googleOff'), true); return; }
    busy(true);
    try {
      const r = await Sync.googleAuth();
      if (r.exists && !await confirmDialog(t('cloud.googleExists'), t('cloud.login'))) { await Sync.cancelGoogle(); busy(false); return; }
      done(await Sync.useGoogle(r));
    } catch (err) {
      if (err.message !== 'err.cancelled') toast(err.detail ? `${t('err.googleFail')} (${err.detail})` : errText(err), true);
      busy(false);
    }
  });
  form.addEventListener('submit', async e => {
    e.preventDefault();
    const mode = App.cloudTab === 'register' ? 'register' : 'login';
    const f = formObj(form);
    const url = f.url.trim().replace(/\/+$/, '');
    if (!/^\S+@\S+\.\S+$/.test(f.email.trim())) { toast(t('err.invalidEmail'), true); return; }
    if (f.password.length < 6) { toast(t('err.passwordShort'), true); return; }
    if (mode === 'login' && !await confirmDialog(t('cloud.loginConfirm'), t('cloud.login'))) return;
    busy(true);
    try {
      if (mode === 'register') await Sync.register(url, f.email.trim(), f.password);
      else await Sync.login(url, f.email.trim(), f.password);
      done(mode);
    } catch (err) {
      toast(errText(err), true);
      busy(false);
    }
  });
}
// ---------- Celulares da loja e convites ----------
async function paintDevices() {
  const box = $('#cl-devs');
  if (!box) return;
  let list;
  try { list = await Sync.listDevices(); } catch (e) { box.innerHTML = `<p class="muted small" style="margin:6px 0">${esc(errText(e))}</p>`; return; }
  if (!$('#cl-devs')) return;
  const ago = ms => { if (!ms) return ''; const m = Math.round((Date.now() - ms) / 60000); return m < 2 ? t('inv.now') : m < 60 ? t('inv.minAgo', { n: m }) : m < 1440 ? t('inv.hAgo', { n: Math.round(m / 60) }) : fmtDate(new Date(ms).toISOString()); };
  const owner = !Sync.state.member;
  box.innerHTML = list.length ? list.map(d => `<div class="iv-dev ${d.revoked ? 'off' : ''}"><span class="iv-ic">${icon('phone')}</span>
    <span class="iv-tx"><b>${esc(d.model || t('inv.phone'))}${d.no ? ` · ${esc(t('cloud.deviceN', { n: d.no }))}` : ''}</b><small>${esc([d.me ? t('inv.thisOne') : '', d.user, d.revoked ? t('inv.revoked') : ago(d.seen), !d.member ? t('inv.ownerLogin') : ''].filter(Boolean).join(' · '))}</small></span>
    ${d.me ? `<span class="iv-me">${esc(t('inv.this'))}</span>` : owner && d.member && !d.revoked ? `<button type="button" class="iv-x" data-revoke="${esc(d.member)}" data-name="${esc(d.model || '')}">${esc(t('inv.disconnect'))}</button>` : ''}</div>`).join('')
    : `<p class="muted small" style="margin:6px 0">${esc(t('inv.none'))}</p>`;
  $$('[data-revoke]', box).forEach(b => b.addEventListener('click', async () => {
    if (!await confirmDialog(t('inv.disconnectConfirm', { name: b.dataset.name || t('inv.phone') }), t('inv.disconnect'), true)) return;
    b.disabled = true;
    try { await Sync.revokeDevice(b.dataset.revoke); toast(t('inv.disconnected')); paintDevices(); } catch (e) { toast(errText(e), true); b.disabled = false; }
  }));
}
async function inviteModal() {
  let inv;
  try { inv = await Sync.createInvite(); } catch (e) { toast(errText(e), true); return; }
  const digits = inv.code.split('').map((c, i) => `${i === 3 ? '<i></i>' : ''}<span>${c}</span>`).join('');
  const m = openModal({ title: t('inv.invite'), autofocus: false, body: `<div class="iv-pop">
    <div class="iv-code" role="button" title="${esc(t('inv.tapCopy'))}">${digits}</div>
    <div class="iv-bar"><i id="iv-bar"></i></div>
    <div class="iv-timer"><span>${icon('copy')}${esc(t('inv.tapCopy'))}</span><b id="iv-timer"></b></div></div>` });
  // Tocar no código copia uma mensagem pronta (o código vem primeiro, para colar em "Tenho um código").
  const codeEl = $('.iv-code', m);
  codeEl.addEventListener('click', async () => {
    if (codeEl.classList.contains('dead')) return;
    const ok = await copyText(t('inv.copyText', { code: inv.code, store: Store.settings.storeName || 'Stoi' }));
    if (!ok) { toast(t('err.server'), true); return; }
    toast(t('inv.copied'));
    codeEl.classList.remove('flash'); void codeEl.offsetWidth; codeEl.classList.add('flash');
    if (navigator.vibrate) navigator.vibrate(10);
  });
  const tick = () => {
    const left = inv.exp - Date.now();
    const bar = $('#iv-bar', m), tm = $('#iv-timer', m);
    if (!bar || !document.body.contains(m)) { clearInterval(iv); return; }
    if (left <= 0) { tm.parentNode.textContent = t('inv.expired'); bar.style.width = '0'; $('.iv-code', m).classList.add('dead'); clearInterval(iv); return; }
    bar.style.width = `${(left / 600000) * 100}%`;
    tm.textContent = `${Math.floor(left / 60000)}:${String(Math.floor(left / 1000) % 60).padStart(2, '0')}`;
  };
  const iv = setInterval(tick, 1000); tick();
  const off = Sync.inviteUsed(inv.code, d => {
    off();
    if (!document.body.contains(m) || !d) return;
    clearInterval(iv);
    $('.modal-body', m).innerHTML = `<div class="iv-ok"><div class="big">${icon('check')}</div><h3>${esc(t('inv.joined'))}</h3><p>${esc(t('inv.joinedSub'))}</p></div>`;
    if (navigator.vibrate) navigator.vibrate(20);
    paintDevices();
  });
  // Fechar sem usar: o código deixa de valer.
  const x = $('[data-close]', m);
  if (x) x.addEventListener('click', () => { clearInterval(iv); off(); Sync.cancelInvite(inv.code); });
}
function joinModal() {
  const m = openModal({ title: t('inv.haveCode'), autofocus: false, body: `<div class="iv-pop">
    <p class="muted small" style="text-align:center;margin:0">${esc(t('inv.typeCode'))}</p>
    <label class="iv-in" for="iv-code">${'<span></span>'.repeat(6)}<input id="iv-code" inputmode="numeric" autocomplete="one-time-code" maxlength="6" pattern="[0-9]*"></label>
    <button class="cx-main" id="iv-go" type="button" disabled>${esc(t('inv.join'))}</button></div>` });
  const inp = $('#iv-code', m), boxes = $$('.iv-in span', m), go = $('#iv-go', m);
  const paint = () => {
    inp.value = inp.value.replace(/\D/g, '').slice(0, 6);
    boxes.forEach((b, i) => { b.textContent = inp.value[i] || ''; b.classList.toggle('f', document.activeElement === inp && i === Math.min(inp.value.length, 5)); });
    go.disabled = inp.value.length !== 6;
  };
  ['input', 'focus', 'blur'].forEach(ev => inp.addEventListener(ev, paint));
  setTimeout(() => inp.focus(), 50); paint();
  const join = async () => {
    if (inp.value.length !== 6) return;
    go.disabled = true; inp.disabled = true; go.textContent = t('cloud.syncing');
    App.joining = true;
    try {
      const r = await Sync.joinWithCode(inp.value);
      App.joining = false;
      moneyFmt = null; App.ticket = newTicket(); saveTicket();
      $('.modal-body', m).innerHTML = `<div class="iv-ok"><div class="big">${icon('check')}</div><h3>${esc(t('inv.connectedTo', { name: r.storeName || t('chat.store') }))}</h3>
        <p>${esc(t('inv.connectedSub', { n: Sync.state.deviceNo || '—' }))}</p><button class="cx-main" id="iv-cont" type="button" style="margin-top:16px">${esc(t('inv.continue'))}</button></div>`;
      const cont = () => { closeModal(); showLogin(); };
      $('#iv-cont', m).addEventListener('click', cont);
      onModalClose(m, cont);
    } catch (e) {
      App.joining = false;
      toast(errText(e), true);
      inp.disabled = false; inp.value = ''; go.textContent = t('inv.join'); paint(); inp.focus();
    }
  };
  go.addEventListener('click', join);
  inp.addEventListener('keydown', e => { if (e.key === 'Enter') join(); });
}
// Olho que mostra / esconde a senha.
function eyeToggle(btn, input) {
  if (!btn || !input) return;
  btn.addEventListener('click', () => {
    const show = input.type === 'password';
    input.type = show ? 'text' : 'password';
    btn.innerHTML = icon(show ? 'eyeOff' : 'eye');
    btn.setAttribute('aria-label', t(show ? 'cloud.hidePw' : 'cloud.showPw'));
  });
}

function wirePrinter() {
  if (!Printer.available()) return;
  const sel = $('#pr-dev');
  const status = $('#pr-status');
  // Ao abrir as Definições a lista carrega em silêncio; só "Atualizar lista" mostra erros em destaque.
  const load = async ({ quiet = false } = {}) => {
    try {
      const list = await Printer.listPaired();
      const cur = (Device.conf.printer || {}).address;
      sel.innerHTML = `<option value="">${esc(list.length ? t('printer.choose') : t('printer.noneFound'))}</option>` +
        list.map(d => `<option value="${esc(d.address)}" ${d.address === cur ? 'selected' : ''}>${esc(d.name || d.address)}</option>`).join('');
      status.hidden = true;
    } catch (e) {
      status.textContent = e && e.code === 'BT_OFF' ? t('printer.btOffInline') : printerError(e);
      status.hidden = false;
      if (!quiet) toast(printerError(e), true);
    }
  };
  $('#pr-scan').addEventListener('click', () => load());
  const save = () => {
    const opt = sel.selectedOptions[0];
    const prev = Device.conf.printer || {};
    Device.conf.printer = {
      address: sel.value || prev.address || '', name: sel.value ? opt.textContent : prev.name || '',
      width: +$('#pr-width').value, auto: $('#pr-auto').checked,
    };
    Device.save();
  };
  $('#pr-save').addEventListener('click', () => { save(); toast(t('settings.saved')); });
  $('#pr-test').addEventListener('click', async () => {
    save();
    const pr = Device.conf.printer;
    if (!pr.address) { toast(t('printer.notConfigured'), true); return; }
    try {
      const p = new EscPos(pr.width);
      p.align('center').bold(true).line('Stoi').bold(false).line(t('printer.testOk')).line(fmtDate(new Date().toISOString())).feed(4).cut();
      await Printer.printBytes(pr.address, p);
      toast(t('printer.printed'));
    } catch (e) { toast(printerError(e), true); }
  });
  load({ quiet: true });
}

// ================= Exportar (CSV, PDF, foto e anotações) =================

// Janela de exportação. cfg: { title, subtitle, file, notes[], columns[], rows[][], totals[], numeric[], pdfHtml? }
function exportModal(cfg) {
  const m = openModal({
    title: t('xp.title'),
    autofocus: false,
    body: `
      <p class="muted small">${esc(cfg.title)}${cfg.subtitle ? ` · ${esc(cfg.subtitle)}` : ''} · ${esc(t('xp.rowsN', { n: cfg.rows.length }))}</p>
      ${cfg.notes.length ? `<div class="xp-notes">${notesHtml(cfg.notes)}</div>
      <label class="check xp-with"><input type="checkbox" id="xw" ${App.xpWithNotes ? 'checked' : ''}> ${esc(t('xp.withNotes'))}</label>` : ''}
      <div class="xp-options">
        <button class="xp-opt" data-xp="csv">${icon('table')}<span><b>Excel</b><small>${esc(t('xp.csvHint'))}</small></span></button>
        <button class="xp-opt" data-xp="pdf">${icon('print')}<span><b>PDF</b><small>${esc(t('xp.pdfHint'))}</small></span></button>
        <button class="xp-opt" data-xp="img">${icon('image')}<span><b>${esc(t('xp.image'))}</b><small>${esc(t('xp.imageHint'))}</small></span></button>
        <button class="xp-opt" data-xp="notes">${icon('text')}<span><b>${esc(t('xp.copyNotes'))}</b><small>${esc(t('xp.copyHint'))}</small></span></button>
      </div>`,
  });
  const base = `${cfg.file}_${dayKey(new Date())}`;
  // PDF e foto: resumo e tabela; as anotações (texto) só se a caixa estiver marcada.
  const withNotes = () => (App.xpWithNotes = !!($('#xw', m) && $('#xw', m).checked));
  $('[data-xp="csv"]', m).onclick = () => {
    if (cfg.xlsxSheets) return saveXlsxBytes(`${base}.xlsx`, xlsxWorkbookBytes(cfg.xlsxSheets()));
    const rows = [cfg.columns, ...cfg.rows];
    if (cfg.totals) rows.push(cfg.totals);
    downloadXlsx(`${base}.xlsx`, rows, cfg.title);
  };
  $('[data-xp="pdf"]', m).onclick = () => savePdfDoc(`${cfg.title} ${cfg.subtitle || ''}`.trim(), cfg.pdfHtml ? cfg.pdfHtml(withNotes() ? cfg.notes : []) : exportDocHtml(cfg, withNotes()), `${base}.pdf`);
  $('[data-xp="img"]', m).onclick = () => {
    const canvas = cfg.imageCanvas ? cfg.imageCanvas() : exportImage(cfg, withNotes());
    const dataUrl = canvas.toDataURL('image/png');
    if (NativePrint.available()) {
      saveToPhone(`${base}.png`, 'image/png', dataUrl.split(',')[1]);
    } else {
      const bin = atob(dataUrl.split(',')[1]);
      const bytes = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
      download(`${base}.png`, new Blob([bytes], { type: 'image/png' }), 'image/png');
    }
  };
  $('[data-xp="notes"]', m).onclick = async () => {
    const text = cfg.text ? cfg.text() : notesText(cfg.notes);
    if (!text.trim()) return toast(t('xp.noText'), true);
    if (await copyText(text)) return toast(t('xp.copied'));
    if (NativePrint.available()) return NativePrint.share(`${base}.txt`, 'text/plain', text).catch(() => {});
    return toast(t('xp.copyFailed'), true);
  };
}

// Documento A4 genérico: título, resumo (cfg.summary: [[rótulo, valor, forte]]), anotações (opcional) e tabela.
function exportDocHtml(cfg, withNotes = false) {
  const num = i => (cfg.numeric || []).includes(i);
  return `<div class="doc">
    <h1>${esc(Store.settings.storeName)}</h1>
    <div class="meta">${esc(cfg.title)}${cfg.subtitle ? ` · ${esc(cfg.subtitle)}` : ''} · ${esc(t('reports.generated', { date: fmtDate(new Date().toISOString()) }))}</div>
    ${cfg.summary ? `<div class="avoid"><h2>${esc(t('xp.summary'))}</h2><table class="summary">${cfg.summary.map(([k, v, strong]) => `<tr class="${strong ? 'total-row' : ''}"><td>${esc(k)}</td><td class="r">${esc(v)}</td></tr>`).join('')}</table></div>` : ''}
    ${withNotes ? `<div class="avoid notes">${notesHtml(cfg.notes)}</div>` : ''}
    <h2>${esc(cfg.tableTitle || cfg.title)}</h2>
    <table><tr>${cfg.columns.map((c, i) => `<th class="${num(i) ? 'r' : ''}">${esc(c)}</th>`).join('')}</tr>
      ${cfg.rows.map(r => `<tr>${r.map((v, i) => `<td class="${num(i) ? 'r' : ''}">${esc(fmtCell(v, num(i)))}</td>`).join('')}</tr>`).join('')}
      ${cfg.totals ? `<tr class="total-row">${cfg.totals.map((v, i) => `<td class="${num(i) ? 'r' : ''}">${esc(fmtCell(v, num(i)))}</td>`).join('')}</tr>` : ''}
    </table></div>`;
}

const fmtCell = (v, isNum) => (v == null ? '' : isNum && typeof v === 'number' ? (Number.isInteger(v) ? String(v) : String(round2(v)).replace('.', ',')) : String(v));

// Foto (PNG) desenhada num canvas: cabeçalho, anotações e tabela. Funciona sem internet.
function exportImage(cfg, withNotes = false) {
  // cfg.image: colunas/linhas próprias para a foto (menos colunas, para os nomes caberem).
  cfg = Object.assign({}, cfg, cfg.image || {});
  const W = 1080, P = 48, rowH = 46, maxRows = 300;
  const font = (w, s) => `${w} ${s}px system-ui, -apple-system, "Segoe UI", Roboto, Arial, sans-serif`;
  const rows = cfg.rows.slice(0, maxRows);
  const measure = document.createElement('canvas').getContext('2d');
  const wrap = (text, width, f) => {
    measure.font = f;
    const words = String(text).split(' '); const lines = []; let line = '';
    for (const w of words) {
      const test = line ? `${line} ${w}` : w;
      if (measure.measureText(test).width > width && line) { lines.push(line); line = w; } else line = test;
    }
    if (line) lines.push(line);
    return lines;
  };
  const noteLines = (withNotes ? cfg.notes : []).map((n, k) => ({ h: noteIsH(n), gap: noteIsH(n) && k ? 18 : 0, lines: wrap(noteIsH(n) ? n.h : n, W - P * 2 - 48, font(noteIsH(n) ? 700 : 400, 26)) }));
  const notesH = noteLines.length ? noteLines.reduce((a, n) => a + n.gap + n.lines.length * 36, 0) + 56 : 0;
  const sum = cfg.summary || [];
  const sumH = sum.length ? sum.length * 50 + 30 : 0;
  const tableH = (rows.length + 1 + (cfg.totals ? 1 : 0)) * rowH + (cfg.rows.length > maxRows ? 50 : 0);
  const H = P + 120 + sumH + notesH + 40 + tableH + 90;
  const c = document.createElement('canvas'); c.width = W; c.height = H;
  const g = c.getContext('2d');
  g.fillStyle = '#ffffff'; g.fillRect(0, 0, W, H);
  // cabeçalho verde
  g.fillStyle = '#2e7d32'; g.fillRect(0, 0, W, 150);
  g.fillStyle = '#ffffff'; g.font = font(700, 40); g.fillText(Store.settings.storeName, P, 70);
  g.font = font(400, 26); g.fillText(`${cfg.title}${cfg.subtitle ? ` · ${cfg.subtitle}` : ''}`, P, 115);
  let y = 150 + 36;
  // resumo (totais), em linhas rótulo / valor
  sum.forEach(([k, v, strong], i) => {
    const yy = y + i * 50;
    if (strong) { g.fillStyle = '#e8f5e9'; g.fillRect(P, yy, W - P * 2, 50); }
    g.fillStyle = strong ? '#1b5e20' : '#1f2937'; g.font = font(strong ? 700 : 400, 26);
    g.fillText(k, P + 16, yy + 34);
    g.textAlign = 'right'; g.fillText(v, W - P - 16, yy + 34); g.textAlign = 'left';
    g.fillStyle = '#e5e7eb'; g.fillRect(P, yy + 49, W - P * 2, 1);
  });
  y += sumH;
  // anotações (só se pedidas)
  if (noteLines.length) { g.fillStyle = '#fff3e0'; g.fillRect(P, y, W - P * 2, notesH - 20); }
  let ny = y + 50;
  g.fillStyle = '#1f2937';
  noteLines.forEach(n => {
    ny += n.gap; g.font = font(n.h ? 700 : 400, 26);
    n.lines.forEach((l, i) => { g.fillText(l, P + 24, ny + i * 36); });
    ny += n.lines.length * 36;
  });
  y += notesH + (noteLines.length ? 20 : 0);
  // tabela
  const n = cfg.columns.length;
  const isNum = i => (cfg.numeric || []).includes(i);
  // Largura de cada coluna segundo o texto mais largo; se não couber, encolhe as mais largas.
  const avail = W - P * 2;
  const need = cfg.columns.map((h, i) => {
    measure.font = font(700, 20);
    let w = measure.measureText(String(h).toUpperCase()).width;
    measure.font = font(400, 24);
    [...rows, cfg.totals || []].forEach(r => { if (r[i] != null) w = Math.max(w, measure.measureText(fmtCell(r[i], isNum(i))).width); });
    return w + 28;
  });
  let widths = need.slice();
  const total = need.reduce((a, b) => a + b, 0);
  if (total <= avail) widths = need.map(w => w + (avail - total) * (w / total));
  else {
    let cap = Math.max(...need);
    while (widths.reduce((a, b) => a + b, 0) > avail && cap > 60) { cap -= 4; widths = need.map(w => Math.min(w, cap)); }
  }
  const colW = i => widths[i];
  const colX = i => P + widths.slice(0, i).reduce((a, b) => a + b, 0);
  const cellText = (v, i, w, f) => {
    let s = fmtCell(v, isNum(i)); measure.font = f;
    while (s.length > 1 && measure.measureText(s).width > w - 20) s = s.slice(0, -2) + '…';
    return s;
  };
  const drawRow = (vals, yy, f, color) => {
    g.font = f; g.fillStyle = color;
    vals.forEach((v, i) => {
      const s = cellText(v, i, colW(i), f);
      if (isNum(i)) { g.textAlign = 'right'; g.fillText(s, colX(i) + colW(i) - 12, yy); g.textAlign = 'left'; }
      else g.fillText(s, colX(i) + 12, yy);
    });
  };
  g.fillStyle = '#f3f4f6'; g.fillRect(P, y, W - P * 2, rowH);
  drawRow(cfg.columns.map(x => String(x).toUpperCase()), y + 30, font(700, 20), '#6b7280');
  y += rowH;
  rows.forEach((r, k) => {
    if (k % 2) { g.fillStyle = '#fafafa'; g.fillRect(P, y, W - P * 2, rowH); }
    drawRow(r, y + 31, font(400, 24), '#1f2937');
    g.fillStyle = '#e5e7eb'; g.fillRect(P, y + rowH - 1, W - P * 2, 1);
    y += rowH;
  });
  if (cfg.totals) {
    g.fillStyle = '#e8f5e9'; g.fillRect(P, y, W - P * 2, rowH);
    drawRow(cfg.totals, y + 31, font(700, 24), '#1b5e20'); y += rowH;
  }
  if (cfg.rows.length > maxRows) { g.font = font(400, 22); g.fillStyle = '#6b7280'; g.fillText(t('xp.moreRows', { n: cfg.rows.length - maxRows }), P, y + 34); y += 50; }
  g.font = font(400, 20); g.fillStyle = '#9ca3af';
  g.fillText(`Stoi · ${fmtDate(new Date().toISOString())}`, P, H - 36);
  return c;
}

// Anotações no estilo de mensagem (para WhatsApp): títulos {h} e linhas de texto.
// Não mostram custo, margem nem preço de compra.
const noteIsH = n => typeof n === 'object';
// Copiar texto para o telemóvel: área de transferência e, se o navegador não deixar, o modo antigo.
async function copyText(text) {
  try { if (navigator.clipboard && navigator.clipboard.writeText) { await navigator.clipboard.writeText(text); return true; } } catch (e) { /* tenta o modo antigo */ }
  const ta = document.createElement('textarea');
  ta.value = text; ta.setAttribute('readonly', ''); ta.style.position = 'fixed'; ta.style.top = '-1000px'; ta.style.opacity = '0';
  document.body.appendChild(ta); ta.select(); ta.setSelectionRange(0, text.length);
  let ok = false;
  try { ok = document.execCommand('copy'); } catch (e) { ok = false; }
  ta.remove();
  return ok;
}
const notesText = notes => notes.map((n, i) => (noteIsH(n) ? `${i ? '\n' : ''}${n.h}` : n)).join('\n');
const notesHtml = notes => `<div class="xn">${notes.map(n => (noteIsH(n) ? `<div class="xn-h">${esc(n.h)}</div>` : `<div>${esc(n)}</div>`)).join('')}</div>`;

// "27.Outubro" a partir de 'AAAA-MM-DD', ISO ou timestamp.
function dayMonth(v) {
  const d = typeof v === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(v) ? new Date(+v.slice(0, 4), +v.slice(5, 7) - 1, +v.slice(8, 10)) : new Date(v);
  const m = d.toLocaleDateString(dateLocale(), { month: 'long' });
  return `${d.getDate()}.${m.charAt(0).toUpperCase()}${m.slice(1)}`;
}
const fmtNum = v => fmtCell(round2(v), true);

const stockIsLow = i => i.stock > 0 && i.stock <= (i.lowStock || 0);

// Produtos com controlo de stock (por categoria e pesquisa) e o que entrou no intervalo de datas.
// Sem datas, usa o dia da última entrada desses produtos.
function stockSelection({ cats = [], q = '', from = '', to = '', items = null }) {
  const inCat = i => !cats.length || cats.includes(i.categoryId && Store.find('categories', i.categoryId) ? i.categoryId : 'none');
  const list = (items || Store.data.items).filter(i => i.trackStock && inCat(i) && (!q || i.name.toLowerCase().includes(q)))
    .sort((a, b) => a.name.localeCompare(b.name, 'pt'));
  const ids = new Set(list.map(i => i.id));
  const ins = Store.data.stockEntries.filter(e => e.type === 'in' && e.date && ids.has(e.itemId));
  const lastBy = new Map();
  for (const e of ins) if (!lastBy.has(e.itemId) || e.date > lastBy.get(e.itemId)) lastBy.set(e.itemId, e.date);
  if (!from) { from = to = ins.reduce((a, e) => (e.date > a ? e.date : a), ''); }
  const entered = new Map();
  if (from) for (const e of ins) {
    if (e.date < from || e.date > to) continue;
    const x = entered.get(e.itemId) || { qty: 0, last: e.date };
    x.qty += e.qty; if (e.date > x.last) x.last = e.date;
    entered.set(e.itemId, x);
  }
  return { items: list, from, to, entered, lastEntry: id => lastBy.get(id) || null };
}

// Anotações de stock em forma de mensagem: NOVO ESTOQUE (quanto entrou, por categoria),
// POUCO ESTOQUE e SEM ESTOQUE (PEDIDO). Sem custos nem preços de compra.
function stockNotes(sel, sits = [], list = sel.items) {
  const show = k => !sits.length || sits.includes(k);
  const one = sits.length === 1 ? sits[0] : null;
  const notes = [];
  const byName = (a, b) => a.name.localeCompare(b.name, 'pt');
  const range = sel.from ? (sel.from === sel.to ? dayMonth(sel.from) : `${dayMonth(sel.from)} – ${dayMonth(sel.to)}`) : dayMonth(Date.now());
  const today = dayMonth(Date.now());
  if (show('new')) {
    const fresh = list.filter(i => sel.entered.has(i.id));
    if (fresh.length) {
      notes.push({ h: t('xn.newStock', { date: range }) });
      const groups = {};
      for (const i of fresh) {
        const cat = (Store.find('categories', i.categoryId) || {}).name || t('xn.other');
        (groups[cat] = groups[cat] || []).push(i);
      }
      for (const cat of Object.keys(groups).sort((a, b) => a.localeCompare(b, 'pt'))) {
        notes.push({ h: `${cat.toUpperCase()}:` });
        groups[cat].sort(byName).forEach(i => notes.push(`${fmtNum(sel.entered.get(i.id).qty)}x ${i.name}${i.price > 0 ? ` ${fmtNum(i.price)}` : ''}`));
      }
    } else if (one === 'new') notes.push({ h: t('xn.newStock', { date: range }) }, t('xn.noEntries'));
  }
  if (show('low')) {
    const low = list.filter(stockIsLow).sort(byName);
    if (low.length || one === 'low') notes.push({ h: one === 'low' ? t('xn.lowTitle', { date: today }) : `${t('xn.low')}:` });
    low.forEach(i => notes.push(`${fmtNum(i.stock)}x ${dn(i)}`));
    if (!low.length && one === 'low') notes.push(t('xn.nothing'));
  }
  if (show('out')) {
    const out = list.filter(i => i.stock <= 0).sort(byName);
    if (out.length || one === 'out') notes.push({ h: one === 'out' ? t('xn.outTitle', { date: today }) : `${t('xn.soldOut')}:` });
    out.forEach(i => notes.push(dn(i)));
    if (!out.length && one === 'out') notes.push(t('xn.nothing'));
  }
  if (!notes.length) notes.push({ h: t('xn.stock', { date: today }) }, t(sel.items.length ? 'xn.nothing' : 'xn.noTracked'));
  return notes;
}

// Anotações sobre a lista de produtos exportada (Entradas): o mesmo formato do Stock.
const productNotes = list => stockNotes(stockSelection({ items: list }));

// Anotações sobre as vendas do período exportado.
function salesNotes(rep, fin, from, to) {
  const oneDay = to - from <= 864e5 + 3600e3;
  const date = oneDay ? dayMonth(from) : `${dayMonth(from)} – ${dayMonth(to - 1)}`;
  const notes = [{ h: t('xn.salesTitle', { date }) }];
  if (!rep.salesCount) return [...notes, t('xn.noSales')];
  notes.push(t('xn.total', { total: money(fin.netSales), n: rep.salesCount }));
  const best = Object.entries(oneDay ? rep.byHour : rep.byDay).sort((a, b) => b[1] - a[1])[0];
  if (best) notes.push(oneDay ? t('xn.bestHour', { hour: best[0].slice(11) }) : t('xn.bestDay', { day: dayMonth(best[0]) }));
  const top = Object.values(rep.byItem).filter(x => x.qty > 0).sort((a, b) => b.qty - a.qty || b.net - a.net).slice(0, 10);
  if (top.length) { notes.push({ h: `${t('xn.topItems')}:` }); top.forEach(x => notes.push(`${fmtNum(x.qty)}x ${x.name} ${fmtNum(x.net)}`)); }
  const pays = Object.entries(rep.byPayment).filter(([, v]) => v > 0).sort((a, b) => b[1] - a[1]);
  if (pays.length) { notes.push({ h: `${t('xn.payments')}:` }); pays.forEach(([k, v]) => notes.push(`${payLabel(k)} ${fmtNum(v)}`)); }
  if (fin.creditSales) { notes.push({ h: `${t('xn.credit')}:` }, t('xn.creditLine', { total: fmtNum(fin.creditSales), debt: fmtNum(fin.totalDebt) })); }
  if (rep.refundCount) { notes.push({ h: `${t('xn.refunds')}:` }, t('xn.refundsLine', { n: rep.refundCount, total: fmtNum(rep.refunds) })); }
  if (fin.totalExpenses) { notes.push({ h: `${t('xn.expenses')}:` }, fmtNum(fin.totalExpenses)); }
  return notes;
}

// ================= Termos da app (tradução manual) =================

// Comparação sem maiúsculas nem acentos ("saidas" encontra "Saídas").
const norm = s => String(s).toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
// Texto com a parte procurada destacada.
function mark(text, qq) {
  if (!qq) return esc(text);
  const i = norm(text).indexOf(qq);
  return i < 0 ? esc(text) : `${esc(text.slice(0, i))}<mark>${esc(text.slice(i, i + qq.length))}</mark>${esc(text.slice(i + qq.length))}`;
}
// Onde cada termo aparece, pela primeira parte da chave (ex.: "sup.total" → Fecho).
const TERM_AREAS = {
  nav: 'terms.area.menu', common: 'terms.area.general', app: 'terms.area.general', err: 'terms.area.errors', login: 'terms.area.login', role: 'nav.employees',
  sales: 'nav.sales', ticket: 'nav.sales', totals: 'nav.sales', discount: 'nav.sales', pay: 'terms.area.payment',
  receipt: 'nav.receipts', receipts: 'nav.receipts', shift: 'nav.shifts', items: 'nav.items', categories: 'nav.categories',
  stock: 'stock.tab', count: 'bal.tabStock', bal: 'nav.stockCount', sup: 'bal.tabClosing', fin: 'bal.tabFinance', exp: 'fin.expenses', debt: 'terms.area.credit',
  customers: 'nav.customers', reports: 'nav.reports', rep: 'nav.reports', employees: 'nav.employees',
  settings: 'nav.settings', cloud: 'cloud.title', printer: 'printer.title', terms: 'terms.title', xp: 'xp.title', xn: 'terms.area.notes',
};
const termArea = k => { const a = TERM_AREAS[k.split('.')[0]]; return a ? t(a) : ''; };
const termCount = () => Object.keys((Store.settings.terms || {})[getLang()] || {}).length;
const termVars = s => (String(s).match(/\{\w+\}/g) || []).sort().join(',');

// Lista de todos os termos do idioma atual: o texto de origem e, ao lado, o texto próprio da loja.
// Fica guardado nas configurações (sincroniza com os outros dispositivos).
function termsModal() {
  const lang = getLang();
  const base = I18N[lang] || I18N.pt;
  const keys = Object.keys(base).sort((a, b) => base[a].localeCompare(base[b], lang));
  const own = () => ((Store.settings.terms || {})[lang] || {});
  let q = '', onlyChanged = false, exact = false, limit = 60;
  const m = openModal({
    title: t('terms.title'),
    wide: true,
    autofocus: false,
    body: `
      <div class="page-head stock-head" style="margin-bottom:10px">
        <input class="input grow" id="tq" type="search" placeholder="${esc(t('terms.search'))}">
      </div>
      <div class="terms-opts">
        <label class="check"><input type="checkbox" id="tx"> ${esc(t('terms.exact'))}</label>
        <label class="check"><input type="checkbox" id="tc"> ${esc(t('terms.onlyChanged'))}</label>
        <span class="muted small" id="tn"></span>
      </div>
      <p class="muted small" style="margin:0 0 10px">${esc(t('terms.varsHint'))}</p>
      <div id="tl" class="terms-list"></div>`,
    footer: `<button class="btn danger" data-reset-all>${esc(t('terms.resetAll'))}</button>`,
  });
  const paint = () => {
    const o = own();
    const qq = norm(q.trim());
    // Proximidade: 0 igual, 1 começa por, 2 palavra inteira, 3 contém; -1 não serve.
    const rank = k => {
      let best = -1;
      for (const txt of [base[k], o[k] || '']) {
        const v = norm(txt);
        if (!v) continue;
        const r = v === qq ? 0 : exact ? -1 : v.startsWith(qq) ? 1 : new RegExp(`(^|[^\\p{L}\\p{N}])${qq.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}($|[^\\p{L}\\p{N}])`, 'u').test(v) ? 2 : v.includes(qq) ? 3 : -1;
        if (r >= 0 && (best < 0 || r < best)) best = r;
      }
      return best;
    };
    const list = keys.filter(k => !onlyChanged || o[k]).map(k => [k, qq ? rank(k) : 0]).filter(([, r]) => r >= 0)
      .sort((a, b) => a[1] - b[1]).map(([k]) => k);
    $('#tn', m).textContent = qq || onlyChanged ? t('terms.foundN', { n: list.length }) : t('terms.totalN', { n: list.length });
    $('#tl', m).innerHTML = list.length ? list.slice(0, limit).map(k => `
      <div class="term-row ${o[k] ? 'changed' : ''}" data-k="${esc(k)}">
        <div class="muted small term-orig"><span class="term-area">${esc(termArea(k))}</span>${mark(base[k], qq)}</div>
        <div class="term-edit"><input class="input" value="${esc(o[k] || '')}" placeholder="${esc(base[k])}" aria-label="${esc(base[k])}">
          <button class="icon-btn" data-undo title="${esc(t('terms.reset'))}" aria-label="${esc(t('terms.reset'))}" ${o[k] ? '' : 'hidden'}>${icon('close')}</button></div>
      </div>`).join('') + (list.length > limit ? `<button class="btn block" id="tmore">${esc(t('terms.more', { n: list.length - limit }))}</button>` : '')
      : `<div class="empty">${esc(t('terms.none'))}</div>`;
    $$('.term-row', m).forEach(row => {
      const k = row.dataset.k, input = $('input', row);
      const save = v => {
        const terms = Store.settings.terms = Object.assign({}, Store.settings.terms);
        const mine = terms[lang] = Object.assign({}, terms[lang]);
        if (!v || v === base[k]) delete mine[k]; else mine[k] = v;
        Store.save(); setTermOverrides(terms); App.stale = true;
        row.classList.toggle('changed', !!mine[k]);
        $('[data-undo]', row).hidden = !mine[k];
      };
      input.addEventListener('change', () => {
        const v = input.value.trim();
        // As partes entre chavetas ({n}, {date}…) são trocadas por valores; têm de continuar lá.
        if (v && termVars(v) !== termVars(base[k])) { toast(t('terms.needVars', { vars: termVars(base[k]) }), true); input.focus(); return; }
        save(v);
      });
      $('[data-undo]', row).addEventListener('click', () => { input.value = ''; save(''); });
    });
    const more = $('#tmore', m);
    if (more) more.onclick = () => { limit += 100; paint(); };
  };
  $('#tq', m).addEventListener('input', e => { q = e.target.value; limit = 60; paint(); });
  $('#tc', m).addEventListener('change', e => { onlyChanged = e.target.checked; limit = 60; paint(); });
  $('#tx', m).addEventListener('change', e => { exact = e.target.checked; limit = 60; paint(); });
  $('[data-reset-all]', m).onclick = async () => {
    if (!termCount()) return;
    if (!await confirmDialog(t('terms.resetAllConfirm', { n: termCount() }), t('terms.resetAll'), true)) return termsModal();
    const terms = Object.assign({}, Store.settings.terms); delete terms[lang];
    Store.settings.terms = terms; Store.save(); setTermOverrides(terms);
    renderShell(); render(); termsModal();
  };
  paint();
}

// ================= Ficheiros =================

// Na app do telemóvel os ficheiros exportados ficam guardados em Documentos/Stoi (sem partilhar).
const SAVE_FOLDER = 'Stoi';
function saveToPhone(name, mime, base64) {
  return NativePrint.saveFile(name, mime, base64, SAVE_FOLDER)
    .then(() => toast(t('xp.saved', { f: `${t('xp.docs')}/${SAVE_FOLDER}`, name }), false, true))
    .catch(e => toast(errText(e), true));
}
const toB64 = text => btoa(unescape(encodeURIComponent(text)));

function download(name, content, type) {
  if (NativePrint.available() && !(content instanceof Blob)) {
    saveToPhone(name, type.split(';')[0], toB64(content));
    return;
  }
  const a = document.createElement('a');
  a.href = URL.createObjectURL(content instanceof Blob ? content : new Blob([content], { type }));
  a.download = name;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}

// ---------- Excel (.xlsx) sem bibliotecas: uma folha, números como números ----------
// Cabeçalho e linhas de Total/secção a negrito. O ficheiro é um ZIP simples (sem compressão).
const CRC_TABLE = (() => { const tb = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; tb[n] = c >>> 0; } return tb; })();
const crc32 = bytes => { let c = 0xFFFFFFFF; for (let i = 0; i < bytes.length; i++) c = CRC_TABLE[(c ^ bytes[i]) & 0xFF] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; };
function zipStore(files) {
  const enc = new TextEncoder();
  const parts = [], central = [];
  let offset = 0;
  const u16 = v => [v & 255, (v >>> 8) & 255], u32 = v => [v & 255, (v >>> 8) & 255, (v >>> 16) & 255, (v >>> 24) & 255];
  for (const [name, text] of files) {
    const data = enc.encode(text), nm = enc.encode(name), crc = crc32(data);
    const head = [...u32(0x04034b50), ...u16(20), ...u16(0x0800), ...u16(0), ...u16(0), ...u16(0x21), ...u32(crc), ...u32(data.length), ...u32(data.length), ...u16(nm.length), ...u16(0)];
    parts.push(new Uint8Array(head), nm, data);
    central.push(new Uint8Array([...u32(0x02014b50), ...u16(20), ...u16(20), ...u16(0x0800), ...u16(0), ...u16(0), ...u16(0x21), ...u32(crc), ...u32(data.length), ...u32(data.length), ...u16(nm.length), ...u16(0), ...u16(0), ...u16(0), ...u16(0), ...u32(0), ...u32(offset)]), nm);
    offset += head.length + nm.length + data.length;
  }
  const cdSize = central.reduce((a, x) => a + x.length, 0);
  const end = new Uint8Array([...u32(0x06054b50), ...u16(0), ...u16(0), ...u16(files.length), ...u16(files.length), ...u32(cdSize), ...u32(offset), ...u16(0)]);
  const all = [...parts, ...central, end];
  const out = new Uint8Array(all.reduce((a, x) => a + x.length, 0));
  let p = 0; for (const x of all) { out.set(x, p); p += x.length; }
  return out;
}
function xlsxBytes(rows, sheetName = 'Folha1') {
  const x = v => String(v).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  const col = i => { let n = i + 1, s2 = ''; while (n) { const m = (n - 1) % 26; s2 = String.fromCharCode(65 + m) + s2; n = Math.floor((n - 1) / 26); } return s2; };
  const isBold = (r, i) => i === 0 || /^(total|—)/i.test(String(r[0] || ''));
  const widths = [];
  rows.forEach(r => r.forEach((v, i) => { widths[i] = Math.min(60, Math.max(widths[i] || 8, String(v ?? '').length + 2)); }));
  const sheetRows = rows.map((r, ri) => `<row r="${ri + 1}">${r.map((v, ci) => {
    const ref = `${col(ci)}${ri + 1}`, st = isBold(r, ri) ? ' s="1"' : '';
    if (v === '' || v == null) return st ? `<c r="${ref}"${st}/>` : '';
    return typeof v === 'number' && Number.isFinite(v) ? `<c r="${ref}"${st}><v>${v}</v></c>` : `<c r="${ref}" t="inlineStr"${st}><is><t xml:space="preserve">${x(v)}</t></is></c>`;
  }).join('')}</row>`).join('');
  const files = [
    ['[Content_Types].xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>'],
    ['_rels/.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>'],
    ['xl/workbook.xml', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="${x(sheetName.slice(0, 31).replace(/[\\/?*[\]:]/g, ' '))}" sheetId="1" r:id="rId1"/></sheets></workbook>`],
    ['xl/_rels/workbook.xml.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>'],
    ['xl/styles.xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><name val="Calibri"/></font></fonts><fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="2"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>'],
    ['xl/worksheets/sheet1.xml', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><cols>${widths.map((w, i) => `<col min="${i + 1}" max="${i + 1}" width="${w}" customWidth="1"/>`).join('')}</cols><sheetData>${sheetRows}</sheetData></worksheet>`],
  ];
  return zipStore(files);
}
// Livro Excel com várias folhas e estilos fixos (modelo "Resumo + uma folha por secção").
// Cada célula: valor simples ou { v, s } com s = índice de XS (estilos abaixo).
const XS = { normal: 0, bold: 1, title: 2, sub: 3, head: 4, headL: 5, txt: 6, num: 7, totL: 8, totN: 9,
  barG: 10, barB: 11, barP: 12, barR: 13, sumL: 14, sumM: 15, sumSL: 16, sumSM: 17, sumTL: 18, sumTM: 19, totE: 20,
  barGc: 21, barBc: 22, barPc: 23, barRc: 24, dark: 25 };
function xlsxWorkbookBytes(sheets) {
  const x = v => String(v).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  const col = i => { let n = i + 1, s2 = ''; while (n) { const m = (n - 1) % 26; s2 = String.fromCharCode(65 + m) + s2; n = Math.floor((n - 1) / 26); } return s2; };
  const cur = (money(0).replace(/[\d\s.,  -]/g, '') || 'MZN').trim();
  const sheetXml = sh => {
    const rowsXml = sh.rows.map((r, ri) => `<row r="${ri + 1}">${(r || []).map((c, ci) => {
      const cell = c && typeof c === 'object' && !Array.isArray(c) ? c : { v: c };
      const ref = `${col(ci)}${ri + 1}`, st = cell.s ? ` s="${cell.s}"` : '';
      if (cell.v === '' || cell.v == null) return st ? `<c r="${ref}"${st}/>` : '';
      return typeof cell.v === 'number' && Number.isFinite(cell.v) ? `<c r="${ref}"${st}><v>${cell.v}</v></c>`
        : `<c r="${ref}" t="inlineStr"${st}><is><t xml:space="preserve">${x(cell.v)}</t></is></c>`;
    }).join('')}</row>`).join('');
    const pane = sh.freeze ? `<pane ySplit="${sh.freeze}" topLeftCell="A${sh.freeze + 1}" activePane="bottomLeft" state="frozen"/>` : '';
    return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetPr><pageSetUpPr fitToPage="1"/></sheetPr><sheetViews><sheetView workbookViewId="0" showGridLines="0">${pane}</sheetView></sheetViews>`
      + `<cols>${(sh.cols || []).map((w, i) => `<col min="${i + 1}" max="${i + 1}" width="${w}" customWidth="1"/>`).join('')}</cols><sheetData>${rowsXml}</sheetData>`
      + (sh.merges && sh.merges.length ? `<mergeCells count="${sh.merges.length}">${sh.merges.map(m => `<mergeCell ref="${m}"/>`).join('')}</mergeCells>` : '')
      + `<pageMargins left="0.5" right="0.5" top="0.6" bottom="0.6" header="0.3" footer="0.3"/><pageSetup paperSize="9" orientation="${sh.landscape ? 'landscape' : 'portrait'}" fitToWidth="1" fitToHeight="0"/></worksheet>`;
  };
  const fills = ['<fill><patternFill patternType="none"/></fill>', '<fill><patternFill patternType="gray125"/></fill>',
    ...['F3F4F6', 'E8F5E9', '2E7D32', '1565C0', '6A1B9A', 'C62828', '1F2937'].map(c => `<fill><patternFill patternType="solid"><fgColor rgb="FF${c}"/><bgColor indexed="64"/></patternFill></fill>`)];
  const fonts = ['<font><sz val="11"/><name val="Calibri"/></font>', '<font><b/><sz val="11"/><name val="Calibri"/></font>',
    '<font><b/><sz val="16"/><color rgb="FF1F2937"/><name val="Calibri"/></font>', '<font><sz val="11"/><color rgb="FF6B7280"/><name val="Calibri"/></font>',
    '<font><b/><sz val="11"/><color rgb="FF374151"/><name val="Calibri"/></font>', '<font><b/><sz val="11"/><color rgb="FF1B5E20"/><name val="Calibri"/></font>',
    '<font><b/><sz val="12"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font>', '<font><b/><sz val="11"/><color rgb="FF1D4ED8"/><name val="Calibri"/></font>'];
  const side = '<left style="thin"><color rgb="FFD1D5DB"/></left><right style="thin"><color rgb="FFD1D5DB"/></right><top style="thin"><color rgb="FFD1D5DB"/></top><bottom style="thin"><color rgb="FFD1D5DB"/></bottom><diagonal/>';
  const borders = ['<border><left/><right/><top/><bottom/><diagonal/></border>', `<border>${side}</border>`, '<border><left/><right/><top/><bottom style="thin"><color rgb="FFD1D5DB"/></bottom><diagonal/></border>'];
  // [numFmt, font, fill, border, alinhamento]
  const xf = [[0, 0, 0, 0], [0, 1, 0, 0], [0, 2, 0, 0], [0, 3, 0, 0], [0, 4, 2, 1, 'right'], [0, 4, 2, 1, 'left'], [0, 0, 0, 1], [164, 0, 0, 1],
    [0, 5, 3, 1], [164, 5, 3, 1], [0, 6, 4, 0], [0, 6, 5, 0], [0, 6, 6, 0], [0, 6, 7, 0], [0, 0, 0, 2], [165, 0, 0, 2], [0, 1, 0, 2], [165, 1, 0, 2],
    [0, 1, 3, 0], [165, 7, 3, 0], [0, 0, 3, 1],
    [0, 6, 4, 0, 'center'], [0, 6, 5, 0, 'center'], [0, 6, 6, 0, 'center'], [0, 6, 7, 0, 'center'], [0, 6, 8, 0, 'left']];
  const styles = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">`
    + `<numFmts count="2"><numFmt numFmtId="164" formatCode="#,##0"/><numFmt numFmtId="165" formatCode="#,##0.00&quot; ${x(cur)}&quot;"/></numFmts>`
    + `<fonts count="${fonts.length}">${fonts.join('')}</fonts><fills count="${fills.length}">${fills.join('')}</fills><borders count="${borders.length}">${borders.join('')}</borders>`
    + '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
    + `<cellXfs count="${xf.length}">${xf.map(([n, f, fl, b, al]) => `<xf numFmtId="${n}" fontId="${f}" fillId="${fl}" borderId="${b}" xfId="0"${n ? ' applyNumberFormat="1"' : ''}${f ? ' applyFont="1"' : ''}${fl ? ' applyFill="1"' : ''}${b ? ' applyBorder="1"' : ''}${al ? ` applyAlignment="1"><alignment horizontal="${al}"/></xf>` : '/>'}`).join('')}</cellXfs>`
    + '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>';
  const safe = n => String(n).slice(0, 31).replace(/[\\/?*[\]:]/g, ' ');
  const files = [
    ['[Content_Types].xml', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>${sheets.map((_, i) => `<Override PartName="/xl/worksheets/sheet${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`).join('')}<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>`],
    ['_rels/.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>'],
    ['xl/workbook.xml', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>${sheets.map((sh, i) => `<sheet name="${x(safe(sh.name))}" sheetId="${i + 1}" r:id="rId${i + 1}"/>`).join('')}</sheets></workbook>`],
    ['xl/_rels/workbook.xml.rels', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${sheets.map((_, i) => `<Relationship Id="rId${i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${i + 1}.xml"/>`).join('')}<Relationship Id="rId${sheets.length + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>`],
    ['xl/styles.xml', styles],
    ...sheets.map((sh, i) => [`xl/worksheets/sheet${i + 1}.xml`, sheetXml(sh)]),
  ];
  return zipStore(files);
}

function saveXlsxBytes(name, bytes) {
  const mime = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
  if (NativePrint.available()) {
    let bin = ''; for (let i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
    NativePrint.share(name, mime, btoa(bin), true).catch(e => toast(errText(e), true));
    return;
  }
  download(name, new Blob([bytes], { type: mime }), mime);
}

function downloadXlsx(name, rows, sheetName) {
  const bytes = xlsxBytes(rows, sheetName);
  const mime = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
  if (NativePrint.available()) {
    let bin = ''; for (let i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
    saveToPhone(name, mime, btoa(bin));
    return;
  }
  download(name, new Blob([bytes], { type: mime }), mime);
}

// ================= Arranque =================

function init() {
  Device.load();
  applyFontSize();
  Store.deviceId = Device.conf.id;
  Store.load();
  setTermOverrides(Store.settings.terms);
  loadTicket();
  Store.onSave = () => { Sync.schedule(); paintSyncBadge(); if (typeof paintBell === 'function') paintBell(); if ($('#modal-root').innerHTML) App.stale = true; };
  Sync.onStatus = paintSyncBadge;
  Sync.onKicked = why => { toast(t(why === 'err.revoked' ? 'err.revoked' : 'cloud.signedOut'), true); renderShell(); render(); };
  Sync.onRemoteChange = () => {
    moneyFmt = null;
    if (App.joining) return; // a ligar por código: a janela de sucesso mostra o resto
    if (App.user && !Store.find('employees', App.user.id)) { showLogin(); return; }
    refreshView();
  };
  // Acabou de escrever: aplicar os dados que chegaram entretanto.
  $('#main').addEventListener('focusout', () => { if (App.stale) setTimeout(refreshView, 300); });
  Sync.init(Device.conf.id);
  MENU_SVG = $('#menu-btn').innerHTML;
  initPullRefresh();
  $('#menu-btn').addEventListener('click', () => (App.back ? App.back.fn() : $('#app').classList.contains('nav-open') ? closeNav() : $('#app').classList.add('nav-open')));
  $('#scrim').addEventListener('click', closeNav);
  $('#sidebar').addEventListener('click', e => { if (e.target.closest('#sync-badge')) Sync.syncNow().catch(er => toast(errText(er), true)); });
  window.addEventListener('hashchange', () => { hideTip(); closeModal(); render(); });
  const tip = document.createElement('div');
  tip.id = 'chart-tip'; tip.className = 'chart-tip'; tip.hidden = true; tip.setAttribute('role', 'tooltip');
  document.body.appendChild(tip);
  document.addEventListener('pointerdown', e => { if (!e.target.closest('.chart, .donut')) hideTip(); });
  let resizeTimer = null;
  window.addEventListener('resize', () => { clearTimeout(resizeTimer); resizeTimer = setTimeout(() => { hideTip(); fitTitle(); if (App.onResize) App.onResize(); }, 150); });
  let saved = null;
  try { saved = sessionStorage.getItem('stoi-user'); } catch (e) { /* ignorar */ }
  const emp = saved && Store.find('employees', saved);
  if (emp) login(emp); else showLogin();
  if (Sync.enabled()) Sync.syncNow().catch(() => {});
  if (typeof Upd !== 'undefined') Upd.start();
  if ('serviceWorker' in navigator && /^https?:$/.test(location.protocol) && !Printer.available()) {
    navigator.serviceWorker.register('sw.js').catch(() => {});
  }
}

document.addEventListener('DOMContentLoaded', init);

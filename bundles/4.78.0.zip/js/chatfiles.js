'use strict';
// Stoi — ficheiros do chat (fotos, PDF e mensagens de voz) em qualidade original.
//
// O Firebase serve só de "carteiro": o ficheiro vai em partes para stores/{loja}/files e cada
// celular da loja recebe-o e guarda-o no próprio aparelho (IndexedDB e, no Android, na pasta
// Documentos/"Stoi Files App"). Quando todos os destinatários já o têm, ou passado o prazo
// escolhido (7 a 60 dias), as partes são apagadas da nuvem. Perto do limite grátis (1 GB),
// saem primeiro os mais antigos. A mensagem fica no chat com a miniatura e o estado.

/* global Chat, Store, FB, firebase, NativePrint, App, Sync, Capacitor, google, confirmDialog, $, $$, esc, t, toast, closeModal, icon, setRow, setTg, setVal, choiceModal, planeFly, PLANE_D */

const FILE_MAX = 10 * 1024 * 1024;
const CLOUD_SOFT = 900 * 1024 * 1024; // acima disto, saem os mais antigos
const CLOUD_FREE = 1024 * 1024 * 1024;
const VOICE_MAX = 300; // segundos
const MIC_SVG = '<svg class="mic" viewBox="0 0 24 24"><rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/></svg>';

const b64Blob = (b64, mime) => {
  const bin = atob(b64); const u = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
  return new Blob([u], { type: mime || 'application/octet-stream' });
};
const blobB64 = blob => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(String(r.result).slice(String(r.result).indexOf(',') + 1)); r.onerror = () => rej(r.error); r.readAsDataURL(blob); });
const fmtDur = s => { s = Math.max(0, Math.round(s || 0)); return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`; };

const FileBox = {
  _db: null, _urls: {}, _has: new Set(), _loading: {}, _p: {}, _sw: 0, _cur: null, _rate: 1,

  // ---------- Guardado no aparelho (IndexedDB) ----------
  db() {
    if (!this._db) this._db = new Promise((res, rej) => { const r = indexedDB.open('stoi-files', 1); r.onupgradeneeded = () => r.result.createObjectStore('f'); r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });
    return this._db;
  },
  async put(fid, blob) {
    const db = await this.db();
    await new Promise((res, rej) => { const tx = db.transaction('f', 'readwrite'); tx.objectStore('f').put(blob, fid); tx.oncomplete = res; tx.onerror = () => rej(tx.error); });
    this._has.add(fid);
    setTimeout(() => Drive.run(), 1500);
  },
  async get(fid) {
    const db = await this.db();
    return new Promise(res => { const r = db.transaction('f').objectStore('f').get(fid); r.onsuccess = () => res(r.result || null); r.onerror = () => res(null); });
  },
  async loadKeys() {
    try {
      const db = await this.db();
      await new Promise(res => { const r = db.transaction('f').objectStore('f').getAllKeys(); r.onsuccess = () => { (r.result || []).forEach(k => this._has.add(k)); res(); }; r.onerror = () => res(); });
    } catch (e) { /* sem IndexedDB */ }
  },
  has(fid) { return this._has.has(fid); },
  async url(fid) { if (this._urls[fid]) return this._urls[fid]; const b = await this.get(fid); return b ? (this._urls[fid] = URL.createObjectURL(b)) : null; },

  // ---------- Preferências ----------
  dev() { try { return Object.assign({ save: true, quality: 'orig' }, JSON.parse(localStorage.getItem('stoi-files-dev')) || {}); } catch (e) { return { save: true, quality: 'orig' }; } },
  setDev(p) { try { localStorage.setItem('stoi-files-dev', JSON.stringify(Object.assign(this.dev(), p))); } catch (e) { /* sem espaço */ } },
  days() { return Number((Store.settings.chatFiles || {}).days) || 30; },

  // ---------- Estado de cada ficheiro ----------
  state(m) {
    const f = m.file;
    if (this.has(f.id)) return 'local';
    if (this._loading[f.id] != null) return 'loading';
    return f.cloud === false ? 'gone' : 'cloud';
  },
  recipients(m) {
    // Na conversa da loja contam só os funcionários que usam o chat (já escreveram ou já receberam
    // algum ficheiro); quem nunca abriu o chat não fica à espera, sai pelo prazo.
    if (m.room === 'loja') {
      const ids = new Set();
      for (const x of Chat.msgs) { if (x.from && x.from !== 'sys') ids.add(x.from); (x.got || []).forEach(g => ids.add(g)); }
      ids.delete(m.from);
      return [...ids].filter(id => Store.find('employees', id));
    }
    if (m.room && m.room.startsWith('dm:')) return m.room.slice(3).split('+').filter(x => x !== m.from);
    return [];
  },
  cloudBytes(m) { return Math.ceil((m.file.size || 0) * 4 / 3); },
  cloudFiles() { return Chat.msgs.filter(m => m.file && m.file.cloud !== false && !m.pending); },

  // Receber: descarrega as partes (com progresso), guarda no aparelho e avisa que já tem.
  download(m) {
    const f = m.file;
    if (this.has(f.id)) return Promise.resolve(true);
    if (f.cloud === false || !Chat._uid) return Promise.resolve(false);
    if (this._p[f.id]) return this._p[f.id];
    this._p[f.id] = (async () => {
      this._loading[f.id] = 0; this.paintProgress(f.id, true);
      try {
        const col = FB.store(Chat._uid).collection('files'); const parts = [];
        const n = f.parts || 1;
        for (let i = 0; i < n; i++) {
          const d = await col.doc(`${f.id}__${i}`).get();
          if (!d.exists) throw new Error('missing');
          parts.push(d.data().d); this._loading[f.id] = (i + 1) / n; this.paintProgress(f.id);
        }
        const b64 = parts.join('');
        await this.put(f.id, b64Blob(b64, f.mime));
        if (this.dev().save && !Chat.mine(m)) this.saveToFolder(m, b64);
        if (!Chat.mine(m) && Chat.me()) FB.store(Chat._uid).collection('chat').doc(m.id).update({ got: firebase.firestore.FieldValue.arrayUnion(Chat.me().id) }).catch(() => {});
        return true;
      } catch (e) { return false; } finally {
        delete this._loading[f.id]; delete this._p[f.id];
        if (location.hash === '#chat') Chat.paint();
      }
    })();
    return this._p[f.id];
  },
  saveToFolder(m, b64) {
    const p = typeof NativePrint !== 'undefined' && NativePrint.plugin();
    if (!p || !p.saveFile) return;
    const d = new Date(Chat.ts(m));
    const stamp = `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}_${String(d.getHours()).padStart(2, '0')}${String(d.getMinutes()).padStart(2, '0')}`;
    p.saveFile({ name: `${stamp}_${m.file.name}`, mime: m.file.mime, data: b64, folder: 'Stoi Files App' }).catch(() => {});
  },
  // Receber sozinho tudo o que ainda está na nuvem (um de cada vez).
  async autoFetch() {
    if (this._auto || !this.dev().save || !Chat.ready) return;
    const list = Chat.msgs.filter(m => m.file && !m.deleted && !Chat.mine(m) && Chat.visible(m.room) && this.state(m) === 'cloud' && !m.pending);
    if (!list.length) return;
    this._auto = true;
    try { for (const m of list.reverse()) await this.download(m); } finally { this._auto = false; }
  },
  // Limpar a nuvem: quando todos já receberam, quando passou o prazo, ou perto do limite.
  sweep() {
    if (!Chat.ready || !Chat._uid) return;
    const now = Date.now();
    if (now - this._sw < 20000) return;
    this._sw = now;
    const lim = this.days() * 864e5, drop = [];
    const files = this.cloudFiles();
    for (const m of files) {
      const got = m.got || [], need = this.recipients(m);
      if (m.deleted || (need.length && need.every(id => got.includes(id))) || now - Chat.ts(m) > lim) drop.push(m);
    }
    const left = files.filter(m => !drop.includes(m)).sort((a, b) => Chat.ts(a) - Chat.ts(b));
    let total = left.reduce((a, m) => a + this.cloudBytes(m), 0);
    while (total > CLOUD_SOFT && left.length) { const m = left.shift(); drop.push(m); total -= this.cloudBytes(m); }
    for (const m of drop) this.dropCloud(m);
  },
  dropCloud(m) {
    const col = FB.store(Chat._uid).collection('files');
    for (let i = 0; i < (m.file.parts || 1); i++) col.doc(`${m.file.id}__${i}`).delete().catch(() => {});
    FB.store(Chat._uid).collection('chat').doc(m.id).update({ 'file.cloud': false }).catch(() => {});
  },
  onSnap() { this.sweep(); this.autoFetch().then(() => Drive.run()); },

  // ---------- Desenho no chat ----------
  html(m) {
    const f = m.file, st = this.state(m);
    if (f.kind === 'audio') return this.voiceHtml(m, st);
    const sz = esc(fmtKB(f.size));
    if (f.kind === 'img') {
      if (st === 'gone') return this.goneHtml(m, t('att.photoGone'));
      const src = this._urls[f.id] || f.thumb || '';
      if (st === 'local') return `<button type="button" class="ch-ph" data-file="${esc(m.id)}"><img src="${esc(src)}" data-lfid="${esc(f.id)}" alt=""></button>`;
      const pc = Math.round((this._loading[f.id] || 0) * 100);
      return `<button type="button" class="ch-ph ph-wait" data-file="${esc(m.id)}"><img src="${esc(src)}" alt="">
        <span class="ph-ring">${st === 'loading' ? `<b data-fp="${esc(f.id)}">${pc}%</b>` : '<svg viewBox="0 0 24 24"><path d="M12 4v12M7 11l5 5 5-5M5 20h14"/></svg>'}</span>
        <span class="ph-badge">${esc(st === 'loading' ? t('att.arriving') : t('att.tapSave'))} · ${sz}</span></button>`;
    }
    const ext = (f.name.split('.').pop() || 'DOC').slice(0, 4).toUpperCase();
    const col = ext === 'PDF' ? '#e53935' : /XLS|CSV/.test(ext) ? '#16a34a' : /DOC/.test(ext) ? '#2563eb' : '#64748b';
    const sub = st === 'local' ? `<span class="ok">${esc(t('att.onPhone'))}</span>` : st === 'loading' ? `${esc(t('att.arriving'))} <b data-fp="${esc(f.id)}">${Math.round((this._loading[f.id] || 0) * 100)}%</b>` : st === 'gone' ? esc(t('att.gone')) : esc(t('att.tapSave'));
    return `<button type="button" class="ch-doc ${st === 'gone' ? 'gone' : ''}" data-file="${esc(m.id)}"><span class="ch-doc-ic" style="background:${col}">${esc(ext)}</span><span class="ch-doc-tx"><b>${esc(f.name)}</b><small>${sz} · ${sub}</small></span></button>`;
  },
  goneHtml(m, what) {
    return `<span class="ch-gone"><svg viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="3"/><path d="m3 3 18 18"/></svg><span>${esc(what)}<small>${esc(Chat.mine(m) ? t('att.goneMine') : t('att.goneAsk', { name: m.name }))}</small></span></span>`;
  },
  voiceHtml(m, st) {
    const f = m.file, wave = Array.isArray(f.wave) && f.wave.length ? f.wave : Array(32).fill(0.3);
    const bars = wave.map(v => `<i style="height:${Math.round(4 + Math.min(1, v) * 22)}px"></i>`).join('');
    // Modelo B: botão verde, onda e tempo na mesma linha; a velocidade aparece a tocar.
    const play = st === 'loading' ? `<b class="vm-pc" data-fp="${esc(f.id)}">${Math.round((this._loading[f.id] || 0) * 100)}%</b>` : '<svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>';
    return `<span class="vm vmb ${st === 'gone' ? 'gone' : ''}" data-voice="${esc(m.id)}"><button type="button" class="vm-pl" data-vplay aria-label="${esc(t('att.play'))}">${play}</button><span class="vm-wv">${bars}<span class="vm-dot" hidden></span></span><span class="vm-dur" data-vt>${st === 'gone' ? '—' : fmtDur(f.dur)}</span><button type="button" class="vm-sp" data-vsp hidden>1×</button></span>${st === 'gone' ? `<span class="vm-gone">${esc(t('att.voiceGone'))}</span>` : ''}`;
  },
  paintProgress(fid, full) {
    if (full) { if (location.hash === '#chat') Chat.paint(); return; }
    const pc = `${Math.round((this._loading[fid] || 0) * 100)}%`;
    document.querySelectorAll(`[data-fp="${CSS.escape(fid)}"]`).forEach(el => { el.textContent = pc; });
  },
  // Depois de desenhar: fotos guardadas com qualidade original, áudio a tocar, aviso de prazo.
  hydrate(root, room) {
    root.querySelectorAll('img[data-lfid]').forEach(async img => { const u = await this.url(img.dataset.lfid); if (u && img.src !== u) img.src = u; });
    root.querySelectorAll('[data-voice]').forEach(el => {
      const m = Chat.msgs.find(x => x.id === el.dataset.voice);
      if (!m) return;
      $('[data-vplay]', el).addEventListener('click', e => { e.stopPropagation(); if (Chat.sel.size) return; this.play(m); });
      const sp = el.querySelector('[data-vsp]');
      if (sp) sp.addEventListener('click', e => { e.stopPropagation(); this._rate = this._rate === 1 ? 1.5 : this._rate === 1.5 ? 2 : 1; if (this._cur) this._cur.a.playbackRate = this._rate; this.paintVoice(); });
    });
    this.paintVoice();
    this.banner(root, room);
  },
  banner(root, room) {
    const old = root.querySelector('.exp-bar'); if (old) old.remove();
    const now = Date.now(), lim = this.days() * 864e5;
    const list = Chat.inRoom(room).filter(m => m.file && !m.deleted && !Chat.mine(m) && this.state(m) === 'cloud' && Chat.ts(m) + lim - now < 3 * 864e5);
    if (!list.length) return;
    const d = Math.max(0, Math.ceil(Math.min(...list.map(m => Chat.ts(m) + lim - now)) / 864e5));
    const msgs = root.querySelector('#ch-msgs');
    if (!msgs) return;
    msgs.insertAdjacentHTML('beforebegin', `<div class="exp-bar"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg><span><b>${esc(t(d <= 1 ? 'att.exp1' : 'att.expN', { n: list.length, d }))}</b>${esc(t('att.expHint'))}</span><button type="button">${esc(t('att.saveAll'))}</button></div>`);
    root.querySelector('.exp-bar button').onclick = async () => { for (const m of list) await this.download(m); };
  },

  // ---------- Abrir ----------
  async open(m) {
    const f = m.file;
    if (!this.has(f.id)) {
      if (f.cloud === false) { toast(t('att.gone'), true); return; }
      if (!await this.download(m)) { toast(t('att.notYet'), true); return; }
    }
    const blob = await this.get(f.id);
    if (!blob) return;
    if (f.kind === 'audio') { this.play(m); return; }
    if (f.kind === 'img') { imageViewer(await this.url(f.id)); return; }
    if (typeof NativePrint !== 'undefined' && NativePrint.available()) { NativePrint.share(f.name, f.mime, await blobB64(blob), true).catch(e => toast(String(e && e.message || e), true)); return; }
    const a = document.createElement('a');
    a.href = await this.url(f.id); a.download = f.name;
    document.body.appendChild(a); a.click(); a.remove();
  },

  // ---------- Ouvir mensagens de voz ----------
  async play(m) {
    const f = m.file;
    if (this._cur && this._cur.id === m.id) { const a = this._cur.a; if (a.paused) a.play().catch(() => {}); else a.pause(); this.paintVoice(); return; }
    this.stopAudio();
    if (!this.has(f.id)) { if (!await this.download(m)) { toast(t(f.cloud === false ? 'att.voiceGone' : 'att.notYet'), true); return; } }
    const a = new Audio(await this.url(f.id));
    a.playbackRate = this._rate;
    this._cur = { id: m.id, a, dur: f.dur || 0 };
    a.ontimeupdate = () => this.paintVoice();
    a.onpause = () => this.paintVoice();
    a.onended = () => { this._cur = null; this.paintVoice(m.id); };
    a.play().catch(() => {});
    this.paintVoice();
  },
  stopAudio() { if (this._cur) { const id = this._cur.id; this._cur.a.pause(); this._cur = null; this.paintVoice(id); } },
  paintVoice(endedId) {
    document.querySelectorAll('[data-voice]').forEach(el => {
      const on = this._cur && this._cur.id === el.dataset.voice;
      const m = Chat.msgs.find(x => x.id === el.dataset.voice);
      if (!m || (!on && endedId !== el.dataset.voice && !el.classList.contains('playing'))) return;
      const a = on ? this._cur.a : null;
      const dur = (a && isFinite(a.duration) && a.duration) || m.file.dur || 1;
      const fr = a ? Math.min(1, a.currentTime / dur) : 0;
      el.classList.toggle('playing', !!on);
      const bars = el.querySelectorAll('.vm-wv i');
      bars.forEach((b, i) => b.classList.toggle('p', !!on && i / bars.length < fr));
      const dot = el.querySelector('.vm-dot'); if (dot) { dot.style.left = `${fr * 100}%`; dot.hidden = !on; }
      const pl = el.querySelector('[data-vplay]');
      if (pl && !pl.querySelector('[data-fp]')) pl.innerHTML = `<svg viewBox="0 0 24 24">${on && a && !a.paused ? '<path d="M7 5h4v14H7zM13 5h4v14h-4z"/>' : '<path d="M8 5v14l11-7z"/>'}</svg>`;
      const vt = el.querySelector('[data-vt]'); if (vt) vt.textContent = on ? fmtDur(a.currentTime) : fmtDur(m.file.dur);
      const sp = el.querySelector('[data-vsp]'); if (sp) { sp.hidden = !on; sp.textContent = `${String(this._rate).replace('.', ',')}×`; }
    });
  },
};

// ---------- Gravar mensagens de voz ----------
// Manter premido o microfone: grava. Largar: envia. Deslizar para a esquerda: cancela.
// Deslizar para cima até ao cadeado: fica a gravar sem segurar (apagar, pausa, enviar).
const Rec = {
  on: false,
  async start() {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } });
    const mime = ['audio/webm;codecs=opus', 'audio/webm', 'audio/mp4', 'audio/ogg;codecs=opus'].find(x => window.MediaRecorder && MediaRecorder.isTypeSupported(x)) || '';
    const rec = new MediaRecorder(stream, mime ? { mimeType: mime, audioBitsPerSecond: 24000 } : undefined);
    const chunks = [];
    rec.ondataavailable = e => { if (e.data && e.data.size) chunks.push(e.data); };
    rec.start(250);
    const Ctx = window.AudioContext || window.webkitAudioContext;
    const ctx = Ctx ? new Ctx() : null, an = ctx ? ctx.createAnalyser() : null;
    if (an) { an.fftSize = 512; ctx.createMediaStreamSource(stream).connect(an); }
    Object.assign(this, { on: true, stream, rec, chunks, ctx, an, mime: rec.mimeType || mime || 'audio/webm', peaks: [], acc: 0, t0: Date.now(), paused: false });
  },
  level() {
    if (!this.an) return 0.3 + Math.random() * 0.4;
    const d = new Uint8Array(this.an.fftSize); this.an.getByteTimeDomainData(d);
    let s = 0; for (const v of d) { const x = (v - 128) / 128; s += x * x; }
    return Math.min(1, Math.sqrt(s / d.length) * 3.2);
  },
  elapsed() { return (this.acc + (this.paused ? 0 : Date.now() - this.t0)) / 1000; },
  pause() { if (this.paused) return; this.rec.pause(); this.acc += Date.now() - this.t0; this.paused = true; },
  resume() { if (!this.paused) return; this.rec.resume(); this.t0 = Date.now(); this.paused = false; },
  wave(n = 40) {
    const p = this.peaks.length ? this.peaks : [0.2];
    const out = [];
    for (let i = 0; i < n; i++) { const a = Math.floor(i * p.length / n), b = Math.max(a + 1, Math.floor((i + 1) * p.length / n)); out.push(Math.max(...p.slice(a, b))); }
    const mx = Math.max(...out) || 1;
    return out.map(v => Math.round(Math.max(0.08, v / mx) * 100) / 100);
  },
  cleanup() {
    this.on = false;
    if (this.stream) this.stream.getTracks().forEach(tr => tr.stop());
    if (this.ctx) this.ctx.close().catch(() => {});
  },
  stop() {
    return new Promise(res => {
      const dur = this.elapsed(), wave = this.wave(), mime = this.mime;
      this.rec.onstop = () => { this.cleanup(); res({ blob: new Blob(this.chunks, { type: mime }), dur, wave, mime }); };
      if (this.rec.state === 'inactive') this.rec.onstop(); else this.rec.stop();
    });
  },
  cancel() { try { if (this.rec && this.rec.state !== 'inactive') this.rec.stop(); } catch (e) { /* já parado */ } this.cleanup(); },
};

// Liga o microfone ao botão de enviar de uma conversa aberta.
function wireVoice(room, main, getReply, clearReply) {
  const btn = $('#ch-send', main), ta = $('#ch-text', main), bar = $('.ch-bar', main);
  if (!btn || !ta || !window.MediaRecorder || !navigator.mediaDevices) return;
  const plane = `<svg viewBox="0 0 24 24"><path d="${PLANE_D}"/></svg>`;
  const setBtn = () => {
    const mic = !ta.value.trim() && !Chat.getCard(room) && !Rec.on;
    if (btn.classList.contains('mic') === mic && btn.firstChild) return;
    btn.classList.toggle('mic', mic); btn.innerHTML = mic ? MIC_SVG : plane;
    btn.setAttribute('aria-label', t(mic ? 'rec.hold' : 'chat.send'));
  };
  setBtn();
  ta.addEventListener('input', setBtn);
  let st = null, timer = null;
  const ui = () => {
    let v = $('.rec-ui', bar);
    if (!v) { bar.classList.add('recording'); $('.ch-in', bar).insertAdjacentHTML('afterend', '<div class="rec-ui"></div>'); v = $('.rec-ui', bar); }
    const lv = (st.lv || []).slice(-22).map(x => `<i style="height:${Math.round(4 + x * 20)}px"></i>`).join('');
    v.innerHTML = st.locked
      ? `<button type="button" class="rec-del" aria-label="${esc(t('common.delete'))}"><svg viewBox="0 0 24 24"><path d="M3 6h18M8 6V4h8v2M6 6l1 14a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-14"/></svg></button><span class="rec-dot ${Rec.paused ? 'off' : ''}"></span><b>${fmtDur(Rec.elapsed())}</b><span class="rec-lv">${lv}</span><button type="button" class="rec-pause" aria-label="Pausa"><svg viewBox="0 0 24 24">${Rec.paused ? '<path d="M8 5v14l11-7z"/>' : '<path d="M9 5v14M15 5v14"/>'}</svg></button>`
      : `<span class="rec-dot"></span><b>${fmtDur(Rec.elapsed())}</b><span class="rec-lv">${lv}</span><small>‹ ${esc(t('rec.cancel'))}</small>`;
    if (st.locked) {
      $('.rec-del', v).onclick = () => end(false);
      $('.rec-pause', v).onclick = () => { if (Rec.paused) Rec.resume(); else Rec.pause(); ui(); };
    }
  };
  const lockPill = on => {
    let l = $('.rec-lock', main);
    if (on && !l) { main.querySelector('.ch-room').insertAdjacentHTML('beforeend', '<div class="rec-lock"><svg viewBox="0 0 24 24"><rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/></svg><svg viewBox="0 0 24 24"><path d="m6 15 6-6 6 6"/></svg></div>'); }
    if (!on && l) l.remove();
  };
  const reset = () => {
    clearInterval(timer); timer = null; st = null;
    bar.classList.remove('recording'); btn.classList.remove('rec-big');
    const v = $('.rec-ui', bar); if (v) v.remove();
    lockPill(false); setBtn();
    if (Chat._dirty) { Chat._dirty = false; Chat.paint(); }
  };
  const end = async send => {
    if (!st) return;
    const s = st; st.ending = true;
    if (!Rec.on) { reset(); return; }
    if (!send) { Rec.cancel(); reset(); return; }
    const r = await Rec.stop();
    reset();
    if (r.dur < 0.8) { toast(t('rec.short')); return; }
    const ext = /mp4/.test(r.mime) ? 'm4a' : /ogg/.test(r.mime) ? 'ogg' : 'webm';
    planeFly(btn);
    Chat.send(room, '', getReply(), { kind: 'audio', name: `voz-${Date.now()}.${ext}`, mime: r.mime.split(';')[0], size: r.blob.size, b64: await blobB64(r.blob), wave: r.wave, dur: Math.round(r.dur * 10) / 10 });
    clearReply();
    return s;
  };
  btn.addEventListener('pointerdown', async e => {
    if (!btn.classList.contains('mic') || st) return;
    e.preventDefault();
    try { btn.setPointerCapture(e.pointerId); } catch (er) { /* sem captura */ }
    st = { x0: e.clientX, y0: e.clientY, down: true, locked: false, lv: [], at: Date.now() };
    btn.classList.add('rec-big');
    if (navigator.vibrate) navigator.vibrate(15);
    const t0 = Date.now();
    try { await Rec.start(); } catch (er) { toast(t('rec.noMic'), true); reset(); return; }
    if (!st || st.ending) { Rec.cancel(); reset(); return; }
    // A 1.ª vez o celular pergunta pelo microfone e o dedo sai do botão: recomeça do zero.
    if (Date.now() - t0 > 1500) { Rec.cancel(); reset(); toast(t('rec.hold')); return; }
    if (!st.down && !st.locked) { // largou antes de o microfone abrir
      Rec.cancel(); reset(); toast(t('rec.hold')); return;
    }
    lockPill(!st.locked);
    timer = setInterval(() => {
      if (!st) return;
      if (!Rec.paused) { const l = Rec.level(); Rec.peaks.push(l); st.lv.push(l); }
      if (Rec.elapsed() >= VOICE_MAX) { end(true); return; }
      ui();
    }, 100);
    ui();
  });
  btn.addEventListener('pointermove', e => {
    if (!st || !st.down || st.locked) return;
    const dx = e.clientX - st.x0, dy = e.clientY - st.y0;
    if (dx < -90) { st.down = false; end(false); if (navigator.vibrate) navigator.vibrate(30); return; }
    if (dy < -70 && Rec.on) { st.locked = true; st.down = false; lockPill(false); btn.classList.remove('rec-big'); btn.classList.remove('mic'); btn.innerHTML = plane; ui(); }
  });
  const up = () => {
    if (!st || !st.down) return;
    st.down = false;
    if (!Rec.on) return; // ainda a abrir o microfone: o pointerdown trata
    if (Date.now() - st.at < 450) { end(false); toast(t('rec.hold')); return; }
    end(true);
  };
  btn.addEventListener('pointerup', up);
  btn.addEventListener('pointercancel', () => { if (st && st.down) { st.down = false; end(false); } });
  btn.addEventListener('click', e => {
    if (st && st.locked) { e.stopImmediatePropagation(); end(true); return; }
    if (btn.classList.contains('mic') || st) e.stopImmediatePropagation();
  }, true);
}

// ---------- Cópia no Google Drive (cada pessoa liga a sua conta) ----------
// O app só pede "drive.file": vê apenas o que ele próprio cria (a pasta "Stoi Files App").
const Drive = {
  SCOPE: 'https://www.googleapis.com/auth/drive.file',
  FOLDER: 'Stoi Files App',
  _tok: null, _busy: false,
  key() { return `stoi-drive-${App.user ? App.user.id : ''}`; },
  conf() { const d = { email: '', on: true, wifi: true, done: {}, count: 0, last: 0, folder: '' }; try { return Object.assign(d, JSON.parse(localStorage.getItem(this.key())) || {}); } catch (e) { return d; } },
  save(p) { try { localStorage.setItem(this.key(), JSON.stringify(Object.assign(this.conf(), p))); } catch (e) { /* sem espaço */ } },
  linked() { return !!this.conf().email; },
  clientId() { return (window.STOI_FIREBASE || {}).googleClientId || ''; },
  available() { return !!this.clientId(); },
  native() { return typeof Capacitor !== 'undefined' && Capacitor.isNativePlatform && Capacitor.isNativePlatform() && Capacitor.Plugins && Capacitor.Plugins.SocialLogin; },
  async token(interactive) {
    if (this._tok && this._tok.exp > Date.now() + 60000) return this._tok.v;
    if (this.native()) {
      const SL = Capacitor.Plugins.SocialLogin;
      if (!Sync._slInit) { await SL.initialize({ google: { webClientId: this.clientId(), skipAuthOnlyAuthorizationAfterSignIn: true } }); Sync._slInit = true; }
      const opt = interactive ? { scopes: [this.SCOPE], forcePrompt: true } : { scopes: [this.SCOPE], style: 'bottom', filterByAuthorizedAccounts: true, autoSelectEnabled: true };
      const res = await SL.login({ provider: 'google', options: opt });
      const r = (res && res.result) || {};
      const v = r.accessToken && (r.accessToken.token || r.accessToken);
      if (!v || typeof v !== 'string') throw new Error('no-token');
      this._tok = { v, exp: Date.now() + 50 * 60000, email: r.profile && r.profile.email };
      return v;
    }
    await new Promise((res, rej) => {
      if (window.google && google.accounts && google.accounts.oauth2) { res(); return; }
      const sc = document.createElement('script'); sc.src = 'https://accounts.google.com/gsi/client'; sc.onload = res; sc.onerror = () => rej(new Error('offline')); document.head.appendChild(sc);
    });
    return new Promise((res, rej) => {
      const c = google.accounts.oauth2.initTokenClient({ client_id: this.clientId(), scope: this.SCOPE, prompt: interactive ? 'select_account' : '',
        callback: r => { if (r.error || !r.access_token) { rej(new Error(r.error || 'no-token')); return; } this._tok = { v: r.access_token, exp: Date.now() + (r.expires_in || 3500) * 1000 }; res(r.access_token); },
        error_callback: e => rej(new Error((e && e.type) || 'cancel')) });
      c.requestAccessToken();
    });
  },
  async api(url, opts = {}, tok) {
    const r = await fetch(url, Object.assign({}, opts, { headers: Object.assign({ Authorization: `Bearer ${tok}` }, opts.headers || {}) }));
    if (r.status === 401) { this._tok = null; throw new Error('auth'); }
    if (!r.ok) throw new Error(`drive ${r.status}`);
    return r;
  },
  async folder(tok) {
    const c = this.conf();
    if (c.folder) return c.folder;
    const q = encodeURIComponent(`name='${this.FOLDER}' and mimeType='application/vnd.google-apps.folder' and trashed=false`);
    const l = await (await this.api(`https://www.googleapis.com/drive/v3/files?q=${q}&fields=files(id)&spaces=drive`, {}, tok)).json();
    let id = l.files && l.files[0] && l.files[0].id;
    if (!id) id = (await (await this.api('https://www.googleapis.com/drive/v3/files?fields=id', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name: this.FOLDER, mimeType: 'application/vnd.google-apps.folder' }) }, tok)).json()).id;
    this.save({ folder: id });
    return id;
  },
  // Ligar a conta: pede a autorização (uma vez) e mostra o e-mail.
  async link() {
    const tok = await this.token(true);
    let email = this._tok && this._tok.email;
    try { const a = await (await this.api('https://www.googleapis.com/drive/v3/about?fields=user(emailAddress)', {}, tok)).json(); email = (a.user && a.user.emailAddress) || email; } catch (e) { /* fica o do login */ }
    this.save({ email: email || 'Google Drive', on: true, folder: '' });
    await this.folder(tok);
    this.run();
  },
  unlink() {
    try { localStorage.removeItem(this.key()); } catch (e) { /* nada */ }
    this._tok = null;
    if (this.native()) Capacitor.Plugins.SocialLogin.logout({ provider: 'google' }).catch(() => {});
  },
  wifiOk() { const c = navigator.connection; return !this.conf().wifi || !c || !c.type || ['wifi', 'ethernet', 'unknown'].includes(c.type); },
  // Copia para o Drive os ficheiros guardados neste celular que ainda lá não estão.
  async run() {
    if (this._busy || !this.linked() || !this.conf().on || !this.wifiOk() || typeof Chat === 'undefined' || !Chat.ready) return;
    const done = this.conf().done;
    const list = Chat.msgs.filter(m => m.file && !m.deleted && Chat.visible(m.room) && FileBox.has(m.file.id) && !done[m.file.id]);
    if (!list.length) return;
    this._busy = true;
    try {
      const tok = await this.token(false);
      const dir = await this.folder(tok);
      for (const m of list) {
        const blob = await FileBox.get(m.file.id);
        if (!blob) continue;
        const d = new Date(Chat.ts(m));
        const p2 = x => String(x).padStart(2, '0');
        const name = `${d.getFullYear()}${p2(d.getMonth() + 1)}${p2(d.getDate())}_${p2(d.getHours())}${p2(d.getMinutes())}_${m.file.name}`;
        const start = await this.api('https://www.googleapis.com/upload/drive/v3/files?uploadType=resumable&fields=id', { method: 'POST', headers: { 'Content-Type': 'application/json; charset=UTF-8', 'X-Upload-Content-Type': m.file.mime }, body: JSON.stringify({ name, parents: [dir], description: `Stoi · ${m.name}` }) }, tok);
        const loc = start.headers.get('Location');
        if (!loc) throw new Error('no-upload-url');
        await this.api(loc, { method: 'PUT', headers: { 'Content-Type': m.file.mime }, body: blob }, tok);
        const c = this.conf(); c.done[m.file.id] = 1;
        this.save({ done: c.done, count: (c.count || 0) + 1, last: Date.now() });
      }
    } catch (e) {
      if (/folder|404/.test(String(e.message))) this.save({ folder: '' });
    } finally {
      this._busy = false;
      const box = document.querySelector('[data-set="chatfiles"]');
      if (box && !box.hidden && typeof wireChatFilesSettings === 'function') { box.innerHTML = chatFilesSettingsHtml(); wireChatFilesSettings(box.parentElement); }
    }
  },
};

// ---------- Configurações › Ficheiros do chat ----------
function chatFilesSummary() { return t('cf.sum', { d: FileBox.days() }); }
function chatFilesSettingsHtml() {
  const dv = FileBox.dev(), days = FileBox.days();
  const files = typeof Chat !== 'undefined' ? FileBox.cloudFiles() : [];
  const used = files.reduce((a, m) => a + FileBox.cloudBytes(m), 0);
  return `<div class="sx-gt">${esc(t('cf.gFiles'))}</div><div class="sx-list">
      ${setRow('cf-q', t('cf.quality'), t(dv.quality === 'light' ? 'cf.qLightSub' : 'cf.qOrigSub'), setVal(t(dv.quality === 'light' ? 'cf.qLight' : 'cf.qOrig')))}
      ${setRow('cf-save', t('cf.save'), t('cf.saveSub'), setTg(dv.save))}</div>
    <div class="sx-gt">${esc(t('cf.gCloud'))}</div>
    <div class="sx-list"><div class="cf-box"><b>${esc(t('cf.days'))}</b><div class="muted small">${esc(t('cf.daysSub'))}</div>
      <div class="cf-seg">${[7, 15, 30, 60].map(d => `<button type="button" class="${d === days ? 'on' : ''}" data-cfd="${d}">${esc(t('cf.nDays', { n: d }))}</button>`).join('')}</div></div></div>
    <div class="sx-list" style="margin-top:10px"><div class="cf-box"><b>${esc(t('cf.space'))}</b><div class="cf-bar"><i style="width:${Math.min(100, used / CLOUD_FREE * 100).toFixed(1)}%"></i></div>
      <div class="muted small">${esc(t('cf.spaceSub', { used: used ? fmtKB(used) : '0 MB', n: files.length }))}</div><div class="muted small" style="margin-top:6px">${esc(t('cf.spaceHint'))}</div></div></div>
    <div class="sx-gt">${esc(t('cf.gBackup', { name: App.user ? App.user.name : '' }))}</div>
    ${chatDriveHtml()}`;
}
const CLOUD_IC = '<span class="sx-ic" style="background:#2563eb"><svg viewBox="0 0 24 24"><path d="M7 18a4.5 4.5 0 0 1-.6-9A6 6 0 0 1 18 8.5a4.5 4.5 0 0 1-.5 9.5z"/><path d="M12 11v5M9.5 13.5 12 11l2.5 2.5"/></svg></span>';
function chatDriveHtml() {
  if (!Drive.available()) return `<div class="sx-list"><div class="cf-drive">${CLOUD_IC}<span class="sx-t"><b>Google Drive</b><small>${esc(t('cf.driveNo'))}</small></span></div></div>`;
  const c = Drive.conf();
  if (!c.email) {
    return `<div class="sx-list"><div class="cf-drive">${CLOUD_IC}<span class="sx-t"><b>Google Drive</b><small>${esc(t('cf.driveNone'))}</small></span></div>
      <div style="padding:0 12px 12px"><button type="button" class="btn primary" style="width:100%" data-drv="link">${esc(t('cf.driveAdd'))}</button></div></div>
      <p class="muted small" style="margin:8px 4px 0">${esc(t('cf.driveHint'))}</p>`;
  }
  const ago = c.last ? fmtAgo(c.last) : '—';
  return `<div class="sx-list"><div class="cf-drive">${CLOUD_IC}<span class="sx-t" style="min-width:0"><b class="cf-mail">${esc(c.email)}</b><small>${esc(t('cf.driveFolder'))}</small></span><button type="button" class="btn" data-drv="swap">${esc(t('cf.driveSwap'))}</button></div>
      ${setRow('drv-on', t('cf.driveAuto'), t('cf.driveAutoSub'), setTg(c.on))}
      ${setRow('drv-now', t('cf.driveLast'), t('cf.driveLastSub', { n: c.count || 0, ago }), setVal(''))}
      ${setRow('drv-wifi', t('cf.driveWifi'), t('cf.driveWifiSub'), setTg(c.wifi))}
      <button type="button" class="sx-row cf-unlink" data-drv="unlink">${esc(t('cf.driveRemove'))}</button></div>`;
}
const fmtAgo = ms => { const s = Math.round((Date.now() - ms) / 1000); return s < 60 ? t('cf.agoNow') : s < 3600 ? t('cf.agoMin', { n: Math.round(s / 60) }) : s < 86400 ? t('cf.agoH', { n: Math.round(s / 3600) }) : new Date(ms).toLocaleDateString(); };
function wireChatFilesSettings(root) {
  const box = $('[data-set="chatfiles"]', root);
  if (!box) return;
  const repaint = () => { box.innerHTML = chatFilesSettingsHtml(); wireChatFilesSettings(root); };
  const q = $('[data-setk="cf-q"]', box);
  if (q) q.onclick = () => choiceModal({ title: t('cf.quality'), value: FileBox.dev().quality, options: [['orig', t('cf.qOrig')], ['light', t('cf.qLight')]], onPick: v => { FileBox.setDev({ quality: v }); repaint(); } });
  const sv = $('[data-setk="cf-save"]', box);
  if (sv) sv.onclick = () => { FileBox.setDev({ save: !FileBox.dev().save }); repaint(); if (FileBox.dev().save) FileBox.autoFetch(); };
  const link = async () => {
    try { await Drive.link(); toast(t('cf.driveOk')); } catch (e) { const msg = String((e && (e.message || e.errorMessage)) || e || ''); if (!/cancel/i.test(msg)) toast(t('cf.driveFail'), true); }
    repaint();
  };
  $$('[data-drv="link"], [data-drv="swap"]', box).forEach(b => { b.onclick = async () => { if (b.dataset.drv === 'swap') Drive.unlink(); await link(); }; });
  const un = $('[data-drv="unlink"]', box);
  if (un) un.onclick = async () => { if (!await confirmDialog(t('cf.driveRemoveQ'), t('cf.driveRemove'), true)) return; Drive.unlink(); repaint(); };
  const on = $('[data-setk="drv-on"]', box); if (on) on.onclick = () => { Drive.save({ on: !Drive.conf().on }); repaint(); Drive.run(); };
  const wf = $('[data-setk="drv-wifi"]', box); if (wf) wf.onclick = () => { Drive.save({ wifi: !Drive.conf().wifi }); repaint(); Drive.run(); };
  const nw = $('[data-setk="drv-now"]', box); if (nw) nw.onclick = () => { toast(t('cf.driveRunning')); Drive.run(); };
  $$('[data-cfd]', box).forEach(b => b.addEventListener('click', () => {
    Store.settings.chatFiles = Object.assign({}, Store.settings.chatFiles, { days: Number(b.dataset.cfd) });
    Store.save(); repaint(); toast(t('settings.saved'));
  }));
}

FileBox.loadKeys().then(() => { if (typeof Chat !== 'undefined' && location.hash === '#chat') Chat.paint(); });

// ---------- Ver uma foto ----------
// Ecrã limpo (só a foto, fundo preto): dois dedos ou dois toques para ampliar, arrastar para
// mover a foto ampliada, e deslizar para baixo (ou para cima) para fechar.
function imageViewer(src) {
  const old = document.querySelector('.iv'); if (old) old.remove();
  const v = document.createElement('div');
  v.className = 'iv';
  v.innerHTML = `<img src="${esc(src)}" alt="" draggable="false">`;
  document.body.appendChild(v);
  const img = v.firstChild;
  let s = 1, x = 0, y = 0, dragY = 0, anim = false;
  const pts = new Map();
  let start = null, pinch = null, lastTap = 0;
  const apply = () => {
    img.style.transition = anim ? 'transform .22s ease' : 'none';
    img.style.transform = `translate(${x}px, ${y + dragY}px) scale(${s})`;
    v.style.backgroundColor = `rgba(0,0,0,${s > 1 ? 1 : Math.max(0.15, 1 - Math.abs(dragY) / 450)})`;
  };
  const close = () => {
    anim = true; dragY = (dragY < 0 ? -1 : 1) * window.innerHeight; apply();
    v.style.transition = 'background-color .22s'; v.style.backgroundColor = 'rgba(0,0,0,0)';
    setTimeout(() => v.remove(), 220);
  };
  v.ivClose = close;
  const clampPan = () => {
    const r = img.getBoundingClientRect(), W = window.innerWidth, H = window.innerHeight;
    const mx = Math.max(0, (r.width - W) / 2), my = Math.max(0, (r.height - H) / 2);
    x = Math.max(-mx, Math.min(mx, x)); y = Math.max(-my, Math.min(my, y));
  };
  const zoomTo = (ns, cx, cy) => {
    const W = window.innerWidth / 2, H = window.innerHeight / 2;
    // mantém o ponto tocado no mesmo sítio
    x = (x - (cx - W)) * (ns / s) + (cx - W); y = (y - (cy - H)) * (ns / s) + (cy - H);
    s = ns;
    if (s <= 1.01) { s = 1; x = 0; y = 0; }
  };
  v.addEventListener('pointerdown', e => {
    v.setPointerCapture(e.pointerId);
    pts.set(e.pointerId, { x: e.clientX, y: e.clientY });
    anim = false;
    if (pts.size === 2) {
      const [a, b] = [...pts.values()];
      pinch = { d: Math.hypot(a.x - b.x, a.y - b.y), s, cx: (a.x + b.x) / 2, cy: (a.y + b.y) / 2 };
      start = null; dragY = 0;
    } else if (pts.size === 1) {
      start = { x: e.clientX, y: e.clientY, x0: x, y0: y, t: Date.now(), moved: false };
    }
  });
  v.addEventListener('pointermove', e => {
    if (!pts.has(e.pointerId)) return;
    pts.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (pinch && pts.size >= 2) {
      const [a, b] = [...pts.values()];
      const ns = Math.max(1, Math.min(5, pinch.s * Math.hypot(a.x - b.x, a.y - b.y) / pinch.d));
      zoomTo(ns, pinch.cx, pinch.cy); clampPan(); apply();
      return;
    }
    if (!start) return;
    const dx = e.clientX - start.x, dy = e.clientY - start.y;
    if (Math.abs(dx) + Math.abs(dy) > 8) start.moved = true;
    if (s > 1) { x = start.x0 + dx; y = start.y0 + dy; clampPan(); } else dragY = dy;
    apply();
  });
  const up = e => {
    pts.delete(e.pointerId);
    if (pinch) { if (pts.size < 2) { pinch = null; anim = true; if (s <= 1.05) zoomTo(1, 0, 0); apply(); } start = null; return; }
    if (!start) return;
    const st = start; start = null;
    if (s === 1 && Math.abs(dragY) > 110) { close(); return; }
    anim = true; dragY = 0;
    if (!st.moved && Date.now() - st.t < 250) { // dois toques: ampliar / voltar ao normal
      if (Date.now() - lastTap < 320) { zoomTo(s > 1 ? 1 : 2.5, e.clientX, e.clientY); clampPan(); lastTap = 0; } else lastTap = Date.now();
    }
    apply();
  };
  v.addEventListener('pointerup', up);
  v.addEventListener('pointercancel', up);
  v.addEventListener('wheel', e => { e.preventDefault(); anim = false; zoomTo(Math.max(1, Math.min(5, s * (e.deltaY < 0 ? 1.15 : 0.87))), e.clientX, e.clientY); clampPan(); apply(); }, { passive: false });
  apply();
}

'use strict';
// Stoi — camada de dados e regras de negócio (persistência em localStorage).
// Os erros lançados usam chaves de tradução ('err.*'), traduzidas pela interface.

const DB_KEY = 'stoi-data-v1';
const LEGACY_DB_KEY = 'pdv-data-v1';

const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
const round2 = n => Math.round((Number(n) + Number.EPSILON) * 100) / 100;

const CURRENCIES = {
  MZN: { locale: 'pt-MZ', label: 'Metical (MT)' },
  ZAR: { locale: 'en-ZA', label: 'Rand (R)' },
  BRL: { locale: 'pt-BR', label: 'Real (R$)' },
  EUR: { locale: 'pt-PT', label: 'Euro (€)' },
  USD: { locale: 'en-US', label: 'US Dollar (US$)' },
  AOA: { locale: 'pt-AO', label: 'Kwanza (Kz)' },
  CVE: { locale: 'pt-CV', label: 'Escudo (CVE)' },
};

// 'credit' = fiado: o cliente leva e fica a dever (soma à dívida do cliente).
const PAY_TYPES = ['cash', 'card', 'mobile', 'other', 'credit'];
const EXPENSE_CATEGORIES = ['rent', 'salaries', 'utilities', 'suppliers', 'transport', 'maintenance', 'taxes', 'other'];

// Campos numéricos que a sincronização junta somando diferenças (não "o último ganha").
const MERGE_FIELDS = { items: ['stock'], customers: ['points', 'visits', 'totalSpent', 'debt'] };
// Balanço em curso feito em dois dispositivos: junta as contagens produto a produto,
// ficando com a mais recente de cada um. Um balanço concluído ganha a um em curso.
function mergeCount(a, b) {
  if (!a || !b) return a || b;
  if (a.status !== 'draft' || b.status !== 'draft') return a.status !== 'draft' ? a : b;
  const lines = new Map();
  for (const l of [...(a.lines || []), ...(b.lines || [])]) {
    const cur = lines.get(l.itemId);
    if (!cur || (l.at || '') > (cur.at || '')) lines.set(l.itemId, l);
  }
  return Object.assign({}, a, { lines: [...lines.values()] });
}

// Motivos dos ajustes de stock (saídas que não são vendas). Os antigos, sem motivo, contam como 'manual'.
const ADJUST_REASONS = ['loss', 'break', 'internal', 'manual'];

const SYNC_COLLECTIONS = ['categories', 'items', 'customers', 'employees', 'receipts', 'shifts', 'openTickets', 'stockEntries', 'stockCounts', 'expenses', 'debtPayments', 'settlements', 'stockBalances', 'credits'];

// Chave AAAA-MM-DD no fuso horário local.
const dayKey = dt => `${dt.getFullYear()}-${String(dt.getMonth() + 1).padStart(2, '0')}-${String(dt.getDate()).padStart(2, '0')}`;

const fail = key => { throw new Error(key); };

function defaultSettings() {
  return {
    storeName: 'Stoi',
    address: '',
    phone: '',
    currency: 'MZN',
    taxRate: 0,
    taxMode: 'included', // 'included' (preço já inclui imposto) ou 'added' (acrescido no total)
    loyaltyRate: 5, // % do total devolvido em pontos (1 ponto = 1 unidade monetária)
    useShifts: false,
    // Venda à consignação: a mercadoria é do fornecedor e vende-se ao preço dele; esconde custos e lucro.
    consignment: true,
    tagCats: [], // categorias que levam sempre o nome da categoria (vazio = automático: só nomes repetidos)
    terms: {}, // termos alterados à mão: { pt: { chave: texto }, en: {...} }
    receiptFooter: '',
  };
}

function emptyData() {
  return {
    version: 2,
    settings: defaultSettings(),
    categories: [],
    items: [],
    customers: [],
    employees: [{ id: uid(), name: 'Admin', pin: '0000', role: 'owner' }],
    receipts: [],
    shifts: [],
    openTickets: [],
    stockEntries: [],
    stockCounts: [],
    expenses: [],
    debtPayments: [],
    settlements: [],
    stockBalances: [],
    credits: [], // fiado registado à mão (sem venda no caixa): cliente, valor, data, o que levou
    counters: { receipt: 1000, sku: 10000 },
  };
}

function demoData() {
  const d = emptyData();
  const cat = (name, color) => ({ id: uid(), name, color });
  d.categories = [
    cat('Bebidas', '#1e88e5'),
    cat('Lanches', '#fb8c00'),
    cat('Doces', '#d81b60'),
    cat('Mercearia', '#43a047'),
  ];
  const item = (name, c, price, cost, stock, barcode = '') => ({
    id: uid(),
    name,
    categoryId: d.categories[c].id,
    price,
    cost,
    sku: String(++d.counters.sku),
    barcode,
    trackStock: stock !== null,
    stock: stock ?? 0,
    lowStock: 5,
    color: d.categories[c].color,
  });
  d.items = [
    item('Café expresso', 0, 50, 12, null),
    item('Cappuccino', 0, 85, 25, null),
    item('Sumo de laranja', 0, 90, 30, null),
    item('Água mineral 500ml', 0, 35, 10, 48, '6001234500011'),
    item('Refrigerante lata', 0, 60, 28, 36, '6001234500028'),
    item('Pão com chouriço', 1, 45, 15, 60),
    item('Sanduíche misto', 1, 120, 45, 20),
    item('Chamuça', 1, 25, 8, 30),
    item('Prego no pão', 1, 150, 55, 15),
    item('Bolo de coco (fatia)', 2, 75, 24, 12),
    item('Pastel de nata', 2, 40, 13, 24),
    item('Arroz 1kg', 3, 95, 70, 25, '6001234500035'),
    item('Feijão manteiga 1kg', 3, 140, 105, 4, '6001234500042'),
    item('Açúcar 1kg', 3, 80, 60, 18, '6001234500059'),
  ];
  // Entradas de stock de exemplo: uma antiga e uma recente para cada item com stock.
  const daysAgo = n => { const x = new Date(); x.setDate(x.getDate() - n); return dayKey(x); };
  d.items.filter(i => i.trackStock).forEach((i, k) => {
    const recent = Math.ceil(i.stock / 2);
    const older = i.stock - recent;
    if (older > 0) d.stockEntries.push({ id: uid(), itemId: i.id, type: 'in', qty: older, date: daysAgo(20 + k), cost: i.cost, note: '', createdAt: new Date().toISOString(), employeeId: null });
    d.stockEntries.push({ id: uid(), itemId: i.id, type: 'in', qty: recent, date: daysAgo(2 + (k % 4)), cost: i.cost, note: '', createdAt: new Date().toISOString(), employeeId: null });
  });
  d.customers = [
    { id: uid(), name: 'Maria Cossa', phone: '+258 84 123 4567', email: 'maria@exemplo.com', note: '', points: 125, visits: 3, totalSpent: 2500 },
    { id: uid(), name: 'João Mabunda', phone: '+258 82 765 4321', email: '', note: 'VIP', points: 0, visits: 0, totalSpent: 0 },
  ];
  return d;
}

// Preenche campos em falta em dados antigos/importados.
function migrate(data) {
  const base = emptyData();
  const d = Object.assign({}, base, data);
  d.settings = Object.assign(defaultSettings(), data.settings || {});
  d.counters = Object.assign(base.counters, data.counters || {});
  for (const k of SYNC_COLLECTIONS) {
    if (!Array.isArray(d[k])) d[k] = [];
  }
  if (!Array.isArray(d.employees) || !d.employees.length) d.employees = base.employees;
  for (const r of d.receipts) {
    if (r.payment && r.payment.type === 'pix') r.payment.type = 'mobile';
  }
  d.version = 2;
  return d;
}

function newTicket() {
  return { lines: [], customerId: null, discount: { type: '%', value: 0 }, pointsRedeemed: 0, openTicketId: null, name: '' };
}

function computeTotals(ticket, settings) {
  const subtotal = round2(ticket.lines.reduce((s, l) => s + l.price * l.qty, 0));
  const d = ticket.discount || { type: '%', value: 0 };
  const dv = Math.max(0, Number(d.value) || 0);
  let discount = d.type === '%' ? subtotal * Math.min(100, dv) / 100 : dv;
  discount = round2(Math.min(discount, subtotal));
  const points = round2(Math.min(Math.max(0, ticket.pointsRedeemed || 0), subtotal - discount));
  const afterDiscounts = round2(subtotal - discount - points);
  const rate = Math.max(0, Number(settings.taxRate) || 0) / 100;
  let tax, total, net;
  if (settings.taxMode === 'added') {
    tax = round2(afterDiscounts * rate);
    total = round2(afterDiscounts + tax);
    net = afterDiscounts;
  } else {
    tax = round2(afterDiscounts - afterDiscounts / (1 + rate));
    total = afterDiscounts;
    net = round2(afterDiscounts - tax);
  }
  const cost = round2(ticket.lines.reduce((s, l) => s + (l.cost || 0) * l.qty, 0));
  return { subtotal, discount, points, tax, total, net, cost };
}

// Número visível do recibo: "2-1005" quando a loja tem vários dispositivos ligados à nuvem.
const receiptNo = r => (r.deviceNo ? `${r.deviceNo}-${r.number}` : String(r.number));

const Store = {
  data: null,
  deviceId: 'local', // identificador deste dispositivo (turnos são por dispositivo)
  deviceNo: null, // número atribuído pela nuvem, usado nos recibos
  onSave: null, // chamado depois de cada gravação (usado pela sincronização)

  load() {
    let raw = null;
    try { raw = localStorage.getItem(DB_KEY) || localStorage.getItem(LEGACY_DB_KEY); } catch (e) { /* indisponível */ }
    try { this.data = raw ? migrate(JSON.parse(raw)) : demoData(); } catch (e) { this.data = demoData(); }
    this.save();
  },

  save() {
    try { localStorage.setItem(DB_KEY, JSON.stringify(this.data)); } catch (e) { /* armazenamento indisponível */ }
    if (this.onSave) this.onSave();
  },

  replaceAll(data) {
    this.data = migrate(data);
    this.save();
  },

  reset(withDemo) {
    this.data = withDemo ? demoData() : emptyData();
    this.save();
  },

  get settings() { return this.data.settings; },

  find(collection, id) {
    return this.data[collection].find(x => x.id === id) || null;
  },

  upsert(collection, obj) {
    const list = this.data[collection];
    if (!obj.id) obj.id = uid();
    const i = list.findIndex(x => x.id === obj.id);
    if (i >= 0) list[i] = Object.assign(list[i], obj);
    else list.push(obj);
    this.save();
    return obj;
  },

  remove(collection, id) {
    this.data[collection] = this.data[collection].filter(x => x.id !== id);
    this.save();
  },

  nextSku() {
    this.data.counters.sku += 1;
    return String(this.data.counters.sku);
  },

  findByCode(code) {
    const c = String(code).trim();
    if (!c) return null;
    return this.data.items.find(i => i.barcode === c || i.sku === c) || null;
  },

  // ---------- Registos para sincronização ----------

  // Todos os registos sincronizáveis, por chave "coleção/id".
  records() {
    const out = { 'settings/main': this.data.settings };
    for (const c of SYNC_COLLECTIONS) for (const r of this.data[c]) out[`${c}/${r.id}`] = r;
    return out;
  },

  setRecord(col, id, data) {
    if (col === 'settings') { this.data.settings = Object.assign(defaultSettings(), data); return; }
    if (!SYNC_COLLECTIONS.includes(col)) return;
    const list = this.data[col];
    const i = list.findIndex(x => x.id === id);
    const rec = Object.assign({}, data, { id });
    if (i >= 0) list[i] = rec;
    else if (col === 'receipts') list.unshift(rec);
    else list.push(rec);
  },

  removeRecord(col, id) {
    if (!SYNC_COLLECTIONS.includes(col)) return;
    this.data[col] = this.data[col].filter(x => x.id !== id);
  },

  // ---------- Entradas de stock ----------

  // Regista uma entrada (receção de mercadoria) ou um ajuste (correção, pode ser negativo).
  addStockEntry({ itemId, type = 'in', qty, date, cost = null, note = '', reason = null, justified = false }, employeeId) {
    const item = this.find('items', itemId);
    if (!item) fail('err.itemNotFound');
    if (!item.trackStock) fail('err.stockNotTracked');
    // Perdas, quebras e consumo interno são sempre saídas (quantidade negativa).
    const why = type === 'adjust' && ADJUST_REASONS.includes(reason) ? reason : null;
    let q = round2(qty);
    if (why && why !== 'manual') q = -Math.abs(q);
    if (!Number.isFinite(q) || q === 0 || (type === 'in' && q < 0)) fail('err.invalidQty');
    if (!/^\d{4}-\d{2}-\d{2}$/.test(String(date || '')) || date > dayKey(new Date())) fail('err.invalidDate');
    const entry = {
      id: uid(), itemId, type: type === 'adjust' ? 'adjust' : 'in', qty: q, date,
      cost: cost == null || cost === '' ? null : round2(cost), note: String(note || '').trim(),
      createdAt: new Date().toISOString(), employeeId, ...(why ? { reason: why } : {}),
      ...(why === 'loss' || why === 'break' ? { justified: !!justified } : {}),
    };
    item.stock = round2(item.stock + q);
    this.data.stockEntries.push(entry);
    this.save();
    return entry;
  },

  // Marca uma perda/quebra como justificada ao fornecedor (fica com ele) ou não (conta como falta).
  setJustified(entryId, value) {
    const e = this.find('stockEntries', entryId);
    if (!e || !(e.reason === 'loss' || e.reason === 'break')) fail('err.notFound');
    e.justified = !!value;
    this.save();
    return e;
  },

  // Corrige uma entrada ou um ajuste (data, quantidade, nota, custo). O stock muda só pela diferença.
  // Ajustes de balanço e de caixas abertas não se editam aqui (corrigem-se no balanço ou apagando).
  // Corrigir um movimento já registado: data, quantidade, nota, custo e também o tipo
  // (entrada, quebra, perda, ajuste) e o produto. O stock desfaz o efeito antigo e aplica o novo.
  updateStockEntry(id, { date, qty, note, cost, itemId, kind }, employeeId) {
    const e = this.find('stockEntries', id);
    if (!e || e.countId || e.open) fail('err.notFound');
    const oldItem = this.find('items', e.itemId);
    const newItem = itemId ? this.find('items', itemId) : oldItem;
    if (!newItem) fail('err.itemNotFound');
    if (newItem !== oldItem && !newItem.trackStock) fail('err.stockNotTracked');
    const curKind = e.type === 'in' ? 'in' : (e.reason || 'manual');
    const k = kind && (kind === 'in' || ADJUST_REASONS.includes(kind)) ? kind : curKind;
    // "Stock sem data" a que se deu uma data não mexeu no stock: só pode mudar data, quantidade e nota.
    if (e.dated && (k !== 'in' || newItem !== oldItem)) fail('err.notFound');
    if (date != null) {
      if (!/^\d{4}-\d{2}-\d{2}$/.test(String(date)) || date > dayKey(new Date())) fail('err.invalidDate');
    }
    let q = round2(qty != null ? qty : (k === curKind ? e.qty : Math.abs(e.qty)));
    if (k === 'loss' || k === 'break' || k === 'internal') q = -Math.abs(q);
    if (!Number.isFinite(q) || q === 0 || (k === 'in' && q < 0)) fail('err.invalidQty');
    if (!e.dated) {
      if (oldItem) oldItem.stock = round2(oldItem.stock - e.qty);
      newItem.stock = round2(newItem.stock + q);
    }
    if (date != null) e.date = date;
    e.qty = q;
    e.itemId = newItem.id;
    if (k === 'in') { e.type = 'in'; delete e.reason; delete e.justified; }
    else {
      e.type = 'adjust'; e.reason = k;
      if (k === 'loss' || k === 'break') { if (e.justified == null) e.justified = false; } else delete e.justified;
      e.cost = null;
    }
    if (note != null) e.note = String(note).trim();
    if (cost !== undefined && e.type === 'in') e.cost = cost == null || cost === '' ? null : round2(cost);
    e.editedAt = new Date().toISOString();
    e.editedBy = employeeId;
    this.save();
    return e;
  },

  // Stock sem data de entrada: dar-lhe uma data (passa a ser uma entrada desse dia, sem mudar o
  // stock de agora, porque essas unidades já estão contadas no stock).
  dateUnknownStock(itemId, qty, date, employeeId, note = '') {
    const item = this.find('items', itemId);
    if (!item || !item.trackStock) fail('err.itemNotFound');
    const q = round2(qty);
    const unknown = this.stockLots(itemId).unknown;
    if (!(q > 0) || q > unknown + 1e-9) fail('err.invalidQty');
    if (!/^\d{4}-\d{2}-\d{2}$/.test(String(date || '')) || date > dayKey(new Date())) fail('err.invalidDate');
    const e = { id: uid(), itemId, type: 'in', qty: q, date, cost: null, note: String(note || '').trim(), createdAt: new Date().toISOString(), employeeId, dated: true };
    this.data.stockEntries.push(e);
    this.save();
    return e;
  },

  // Apagar uma entrada desfaz o efeito no stock.
  // Apaga uma entrada ou ajuste e repõe o stock. Numa caixa aberta apagam-se os dois lados (desfaz a abertura).
  removeStockEntry(id) {
    const e = this.find('stockEntries', id);
    if (!e) return;
    const gone = e.open ? this.data.stockEntries.filter(x => x.open === e.open) : [e];
    for (const x of gone) {
      const item = this.find('items', x.itemId);
      // "Stock sem data" a que se deu uma data: não mexeu no stock, por isso apagar também não mexe.
      if (item && !x.dated) item.stock = round2(item.stock - x.qty);
    }
    this.data.stockEntries = this.data.stockEntries.filter(x => !gone.includes(x));
    this.save();
  },

  entriesFor(itemId) {
    return this.data.stockEntries.filter(e => e.itemId === itemId)
      .sort((a, b) => (a.date === b.date ? a.createdAt.localeCompare(b.createdAt) : a.date.localeCompare(b.date)));
  },

  // Quanto do stock atual vem de cada entrada, assumindo que se vende primeiro o mais antigo (FIFO):
  // o stock que resta pertence às entradas mais recentes. Stock sem entrada registada fica em "unknown".
  stockLots(itemId) {
    const item = this.find('items', itemId);
    if (!item) return { lots: [], unknown: 0 };
    let left = Math.max(0, item.stock);
    const lots = [];
    for (const e of this.entriesFor(itemId).filter(x => x.type === 'in').reverse()) {
      const remaining = round2(Math.min(e.qty, left));
      left = round2(left - remaining);
      lots.push({ entry: e, remaining });
    }
    return { lots: lots.reverse(), unknown: left };
  },

  // ---------- Balanço (contagem física do stock) ----------

  // kind: 'normal' (balanço com fornecedor/gestor, conta no Fecho) ou 'check' (verificação sozinho,
  // guardada à parte: não mexe no stock nem no Fecho).
  currentCount(kind = 'normal') {
    return this.data.stockCounts.find(c => c.status === 'draft' && (c.kind || 'normal') === kind) || null;
  },

  isCheck(c) { return !!c && c.kind === 'check'; },

  // Stock que o sistema espera para um produto numa contagem: o stock de agora, mais as caixas
  // abertas só em simulação (verificação). No balanço normal as caixas abrem-se a sério.
  countStock(c, item) {
    let v = c && c.day ? this.stockAt(item, c.day) : item.stock;
    for (const o of (c && c.opens) || []) {
      if (!o.sim) continue;
      const box = this.find('items', o.boxId);
      if (!box) continue;
      if (box.id === item.id) v -= o.n;
      if (box.opensInto === item.id) v += o.n * (Number(box.opensQty) || 1);
    }
    return round2(v);
  },

  // Stock de um produto no fim de um dia: o de agora, sem os movimentos e vendas dos dias seguintes.
  stockAt(item, day) {
    let v = item.stock;
    for (const e of this.data.stockEntries) if (e.itemId === item.id && e.date > day) v -= e.qty;
    for (const r of this.data.receipts) {
      if (dayKey(new Date(r.date)) <= day) continue;
      const sg = r.type === 'refund' ? -1 : 1;
      for (const l of r.lines) if (l.itemId === item.id) v += sg * l.qty;
    }
    return round2(v);
  },

  // Caixa (que controla stock) que se abre nesta lâmina e ainda tem caixas nesta contagem.
  countPackSource(c, itemId) {
    return this.data.items.find(i => i.opensInto === itemId && i.trackStock && this.countStock(c, i) > 0) || null;
  },

  // Abre n caixas durante uma contagem (sobra de lâminas): no balanço normal regista a abertura
  // a sério (mudança interna); na verificação só simula, até "Aplicar ao stock".
  countOpenPack(countId, boxId, n, employeeId) {
    const c = this.find('stockCounts', countId);
    if (!c || c.status !== 'draft') fail('err.countClosed');
    const box = this.find('items', boxId);
    const k = round2(n);
    if (!box || !box.opensInto || !this.find('items', box.opensInto)) fail('err.notFound');
    if (!(k > 0) || !Number.isInteger(k)) fail('err.invalidQty');
    if (this.countStock(c, box) + 1e-9 < k) fail('err.packNoStock');
    const sim = this.isCheck(c);
    if (!sim) this.openPack(box.id, k, employeeId);
    (c.opens || (c.opens = [])).push({ boxId: box.id, n: k, sim, at: new Date().toISOString() });
    this.save();
    return c;
  },

  // Mostrar preço de custo, margens e lucro (opção nas Configurações). Sem escolha feita:
  // escondido na venda à consignação, visível nos outros casos.
  showCost() {
    const st = this.data.settings;
    return st.showCost != null ? !!st.showCost : !st.consignment;
  },

  // Começa um balanço com todos os itens que controlam stock (ou continua o que está em curso).
  startCount(employeeId, kind = 'normal', day = null) {
    const cur = this.currentCount(kind);
    if (cur) return cur;
    const today = dayKey(new Date());
    if (day && (!/^\d{4}-\d{2}-\d{2}$/.test(day) || day > today)) fail('err.invalidDate');
    const c = {
      id: uid(), status: 'draft', ...(kind === 'check' ? { kind: 'check' } : {}), ...(day && day < today ? { day } : {}),
      startedAt: new Date().toISOString(), finishedAt: null,
      employeeId, finishedBy: null,
      lines: this.data.items.filter(i => i.trackStock).map(i => ({ itemId: i.id, counted: null })),
    };
    this.data.stockCounts.push(c);
    this.save();
    return c;
  },

  setCounted(countId, itemId, value) {
    const c = this.find('stockCounts', countId);
    if (!c || c.status !== 'draft') fail('err.countClosed');
    let line = c.lines.find(l => l.itemId === itemId);
    if (!line) { line = { itemId, counted: null }; c.lines.push(line); }
    const v = value === null || value === '' ? null : round2(value);
    if (v != null && (!Number.isFinite(v) || v < 0)) fail('err.invalidQty');
    line.counted = v;
    line.at = new Date().toISOString();
    this.save();
  },

  // Valor do stock atual a preço de custo e de venda (só itens que controlam stock).
  stockValue() {
    const out = { units: 0, cost: 0, retail: 0 };
    for (const i of this.data.items) {
      if (!i.trackStock || i.stock <= 0) continue;
      out.units += i.stock;
      out.cost += i.stock * (i.cost || 0);
      out.retail += i.stock * (i.price || 0);
    }
    return { units: round2(out.units), cost: round2(out.cost), retail: round2(out.retail) };
  },

  // Fecha o balanço: as diferenças entre o contado e o sistema passam a ajustes de stock.
  // Itens não contados ficam como estão.
  finishCount(countId, employeeId, note) {
    const c = this.find('stockCounts', countId);
    if (!c || c.status !== 'draft') fail('err.countClosed');
    const date = c.day || dayKey(new Date());
    const doneAt = c.day ? new Date(`${c.day}T23:59:59`).toISOString() : new Date().toISOString();
    const label = note || 'Balanço';
    const real = !this.isCheck(c); // a verificação não mexe no stock
    const lines = [];
    let diffQty = 0, diffValue = 0, withDiff = 0, counted = 0;
    for (const l of c.lines) {
      const item = this.find('items', l.itemId);
      if (!item || !item.trackStock) continue;
      const expected = this.countStock(c, item);
      const line = { itemId: item.id, name: this.displayName(item), expected, counted: l.counted, diff: null, cost: item.cost || 0, price: item.price || 0 };
      if (l.counted != null) {
        counted++;
        line.diff = round2(l.counted - expected);
        if (line.diff !== 0) {
          withDiff++;
          diffQty += line.diff;
          diffValue += line.diff * (this.showCost() ? line.cost : line.price);
          if (real) {
            const e = { id: uid(), itemId: item.id, type: 'adjust', qty: line.diff, date, cost: null, note: label, createdAt: doneAt, employeeId, countId: c.id };
            this.data.stockEntries.push(e);
            item.stock = round2(item.stock + line.diff);
          }
        }
      }
      lines.push(line);
    }
    if (!counted) fail('err.nothingCounted');
    Object.assign(c, {
      status: 'done', finishedAt: doneAt, finishedBy: employeeId, lines,
      totals: { items: lines.length, counted, withDiff, diffQty: round2(diffQty), diffValue: round2(diffValue), value: this.stockValue() },
    });
    this.recountTotals(c);
    this.save();
    return c;
  },

  // Passa uma verificação para o stock: vira um balanço normal e as diferenças encontradas
  // passam a ajustes (somadas ao stock de agora, para não apagar as vendas feitas depois).
  applyCheck(countId, employeeId) {
    const c = this.find('stockCounts', countId);
    if (!c || c.status !== 'done' || !this.isCheck(c)) fail('err.countClosed');
    for (const o of c.opens || []) {
      if (!o.sim) continue;
      this.openPack(o.boxId, o.n, employeeId);
      o.sim = false;
    }
    const at = new Date().toISOString();
    for (const l of c.lines) {
      if (!l.diff) continue;
      const item = this.find('items', l.itemId);
      if (!item) continue;
      item.stock = round2(item.stock + l.diff);
      this.data.stockEntries.push({ id: uid(), itemId: item.id, type: 'adjust', qty: l.diff, date: dayKey(new Date(at)), cost: null, note: 'Balanço', createdAt: at, employeeId, countId: c.id });
    }
    delete c.kind;
    Object.assign(c, { checkedAt: c.finishedAt, finishedAt: at, appliedBy: employeeId });
    this.recountTotals(c);
    this.save();
    return c;
  },

  // Marca uma verificação como vista e guardada à parte (continua sem mexer no stock).
  saveCheck(countId) {
    const c = this.find('stockCounts', countId);
    if (!c || !this.isCheck(c)) fail('err.countClosed');
    c.saved = true;
    this.save();
    return c;
  },

  // Último balanço normal concluído e o que aconteceu desde então aos produtos contados:
  // Contado + Entrou (entradas e outros ajustes) − Vendido (caixa) = Agora.
  salesSinceCount() {
    const last = this.data.stockCounts.filter(c => c.status === 'done' && !this.isCheck(c) && c.finishedAt)
      .sort((a, b) => b.finishedAt.localeCompare(a.finishedAt))[0];
    if (!last) return null;
    const from = last.finishedAt;
    const rep = this.report(new Date(from), new Date(Date.now() + 1000));
    const lines = [];
    for (const l of last.lines) {
      if (l.counted == null) continue;
      const item = this.find('items', l.itemId);
      if (!item) continue;
      const qIn = round2(this.data.stockEntries.filter(e => e.itemId === item.id && e.createdAt >= from && e.countId !== last.id
        && (e.type === 'in' || e.type === 'adjust')).reduce((a, e) => a + e.qty, 0));
      const it = rep.byItem[item.id] || { qty: 0, net: 0 };
      const sold = round2(it.qty);
      lines.push({ itemId: item.id, name: this.displayName(item), counted: l.counted, in: qIn, sold, value: round2(it.net), now: round2(l.counted + qIn - sold), stock: item.stock, price: item.price || 0 });
    }
    lines.sort((a, b) => a.name.localeCompare(b.name, 'pt'));
    const sum = f => round2(lines.reduce((a, l) => a + l[f], 0));
    return { countId: last.id, from, lines, totals: { counted: sum('counted'), in: sum('in'), sold: sum('sold'), now: sum('now'), value: sum('value') }, posTotal: round2(rep.total) };
  },

  // Põe várias quantidades de uma vez numa contagem (em curso ou concluída): [{ itemId, value }].
  // Numa concluída, o stock acompanha a diferença (como ao editar à mão).
  setCountValues(countId, values, employeeId) {
    const c = this.find('stockCounts', countId);
    if (!c) fail('err.countClosed');
    let n = 0;
    for (const { itemId, value } of values) {
      const item = this.find('items', itemId);
      if (!item || !item.trackStock) continue;
      if (c.status === 'draft') this.setCounted(c.id, itemId, value);
      else {
        if (!c.lines.some(l => l.itemId === itemId)) {
          c.lines.push({ itemId, name: this.displayName(item), expected: this.countStock(c, item), counted: null, diff: null, cost: item.cost || 0, price: item.price || 0 });
        }
        this.editCountLine(c.id, itemId, value, employeeId);
      }
      n++;
    }
    return n;
  },

  // Copia os números contados de outra contagem para esta (só os produtos contados na outra).
  copyCountFrom(countId, fromId, employeeId) {
    const src = this.find('stockCounts', fromId);
    if (!src || src.id === countId) fail('err.countClosed');
    return this.setCountValues(countId, src.lines.filter(l => l.counted != null).map(l => ({ itemId: l.itemId, value: l.counted })), employeeId);
  },

  // Muda a data de uma contagem. Numa concluída, refaz as diferenças com o stock desse dia
  // e os ajustes passam para a nova data (o stock de agora acompanha).
  setCountDay(countId, day, employeeId) {
    const c = this.find('stockCounts', countId);
    if (!c) fail('err.countClosed');
    const today = dayKey(new Date());
    if (!/^\d{4}-\d{2}-\d{2}$/.test(String(day || '')) || day > today) fail('err.invalidDate');
    if (c.status === 'draft') { if (day < today) c.day = day; else delete c.day; this.save(); return c; }
    const at = day < today ? new Date(`${day}T23:59:59`).toISOString() : new Date().toISOString();
    // desfaz os ajustes desta contagem e volta a fazê-los no novo dia
    for (const l of c.lines) {
      const item = this.find('items', l.itemId);
      if (item && l.diff && !this.isCheck(c)) item.stock = round2(item.stock - l.diff);
    }
    this.data.stockEntries = this.data.stockEntries.filter(e => !(e.countId === c.id && e.type === 'adjust'));
    if (day < today) c.day = day; else delete c.day;
    c.finishedAt = at;
    for (const l of c.lines) {
      const item = this.find('items', l.itemId);
      if (!item) continue;
      l.expected = this.countStock(c, item);
      l.diff = l.counted == null ? null : round2(l.counted - l.expected);
      if (l.diff && !this.isCheck(c)) {
        item.stock = round2(item.stock + l.diff);
        this.data.stockEntries.push({ id: uid(), itemId: item.id, type: 'adjust', qty: l.diff, date: day, cost: null, note: 'Balanço', createdAt: at, employeeId, countId: c.id });
      }
    }
    this.recountTotals(c);
    c.editedAt = new Date().toISOString(); c.editedBy = employeeId;
    this.save();
    return c;
  },

  // Corrige a quantidade contada de um produto num balanço já concluído (null = deixa de estar contado).
  // O stock e o ajuste desse balanço mudam só pela diferença entre a contagem antiga e a nova.
  editCountLine(countId, itemId, value, employeeId) {
    const c = this.find('stockCounts', countId);
    if (!c || c.status !== 'done') fail('err.countClosed');
    const line = c.lines.find(l => l.itemId === itemId);
    if (!line) fail('err.itemNotFound');
    const v = value === null || value === '' ? null : round2(value);
    if (v != null && (!Number.isFinite(v) || v < 0)) fail('err.invalidQty');
    const oldDiff = line.diff || 0;
    const newDiff = v == null ? null : round2(v - line.expected);
    const item = this.find('items', itemId);
    const real = !this.isCheck(c);
    if (item && real) item.stock = round2(item.stock + (newDiff || 0) - oldDiff);
    const entry = this.data.stockEntries.find(e => e.countId === c.id && e.itemId === itemId && e.type === 'adjust');
    if (!real) { /* verificação: só a contagem muda */ } else if (newDiff) {
      if (entry) entry.qty = newDiff;
      else this.data.stockEntries.push({ id: uid(), itemId, type: 'adjust', qty: newDiff, date: dayKey(new Date(c.finishedAt)), cost: null, note: 'Balanço', createdAt: c.finishedAt, employeeId, countId: c.id });
    } else if (entry) this.data.stockEntries = this.data.stockEntries.filter(e => e !== entry);
    line.counted = v;
    line.diff = newDiff;
    this.recountTotals(c);
    c.editedAt = new Date().toISOString();
    c.editedBy = employeeId;
    this.save();
    return c;
  },

  // Atualiza o "Sistema" de um balanço concluído com o stock de agora (como se a contagem fosse
  // feita agora com os mesmos números): os contados ficam com stock = contado e as diferenças
  // refazem-se; produtos que entretanto passaram a controlar stock entram na lista, por contar.
  refreshCount(countId, employeeId, onlyItemId = null) {
    const c = this.find('stockCounts', countId);
    if (!c || c.status !== 'done' || this.isCheck(c)) fail('err.countClosed');
    for (const line of c.lines) {
      if (onlyItemId && line.itemId !== onlyItemId) continue;
      const item = this.find('items', line.itemId);
      if (!item) continue;
      const base = round2(item.stock - (line.diff || 0)); // stock sem o ajuste deste balanço
      Object.assign(line, { expected: base, name: this.displayName(item), price: item.price || 0, cost: item.cost || 0 });
      if (line.counted == null) continue;
      line.diff = round2(line.counted - base);
      item.stock = round2(line.counted);
      const entry = this.data.stockEntries.find(e => e.countId === c.id && e.itemId === item.id && e.type === 'adjust');
      if (line.diff) {
        if (entry) entry.qty = line.diff;
        else this.data.stockEntries.push({ id: uid(), itemId: item.id, type: 'adjust', qty: line.diff, date: dayKey(new Date(c.finishedAt)), cost: null, note: 'Balanço', createdAt: c.finishedAt, employeeId, countId: c.id });
      } else if (entry) this.data.stockEntries = this.data.stockEntries.filter(e => e !== entry);
    }
    const have = new Set(c.lines.map(l => l.itemId));
    for (const item of onlyItemId ? [] : this.data.items.filter(i => i.trackStock && !have.has(i.id))) {
      c.lines.push({ itemId: item.id, name: this.displayName(item), expected: item.stock, counted: null, diff: null, cost: item.cost || 0, price: item.price || 0 });
    }
    this.recountTotals(c);
    c.editedAt = new Date().toISOString();
    c.editedBy = employeeId;
    this.save();
    return c;
  },

  // Tira um produto de um balanço (em curso ou concluído). Num concluído, desfaz o ajuste que ele fez.
  removeCountLine(countId, itemId) {
    const c = this.find('stockCounts', countId);
    if (!c) fail('err.countClosed');
    const line = c.lines.find(l => l.itemId === itemId);
    if (!line) return c;
    if (c.status === 'done' && !this.isCheck(c)) {
      const item = this.find('items', itemId);
      if (item && line.diff) item.stock = round2(item.stock - line.diff);
      this.data.stockEntries = this.data.stockEntries.filter(e => !(e.countId === c.id && e.itemId === itemId));
    }
    c.lines = c.lines.filter(l => l !== line);
    if (c.status === 'done') this.recountTotals(c);
    this.save();
    return c;
  },

  // Totais de um balanço concluído, a partir das linhas.
  recountTotals(c) {
    const unit = l => (this.showCost() ? l.cost || 0 : l.price || 0);
    const done = c.lines.filter(l => l.counted != null);
    const withDiff = done.filter(l => l.diff);
    const miss = withDiff.filter(l => l.diff < 0), sur = withDiff.filter(l => l.diff > 0);
    Object.assign(c.totals, {
      missQty: round2(miss.reduce((a, l) => a - l.diff, 0)), missValue: round2(miss.reduce((a, l) => a - l.diff * unit(l), 0)),
      surQty: round2(sur.reduce((a, l) => a + l.diff, 0)), surValue: round2(sur.reduce((a, l) => a + l.diff * unit(l), 0)),
      items: c.lines.length, counted: done.length, withDiff: withDiff.length,
      diffQty: round2(withDiff.reduce((a, l) => a + l.diff, 0)),
      diffValue: round2(withDiff.reduce((a, l) => a + l.diff * unit(l), 0)),
    });
  },

  // Apaga um balanço concluído e desfaz os ajustes de stock que ele fez.
  deleteCount(countId) {
    const c = this.find('stockCounts', countId);
    if (!c || c.status !== 'done') return;
    for (const l of this.isCheck(c) ? [] : c.lines) {
      const item = l.diff ? this.find('items', l.itemId) : null;
      if (item) item.stock = round2(item.stock - l.diff);
    }
    this.data.stockEntries = this.data.stockEntries.filter(e => e.countId !== c.id);
    this.remove('stockCounts', countId);
  },

  cancelCount(countId) {
    const c = this.find('stockCounts', countId);
    if (!c || c.status !== 'draft') return;
    this.remove('stockCounts', countId);
  },

  // ---------- Dívidas de clientes (fiado) ----------

  receiveDebtPayment({ customerId, amount, payType = 'cash', note = '' }, employeeId) {
    const c = this.find('customers', customerId);
    if (!c) fail('err.customerNotFound');
    const a = round2(amount);
    if (!(a > 0)) fail('err.invalidAmount');
    if (a > round2(c.debt || 0) + 1e-9) fail('err.paymentOverDebt');
    if (!['cash', 'card', 'mobile', 'other'].includes(payType)) fail('err.invalidAmount');
    const shift = this.currentShift();
    const p = { id: uid(), customerId, amount: a, payType, note: String(note || '').trim(), date: new Date().toISOString(), employeeId, shiftId: shift ? shift.id : null, deviceNo: this.deviceNo };
    c.debt = round2((c.debt || 0) - a);
    this.data.debtPayments.push(p);
    this.save();
    return p;
  },

  // Fiado registado à mão (no Fecho): fica na conta do cliente sem passar pelo caixa.
  addCredit({ customerId, amount, date, note = '' }, employeeId) {
    const c = this.find('customers', customerId);
    if (!c) fail('err.customerNotFound');
    const a = round2(amount);
    if (!(a > 0)) fail('err.invalidAmount');
    if (!/^\d{4}-\d{2}-\d{2}$/.test(String(date || '')) || date > dayKey(new Date())) fail('err.invalidDate');
    const r = { id: uid(), customerId, amount: a, date, note: String(note || '').trim(), createdAt: new Date().toISOString(), employeeId };
    c.debt = round2((c.debt || 0) + a);
    this.data.credits.push(r);
    this.save();
    return r;
  },
  removeCredit(id) {
    const r = this.find('credits', id);
    if (!r) return;
    const c = this.find('customers', r.customerId);
    if (c) c.debt = round2((c.debt || 0) - r.amount);
    this.remove('credits', id);
  },

  // Vendas a crédito e pagamentos de um cliente, mais recentes primeiro.
  debtHistory(customerId) {
    const sales = this.data.receipts.filter(r => r.customerId === customerId && r.payment.type === 'credit')
      .map(r => ({ kind: r.type === 'refund' ? 'refund' : 'sale', date: r.date, amount: r.total, receipt: r }));
    const pays = this.data.debtPayments.filter(p => p.customerId === customerId).map(p => ({ kind: 'payment', date: p.date, amount: p.amount, payment: p }));
    const manual = this.data.credits.filter(r => r.customerId === customerId).map(r => ({ kind: 'sale', date: `${r.date}T12:00:00.000Z`, amount: r.amount, credit: r }));
    sales.push(...manual);
    // Mais recentes primeiro; à mesma hora, o pagamento vem depois da venda.
    return [...sales, ...pays].sort((a, b) => b.date.localeCompare(a.date) || (a.kind === 'payment' ? -1 : 1) - (b.kind === 'payment' ? -1 : 1));
  },

  totalDebt() {
    return round2(this.data.customers.reduce((a, c) => a + Math.max(0, c.debt || 0), 0));
  },

  // ---------- Despesas ----------

  addExpense({ date, category, amount, description = '', payType = 'cash', fromDrawer = false, supplierPays = false }, employeeId) {
    const a = round2(amount);
    if (!(a > 0)) fail('err.invalidAmount');
    if (!/^\d{4}-\d{2}-\d{2}$/.test(String(date || '')) || date > dayKey(new Date())) fail('err.invalidDate');
    if (!EXPENSE_CATEGORIES.includes(category)) fail('err.invalidCategory');
    let movementId = null, shiftId = null;
    if (fromDrawer) {
      const shift = this.currentShift();
      if (!shift) fail('err.noOpenShift');
      movementId = uid();
      shiftId = shift.id;
      shift.movements.push({ id: movementId, type: 'out', amount: a, note: String(description || category), date: new Date().toISOString(), employeeId, expense: true });
    }
    // supplierPays: o fornecedor aceita a despesa e ela desconta-se do total a entregar no fecho.
    const e = { id: uid(), date, category, amount: a, description: String(description || '').trim(), payType: fromDrawer ? 'cash' : payType, employeeId, createdAt: new Date().toISOString(), shiftId, movementId, supplierPays: !!supplierPays };
    this.data.expenses.push(e);
    this.save();
    return e;
  },

  setExpenseSupplierPays(id, on) {
    const e = this.find('expenses', id);
    if (!e) fail('err.notFound');
    e.supplierPays = !!on;
    this.save();
    return e;
  },

  removeExpense(id) {
    const e = this.find('expenses', id);
    if (!e) return;
    if (e.movementId) {
      const shift = this.find('shifts', e.shiftId);
      if (shift && !shift.closedAt) shift.movements = shift.movements.filter(m => m.id !== e.movementId);
    }
    this.remove('expenses', id);
  },

  // ---------- Balanço financeiro ----------

  financialReport(from, to) {
    // Despesas têm só o dia (AAAA-MM-DD): contam se o dia estiver dentro do período.
    const firstDay = dayKey(from), lastDay = dayKey(new Date(to.getTime() - 1));
    const inRange = iso => (iso.length === 10 ? iso >= firstDay && iso <= lastDay : new Date(iso) >= from && new Date(iso) < to);
    const rep = this.report(from, to);
    const expenses = this.data.expenses.filter(e => inRange(e.date));
    const byCategory = {};
    for (const e of expenses) byCategory[e.category] = round2((byCategory[e.category] || 0) + e.amount);
    const totalExpenses = round2(expenses.reduce((a, e) => a + e.amount, 0));
    const payments = this.data.debtPayments.filter(p => inRange(p.date));
    const debtReceived = round2(payments.reduce((a, p) => a + p.amount, 0));
    const creditSales = round2(rep.byPayment.credit || 0);
    // Dinheiro que entrou de facto: vendas pagas no momento (sem fiado) + pagamentos de dívidas.
    const received = {};
    for (const k of PAY_TYPES) if (k !== 'credit') received[k] = round2(rep.byPayment[k] || 0);
    for (const p of payments) received[p.payType] = round2((received[p.payType] || 0) + p.amount);
    const totalReceived = round2(Object.values(received).reduce((a, v) => a + v, 0));
    const debtors = this.data.customers.filter(c => (c.debt || 0) > 0).sort((a, b) => b.debt - a.debt);
    // Mercadoria recebida no período (entradas de stock), ao custo da entrada ou, sem ele, ao custo do item.
    const stockIn = { qty: 0, value: 0, retail: 0 };
    for (const e of this.data.stockEntries) {
      if (e.type !== 'in' || !inRange(e.date)) continue;
      const item = this.find('items', e.itemId);
      stockIn.qty += e.qty;
      stockIn.value += e.qty * (e.cost != null ? e.cost : (item && item.cost) || 0);
      stockIn.retail += e.qty * ((item && item.price) || 0);
    }
    // Itens vendidos sem custo registado: o lucro aparece maior do que é.
    const uncosted = Object.values(rep.byItem).filter(i => i.net > 0 && !(i.cost > 0)).map(i => i.name);
    return {
      netSales: rep.netSales, cost: rep.cost, grossProfit: rep.profit, tax: rep.tax,
      grossSales: rep.grossSales, refunds: rep.refunds, discounts: rep.discounts, salesCount: rep.salesCount, average: rep.average,
      stockIn: { qty: round2(stockIn.qty), value: round2(stockIn.value), retail: round2(stockIn.retail) }, uncosted,
      totalExpenses, byCategory, expenses: expenses.sort((a, b) => b.date.localeCompare(a.date) || b.createdAt.localeCompare(a.createdAt)),
      result: round2(rep.profit - totalExpenses),
      received, totalReceived, cashBalance: round2(totalReceived - totalExpenses),
      creditSales, debtReceived, totalDebt: this.totalDebt(), debtors,
      stock: this.stockValue(),
    };
  },

  // ---------- Fecho com o fornecedor (venda à consignação) ----------

  lastSettlement() {
    return this.data.settlements.slice().sort((a, b) => b.to.localeCompare(a.to))[0] || null;
  },

  // Início do primeiro fecho: a primeira venda ou entrada de stock registada.
  firstActivity() {
    const dates = [...this.data.receipts.map(r => r.date), ...this.data.stockEntries.map(e => e.createdAt)].filter(Boolean).sort();
    return dates[0] || new Date().toISOString();
  },

  // Contas do fecho desde o último (ou desde `fromIso` no primeiro), até agora:
  // dinheiro recebido das vendas (o fiado só conta quando é pago), faltas da contagem
  // feita no período (ao preço de venda) e, por produto, o stock que devia haver.
  // fromIso/toIso: outro período escolhido (por defeito, desde o último fecho até agora).
  settlementPreview(fromIso, toIso, counts = null) {
    // Fecho entre contagens: o período e as saídas vêm do Balanço de stock (as duas contagens).
    if (counts && counts.fromId && counts.toId) {
      const a = this.find('stockCounts', counts.fromId), b = this.find('stockCounts', counts.toId);
      if (a && b && a.finishedAt && b.finishedAt) {
        const p = this.settlementPreview(a.finishedAt, b.finishedAt);
        p.to = b.finishedAt;
        p.byCounts = this.countSettlement(a.id, b.id);
        // Por produto também vale o Balanço: início/entradas/fim contados e saídas; a falta é o que
        // saiu do stock sem venda registada no caixa.
        const bal = this.countBalance(a.id, b.id);
        const byId = new Map(p.lines.map(l => [l.itemId, l]));
        for (const bl of bal.lines) {
          let l = byId.get(bl.itemId);
          if (!l) { l = { itemId: bl.itemId, name: bl.name, price: bl.price, sold: 0, adjust: 0, unjust: 0 }; p.lines.push(l); byId.set(bl.itemId, l); }
          Object.assign(l, { opening: bl.opening, in: bl.in, out: bl.out, counted: bl.final, expected: bl.final, opened: 0, diff: round2(l.sold - bl.out) });
        }
        for (const l of p.lines) if (!bal.lines.some(bl => bl.itemId === l.itemId)) Object.assign(l, { out: 0, diff: 0 });
        p.lines.sort((x, y) => x.name.localeCompare(y.name, 'pt'));
        const miss = p.lines.filter(l => l.diff < 0);
        p.totals.missingQty = round2(miss.reduce((acc, l) => acc - l.diff, 0));
        p.totals.missingValue = round2(miss.reduce((acc, l) => acc - l.diff * l.price, 0));
        p.totals.surplusQty = round2(p.lines.filter(l => l.diff > 0).reduce((acc, l) => acc + l.diff, 0));
        p.totals.stockSalesQty = round2(p.lines.reduce((acc, l) => acc + (l.out || 0), 0));
        p.countId = b.id; p.countAt = b.finishedAt;
        p.totals.total = p.byCounts.total;
        p.totals.stockSalesValue = p.byCounts.out;
        return p;
      }
    }
    const last = this.lastSettlement();
    const from = fromIso || (last ? last.to : this.firstActivity());
    const to = toIso && toIso < new Date().toISOString() ? toIso : new Date().toISOString();
    // Logo a seguir a um fecho, o período começa depois dele (o momento do fecho fica no anterior).
    const afterLast = this.data.settlements.some(x => x.to === from);
    const fromD = new Date(new Date(from).getTime() + (afterLast ? 1 : 0)), toD = new Date(new Date(to).getTime() + 1);
    const rep = this.report(fromD, toD);
    const inPeriod = iso => (afterLast ? iso > from : iso >= from) && iso <= to;
    const received = {};
    for (const k of PAY_TYPES) if (k !== 'credit' && rep.byPayment[k]) received[k] = round2(rep.byPayment[k]);
    const debtPays = this.data.debtPayments.filter(p => inPeriod(p.createdAt || p.date));
    const debtReceived = round2(debtPays.reduce((a, p) => a + p.amount, 0));
    const salesReceived = round2(Object.values(received).reduce((a, v) => a + v, 0));
    // Contagem concluída dentro do período (a mais recente).
    const count = this.data.stockCounts.filter(c => c.status === 'done' && !this.isCheck(c) && c.finishedAt && inPeriod(c.finishedAt))
      .sort((a, b) => b.finishedAt.localeCompare(a.finishedAt))[0] || null;
    const countLine = new Map(count ? count.lines.map(l => [l.itemId, l]) : []);
    const lines = [];
    for (const item of this.data.items.filter(i => i.trackStock)) {
      const entries = this.data.stockEntries.filter(e => e.itemId === item.id && inPeriod(e.createdAt));
      const qIn = round2(entries.filter(e => e.type === 'in').reduce((a, e) => a + e.qty, 0));
      const countAdj = round2(entries.filter(e => e.type === 'adjust' && count && e.countId === count.id).reduce((a, e) => a + e.qty, 0));
      const otherAdj = round2(entries.filter(e => e.type === 'adjust' && !(count && e.countId === count.id)).reduce((a, e) => a + e.qty, 0));
      // Caixas abertas (mudança interna): − na caixa, + na lâmina.
      const opened = round2(entries.filter(e => e.type === 'adjust' && e.open).reduce((a, e) => a + e.qty, 0));
      // Perdas e quebras não justificadas ao fornecedor: a loja paga, como uma falta.
      const unjust = round2(entries.filter(e => e.type === 'adjust' && (e.reason === 'loss' || e.reason === 'break') && !e.justified).reduce((a, e) => a - e.qty, 0));
      const sold = round2((rep.byItem[item.id] || {}).qty || 0);
      const cl = countLine.get(item.id);
      const counted = cl && cl.counted != null ? cl.counted : null;
      // Stock que devia haver sem as diferenças da contagem; o de início calcula-se para trás.
      const expected = round2(item.stock - countAdj);
      const opening = round2(expected - qIn - otherAdj + sold);
      const diff = counted == null ? null : round2(counted - (cl.expected != null ? cl.expected : expected));
      if (!opening && !qIn && !sold && !otherAdj && !expected && counted == null) continue;
      lines.push({ itemId: item.id, name: this.displayName(item), price: item.price || 0, opening, in: qIn, adjust: otherAdj, opened, sold, expected, counted, diff, unjust });
    }
    lines.sort((a, b) => a.name.localeCompare(b.name, 'pt'));
    const missing = lines.filter(l => l.diff < 0);
    const missingQty = round2(missing.reduce((a, l) => a - l.diff, 0));
    const missingValue = round2(missing.reduce((a, l) => a - l.diff * l.price, 0));
    const surplusQty = round2(lines.filter(l => l.diff > 0).reduce((a, l) => a + l.diff, 0));
    // Despesas contam pelo dia da despesa. No dia em que acabou o fecho anterior, só as registadas depois dele.
    const fromDay = dayKey(new Date(from)), toDay = dayKey(new Date(to));
    const expInPeriod = e => e.date >= fromDay && e.date <= toDay && !(afterLast && e.date === fromDay && (e.createdAt || '') <= from);
    const expenseList = this.data.expenses.filter(expInPeriod).sort((a, b) => b.date.localeCompare(a.date) || b.createdAt.localeCompare(a.createdAt));
    const expenses = round2(expenseList.reduce((a, e) => a + e.amount, 0));
    const expensesDeducted = round2(expenseList.filter(e => e.supplierPays).reduce((a, e) => a + e.amount, 0));
    // Entradas de stock do período, por ordem de data.
    // (Entradas de produtos já apagados ficam de fora.)
    const entries = this.data.stockEntries.filter(e => e.type === 'in' && inPeriod(e.createdAt) && this.find('items', e.itemId)).map(e => {
      const item = this.find('items', e.itemId);
      return { itemId: e.itemId, name: this.displayName(item), qty: e.qty, date: e.date, price: item.price || 0 };
    }).sort((a, b) => b.date.localeCompare(a.date) || a.name.localeCompare(b.name, 'pt'));
    const toDeliver = round2(salesReceived + debtReceived);
    const unjustQty = round2(lines.reduce((a, l) => a + l.unjust, 0));
    const unjustValue = round2(lines.reduce((a, l) => a + l.unjust * l.price, 0));
    // Vendas pelo stock: o que saiu (vendido na caixa + saídas sem registo da contagem), ao preço de venda.
    for (const l of lines) l.out = round2(l.sold + (l.diff < 0 ? -l.diff : 0));
    const soldValue = round2(lines.reduce((a, l) => a + l.sold * l.price, 0));
    return {
      from, to, first: !last, custom: !!fromIso || !!toIso, countId: count ? count.id : null, countAt: count ? count.finishedAt : null,
      countInProgress: !!this.currentCount(), lines, entries,
      expenseList: expenseList.map(e => ({ id: e.id, date: e.date, category: e.category, description: e.description, amount: e.amount, supplierPays: !!e.supplierPays })),
      totals: {
        received, salesReceived, debtReceived, toDeliver, missingQty, missingValue, surplusQty,
        total: round2(toDeliver + missingValue + unjustValue - expensesDeducted), unjustQty, unjustValue, expensesDeducted, creditSales: round2(rep.byPayment.credit || 0),
        openDebt: this.totalDebt(), expenses, soldQty: round2(lines.reduce((a, l) => a + l.sold, 0)),
        inQty: round2(lines.reduce((a, l) => a + l.in, 0)),
        soldValue, stockSalesValue: round2(soldValue + missingValue), stockSalesQty: round2(lines.reduce((a, l) => a + l.out, 0)),
      },
    };
  },

  // Total a entregar a partir do Balanço de stock entre duas contagens:
  // Saídas − quebras/perdas justificadas − fiado ainda por receber + fiado recebido − despesas pagas.
  // Conferência: o dinheiro que entrou no caixa (POS) comparado com o que saiu do stock.
  countSettlement(fromId, toId) {
    const a = this.find('stockCounts', fromId), b = this.find('stockCounts', toId);
    const bal = this.countBalance(fromId, toId);
    const fromDay = bal.from, toDay = bal.to;
    const inDays = d => d > fromDay && d <= toDay;
    const justified = round2(this.data.stockEntries.filter(e => e.type === 'adjust' && (e.reason === 'loss' || e.reason === 'break') && e.justified && inDays(e.date))
      .reduce((acc, e) => { const it = this.find('items', e.itemId); return acc + (-e.qty) * (it ? it.price || 0 : 0); }, 0));
    const fromD = new Date(new Date(a.finishedAt).getTime() + 1), toD = new Date(new Date(b.finishedAt).getTime() + 1);
    const rep = this.report(fromD, toD);
    // Fiado: vendas a crédito no caixa + fiado registado à mão no período.
    const manualCredit = round2(this.data.credits.filter(r => inDays(r.date)).reduce((acc, r) => acc + r.amount, 0));
    const creditSales = round2((rep.byPayment.credit || 0) + manualCredit);
    const cashIn = round2(PAY_TYPES.filter(k => k !== 'credit').reduce((acc, k) => acc + (rep.byPayment[k] || 0), 0));
    const inTime = iso => iso > a.finishedAt && iso <= b.finishedAt;
    const debtReceived = round2(this.data.debtPayments.filter(x => inTime(x.createdAt || x.date)).reduce((acc, x) => acc + x.amount, 0));
    const expensesDeducted = round2(this.data.expenses.filter(e => e.supplierPays && inDays(e.date)).reduce((acc, e) => acc + e.amount, 0));
    const out = bal.totals.out;
    const total = round2(out - justified - creditSales + debtReceived - expensesDeducted);
    // Dinheiro que devia ter entrado pelas vendas do stock (sem o fiado) e o que entrou de facto.
    const cashExpected = round2(out - justified - creditSales);
    return { fromId, toId, from: fromDay, to: toDay, out, justified, creditSales, debtReceived, expensesDeducted, total, cashIn, cashExpected, cashDiff: round2(cashIn - cashExpected), noFinal: bal.noFinal };
  },

  // Guarda o fecho: o próximo começa aqui.
  saveSettlement(preview, employeeId, note = '') {
    if (this.currentCount()) fail('err.countOpen');
    const s = Object.assign({ id: uid(), createdAt: new Date().toISOString(), employeeId, note }, preview);
    delete s.countInProgress; delete s.first;
    this.data.settlements.push(s);
    this.save();
    return s;
  },

  // Corrige um fecho anterior: novas datas e nota; as contas refazem-se com os dados de agora
  // (por exemplo, depois de corrigir uma contagem).
  updateSettlement(id, { from, to, note }, employeeId) {
    const s = this.find('settlements', id);
    if (!s) fail('err.notFound');
    if (from > to) [from, to] = [to, from];
    const p = this.settlementPreview(from, to);
    delete p.countInProgress; delete p.first; delete p.custom;
    Object.assign(s, p, { note: String(note == null ? s.note || '' : note).trim(), editedAt: new Date().toISOString(), editedBy: employeeId });
    this.save();
    return s;
  },

  deleteSettlement(id) {
    this.remove('settlements', id);
  },

  // ---------- Balanço de stock (movimento do período) ----------
  // Stock inicial + Entradas − Stock final = Saídas, por produto e no total, em quantidade e valor.
  // Período por dias (inclusive), pela data de cada movimento. O stock final calcula-se a partir do
  // stock de agora, tirando os movimentos depois do período; o inicial, tirando os do período.
  // Assim o inicial de um período é sempre o final do anterior e cada movimento conta uma só vez.
  // Saídas = Vendas + Perdas + Quebras + Consumo interno + Ajustes manuais − Diferenças de contagem
  //          − Caixas abertas (mudança interna entre produtos).
  stockBalance(fromDay, toDay) {
    const unitOf = i => (this.showCost() ? i.cost || 0 : i.price || 0);
    const sales = {}; // itemId -> [{ day, qty }]
    for (const r of this.data.receipts) {
      const day = dayKey(new Date(r.date)), sg = r.type === 'refund' ? -1 : 1;
      for (const l of r.lines) (sales[l.itemId] || (sales[l.itemId] = [])).push({ day, qty: sg * l.qty });
    }
    const lines = [];
    for (const item of this.data.items.filter(i => i.trackStock)) {
      const z = { in: 0, sold: 0, loss: 0, break: 0, internal: 0, manual: 0, count: 0, opened: 0 };
      let after = 0;
      for (const e of this.data.stockEntries) {
        if (e.itemId !== item.id) continue;
        if (e.date > toDay) { after += e.qty; continue; }
        if (e.date < fromDay) continue;
        if (e.type === 'in') z.in += e.qty;
        else if (e.open) z.opened += e.qty;
        else if (e.countId) z.count += e.qty;
        else z[ADJUST_REASONS.includes(e.reason) ? e.reason : 'manual'] += e.qty;
      }
      for (const x of sales[item.id] || []) {
        if (x.day > toDay) after -= x.qty;
        else if (x.day >= fromDay) z.sold += x.qty;
      }
      for (const k in z) z[k] = round2(z[k]);
      const final = round2(item.stock - after);
      const adj = z.loss + z.break + z.internal + z.manual;
      const opening = round2(final - z.in - adj - z.count - z.opened + z.sold);
      const out = round2(opening + z.in - final);
      if (!opening && !final && !z.in && !out && !z.count && !z.opened && !adj) continue;
      const unit = unitOf(item);
      lines.push({
        itemId: item.id, name: this.displayName(item), categoryId: item.categoryId || null, unit,
        opening, in: z.in, final, out, sold: z.sold,
        loss: round2(-z.loss), break: round2(-z.break), internal: round2(-z.internal), manual: round2(-z.manual),
        diff: z.count, opened: z.opened,
      });
    }
    lines.sort((a, b) => a.name.localeCompare(b.name, 'pt'));
    return { from: fromDay, to: toDay, byCost: this.showCost(), lines, totals: this.balanceTotals(lines) };
  },

  // Totais (quantidade e valor) de um conjunto de linhas do balanço de stock.
  balanceTotals(lines) {
    const t = {};
    for (const f of ['opening', 'in', 'final', 'out', 'sold', 'loss', 'break', 'internal', 'manual', 'diff', 'opened']) {
      t[f] = round2(lines.reduce((a, l) => a + l[f], 0));
      t[`${f}Value`] = round2(lines.reduce((a, l) => a + l[f] * l.unit, 0));
    }
    t.available = round2(t.opening + t.in);
    t.availableValue = round2(t.openingValue + t.inValue);
    return t;
  },

  // Movimentos que formam um número do balanço (para conferir): entradas, vendas, ajustes, etc.
  balanceMovements(fromDay, toDay, kind, itemIds = null) {
    const ok = id => !itemIds || itemIds.includes(id);
    const out = [];
    if (kind === 'sold') {
      for (const r of this.data.receipts) {
        const day = dayKey(new Date(r.date));
        if (day < fromDay || day > toDay) continue;
        for (const l of r.lines) if (ok(l.itemId)) out.push({ date: r.date, itemId: l.itemId, name: l.name, qty: (r.type === 'refund' ? -1 : 1) * l.qty, ref: r.number, employeeId: r.employeeId });
      }
    } else {
      for (const e of this.data.stockEntries) {
        if (e.date < fromDay || e.date > toDay || !ok(e.itemId)) continue;
        const k = e.type === 'in' ? 'in' : e.open ? 'opened' : e.countId ? 'diff' : ADJUST_REASONS.includes(e.reason) ? e.reason : 'manual';
        if (k !== kind) continue;
        const sign = ['loss', 'break', 'internal', 'manual'].includes(k) ? -1 : 1;
        out.push({ date: e.date, itemId: e.itemId, qty: round2(sign * e.qty), note: e.note || '', employeeId: e.employeeId });
      }
    }
    return out.sort((a, b) => String(b.date).localeCompare(String(a.date)));
  },

  saveStockBalance(bal, employeeId, label = '') {
    const b = { id: uid(), createdAt: new Date().toISOString(), employeeId, label: String(label || ''), from: bal.from, to: bal.to, byCost: bal.byCost, lines: bal.lines, totals: bal.totals,
      ...(bal.mode === 'counts' ? { mode: 'counts', fromId: bal.fromId, toId: bal.toId } : {}) };
    this.data.stockBalances.push(b);
    this.save();
    return b;
  },

  deleteStockBalance(id) { this.remove('stockBalances', id); },

  // ---------- Balanço entre contagens (como no caderno) ----------
  // Stock inicial (contado) + Entradas (entre as duas datas) − Stock final (contado) = Saídas.
  // Valores ao preço de cada produto. Não depende das vendas do POS (que aparecem só para comparar).
  countDay(c) { return c.day || dayKey(new Date(c.finishedAt)); },

  doneCounts() {
    return this.data.stockCounts.filter(c => c.status === 'done' && !this.isCheck(c) && c.finishedAt)
      .sort((a, b) => a.finishedAt.localeCompare(b.finishedAt));
  },

  countValue(c) {
    return round2(c.lines.reduce((a, l) => {
      const item = this.find('items', l.itemId);
      return a + (l.counted || 0) * ((item && item.price) || l.price || 0);
    }, 0));
  },

  countBalance(fromId, toId) {
    const a = this.find('stockCounts', fromId), b = this.find('stockCounts', toId);
    if (!a || !b || a.status !== 'done' || b.status !== 'done') fail('err.countClosed');
    const fromDay = this.countDay(a), toDay = this.countDay(b);
    const ca = new Map(a.lines.map(l => [l.itemId, l])), cb = new Map(b.lines.map(l => [l.itemId, l]));
    const ids = new Set([...ca.keys(), ...cb.keys()]);
    const inQty = {};
    for (const e of this.data.stockEntries) {
      if (e.type !== 'in' || e.date <= fromDay || e.date > toDay) continue;
      ids.add(e.itemId);
      inQty[e.itemId] = round2((inQty[e.itemId] || 0) + e.qty);
    }
    const lines = [];
    let noFinal = 0;
    for (const id of ids) {
      const item = this.find('items', id);
      if (!item) continue;
      const la = ca.get(id), lb = cb.get(id);
      const opening = la && la.counted != null ? la.counted : 0;
      const final = lb && lb.counted != null ? lb.counted : 0;
      if (!(lb && lb.counted != null) && (opening || inQty[id])) noFinal++;
      const qIn = inQty[id] || 0;
      if (!opening && !qIn && !final) continue;
      lines.push({ itemId: id, name: this.displayName(item), price: item.price || 0, opening, in: qIn, final, out: round2(opening + qIn - final) });
    }
    lines.sort((x, y) => x.name.localeCompare(y.name, 'pt'));
    const sum = f => round2(lines.reduce((s2, l) => s2 + l[f] * l.price, 0));
    const t = { opening: sum('opening'), in: sum('in'), final: sum('final'), out: sum('out') };
    t.available = round2(t.opening + t.in);
    // Vendas do POS entre as duas contagens (só para comparar com as saídas).
    const rep = this.report(new Date(new Date(a.finishedAt).getTime() + 1), new Date(new Date(b.finishedAt).getTime() + 1));
    t.posSold = round2(rep.total);
    t.unexplained = round2(t.out - t.posSold);
    return { fromId, toId, from: fromDay, to: toDay, lines, totals: t, noFinal };
  },

  // ---------- Acertar o stock pela última contagem ----------
  // Para cada produto: o que foi contado na última contagem (com fornecedor/gestor) + entradas e
  // ajustes depois dela − vendas depois dela. A diferença para o stock de agora entra no ajuste
  // dessa contagem (assim o balanço entre contagens não muda).
  rebasePreview() {
    const counts = this.doneCounts().slice().reverse(); // mais recente primeiro
    const out = [];
    for (const item of this.data.items.filter(i => i.trackStock)) {
      const c = counts.find(x => x.lines.some(l => l.itemId === item.id && l.counted != null));
      if (!c) continue;
      const line = c.lines.find(l => l.itemId === item.id);
      const day = this.countDay(c);
      let v = line.counted;
      for (const e of this.data.stockEntries) {
        if (e.itemId !== item.id || e.countId === c.id) continue;
        const after = e.date > day || (e.date === day && !c.day && (e.createdAt || '') > c.finishedAt);
        if (after) v += e.qty;
      }
      for (const r of this.data.receipts) {
        if (r.date <= c.finishedAt) continue;
        const sg = r.type === 'refund' ? -1 : 1;
        for (const l of r.lines) if (l.itemId === item.id) v -= sg * l.qty;
      }
      v = round2(v);
      if (Math.abs(v - item.stock) > 1e-9) out.push({ itemId: item.id, name: this.displayName(item), countId: c.id, day, now: item.stock, target: v });
    }
    return out.sort((a, b) => a.name.localeCompare(b.name, 'pt'));
  },

  rebaseFromLastCount(employeeId) {
    const list = this.rebasePreview();
    for (const x of list) {
      const item = this.find('items', x.itemId), c = this.find('stockCounts', x.countId);
      const line = c.lines.find(l => l.itemId === x.itemId);
      const delta = round2(x.target - item.stock);
      item.stock = x.target;
      line.expected = round2((line.expected || 0) - delta);
      line.diff = round2(line.counted - line.expected);
      let e = this.data.stockEntries.find(z => z.countId === c.id && z.itemId === x.itemId && z.type === 'adjust');
      if (!e) {
        e = { id: uid(), itemId: x.itemId, type: 'adjust', qty: 0, date: x.day, cost: null, note: 'Balanço', createdAt: c.finishedAt, employeeId, countId: c.id };
        this.data.stockEntries.push(e);
      }
      e.qty = round2(e.qty + delta);
      if (!e.qty) this.data.stockEntries = this.data.stockEntries.filter(z => z !== e);
      this.recountTotals(c);
    }
    if (list.length) this.save();
    return list.length;
  },

  // ---------- Caixas e lâminas (embalagens ligadas) ----------
  // Um produto "caixa" pode abrir-se noutro produto: item.opensInto (id) × item.opensQty (ex.: 4 lâminas).

  // Caixa (com stock) que se abre neste produto, se existir.
  packSource(itemId) {
    return this.data.items.find(i => i.opensInto === itemId && i.trackStock && i.stock > 0) || null;
  },

  // Abre n caixas: −n na caixa e +n × opensQty no produto em que se abre. É uma mudança interna
  // (ajuste marcado como "open"): não conta como entrada, venda nem saída no fecho.
  openPack(boxId, n, employeeId) {
    const box = this.find('items', boxId);
    const target = box && box.opensInto ? this.find('items', box.opensInto) : null;
    const k = round2(n);
    if (!box || !target) fail('err.notFound');
    if (!(k > 0) || !Number.isInteger(k)) fail('err.invalidQty');
    if (box.trackStock && box.stock + 1e-9 < k) fail('err.packNoStock');
    const per = Number(box.opensQty) || 1;
    const now = new Date().toISOString(), date = dayKey(new Date()), group = uid();
    box.stock = round2(box.stock - k);
    target.stock = round2(target.stock + k * per);
    const entry = (itemId, qty) => ({ id: uid(), itemId, type: 'adjust', open: group, qty, date, cost: null, note: 'Caixa aberta', createdAt: now, employeeId });
    this.data.stockEntries.push(entry(box.id, -k), entry(target.id, k * per));
    this.save();
    return { box, target, qty: k * per };
  },

  // Ligações sugeridas pelo nome: produto numa categoria de caixas → mesmo nome numa de lâminas.
  suggestPackLinks() {
    const norm = x => String(x || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim();
    const catIds = re => this.data.categories.filter(c => re.test(norm(c.name))).map(c => c.id);
    const boxCats = catIds(/caixa/), sheetCats = catIds(/lamina/);
    const sheets = this.data.items.filter(i => sheetCats.includes(i.categoryId));
    const out = [];
    for (const box of this.data.items.filter(i => boxCats.includes(i.categoryId))) {
      const target = sheets.find(sh => norm(sh.name) === norm(box.name));
      if (target) out.push({ box, target, linked: box.opensInto === target.id });
    }
    return out;
  },

  // Nome para mostrar: se houver outro produto com o mesmo nome noutra categoria, junta a
  // categoria em forma curta — "Gold (lâmina)", "Gold (caixa)" ("Por Lâmina" → "lâmina").
  displayName(item) {
    if (!item) return '';
    const norm = x => String(x || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/\s+/g, ' ').trim();
    const cat = item.categoryId && this.find('categories', item.categoryId);
    if (!cat) return item.name;
    const chosen = (this.data.settings.tagCats || []).filter(id => this.find('categories', id));
    if (chosen.length) {
      // Categorias escolhidas nas Configurações: estas levam sempre a categoria; as outras nunca.
      if (!chosen.includes(cat.id)) return item.name;
    } else {
      const n = norm(item.name);
      if (!this.data.items.some(i => i !== item && norm(i.name) === n && i.categoryId !== item.categoryId)) return item.name;
    }
    const short = cat.name.replace(/^(por|a|o|as|os|em|de|da|do)\s+/i, '').trim().toLowerCase();
    return `${item.name} (${short || cat.name})`;
  },

  // ---------- Produtos repetidos ----------

  // Repetidos: mesmo nome e (sem categoria, ou a mesma categoria). Para cada um, os candidatos a ficar.
  findDuplicates() {
    const norm = x => String(x || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/\s+/g, ' ').trim();
    const cat = i => (i.categoryId && this.find('categories', i.categoryId) ? i.categoryId : null);
    const byName = new Map();
    for (const i of this.data.items) {
      const k = norm(i.name);
      if (!byName.has(k)) byName.set(k, []);
      byName.get(k).push(i);
    }
    const out = [];
    for (const group of byName.values()) {
      if (group.length < 2) continue;
      for (const drop of group) {
        // Sem categoria: junta-se a um com categoria. Mesma categoria: o mais recente junta-se ao primeiro.
        const targets = cat(drop) ? group.filter(x => x !== drop && cat(x) === cat(drop) && group.indexOf(x) < group.indexOf(drop))
          : group.filter(x => x !== drop && cat(x));
        if (!cat(drop) && !targets.length) continue;
        if (targets.length) out.push({ drop, targets });
      }
    }
    return out;
  },

  // Junta "drop" em "keep": soma o stock e passa vendas, entradas, contagens e fechos para "keep".
  mergeItems(keepId, dropId) {
    const d = this.data;
    const keep = this.find('items', keepId), drop = this.find('items', dropId);
    if (!keep || !drop || keep === drop) fail('err.notFound');
    if (drop.trackStock) { keep.trackStock = true; keep.stock = round2((keep.stock || 0) + (drop.stock || 0)); }
    for (const e of d.stockEntries) if (e.itemId === dropId) e.itemId = keepId;
    for (const r of [...d.receipts, ...d.openTickets]) for (const l of r.lines || []) if (l.itemId === dropId) l.itemId = keepId;
    for (const i of d.items) if (i.opensInto === dropId) i.opensInto = keepId;
    const sum = (a, b) => (a == null && b == null ? null : round2((a || 0) + (b || 0)));
    const mergeLines = (lines, fields) => {
      const dl = lines.find(l => l.itemId === dropId);
      if (!dl) return lines;
      const kl = lines.find(l => l.itemId === keepId);
      if (!kl) { dl.itemId = keepId; dl.name = keep.name; return lines; }
      for (const f of fields) kl[f] = sum(kl[f], dl[f]);
      return lines.filter(l => l !== dl);
    };
    for (const c of d.stockCounts) {
      c.lines = mergeLines(c.lines, ['expected', 'counted', 'diff']);
      if (c.status === 'done' && c.totals) this.recountTotals(c);
    }
    for (const s of d.settlements) s.lines = mergeLines(s.lines || [], ['opening', 'in', 'adjust', 'opened', 'sold', 'expected', 'counted', 'diff', 'out']);
    d.items = d.items.filter(i => i !== drop);
    this.save();
    return keep;
  },

  // ---------- Vendas ----------

  finalizeSale(ticket, payment, employeeId) {
    const d = this.data;
    if (!ticket.lines.length) fail('err.ticketEmpty');
    const t = computeTotals(ticket, d.settings);
    const customer = ticket.customerId ? this.find('customers', ticket.customerId) : null;
    if (t.points > 0 && (!customer || customer.points + 1e-9 < t.points)) fail('err.notEnoughPoints');
    if (payment.type === 'credit' && !customer) fail('err.creditNeedsCustomer');
    let received = t.total;
    if (payment.type === 'cash' && payment.received != null && payment.received !== '') {
      received = round2(payment.received);
      if (received + 1e-9 < t.total) fail('err.receivedTooLow');
    }
    const earned = customer ? round2(t.total * (Number(d.settings.loyaltyRate) || 0) / 100) : 0;
    const shift = this.currentShift();
    const receipt = {
      id: uid(),
      number: ++d.counters.receipt,
      deviceNo: this.deviceNo,
      type: 'sale',
      date: new Date().toISOString(),
      employeeId,
      customerId: customer ? customer.id : null,
      lines: ticket.lines.map(l => ({ itemId: l.itemId, name: l.name, price: l.price, cost: l.cost || 0, qty: l.qty, categoryId: l.categoryId || null })),
      ...t,
      payment: { type: payment.type, amount: t.total, received, change: round2(received - t.total) },
      pointsEarned: earned,
      shiftId: shift ? shift.id : null,
      refundedBy: null,
    };
    for (const l of receipt.lines) {
      const it = this.find('items', l.itemId);
      if (!it || !it.trackStock) continue;
      // Sem lâminas suficientes: abre as caixas que fizerem falta (se houver caixas ligadas).
      let box = it.stock + 1e-9 < l.qty ? this.packSource(it.id) : null;
      while (box && it.stock + 1e-9 < l.qty) {
        const per = Number(box.opensQty) || 1;
        const n = Math.min(Math.ceil((l.qty - it.stock) / per), Math.floor(box.stock));
        if (n < 1) break;
        this.openPack(box.id, n, employeeId);
        box = this.packSource(it.id);
      }
      it.stock = round2(it.stock - l.qty);
    }
    if (customer) {
      customer.points = round2(customer.points - t.points + earned);
      customer.visits += 1;
      customer.totalSpent = round2(customer.totalSpent + t.total);
      if (payment.type === 'credit') customer.debt = round2((customer.debt || 0) + t.total);
    }
    if (ticket.openTicketId) {
      d.openTickets = d.openTickets.filter(o => o.id !== ticket.openTicketId);
    }
    d.receipts.unshift(receipt);
    this.save();
    return receipt;
  },

  // Apaga um recibo e desfaz o que ele fez (stock, pontos, visitas e dívida do cliente).
  // Uma venda já devolvida apaga-se com a sua devolução; apagar só a devolução desfaz a devolução.
  deleteReceipt(receiptId) {
    const d = this.data;
    const r = this.find('receipts', receiptId);
    if (!r) fail('err.invalidReceipt');
    const customer = r.customerId ? this.find('customers', r.customerId) : null;
    const moveStock = (rec, sign) => {
      for (const l of rec.lines) {
        const it = this.find('items', l.itemId);
        if (it && it.trackStock) it.stock = round2(it.stock + sign * l.qty);
      }
    };
    // Efeito da venda no cliente (sign = -1 desfaz, +1 volta a aplicar).
    const applySale = (sale, sign) => {
      if (!customer) return;
      customer.points = Math.max(0, round2(customer.points + sign * (sale.pointsEarned - sale.points)));
      customer.totalSpent = Math.max(0, round2(customer.totalSpent + sign * sale.total));
      if (sale.payment.type === 'credit') customer.debt = Math.max(0, round2((customer.debt || 0) + sign * sale.total));
    };
    const ids = new Set([r.id]);
    if (r.type === 'sale') {
      if (r.refundedBy) ids.add(r.refundedBy); // a devolução já repôs stock e cliente
      else { moveStock(r, +1); applySale(r, -1); }
      if (customer) customer.visits = Math.max(0, customer.visits - 1);
    } else {
      const orig = this.find('receipts', r.refundOf);
      moveStock(r, -1);
      if (orig) { applySale(orig, +1); orig.refundedBy = null; }
    }
    d.receipts = d.receipts.filter(x => !ids.has(x.id));
    this.save();
    return [...ids];
  },

  refund(receiptId, employeeId) {
    const d = this.data;
    const r = this.find('receipts', receiptId);
    if (!r || r.type !== 'sale') fail('err.invalidReceipt');
    if (r.refundedBy) fail('err.alreadyRefunded');
    const shift = this.currentShift();
    const ref = {
      ...JSON.parse(JSON.stringify(r)),
      id: uid(),
      number: ++d.counters.receipt,
      deviceNo: this.deviceNo,
      type: 'refund',
      date: new Date().toISOString(),
      employeeId,
      refundOf: r.id,
      refundedBy: null,
      shiftId: shift ? shift.id : null,
      payment: { type: r.payment.type, amount: r.total, received: r.total, change: 0 },
      pointsEarned: 0,
    };
    for (const l of r.lines) {
      const it = this.find('items', l.itemId);
      if (it && it.trackStock) it.stock = round2(it.stock + l.qty);
    }
    const customer = r.customerId ? this.find('customers', r.customerId) : null;
    if (customer) {
      customer.points = Math.max(0, round2(customer.points - r.pointsEarned + r.points));
      customer.totalSpent = Math.max(0, round2(customer.totalSpent - r.total));
      if (r.payment.type === 'credit') customer.debt = Math.max(0, round2((customer.debt || 0) - r.total));
    }
    r.refundedBy = ref.id;
    d.receipts.unshift(ref);
    this.save();
    return ref;
  },

  // ---------- Tickets guardados ----------

  saveOpenTicket(ticket, name) {
    const d = this.data;
    const copy = JSON.parse(JSON.stringify(ticket));
    copy.name = name || copy.name || 'Ticket';
    copy.date = new Date().toISOString();
    if (copy.openTicketId) {
      const i = d.openTickets.findIndex(o => o.id === copy.openTicketId);
      copy.id = copy.openTicketId;
      if (i >= 0) d.openTickets[i] = copy;
      else d.openTickets.push(copy);
    } else {
      copy.id = uid();
      copy.openTicketId = copy.id;
      d.openTickets.push(copy);
    }
    this.save();
    return copy;
  },

  // ---------- Turnos (um por dispositivo) ----------

  currentShift() {
    return this.data.shifts.find(s => !s.closedAt && (s.deviceId || 'local') === this.deviceId) || null;
  },

  openShift(startCash, employeeId) {
    if (this.currentShift()) fail('err.shiftAlreadyOpen');
    const s = { id: uid(), deviceId: this.deviceId, deviceNo: this.deviceNo, openedAt: new Date().toISOString(), closedAt: null, openedBy: employeeId, closedBy: null, startCash: round2(startCash || 0), movements: [], actualCash: null };
    this.data.shifts.unshift(s);
    this.save();
    return s;
  },

  addCashMovement(type, amount, note, employeeId) {
    const s = this.currentShift();
    if (!s) fail('err.noOpenShift');
    const a = round2(amount);
    if (!(a > 0)) fail('err.invalidAmount');
    s.movements.push({ id: uid(), type, amount: a, note: note || '', date: new Date().toISOString(), employeeId });
    this.save();
  },

  shiftSummary(shift) {
    const rs = this.data.receipts.filter(r => r.shiftId === shift.id);
    const sales = rs.filter(r => r.type === 'sale');
    const refunds = rs.filter(r => r.type === 'refund');
    const sumBy = (list, type) => round2(list.filter(r => !type || r.payment.type === type).reduce((a, r) => a + r.total, 0));
    const payIns = round2(shift.movements.filter(m => m.type === 'in').reduce((a, m) => a + m.amount, 0));
    const payOuts = round2(shift.movements.filter(m => m.type === 'out').reduce((a, m) => a + m.amount, 0));
    const cashSales = sumBy(sales, 'cash');
    const cashRefunds = sumBy(refunds, 'cash');
    // Pagamentos de dívidas recebidos em dinheiro neste turno também entram na gaveta.
    const debtCash = round2(this.data.debtPayments.filter(p => p.shiftId === shift.id && p.payType === 'cash').reduce((a, p) => a + p.amount, 0));
    const expected = round2(shift.startCash + cashSales - cashRefunds + debtCash + payIns - payOuts);
    const byPayment = {};
    for (const k of PAY_TYPES) byPayment[k] = round2(sumBy(sales, k) - sumBy(refunds, k));
    return {
      receipts: sales.length,
      grossSales: sumBy(sales),
      refunds: sumBy(refunds),
      netSales: round2(sumBy(sales) - sumBy(refunds)),
      cashSales, cashRefunds, debtCash, payIns, payOuts, expected, byPayment,
      difference: shift.actualCash == null ? null : round2(shift.actualCash - expected),
    };
  },

  closeShift(actualCash, employeeId) {
    const s = this.currentShift();
    if (!s) fail('err.noOpenShift');
    s.actualCash = round2(actualCash || 0);
    s.closedAt = new Date().toISOString();
    s.closedBy = employeeId;
    s.summary = this.shiftSummary(s);
    this.save();
    return s;
  },

  // ---------- Relatórios ----------

  report(from, to) {
    const rs = this.data.receipts.filter(r => {
      const t = new Date(r.date).getTime();
      return t >= from.getTime() && t < to.getTime();
    });
    const sign = r => (r.type === 'refund' ? -1 : 1);
    const out = {
      grossSales: 0, refunds: 0, discounts: 0, netSales: 0, tax: 0, total: 0, cost: 0, profit: 0,
      salesCount: 0, refundCount: 0, average: 0,
      byDay: {}, byHour: {}, byItem: {}, byCategory: {}, byPayment: {}, byEmployee: {},
      receipts: rs,
    };
    for (const r of rs) {
      const s = sign(r);
      if (s > 0) { out.grossSales += r.subtotal; out.salesCount++; }
      else { out.refunds += r.subtotal; out.refundCount++; }
      out.discounts += s * (r.discount + r.points);
      out.netSales += s * r.net;
      out.tax += s * r.tax;
      out.total += s * r.total;
      out.cost += s * r.cost;
      const key = dayKey(new Date(r.date));
      out.byDay[key] = (out.byDay[key] || 0) + s * r.net;
      const hourKey = `${key} ${String(new Date(r.date).getHours()).padStart(2, '0')}`;
      out.byHour[hourKey] = (out.byHour[hourKey] || 0) + s * r.net;
      out.byPayment[r.payment.type] = (out.byPayment[r.payment.type] || 0) + s * r.total;
      out.byEmployee[r.employeeId] = (out.byEmployee[r.employeeId] || 0) + s * r.net;
      // Rateio do desconto do recibo pelas linhas, para valores líquidos por item.
      const factor = r.subtotal > 0 ? r.net / r.subtotal : 0;
      for (const l of r.lines) {
        const it = out.byItem[l.itemId] || (out.byItem[l.itemId] = { name: l.name, qty: 0, net: 0, cost: 0 });
        it.qty += s * l.qty;
        it.net += s * l.price * l.qty * factor;
        it.cost += s * l.cost * l.qty;
        const item = this.find('items', l.itemId);
        const catId = l.categoryId || (item && item.categoryId) || 'none';
        const c = out.byCategory[catId] || (out.byCategory[catId] = { qty: 0, net: 0 });
        c.qty += s * l.qty;
        c.net += s * l.price * l.qty * factor;
      }
    }
    out.profit = out.netSales - out.cost;
    out.average = out.salesCount ? out.total / out.salesCount : 0;
    for (const k of ['grossSales', 'refunds', 'discounts', 'netSales', 'tax', 'total', 'cost', 'profit', 'average']) out[k] = round2(out[k]);
    return out;
  },
};

if (typeof module !== 'undefined') {
  module.exports = {
    Store, computeTotals, dayKey, newTicket, round2, uid, demoData, emptyData, migrate, receiptNo,
    CURRENCIES, PAY_TYPES, EXPENSE_CATEGORIES, MERGE_FIELDS, SYNC_COLLECTIONS, ADJUST_REASONS, DB_KEY, mergeCount,
  };
}

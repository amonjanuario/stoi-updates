'use strict';
// Stoi — projeto Firebase da loja (sincronização entre dispositivos e, mais tarde, chat).
// Estes dados não são secretos: identificam o projeto. A proteção vem das regras do Firestore
// (cada conta só lê e escreve os dados da própria loja) — ver docs/FIREBASE.md.
// Projeto: "Stoi App" (stoi-app-81aa5), base de dados em africa-south1 (Joanesburgo).
// Para testes, pode pôr-se outra configuração em localStorage['stoi-fb-config'] (JSON),
// com "emulator": "127.0.0.1" para usar o simulador local do Firebase.
window.STOI_FIREBASE = {
  apiKey: 'AIzaSyCKHrU7bZJNdwxdjvl5eLlgpOvQbkEIBwQ',
  authDomain: 'stoi-app-81aa5.firebaseapp.com',
  projectId: 'stoi-app-81aa5',
  storageBucket: 'stoi-app-81aa5.firebasestorage.app',
  messagingSenderId: '905041424238',
  appId: '1:905041424238:web:2c7666011305e88cc51b7f',
  // Login com Google (cliente Web do OAuth, criado pelo Firebase ao ativar o Google).
  googleClientId: '905041424238-66jrnurqvo6o70nmiumpl8rurrktvjnq.apps.googleusercontent.com',
};

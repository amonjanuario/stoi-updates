'use strict';
// Stoi — sincronização com a conta na nuvem (servidor em server/server.js).
//
// Funciona "offline primeiro": o dispositivo trabalha sempre com os dados locais e, quando há
// ligação, envia o que mudou desde a última sincronização e recebe o que mudou noutros
// dispositivos. As alterações detetam-se comparando cada registo com a última versão
// sincronizada (snapshot), por isso nenhum ecrã precisa de marcar o que alterou.
// Stock e pontos de clientes juntam-se somando diferenças, para que vendas feitas ao mesmo
// tempo em dois dispositivos não se anulem.

/* global Store, MERGE_FIELDS, SYNC_COLLECTIONS, round2, uid, mergeCount, firebase, Capacitor, Chat */

const CLOUD_KEY = 'stoi-cloud';

// ---------- Firebase (Firestore + Authentication) ----------
// Cada loja é uma conta (email e senha). Os registos ficam em stores/{uid}/records/{col}__{id}
// com { col, id, deleted, data, ts } — ts é a hora do servidor, usada como cursor.
// Stock, pontos e dívidas juntam-se por diferenças numa transação, como no servidor próprio.
function fbConfig() {
  try { const o = JSON.parse(localStorage.getItem('stoi-fb-config')); if (o && o.projectId) return o; } catch (e) { /* ignorar */ }
  return (typeof window !== 'undefined' && window.STOI_FIREBASE) || null;
}
const FB_ERR = {
  'auth/email-already-in-use': 'err.emailTaken', 'auth/invalid-email': 'err.invalidEmail', 'auth/weak-password': 'err.passwordShort',
  'auth/wrong-password': 'err.wrongLogin', 'auth/user-not-found': 'err.wrongLogin', 'auth/invalid-credential': 'err.wrongLogin',
  'auth/invalid-login-credentials': 'err.wrongLogin', 'auth/network-request-failed': 'err.network', 'unavailable': 'err.network',
  'permission-denied': 'err.server', 'auth/too-many-requests': 'err.tooMany',
  'auth/missing-email': 'err.invalidEmail', 'auth/popup-closed-by-user': 'err.cancelled', 'auth/cancelled-popup-request': 'err.cancelled',
  'auth/operation-not-allowed': 'err.googleOff', 'auth/requires-recent-login': 'err.recentLogin', 'auth/provider-already-linked': 'err.hasPassword',
  'auth/credential-already-in-use': 'err.emailTaken', 'auth/admin-restricted-operation': 'err.server',
};
const fbError = e => {
  const err = new Error(FB_ERR[e && e.code] || (e && e.message && e.message.startsWith('err.') ? e.message : 'err.server'));
  if (err.message === 'err.network') err.offline = true;
  if (e && (e.code === 'unauthenticated' || e.code === 'auth/user-token-expired')) err.status = 401;
  if (e && e.revoked) { err.message = 'err.revoked'; err.status = 401; }
  return err;
};
const FB = {
  app: null, auth: null, db: null, ready: null,
  available() { return !!(fbConfig() && typeof firebase !== 'undefined' && firebase.initializeApp); },
  init() {
    if (this.app) return this;
    const cfg = fbConfig();
    this.app = firebase.initializeApp(cfg, 'stoi');
    this.auth = this.app.auth();
    this.db = this.app.firestore();
    if (cfg.emulator) {
      this.auth.useEmulator(`http://${cfg.emulator}:9099`, { disableWarnings: true });
      this.db.useEmulator(cfg.emulator, 8085);
    }
    this.ready = new Promise(res => { const off = this.auth.onAuthStateChanged(u => { off(); res(u); }); });
    return this;
  },
  store(uidv) { return this.db.collection('stores').doc(uidv); },
  async user() { this.init(); await this.ready; return this.auth.currentUser; },
  // Número deste dispositivo na loja (para os números dos recibos).
  async deviceNo(uidv, deviceId) {
    const ref = this.store(uidv).collection('meta').doc('devices');
    return this.db.runTransaction(async tx => {
      const d = await tx.get(ref);
      const v = d.exists ? d.data() : { next: 1, devices: {} };
      if (v.devices && v.devices[deviceId]) return v.devices[deviceId];
      const n = v.next || 1;
      tx.set(ref, { next: n + 1, devices: Object.assign({}, v.devices, { [deviceId]: n }) });
      return n;
    });
  },
  async push(uidv, changes, fresh = false) {
    const recs = this.store(uidv).collection('records');
    const ts = firebase.firestore.FieldValue.serverTimestamp();
    const clean = o => JSON.parse(JSON.stringify(o));
    // Conta nova (nuvem vazia): tudo de uma vez, sem transações.
    const merged = c => !fresh && ((MERGE_FIELDS[c.col] || []).length || c.col === 'stockCounts');
    let batch = this.db.batch(), n = 0;
    const flush = async () => { if (n) await batch.commit(); batch = this.db.batch(); n = 0; };
    for (const ch of changes) {
      const ref = recs.doc(`${ch.col}__${ch.id}`);
      if (ch.deleted) { batch.set(ref, { col: ch.col, id: ch.id, deleted: true, data: null, ts, upd: ch.updatedAt }); n++; }
      else if (!merged(ch)) { batch.set(ref, { col: ch.col, id: ch.id, deleted: false, data: clean(ch.data), ts, upd: ch.updatedAt }); n++; }
      else {
        // Stock, pontos, dívidas e contagens: junta com o que já está na nuvem (como o servidor próprio).
        await this.db.runTransaction(async tx => {
          const d = await tx.get(ref);
          const live = d.exists && !d.data().deleted ? d.data() : null;
          if (d.exists && d.data().deleted) return; // apagar ganha
          const newer = live && (live.upd || 0) > ch.updatedAt;
          let data = Object.assign({}, newer ? live.data : ch.data);
          if (ch.col === 'stockCounts' && live) data = newer ? mergeCount(live.data, ch.data) : mergeCount(ch.data, live.data);
          for (const f of MERGE_FIELDS[ch.col] || []) {
            const delta = ch.deltas && Number.isFinite(Number(ch.deltas[f])) ? Number(ch.deltas[f]) : Number(ch.data[f]) || 0;
            data[f] = round2((live ? Number(live.data[f]) || 0 : 0) + delta);
          }
          tx.set(ref, { col: ch.col, id: ch.id, deleted: false, data: clean(data), ts, upd: Math.max(ch.updatedAt, live ? live.upd || 0 : 0) });
        });
      }
      if (n >= 400) await flush();
    }
    await flush();
  },
  // Registos alterados desde o cursor (com 5 s de folga, porque aplicar duas vezes não faz mal).
  async pull(uidv, cursor) {
    let q = this.store(uidv).collection('records');
    if (cursor) q = q.where('ts', '>', firebase.firestore.Timestamp.fromMillis(Math.max(0, cursor - 5000)));
    const snap = await q.orderBy('ts').get({ source: 'server' });
    let max = cursor || 0;
    const records = snap.docs.map(d => {
      const v = d.data();
      const ms = v.ts ? v.ts.toMillis() : 0;
      if (ms > max) max = ms;
      return { col: v.col, id: v.id, deleted: !!v.deleted, data: v.data };
    });
    return { records, cursor: max };
  },
  // Avisa logo que outro dispositivo muda alguma coisa (para sincronizar sem esperar).
  watch(uidv, onChange) {
    const since = firebase.firestore.Timestamp.fromMillis(Date.now());
    return this.store(uidv).collection('records').where('ts', '>', since).onSnapshot(s => { if (!s.metadata.hasPendingWrites && s.docChanges().length) onChange(); }, () => {});
  },
};

// Texto de comparação que não depende da ordem dos campos: a nuvem devolve os campos noutra ordem
// (as Configurações, por exemplo, juntam-se aos valores por defeito) e isso não é uma alteração.
const sortKeys = v => (Array.isArray(v) ? v.map(sortKeys) : v && typeof v === 'object' ? Object.keys(v).sort().reduce((o, k) => { o[k] = sortKeys(v[k]); return o; }, {}) : v);
const stableJson = v => JSON.stringify(sortKeys(v));

const Sync = {
  state: null, // { url, token, email, storeName, cursor, deviceNo, snapshot, lastSync, lastError }
  deviceId: null,
  busy: false,
  status: 'off', // off | idle | syncing | offline | error
  onStatus: null, // (status) => void
  onRemoteChange: null, // () => void
  onKicked: null, // (motivo) => void — a conta deixou de ser válida neste celular
  _timer: null,
  _interval: null,

  init(deviceId) {
    this.deviceId = deviceId;
    try { this.state = JSON.parse(localStorage.getItem(CLOUD_KEY)) || null; } catch (e) { this.state = null; }
    if (this.state) {
      Store.deviceNo = this.state.deviceNo || null;
      this.setStatus('idle');
      this.startAuto();
    }
  },

  enabled() { return !!(this.state && this.state.token); },

  persist() {
    try {
      if (this.state) localStorage.setItem(CLOUD_KEY, JSON.stringify(this.state));
      else localStorage.removeItem(CLOUD_KEY);
    } catch (e) { /* ignorar */ }
  },

  setStatus(s) {
    this.status = s;
    if (this.onStatus) this.onStatus(s);
  },

  pendingCount() {
    if (!this.enabled()) return 0;
    const cur = Store.records();
    const snap = this.state.snapshot;
    let n = 0;
    for (const k in cur) if (snap[k] !== stableJson(cur[k])) n++;
    for (const k in snap) if (!(k in cur)) n++;
    return n;
  },

  async request(path, body, token) {
    const base = (this.state && this.state.url) || '';
    const url = (body && body.__url) || base;
    if (body) delete body.__url;
    let res;
    try {
      res = await fetch(url.replace(/\/+$/, '') + path, {
        method: 'POST',
        headers: Object.assign({ 'Content-Type': 'application/json' }, token ? { Authorization: `Bearer ${token}` } : {}),
        body: JSON.stringify(body || {}),
      });
    } catch (e) {
      const err = new Error('err.network');
      err.offline = true;
      throw err;
    }
    let json = {};
    try { json = await res.json(); } catch (e) { /* resposta vazia */ }
    if (!res.ok) {
      const err = new Error(json.error || 'err.server');
      err.status = res.status;
      throw err;
    }
    return json;
  },

  // Firebase: a conta é criada / aberta no Firebase Authentication; o resto é igual.
  usesFirebase() { return FB.available(); },
  async fbAuth(mode, email, password) {
    FB.init();
    try {
      const cred = mode === 'register' ? await FB.auth.createUserWithEmailAndPassword(email, password) : await FB.auth.signInWithEmailAndPassword(email, password);
      if (mode === 'register') await FB.store(cred.user.uid).set({ email, storeName: Store.settings.storeName || '', createdAt: new Date().toISOString() });
      const meta = mode === 'login' ? await FB.store(cred.user.uid).get() : null;
      return { uid: cred.user.uid, email: cred.user.email, storeName: meta && meta.exists ? meta.data().storeName : Store.settings.storeName };
    } catch (e) { throw fbError(e); }
  },

  // Google: no APK usa a janela nativa do Android (plugin SocialLogin); no navegador, a janela do Firebase.
  googleReady() {
    if (!this.usesFirebase()) return false;
    const native = typeof Capacitor !== 'undefined' && Capacitor.isNativePlatform && Capacitor.isNativePlatform();
    return native ? !!(fbConfig().googleClientId && Capacitor.Plugins.SocialLogin) : true;
  },
  async googleAuth() {
    FB.init();
    try {
      let cred;
      const native = typeof Capacitor !== 'undefined' && Capacitor.isNativePlatform && Capacitor.isNativePlatform();
      if (native) {
        const SL = Capacitor.Plugins.SocialLogin;
        if (!this._slInit) { await SL.initialize({ google: { webClientId: fbConfig().googleClientId, skipAuthOnlyAuthorizationAfterSignIn: true } }); this._slInit = true; }
        let res;
        // Sem "scopes": email e perfil já vêm por defeito (pedir scopes exige outra MainActivity).
        try { res = await SL.login({ provider: 'google', options: {} }); } catch (e) {
          const msg = String((e && (e.message || e.errorMessage)) || e || '');
          if (/cancel/i.test(msg) && !/28444|developer console/i.test(msg)) throw Object.assign(new Error('err.cancelled'), { code: 'auth/popup-closed-by-user' });
          throw Object.assign(new Error('err.googleFail'), { detail: msg.slice(0, 160), google: true });
        }
        const idToken = res && res.result && res.result.idToken;
        if (!idToken) throw Object.assign(new Error('err.cancelled'), { code: 'auth/popup-closed-by-user' });
        cred = await FB.auth.signInWithCredential(firebase.auth.GoogleAuthProvider.credential(idToken));
      } else {
        cred = await FB.auth.signInWithPopup(new firebase.auth.GoogleAuthProvider());
      }
      const u = cred.user;
      const meta = await FB.store(u.uid).get();
      return { uid: u.uid, email: u.email, name: u.displayName, photo: u.photoURL, exists: meta.exists, storeName: meta.exists ? meta.data().storeName : Store.settings.storeName };
    } catch (e) { if (e.google) throw e; throw fbError(e); }
  },
  // Depois de entrar com Google: loja nova (envia os dados deste dispositivo) ou loja existente (recebe os dela).
  async useGoogle(r) {
    if (!r.exists) {
      await FB.store(r.uid).set({ email: r.email, storeName: Store.settings.storeName || '', createdAt: new Date().toISOString(), via: 'google' });
      this.state = { fb: true, fresh: true, url: 'firebase', token: 'fb', uid: r.uid, email: r.email, name: r.name, photo: r.photo, google: true, storeName: r.storeName, cursor: 0, deviceNo: null, snapshot: {}, lastSync: null, lastError: null };
      this.persist();
      await this.syncNow();
      this.startAuto();
      return 'register';
    }
    this.state = { fb: true, url: 'firebase', token: 'fb', uid: r.uid, email: r.email, name: r.name, photo: r.photo, google: true, storeName: r.storeName, cursor: 0, deviceNo: null, snapshot: {}, lastSync: null, lastError: null };
    await this._pullAll();
    return 'login';
  },
  async cancelGoogle() { if (FB.auth) await FB.auth.signOut().catch(() => {}); },
  async resetPassword(email) {
    FB.init();
    try { await FB.auth.sendPasswordResetEmail(email); } catch (e) { throw fbError(e); }
  },
  // Conta criada com Google: junta uma senha para os outros celulares entrarem com email e senha.
  hasPassword() { const u = FB.auth && FB.auth.currentUser; return !!(u && u.providerData.some(p => p.providerId === 'password')); },
  async setPassword(password) {
    FB.init();
    const u = FB.auth.currentUser;
    if (!u) throw new Error('err.recentLogin');
    try { await u.linkWithCredential(firebase.auth.EmailAuthProvider.credential(u.email, password)); } catch (e) { throw fbError(e); }
  },

  // Cria uma conta nova com os dados deste dispositivo.
  async register(url, email, password) {
    if (this.usesFirebase()) {
      const r = await this.fbAuth('register', email, password);
      this.state = { fb: true, fresh: true, url: 'firebase', token: 'fb', uid: r.uid, email: r.email, storeName: r.storeName, cursor: 0, deviceNo: null, snapshot: {}, lastSync: null, lastError: null };
      this.persist();
      await this.syncNow();
      this.startAuto();
      return;
    }
    const r = await this.request('/api/register', { __url: url, email, password, storeName: Store.settings.storeName });
    this.state = { url, token: r.token, email: r.email, storeName: r.storeName, cursor: 0, deviceNo: null, snapshot: {}, lastSync: null, lastError: null };
    this.persist();
    await this.syncNow();
    this.startAuto();
  },

  // Entra numa conta existente: os dados locais são substituídos pelos da conta.
  async login(url, email, password) {
    if (this.usesFirebase()) {
      const r = await this.fbAuth('login', email, password);
      this.state = { fb: true, url: 'firebase', token: 'fb', uid: r.uid, email: r.email, storeName: r.storeName, cursor: 0, deviceNo: null, snapshot: {}, lastSync: null, lastError: null };
    } else {
      const r = await this.request('/api/login', { __url: url, email, password });
      this.state = { url, token: r.token, email: r.email, storeName: r.storeName, cursor: 0, deviceNo: null, snapshot: {}, lastSync: null, lastError: null };
    }
    await this._pullAll();
  },
  async _pullAll() {
    for (const c of SYNC_COLLECTIONS) Store.data[c] = [];
    this.persist();
    await this.syncNow({ pullOnly: true });
    if (!Store.data.employees.length) Store.data.employees.push({ id: uid(), name: 'Admin', pin: '0000', role: 'owner' });
    Store.save();
    this.startAuto();
  },

  logout() {
    const token = this.state && this.state.token;
    if (this.state && this.state.fb) { if (FB.auth) FB.auth.signOut().catch(() => {}); } else if (token) this.request('/api/logout', {}, token).catch(() => {});
    this.stopAuto();
    if (typeof Chat !== 'undefined') Chat.stop();
    this.state = null;
    Store.deviceNo = null;
    this.persist();
    this.setStatus('off');
  },

  startAuto() {
    this.stopAuto();
    // De 10 em 10 segundos com a app à vista; ao voltar à app ou à internet, logo.
    if (this.state && this.state.fb && FB.available()) {
      FB.user().then(u => { if (u && this.state && this.state.fb && !this._unwatch) this._unwatch = FB.watch(this.state.uid, () => this.schedule()); }).catch(() => {});
    }
    this._interval = setInterval(() => { if (typeof document === 'undefined' || !document.hidden) this.syncNow().catch(() => {}); }, 10000);
    if (typeof window !== 'undefined') {
      window.addEventListener('online', this._onOnline = () => this.syncNow().catch(() => {}));
      document.addEventListener('visibilitychange', this._onVisible = () => { if (!document.hidden) this.syncNow().catch(() => {}); });
    }
  },

  stopAuto() {
    if (this._unwatch) { this._unwatch(); this._unwatch = null; }
    clearInterval(this._interval);
    clearTimeout(this._timer);
    if (this._onOnline && typeof window !== 'undefined') window.removeEventListener('online', this._onOnline);
    if (this._onVisible && typeof document !== 'undefined') document.removeEventListener('visibilitychange', this._onVisible);
  },

  // Pede uma sincronização pouco depois de uma alteração local.
  schedule() {
    if (!this.enabled() || this._applying) return;
    clearTimeout(this._timer);
    this._timer = setTimeout(() => this.syncNow().catch(() => {}), 800);
  },

  async syncNow({ pullOnly = false } = {}) {
    if (!this.enabled()) return { pushed: 0, pulled: 0 };
    if (this.busy) { this._again = true; return { pushed: 0, pulled: 0 }; }
    this.busy = true;
    this.setStatus('syncing');
    const st = this.state;
    try {
      const cur = Store.records();
      const sent = {}; // chave → JSON enviado
      const changes = [];
      if (!pullOnly) {
        const now = Date.now();
        for (const key in cur) {
          const json = stableJson(cur[key]);
          if (st.snapshot[key] === json) continue;
          sent[key] = json;
          const [col, id] = key.split('/');
          const prev = st.snapshot[key] ? JSON.parse(st.snapshot[key]) : null;
          const deltas = {};
          for (const f of MERGE_FIELDS[col] || []) deltas[f] = round2((Number(cur[key][f]) || 0) - (prev ? Number(prev[f]) || 0 : 0));
          changes.push({ col, id, data: cur[key], deltas, updatedAt: now });
        }
        for (const key in st.snapshot) {
          if (key in cur) continue;
          const [col, id] = key.split('/');
          changes.push({ col, id, deleted: true, updatedAt: now });
        }
      }
      const res = st.fb ? await this.fbSync(st, changes) : await this.request('/api/sync', { deviceId: this.deviceId, cursor: st.cursor, changes }, st.token);
      if (this.state !== st) return { pushed: 0, pulled: 0 }; // saiu da conta entretanto
      let remote = 0;
      this._applying = true;
      try {
        const now = Store.records();
        for (const rec of res.records) {
          const key = `${rec.col}/${rec.id}`;
          if (rec.deleted) {
            if (now[key]) { Store.removeRecord(rec.col, rec.id); if (!(key in sent)) remote++; }
            delete st.snapshot[key];
            continue;
          }
          const serverJson = stableJson(Object.assign({}, rec.data, rec.col === 'settings' ? {} : { id: rec.id }));
          const local = now[key];
          const localJson = local ? stableJson(local) : null;
          const base = sent[key] || st.snapshot[key];
          if (!local || localJson === base || localJson === serverJson) {
            if (localJson !== serverJson) { Store.setRecord(rec.col, rec.id, rec.data); if (!(key in sent)) remote++; }
          } else {
            // Alterado localmente durante a sincronização: manter a alteração local e reaplicar as diferenças.
            const merged = rec.col === 'stockCounts' ? mergeCount(local, rec.data) : Object.assign({}, local);
            const b = base ? JSON.parse(base) : {};
            for (const f of MERGE_FIELDS[rec.col] || []) {
              merged[f] = round2((Number(rec.data[f]) || 0) + (Number(local[f]) || 0) - (Number(b[f]) || 0));
            }
            Store.setRecord(rec.col, rec.id, merged);
          }
          st.snapshot[key] = serverJson;
        }
        st.cursor = res.cursor;
        st.deviceNo = res.deviceNo;
        st.storeName = res.storeName || st.storeName;
        st.lastSync = new Date().toISOString();
        st.lastError = null;
        Store.deviceNo = res.deviceNo;
        this.persist();
        Store.save();
      } finally {
        this._applying = false;
      }
      this.setStatus('idle');
      if (remote && this.onRemoteChange) this.onRemoteChange();
      return { pushed: changes.length, pulled: remote };
    } catch (e) {
      if (e.status === 401) {
        this.logout();
        this.setStatus('error');
        if (this.onKicked) this.onKicked(e.message);
      } else {
        st.lastError = e.message;
        this.persist();
        this.setStatus(e.offline ? 'offline' : 'error');
      }
      throw e;
    } finally {
      this.busy = false;
      if (this._again) { this._again = false; this.schedule(); }
    }
  },
};

// Uma ronda de sincronização no Firebase, com a mesma resposta do servidor próprio.
Sync.fbSync = async function (st, changes) {
  try {
    if (!FB.available()) throw new Error('err.server');
    const u = await FB.user();
    if (!u || u.uid !== (st.authUid || st.uid)) { const e = new Error('err.wrongLogin'); e.status = 401; throw e; }
    if (!st.deviceNo) st.deviceNo = await FB.deviceNo(st.uid, this.deviceId);
    if (changes.length) await FB.push(st.uid, changes, !!st.fresh && !st.cursor);
    st.fresh = false;
    const r = await FB.pull(st.uid, st.cursor);
    this.fbSeen(st);
    return { records: r.records, cursor: r.cursor, deviceNo: st.deviceNo, storeName: st.storeName };
  } catch (e) {
    if (e.status) throw e;
    // Celular convidado que o dono desligou: deixa de ter acesso à loja.
    if (st.member && e && e.code === 'permission-denied') e.revoked = true;
    throw fbError(e);
  }
};

// Ficha deste celular na loja (lista "Celulares ligados"): no máximo de 5 em 5 minutos.
Sync.who = '';
Sync.fbSeen = function (st) {
  if (this._seenAt && Date.now() - this._seenAt < 300000 && this._seenWho === this.who) return;
  this._seenAt = Date.now(); this._seenWho = this.who;
  FB.store(st.uid).collection('devices').doc(this.deviceId).set({
    no: st.deviceNo || null, model: deviceModel(), member: st.member ? st.authUid : null, user: this.who || '',
    seen: firebase.firestore.FieldValue.serverTimestamp(),
  }, { merge: true }).catch(() => {});
};
function deviceModel() {
  const ua = typeof navigator !== 'undefined' ? navigator.userAgent : '';
  const m = /Android [\d.]+; ([^;)]+?)(?: Build|\))/.exec(ua);
  if (m && m[1] && m[1] !== 'K') return m[1].trim();
  if (/Android/.test(ua)) return 'Android';
  if (/iPhone|iPad/.test(ua)) return 'iPhone';
  return /Windows/.test(ua) ? 'Computador (Windows)' : /Mac/.test(ua) ? 'Computador (Mac)' : 'Computador';
}

// ---------- Convites (código de 6 números) ----------
Sync.createInvite = async function () {
  const st = this.state;
  if (!st || !st.fb || st.member) throw new Error('err.server');
  FB.init();
  for (let i = 0; i < 5; i++) {
    const a = new Uint32Array(1); crypto.getRandomValues(a);
    const code = String(a[0] % 1000000).padStart(6, '0');
    try {
      await FB.db.collection('invites').doc(code).set({ store: st.uid, used: false, by: this.who || '', exp: firebase.firestore.Timestamp.fromMillis(Date.now() + 10 * 60000), at: firebase.firestore.FieldValue.serverTimestamp() });
      return { code, exp: Date.now() + 10 * 60000 };
    } catch (e) { if (e.code !== 'permission-denied') throw fbError(e); } // código já usado por outra loja: tenta outro
  }
  throw new Error('err.server');
};
Sync.cancelInvite = function (code) { FB.db.collection('invites').doc(code).delete().catch(() => {}); };
Sync.inviteUsed = function (code, cb) {
  return FB.db.collection('invites').doc(code).onSnapshot(d => { if (!d.exists || d.data().used) cb(d.exists ? d.data() : null); }, () => {});
};
// Celular novo: entra com o código. Não precisa do email nem da senha da loja.
Sync.joinWithCode = async function (code) {
  FB.init();
  code = String(code).replace(/\D/g, '');
  if (code.length !== 6) throw new Error('err.badCode');
  let u;
  try {
    u = FB.auth.currentUser && FB.auth.currentUser.isAnonymous ? FB.auth.currentUser : (await FB.auth.signInAnonymously()).user;
  } catch (e) { throw fbError(e); }
  const ref = FB.db.collection('invites').doc(code);
  let inv;
  try { inv = await ref.get(); } catch (e) { throw fbError(e); }
  if (!inv.exists || inv.data().used || inv.data().exp.toMillis() < Date.now()) throw new Error('err.badCode');
  const store = inv.data().store;
  const b = FB.db.batch();
  const ts = firebase.firestore.FieldValue.serverTimestamp();
  b.update(ref, { used: true, usedBy: u.uid, usedAt: ts });
  b.set(FB.store(store).collection('members').doc(u.uid), { invite: code, revoked: false, at: ts, model: deviceModel() });
  try { await b.commit(); } catch (e) { if (e.code === 'permission-denied') throw new Error('err.badCode'); throw fbError(e); }
  const meta = await FB.store(store).get().catch(() => null);
  const md = meta && meta.exists ? meta.data() : {};
  this.state = { fb: true, member: true, authUid: u.uid, url: 'firebase', token: 'fb', uid: store, email: md.email || '', storeName: md.storeName || '', cursor: 0, deviceNo: null, snapshot: {}, lastSync: null, lastError: null };
  await this._pullAll();
  return { storeName: md.storeName || '', deviceNo: this.state.deviceNo };
};
// Lista de celulares da loja (para o dono) e desligar um celular convidado.
Sync.listDevices = async function () {
  const st = this.state;
  const [dv, mb] = await Promise.all([FB.store(st.uid).collection('devices').get(), st.member ? null : FB.store(st.uid).collection('members').get()]);
  const members = {};
  if (mb) mb.docs.forEach(d => { members[d.id] = d.data(); });
  return dv.docs.map(d => { const v = d.data(); return { id: d.id, no: v.no, model: v.model, user: v.user, seen: v.seen ? v.seen.toMillis() : 0, member: v.member, revoked: !!(v.member && members[v.member] && members[v.member].revoked), me: d.id === this.deviceId }; })
    .sort((a, b) => (a.no || 99) - (b.no || 99));
};
Sync.revokeDevice = async function (memberUid) {
  try { await FB.store(this.state.uid).collection('members').doc(memberUid).update({ revoked: true, revokedAt: firebase.firestore.FieldValue.serverTimestamp() }); } catch (e) { throw fbError(e); }
};

if (typeof module !== 'undefined') module.exports = { Sync, FB };

'use strict';
// Stoi — atualizações sozinhas (sem Play Store e sem APK nova).
// A app pergunta a um ficheiro público (latest.json) se há versão nova da parte web. Se houver,
// descarrega-a em segundo plano e passa a usá-la quando a app vai para segundo plano ou na
// próxima abertura. Se a versão nova não arrancar, o Android volta à anterior (LiveUpdatePlugin).
// Mudanças na parte Android (versionCode) continuam a precisar de APK nova: "minApk" no latest.json.

/* global t, esc, toast, openModal, confirmDialog, render */

const UPD_URL = 'https://raw.githubusercontent.com/amonjanuario/stoi-updates/main/latest.json';
const UPD_EVERY = 60 * 60 * 1000; // no máximo uma verificação por hora

const Upd = {
  cur: window.STOI_VERSION || '0',
  info: null,
  busy: false,
  plugin() { const C = window.Capacitor; return C && C.isNativePlatform && C.isNativePlatform() && C.Plugins && C.Plugins.LiveUpdate ? C.Plugins.LiveUpdate : null; },
  get(k, d) { try { const v = localStorage.getItem(k); return v === null ? d : JSON.parse(v); } catch (e) { return d; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* sem espaço */ } },
  auto() { return this.get('stoi-upd-auto', true) !== false; },
  setAuto(on) { this.set('stoi-upd-auto', !!on); if (on) this.check(false); },
  // "4.75.0" > "4.74.2"?
  newer(a, b) {
    const pa = String(a).split('.').map(Number), pb = String(b).split('.').map(Number);
    for (let i = 0; i < Math.max(pa.length, pb.length); i++) { const x = pa[i] || 0, y = pb[i] || 0; if (x !== y) return x > y; }
    return false;
  },

  async start() {
    const lu = this.plugin();
    if (!lu) return;
    try { this.info = await lu.info(); await lu.ready(); } catch (e) { return; }
    // Acabou de atualizar: aviso de 5 segundos com o que mudou.
    const shown = this.get('stoi-upd-shown', null);
    if (shown && shown !== this.cur && this.newer(this.cur, shown)) {
      const notes = (this.get('stoi-upd-notes', {}) || {})[this.cur] || '';
      setTimeout(() => this.toast(notes), 1200);
    }
    this.set('stoi-upd-shown', this.cur);
    this.set('stoi-upd-at', this.get('stoi-upd-ver', '') === this.cur ? this.get('stoi-upd-at', null) : new Date().toISOString());
    this.set('stoi-upd-ver', this.cur);
    // Já descarregada antes? Aplica-se já, antes de a pessoa começar a trabalhar.
    const pend = this.get('stoi-upd-pending', null);
    if (pend && this.newer(pend.version, this.cur) && pend.version !== this.info.bad) { this.apply(pend); return; }
    this.set('stoi-upd-pending', null);
    if (this.auto()) setTimeout(() => this.check(false), 15000);
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'hidden') { const p = this.get('stoi-upd-pending', null); if (p && this.auto()) this.apply(p); }
      else if (this.auto()) this.check(false);
    });
  },

  async check(manual) {
    const lu = this.plugin();
    if (!lu) { if (manual) toast(t('upd.notApp')); return; }
    if (this.busy) return;
    if (!manual && Date.now() - (this.get('stoi-upd-checked', 0) || 0) < UPD_EVERY) return;
    this.busy = true;
    try {
      this.set('stoi-upd-checked', Date.now());
      const res = await fetch(`${UPD_URL}?t=${Date.now()}`, { cache: 'no-store' });
      if (!res.ok) throw new Error(String(res.status));
      const m = await res.json();
      if (!m || !m.version || !m.url || !this.newer(m.version, this.cur)) { if (manual) toast(t('upd.latest', { v: this.cur })); return; }
      if (m.minApk && this.info && this.info.apkCode < m.minApk) { if (manual) toast(t('upd.needApk'), true); return; }
      if (this.info && m.version === this.info.bad && !manual) return;
      if (manual) toast(t('upd.downloading', { v: m.version }));
      const r = await lu.download({ url: m.url, version: m.version, sha256: m.sha256 || '' });
      const notes = this.get('stoi-upd-notes', {}) || {};
      notes[m.version] = m.notes || '';
      this.set('stoi-upd-notes', notes);
      const pend = { path: r.path, version: m.version };
      this.set('stoi-upd-pending', pend);
      if (manual && await confirmDialog(t('upd.readyQ', { v: m.version }), t('upd.restart'))) this.apply(pend);
    } catch (e) {
      if (manual) toast(t('upd.failed'), true);
    } finally { this.busy = false; }
  },

  async apply(p) {
    const lu = this.plugin();
    if (!lu || !p) return;
    this.set('stoi-upd-pending', null);
    try { await lu.apply({ path: p.path, version: p.version }); } catch (e) { /* a versão descarregada desapareceu: volta a descarregar mais tarde */ }
  },

  toast(notes) {
    const el = document.createElement('button');
    el.type = 'button';
    el.className = 'upd-toast';
    el.innerHTML = `<span class="upd-ic">✓</span><span class="upd-t"><b>${esc(t('upd.done', { v: this.cur }))}</b>${notes ? `<small>${esc(notes.split('\n')[0])}</small>` : ''}</span>${notes ? `<em>${esc(t('upd.see'))}</em>` : ''}`;
    el.addEventListener('click', () => { el.remove(); if (notes) this.notesModal(); });
    document.body.appendChild(el);
    requestAnimationFrame(() => el.classList.add('in'));
    setTimeout(() => { el.classList.remove('in'); setTimeout(() => el.remove(), 400); }, 5000);
  },

  notesModal() {
    const notes = (this.get('stoi-upd-notes', {}) || {})[this.cur] || '';
    openModal({
      title: t('upd.notesTitle', { v: this.cur }),
      body: notes ? `<ul class="upd-notes">${notes.split('\n').filter(Boolean).map(l => `<li>${esc(l.replace(/^[-•]\s*/, ''))}</li>`).join('')}</ul>` : `<p class="muted">${esc(t('upd.noNotes'))}</p>`,
    });
  },

  // Texto da linha "Versão" nas Definições.
  versionSub() {
    const at = this.get('stoi-upd-at', null);
    if (!at) return '';
    const d = new Date(at), today = new Date().toDateString() === d.toDateString();
    const hm = `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
    return t(today ? 'upd.atToday' : 'upd.atDay', { d: d.toLocaleDateString(), h: hm });
  },
};

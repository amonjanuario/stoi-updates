'use strict';
// Stoi — aspeto do chat: papel de parede (desenhos da loja de bebidas ou cores lisas) e tema
// (claro / escuro / automático, cor dos meus balões, tamanho do texto). Guardado só no celular.
// Também os vistos: um (enviada), dois cinzentos (chegou), dois azuis (lida).

/* global Chat, FileBox, FB, firebase, $, $$, esc, t, openModal */

const WP_ST = (c, w) => `fill="none" stroke="${c}" stroke-width="${w}" stroke-linecap="round" stroke-linejoin="round"`;
const WP_P = {
  whisky: '<path d="M14 0h12v8l4 6h-20l4-6z"/><rect x="6" y="14" width="28" height="46" rx="4"/><rect x="11" y="26" width="18" height="14" rx="2"/>',
  rocks: '<path d="M0 0h26l-3 22H3z"/><path d="M6 8h7v6H6zM14 11h6v6h-6z"/>',
  vodka: '<path d="M10 0h8v16c0 4 6 6 6 12v40a3 3 0 0 1-3 3H7a3 3 0 0 1-3-3V28c0-6 6-8 6-12z"/><path d="M7 40h14v12H7z"/>',
  wine: '<path d="M9 0h8v18c6 4 8 8 8 14v34a3 3 0 0 1-3 3H4a3 3 0 0 1-3-3V32c0-6 2-10 8-14z"/><path d="M4 46h18v14H4z"/>',
  glass: '<path d="M0 0h20c0 12-4 18-10 18S0 12 0 0zM10 18v12M3 30h14"/>',
  gin: '<path d="M13 0h10v8h-10zM10 8h16c4 2 8 6 8 12v34a4 4 0 0 1-4 4H6a4 4 0 0 1-4-4V20c0-6 4-10 8-12z"/><circle cx="18" cy="36" r="8"/>',
  beer: '<path d="M8 0h6v14c4 4 6 8 6 14v32a3 3 0 0 1-3 3H5a3 3 0 0 1-3-3V28c0-6 2-10 6-14z"/><path d="M3 38h16v10H3z"/>',
  mug: '<path d="M2 6h26v30a4 4 0 0 1-4 4H6a4 4 0 0 1-4-4z"/><path d="M28 12h5a4 4 0 0 1 4 4v8a4 4 0 0 1-4 4h-5"/><path d="M2 6c0-4 4-6 8-5 2-3 8-3 10 0 4-1 8 1 8 5"/><path d="M10 14v18M18 14v18"/>',
  juice: '<path d="M2 10l6-8h16l6 8v46H2z"/><path d="M2 10h28M20 2l6-8"/><circle cx="16" cy="34" r="7"/>',
  can: '<path d="M4 0h20l2 4v40l-2 4H4l-2-4V4z"/><path d="M2 12h24M2 36h24M9 2h6"/>',
  soda: '<path d="M8 0h8v8c4 2 6 6 6 10v6c-2 3-2 7 0 10v26a3 3 0 0 1-3 3H5a3 3 0 0 1-3-3V34c2-3 2-7 0-10v-6c0-4 2-8 6-10z"/>',
  cocktail: '<path d="M0 0h30L15 16zM15 16v16M7 32h16"/><circle cx="28" cy="2" r="6"/>',
  cap: '<circle cx="9" cy="9" r="9"/><circle cx="9" cy="9" r="5"/>',
  cork: '<rect x="0" y="0" width="12" height="20" rx="3"/><path d="M3 5h2M7 9h2M3 13h2"/>',
  opener: '<path d="M0 22 16 6"/><circle cx="20" cy="4" r="5"/><path d="M-3 25l6-6"/>',
  grapes: '<circle cx="10" cy="10" r="5"/><circle cx="20" cy="10" r="5"/><circle cx="15" cy="18" r="5"/><circle cx="5" cy="18" r="5"/><circle cx="25" cy="18" r="5"/><circle cx="10" cy="26" r="5"/><circle cx="20" cy="26" r="5"/><circle cx="15" cy="34" r="5"/><path d="M15 5V0l6-4"/>',
  orange: '<circle cx="14" cy="14" r="13"/><path d="M14 1v26M1 14h26M5 5l18 18M23 5 5 23"/>',
  lemon: '<path d="M2 14C2 6 8 2 14 2s12 4 12 12-6 12-12 12S2 22 2 14z"/><path d="M0 14h2M26 14h2"/>',
  ice: '<rect x="0" y="0" width="16" height="16" rx="3"/><path d="M4 4l4 2"/>',
  bubbles: '<circle cx="4" cy="4" r="3"/><circle cx="12" cy="12" r="2"/><circle cx="6" cy="18" r="2.5"/>',
  star: '<path d="M8 0l2 6h6l-5 4 2 6-5-4-5 4 2-6-5-4h6z"/>',
  note: '<path d="M4 18V2l12-2v16"/><circle cx="2" cy="18" r="3"/><circle cx="14" cy="16" r="3"/>',
};
// Tamanho de cada peça (sem escala), para as espalhar sem se tocarem.
const WP_SZ = { whisky: [40, 60], rocks: [26, 22], vodka: [28, 71], wine: [26, 69], glass: [20, 30], gin: [34, 58], beer: [20, 63], mug: [37, 40], juice: [32, 56], can: [28, 48], soda: [22, 63], cocktail: [34, 32], cap: [18, 18], cork: [12, 20], opener: [25, 25], grapes: [30, 39], orange: [28, 28], lemon: [28, 28], ice: [16, 16], bubbles: [15, 20], star: [16, 16], note: [18, 21] };
// [id, fundo, traço, peças que entram, quantas por azulejo]. Azulejo de 260 px; peças pequenas,
// todas inclinadas ou deitadas (nunca direitas), espalhadas ao acaso e sem costura nas bordas.
const WALLS = [
  ['drinks', '#efe7de', '#d3c4ae', ['whisky', 'vodka', 'wine', 'gin', 'beer', 'soda', 'can', 'juice', 'rocks', 'glass', 'mug', 'cocktail', 'cap'], 58],
  ['beer', '#f3e6c4', '#d9bf85', ['beer', 'mug', 'can', 'cap', 'opener', 'bubbles', 'beer', 'mug'], 58],
  ['wine', '#f6e7ea', '#dfb3be', ['wine', 'glass', 'grapes', 'cork', 'opener', 'wine', 'glass'], 56],
  ['bar', '#141a2e', '#3a4878', ['cocktail', 'rocks', 'whisky', 'vodka', 'glass', 'star', 'note', 'gin'], 58],
  ['juice', '#fff3e0', '#efc391', ['orange', 'lemon', 'juice', 'soda', 'can', 'ice', 'orange'], 58],
  ['bottles', '#ece8e1', '#cfc5b7', ['whisky', 'vodka', 'wine', 'gin', 'beer', 'soda'], 56],
  ['caps', '#eef0f3', '#c9d0d9', ['cap', 'cork', 'opener', 'cap', 'bubbles', 'cap'], 64],
  ['c-green', '#d4ecd9'], ['c-blue', '#dbe7f5'], ['c-white', '#f3f4f6'], ['c-pink', '#f8e1ea'],
];
const WP_T = 260;
const _wpCache = {};
function wpLayout(w) {
  if (_wpCache[w[0]]) return _wpCache[w[0]];
  let seed = [...w[0]].reduce((a, c) => (a * 31 + c.charCodeAt(0)) >>> 0, 7);
  const rnd = () => { seed = (seed + 0x6D2B79F5) >>> 0; let x = seed; x = Math.imul(x ^ (x >>> 15), x | 1); x ^= x + Math.imul(x ^ (x >>> 7), x | 61); return ((x ^ (x >>> 14)) >>> 0) / 4294967296; };
  const out = [];
  const dist = (a, b) => { let dx = Math.abs(a.x - b.x), dy = Math.abs(a.y - b.y); dx = Math.min(dx, WP_T - dx); dy = Math.min(dy, WP_T - dy); return Math.hypot(dx, dy); };
  for (let tries = 0; out.length < w[4] && tries < 6000; tries++) {
    const n = w[3][Math.floor(rnd() * w[3].length)], sz = WP_SZ[n];
    const s = (n === 'cap' || n === 'ice' || n === 'star' || n === 'bubbles' ? 0.62 : 0.4) + rnd() * 0.1; // pequenas
    const r = Math.max(sz[0], sz[1]) * s / 2 + 3;
    const p = { n, x: rnd() * WP_T, y: rnd() * WP_T, s, r };
    if (out.some(q => dist(p, q) < p.r + q.r)) continue;
    let a = 20 + rnd() * 140; if (rnd() < 0.5) a = -a; // nunca direitas
    if (rnd() < 0.25) a = rnd() < 0.5 ? 90 : -90; // algumas deitadas
    p.a = Math.round(a);
    out.push(p);
  }
  return (_wpCache[w[0]] = out);
}
function wallCss(id, dark) {
  const w = WALLS.find(x => x[0] === id) || WALLS[0];
  const bgc = dark ? '#0b141a' : w[1];
  if (!w[2]) return `background:${bgc}`;
  const stroke = dark ? '#1d2b33' : w[2];
  let body = '';
  for (const p of wpLayout(w)) {
    const [bw, bh] = WP_SZ[p.n];
    const one = (x, y) => `<g transform="translate(${(x).toFixed(1)} ${(y).toFixed(1)}) rotate(${p.a}) scale(${p.s.toFixed(2)}) translate(${-bw / 2} ${-bh / 2})" stroke-width="${(1.25 / p.s).toFixed(2)}">${WP_P[p.n]}</g>`;
    // repete junto às bordas para o padrão não ter costura
    for (const dx of [-WP_T, 0, WP_T]) for (const dy of [-WP_T, 0, WP_T]) {
      const x = p.x + dx, y = p.y + dy;
      if (x + p.r < 0 || y + p.r < 0 || x - p.r > WP_T || y - p.r > WP_T) continue;
      body += one(x, y);
    }
  }
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${WP_T}" height="${WP_T}"><g fill="none" stroke="${stroke}" stroke-linecap="round" stroke-linejoin="round">${body}</g></svg>`;
  return `background:${bgc} url('data:image/svg+xml,${encodeURIComponent(svg)}');background-size:${WP_T}px ${WP_T}px`;
}
const BUBBLES = { green: ['#d9fdd3', '#005c4b'], blue: ['#d6eaff', '#144d7a'], purple: ['#ece1ff', '#4a2f7a'], orange: ['#ffe6c7', '#7a4a14'], pink: ['#ffdde6', '#7a2f4a'], yellow: ['#fff6c2', '#6b5d12'] };
const CHAT_FS = { s: 0.9, m: 1, l: 1.15 };


Object.assign(Chat, {
  look() {
    const d = { wall: 'drinks', mode: 'light', bubble: 'green', fs: 'm' };
    let v = null;
    try { v = JSON.parse(localStorage.getItem('stoi-chat-look')); } catch (e) { /* nada */ }
    if (!v) { // tema antigo (só fundo)
      let old = 'def'; try { old = localStorage.getItem('stoi-chat-theme') || 'def'; } catch (e) { /* nada */ }
      v = old === 'dark' ? { mode: 'dark' } : { wall: { green: 'c-green', blue: 'c-blue', pink: 'c-pink', plain: 'c-white' }[old] || 'drinks' };
    }
    const r = Object.assign(d, v);
    if (!WALLS.some(w => w[0] === r.wall)) r.wall = 'drinks'; // o antigo "Padrão" (formas) já não existe
    return r;
  },
  setLook(p) { try { localStorage.setItem('stoi-chat-look', JSON.stringify(Object.assign(this.look(), p))); } catch (e) { /* sem espaço */ } this.applyLook(); },
  isDark(l = this.look()) { return l.mode === 'dark' || (l.mode === 'auto' && window.matchMedia && matchMedia('(prefers-color-scheme: dark)').matches); },
  theme() { return this.isDark() ? 'dark' : 'light'; },
  lookStyle() {
    const l = this.look(), dk = this.isDark(l), bb = BUBBLES[l.bubble] || BUBBLES.green;
    return `${wallCss(l.wall, dk)};--meb:${dk ? bb[1] : bb[0]};--chfs:${CHAT_FS[l.fs] || 1}`;
  },
  applyLook() {
    const r = document.querySelector('.ch-room');
    if (!r) return;
    r.dataset.theme = this.theme(); r.setAttribute('style', this.lookStyle());
  },
  themeModal(tab) {
    tab = tab || this._lookTab || 'wall';
    this._lookTab = tab;
    const l = this.look(), dk = this.isDark(l);
    const tabs = `<div class="tw-tabs"><button type="button" data-tw="theme" class="${tab === 'theme' ? 'on' : ''}">${esc(t('chat.tTheme'))}</button><button type="button" data-tw="wall" class="${tab === 'wall' ? 'on' : ''}">${esc(t('chat.tWall'))}</button></div>`;
    const body = tab === 'wall'
      ? `<div class="tw-grid">${WALLS.map(w => `<button type="button" data-wall="${w[0]}" class="${w[0] === l.wall ? 'on' : ''} ${w[0] === 'bar' || dk ? 'dk' : ''}" style="${wallCss(w[0], dk)}"><em></em><em></em>${w[0] === l.wall ? '<b class="ok">✓</b>' : ''}<span>${esc(t(`chat.wp.${w[0]}`))}</span></button>`).join('')}</div>`
      : `<div class="tw-h">${esc(t('chat.lookMode'))}</div>
        <div class="tw-modes">${[['light', 'linear-gradient(#fff 30%,#efe7de 30%)'], ['dark', 'linear-gradient(#1f2c34 30%,#0b141a 30%)'], ['auto', 'linear-gradient(90deg,#efe7de 50%,#0b141a 50%)']].map(([k, g]) => `<button type="button" data-mode="${k}" class="${l.mode === k ? 'on' : ''}"><i style="background:${g}"></i>${esc(t(`chat.mode.${k}`))}</button>`).join('')}</div>
        <div class="tw-h">${esc(t('chat.lookBubble'))}</div>
        <div class="tw-cols">${Object.keys(BUBBLES).map(k => `<button type="button" data-bub="${k}" class="${l.bubble === k ? 'on' : ''}"><b style="background:${BUBBLES[k][dk ? 1 : 0]}"></b>${esc(t(`chat.bub.${k}`))}</button>`).join('')}</div>
        <div class="tw-h" style="margin-top:16px">${esc(t('chat.lookFs'))}</div>
        <div class="tw-modes">${['s', 'm', 'l'].map(k => `<button type="button" data-fs="${k}" class="${l.fs === k ? 'on' : ''}">${esc(t(`chat.fs.${k}`))}</button>`).join('')}</div>`;
    const m = openModal({ title: t('chat.look'), sheet: true, autofocus: false, body: `${tabs}${body}<p class="muted small" style="margin:12px 2px 0">${esc(t('chat.thLocal'))}</p>` });
    const again = p => { this.setLook(p); const sc = $('.modal-body', m) ? $('.modal-body', m).scrollTop : 0; this.themeModal(); const nb = document.querySelector('.modal-body'); if (nb) nb.scrollTop = sc; };
    $$('[data-tw]', m).forEach(b => b.addEventListener('click', () => { this._lookTab = b.dataset.tw; this.themeModal(); }));
    $$('[data-wall]', m).forEach(b => b.addEventListener('click', () => again({ wall: b.dataset.wall })));
    $$('[data-mode]', m).forEach(b => b.addEventListener('click', () => again({ mode: b.dataset.mode })));
    $$('[data-bub]', m).forEach(b => b.addEventListener('click', () => again({ bubble: b.dataset.bub })));
    $$('[data-fs]', m).forEach(b => b.addEventListener('click', () => again({ fs: b.dataset.fs })));
  },

  // ---------- Vistos ----------
  recips(m) { return typeof FileBox !== 'undefined' ? FileBox.recipients(m) : []; },
  tick(m) {
    if (m.pending) return '<svg class="ch-clock" viewBox="0 0 16 16"><path d="M8 1.5a6.5 6.5 0 1 0 0 13 6.5 6.5 0 0 0 0-13zm0 1.3a5.2 5.2 0 1 1 0 10.4A5.2 5.2 0 0 1 8 2.8zM7.4 4.5v4l3.2 1.9.6-1-2.6-1.6V4.5z"/></svg>';
    const need = this.recips(m);
    const all = k => need.length && need.every(id => (m[k] || []).includes(id));
    const two = '<path d="M17.4.65l-7.6 8.1-1-1-.94 1 1.94 1.9 8.56-9.27zM13.07.65l-7.6 8.1L2.6 5.9l-.94 1 3.86 3.8 8.56-9.27z"/>';
    if (all('seen')) return `<svg class="ch-tick two read" viewBox="0 0 18 11">${two}</svg>`;
    if (all('dlv') || all('seen')) return `<svg class="ch-tick two" viewBox="0 0 18 11">${two}</svg>`;
    return '<svg class="ch-tick" viewBox="0 0 16 11"><path d="M13.07.65l-7.6 8.1L2.6 5.9l-.94 1 3.86 3.8 8.56-9.27z"/></svg>';
  },
  // Avisar quem enviou: chegou (dlv) e lida (seen). Só mensagens dos últimos 7 dias.
  _mark(list, keys) {
    const me = this.me(); if (!me || !this._uid) return;
    const col = FB.store(this._uid).collection('chat'), U = firebase.firestore.FieldValue.arrayUnion(me.id);
    for (const m of list.slice(-60)) {
      const d = {}; keys.forEach(k => { if (!(m[k] || []).includes(me.id)) d[k] = U; });
      if (Object.keys(d).length) col.doc(m.id).update(d).catch(() => {});
      keys.forEach(k => { m[k] = [...new Set([...(m[k] || []), me.id])]; });
    }
  },
  _ackable(m) { return !m.pending && !m.deleted && m.from !== 'sys' && !this.mine(m) && this.visible(m.room) && Date.now() - this.ts(m) < 7 * 864e5; },
  ackDelivered() { const me = this.me(); if (!me) return; this._mark(this.msgs.filter(m => this._ackable(m) && !(m.dlv || []).includes(me.id)), ['dlv']); },
  ackSeen(room) { const me = this.me(); if (!me || document.hidden) return; this._mark(this.inRoom(room).filter(m => this._ackable(m) && !(m.seen || []).includes(me.id)), ['dlv', 'seen']); },
});
if (window.matchMedia) matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => Chat.applyLook());

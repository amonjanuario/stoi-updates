// Gerado por scripts/build-www.js a partir do package.json.
window.STOI_VERSION = '4.93.0';

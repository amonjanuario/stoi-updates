'use strict';
// Stoi — chat da loja (conversa de todos + conversas privadas entre funcionários).
//
// As mensagens ficam no Firebase, em stores/{uid}/chat/{id}, na mesma conta da loja (as regras
// do Firestore já só deixam a própria loja ler e escrever). Não entram na sincronização dos
// dados da loja: chegam em tempo real enquanto a app está aberta. Sem internet, a mensagem
// fica em espera (um tracinho de relógio) e segue quando a ligação voltar.
// Quem escreve é o funcionário que entrou com o PIN neste celular (App.user).

/* global uid, NativePrint, can, FB, Sync, Store, App, $, $$, esc, t, icon, openModal, closeModal, toast, confirmDialog, paintBack, render, setTitle, ADMIN, COLORS, firebase */

// Títulos rápidos para a tabela enviada no chat.
const TC_TITLES = ['tc.t.low', 'tc.t.out', 'tc.t.order', 'tc.t.count', 'tc.t.arrived'];
const Chat = {
  msgs: [],
  ready: false,
  _unsub: null,
  _uid: null,
  _t0: 0,
  room: null, // conversa aberta (ou null = lista)
  reply: null, // mensagem a que se está a responder
  sel: new Set(), // mensagens selecionadas (tocar e manter)

  // ---------- Ligação ----------
  available() { return !!(Sync.enabled() && Sync.state && Sync.state.fb && FB.available()); },
  start() {
    if (!this.available()) { this.stop(); return; }
    const uidv = Sync.state.uid;
    if (this._unsub && this._uid === uidv) return;
    this.stop();
    this._uid = uidv;
    this._t0 = Date.now();
    FB.init();
    FB.user().then(u => {
      if (!u || u.uid !== (Sync.state.authUid || uidv) || this._uid !== uidv || this._unsub) return;
      this._unsub = FB.store(uidv).collection('chat').orderBy('at', 'desc').limit(400)
        .onSnapshot({ includeMetadataChanges: true }, s => this._onSnap(s), () => {});
      this._unsubP = FB.store(uidv).collection('presence').onSnapshot(s => {
        this.pres = {}; this.typing = {};
        s.docs.forEach(d => { const x = d.data({ serverTimestamps: 'estimate' }); if (x.at && x.at.toMillis) this.pres[d.id] = x.at.toMillis(); if (x.typing && x.tAt && x.tAt.toMillis) this.typing[d.id] = { room: x.typing, at: x.tAt.toMillis() }; });
        if (location.hash === '#chat' && this.room) this.paintTop();
      }, () => {});
    }).catch(() => {});
  },
  stop() {
    if (this._unsub) this._unsub();
    if (this._unsubP) this._unsubP();
    this._unsubP = null;
    this._unsub = null; this._uid = null; this.msgs = []; this.ready = false;
    this.paintBadges();
  },
  _onSnap(s) {
    const before = new Set(this.msgs.map(m => m.id));
    this.msgs = s.docs.map(d => Object.assign({ id: d.id, pending: d.metadata.hasPendingWrites }, d.data({ serverTimestamps: 'estimate' }))).reverse();
    const fresh = this.ready ? this.msgs.filter(m => !before.has(m.id)) : [];
    this.ready = true;
    for (const m of fresh) if (this.mine(m) === false && this.ts(m) >= this._t0 - 60000 && !m.deleted && this.visible(m.room)) this.notify(m);
    this.paintBadges();
    if (typeof FileBox !== 'undefined') FileBox.onSnap();
    if (this.ackDelivered) this.ackDelivered();
    if (location.hash === '#chat') this.paint();
  },

  // ---------- Dados ----------
  me() { return App.user; },
  ts(m) { return m.at && m.at.toMillis ? m.at.toMillis() : (m.local || 0); },
  mine(m) { return !!(this.me() && m.from === this.me().id); },
  dm(a, b) { return `dm:${[a, b].sort().join('+')}`; },
  // A conversa "loja" é de todos; as privadas só aparecem às duas pessoas.
  inGroup(id) { return !((Store.settings.chatOut || []).includes(id)); },
  groupMembers() { return Store.data.employees.filter(e => this.inGroup(e.id)); },
  isGroupAdmin(e = this.me()) { return !!e && (e.role === 'owner' || (Store.settings.chatAdmins || []).includes(e.id)); },
  visible(room) { if (room === 'avisos') return ['alStock', 'alCredit', 'alCount', 'alCost', 'alIdle'].some(k => can(k)); return (room === 'loja' && (!this.me() || this.inGroup(this.me().id))) || (room && this.me() && room.startsWith('dm:') && room.slice(3).split('+').includes(this.me().id)); },
  other(room) { const id = room.slice(3).split('+').find(x => x !== this.me().id); return Store.find('employees', id) || { id, name: '?' }; },
  roomName(room) { if (room === 'avisos') return t('chat.alertsRoom'); return room === 'loja' ? (Store.settings.chatName || Store.settings.storeName || t('chat.store')) : this.other(room).name; },
  inRoom(room) { return this.msgs.filter(m => m.room === room); },
  _readKey() { return `stoi-chat-read-${this.me() ? this.me().id : ''}`; },
  _read() { try { return JSON.parse(localStorage.getItem(this._readKey())) || {}; } catch (e) { return {}; } },
  markRead(room) {
    const r = this._read(); const last = this.inRoom(room).reduce((a, m) => Math.max(a, this.ts(m)), 0);
    if ((r[room] || 0) >= last) return;
    r[room] = last;
    try { localStorage.setItem(this._readKey(), JSON.stringify(r)); } catch (e) { /* sem espaço */ }
    this.paintBadges();
  },
  unread(room) { const since = this._read()[room] || 0; return this.inRoom(room).filter(m => !this.mine(m) && !m.deleted && this.ts(m) > since).length; },
  totalUnread() { return this.rooms().reduce((n, r) => n + this.unread(r), 0); },
  rooms() {
    const set = new Set(['loja']);
    for (const e of Store.data.employees) if (this.me() && e.id !== this.me().id) set.add(this.dm(this.me().id, e.id));
    for (const m of this.msgs) if (this.visible(m.room)) set.add(m.room);
    if (this.visible('avisos') && Store.settings.alerts && Store.settings.alerts.chat === false && !this.inRoom('avisos').length) set.delete('avisos');
    return [...set];
  },
  pins(room) { return this.inRoom(room).filter(m => m.pinned && !m.deleted); },
  pinned(room) { return this.pins(room).pop() || null; },
  pinText(m) { return m.card && !m.text ? `${t('tc.table')} · ${m.card.title || ''}` : m.file && !m.text ? this.fileLabel(m) : plainText(m.text || ''); },
  canPin() { return can('pin'); },

  async send(room, text, reply, file = null, card = null) {
    text = (text || '').trim();
    if ((!text && !file && !card) || !this.available()) return;
    if (!this._uid) this.start(); // ainda não estava ligado (ex.: enviar alertas sem abrir o chat)
    const u = this.me();
    FB.init();
    const doc = { room, from: u.id, name: u.name, text: text.slice(0, 2000), local: Date.now(), at: firebase.firestore.FieldValue.serverTimestamp(), pinned: false, deleted: false };
    if (reply) doc.reply = { id: reply.id, name: reply.name, text: (reply.text || '').slice(0, 140) };
    // Tabela partilhada: só o resumo e a referência (abre a tabela verdadeira). O Firestore não aceita
    // listas dentro de listas, por isso cada linha vai como { c: [...] }.
    if (card) {
      const enc = rs => (rs || []).map(r => (Array.isArray(r) ? { c: r } : r));
      doc.card = Object.assign({}, card, { rows: enc(card.rows) });
      if (card.snap) doc.card.snap = { cols: card.snap.cols, rows: enc(card.snap.rows) };
    }
    if (file) {
      // O ficheiro vai em partes para stores/{loja}/files (cada documento do Firestore aceita ~1 MB);
      // a mensagem leva só o nome, o tamanho e, nas fotos, uma miniatura para mostrar logo.
      const fid = uid();
      const files = FB.store(this._uid).collection('files');
      const parts = [];
      for (let i = 0; i < file.b64.length; i += 700000) parts.push(file.b64.slice(i, i + 700000));
      doc.file = { id: fid, kind: file.kind, name: file.name, mime: file.mime, size: file.size, parts: parts.length, thumb: file.thumb || null, w: file.w || null, h: file.h || null, cloud: true };
      if (file.wave) doc.file.wave = file.wave;
      if (file.dur) doc.file.dur = file.dur;
      doc.got = [];
      // Quem envia já fica com o original guardado no aparelho.
      if (typeof FileBox !== 'undefined') FileBox.put(fid, b64Blob(file.b64, file.mime)).catch(() => {});
      parts.forEach((d, i) => files.doc(`${fid}__${i}`).set({ d, at: firebase.firestore.FieldValue.serverTimestamp() }).catch(() => {}));
    }
    // Não espera pelo servidor: sem internet a mensagem fica em espera e segue depois.
    FB.store(this._uid).collection('chat').add(doc).catch(() => toast(t('err.network'), true));
  },
  // Mensagem automática da app (alertas) na conversa "Avisos da loja".
  sendSystem(text) {
    if (!this.available()) return;
    if (!this._uid) this.start();
    FB.store(this._uid).collection('chat').add({ room: 'avisos', from: 'sys', name: 'Stoi', text: String(text).slice(0, 500), local: Date.now(), at: firebase.firestore.FieldValue.serverTimestamp(), pinned: false, deleted: false }).catch(() => {});
  },
  update(m, data) { FB.store(this._uid).collection('chat').doc(m.id).update(data).catch(() => toast(t('err.network'), true)); },

  // ---------- Avisos e contadores ----------
  paintBadges() {
    const n = this.ready && this.me() ? this.totalUnread() : 0;
    const a = document.querySelector('#sidebar a[data-route="chat"]');
    if (a) {
      let b = a.querySelector('.nav-badge');
      if (n && !b) { b = document.createElement('b'); b.className = 'nav-badge'; a.appendChild(b); }
      if (b) { if (n) b.textContent = n > 99 ? '99+' : n; else b.remove(); }
    }
    const mb = document.getElementById('menu-btn');
    if (mb) mb.classList.toggle('has-dot', !!n && !App.back);
  },
  notify(m) {
    if (location.hash === '#chat' && this.room === m.room && !document.hidden) return;
    if (navigator.vibrate) navigator.vibrate([18, 60, 18]);
    const old = document.getElementById('chat-pop'); if (old) old.remove();
    const el = document.createElement('button');
    el.id = 'chat-pop'; el.type = 'button'; el.className = 'chat-pop';
    const group = m.room === 'loja' || m.room === 'avisos';
    el.innerHTML = `${m.room === 'avisos' ? this.bellAvatar(40) : this.avatar(m.room === 'loja' ? { id: m.from, name: m.name } : this.other(m.room), 40)}<span><b>${esc(m.name)}</b>${group ? ` <small>· ${esc(this.roomName(m.room))}</small>` : ''}<em>${esc(m.card && !m.text ? `${t('tc.table')} · ${m.card.title}` : m.file && !m.text ? this.fileLabel(m) : plainText(m.text))}</em></span>`;
    el.addEventListener('click', () => { el.remove(); this.room = m.room; if (location.hash !== '#chat') location.hash = '#chat'; else render(); });
    document.body.appendChild(el);
    requestAnimationFrame(() => el.classList.add('on'));
    setTimeout(() => { el.classList.remove('on'); setTimeout(() => el.remove(), 300); }, 4500);
  },

  // ---------- Ecrãs ----------
  color(id) { let h = 0; for (const c of String(id)) h = (h * 31 + c.charCodeAt(0)) >>> 0; return COLORS[h % COLORS.length]; },
  avatar(p, size = 50, store = false) {
    const st = `width:${size}px;height:${size}px;font-size:${Math.round(size * 0.4)}px;background:${store ? 'var(--primary-dark)' : this.color(p.id)}`;
    if (store) {
      const ic = Store.settings.chatIcon || '';
      if (ic.startsWith('data:')) return `<span class="ch-av" style="${st};background:#ccc url('${ic}') center/cover"></span>`;
      if (ic) return `<span class="ch-av" style="${st};font-size:${Math.round(size * 0.5)}px">${esc(ic)}</span>`;
    }
    return `<span class="ch-av" style="${st}">${store ? icon('cart') : esc(((p.name || '?').trim().charAt(0) || '?').toUpperCase())}</span>`;
  },
  bellAvatar(size) { return `<span class="ch-av" style="width:${size}px;height:${size}px;background:#ea580c">${icon('bell')}</span>`; },
  hhmm(ms) { const d = new Date(ms); return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`; },
  dayLabel(ms) {
    const d = new Date(ms), now = new Date(), y = new Date(); y.setDate(now.getDate() - 1);
    const same = (a, b) => a.toDateString() === b.toDateString();
    return same(d, now) ? t('chat.today') : same(d, y) ? t('chat.yesterday') : d.toLocaleDateString(undefined, { day: 'numeric', month: 'long', year: d.getFullYear() === now.getFullYear() ? undefined : 'numeric' });
  },
  when(ms) { const d = new Date(ms); return d.toDateString() === new Date().toDateString() ? this.hhmm(ms) : this.dayLabel(ms); },

  view(main) {
    if (!this.available()) {
      this.room = null;
      main.innerHTML = `<div class="page"><div class="ch-off">
        <div class="ch-off-ic">${icon('chat')}</div><h2>${esc(t('chat.title'))}</h2><p>${esc(t('chat.needCloud'))}</p>
        ${App.user.role === 'owner' ? `<a class="btn primary" href="#definicoes" id="ch-cloud">${esc(t('chat.connect'))}</a>` : `<p class="muted small">${esc(t('chat.askOwner'))}</p>`}
      </div></div>`;
      const b = $('#ch-cloud', main); if (b) b.addEventListener('click', () => { App.openSet = 'cloud'; });
      return;
    }
    this.start();
    main.classList.add('flush');
    this.paint();
  },
  fileLabel(m) {
    const f = m.file;
    return f.kind === 'img' ? `📷 ${t('att.photo')}` : f.kind === 'audio' ? `🎤 ${t('att.voice')} (${fmtDur(f.dur)})` : `📄 ${f.name}`;
  },
  paint() {
    if (typeof Rec !== 'undefined' && Rec.on) { this._dirty = true; return; } // não desfaz a gravação em curso
    const main = $('#main');
    if (!this.room) { const b = document.getElementById('ch-selbar'); if (b) b.remove(); this.sel.clear(); }
    if (!main || location.hash !== '#chat') return;
    if (this.room && !this.visible(this.room)) this.room = null;
    if (this.room) { this.paintRoom(main); this.paintTop(); if (typeof FileBox !== 'undefined') FileBox.hydrate(main, this.room); if (this.q != null) this.highlight(false); } else { this.closeSearch(); this.paintList(main); }
  },
  // ---------- Topo da conversa: Tema · Media · Pesquisar ----------
  paintTop() {
    const box = document.getElementById('top-chat');
    if (!box) return;
    const b = (k, ic, label) => `<button type="button" class="icon-btn" data-ct="${k}" title="${esc(t(label))}" aria-label="${esc(t(label))}">${ic}</button>`;
    if (!box.firstChild) {
      box.innerHTML = b('search', thinIcon('search'), 'chat.search') + b('more', '<svg class="thin" viewBox="0 0 24 24"><circle cx="12" cy="5" r="1.6" fill="currentColor" stroke="none"/><circle cx="12" cy="12" r="1.6" fill="currentColor" stroke="none"/><circle cx="12" cy="19" r="1.6" fill="currentColor" stroke="none"/></svg>', 'chat.more');
      box.querySelector('[data-ct="search"]').onclick = () => this.openSearch();
      box.querySelector('[data-ct="more"]').onclick = e => { e.stopPropagation(); this.moreMenu(); };
    }
    box.hidden = false;
    document.getElementById('app').classList.add('in-room');
    // Foto, nome e, por baixo, os rostos da equipa (conversa da loja) ou função + visto (privada).
    let h = document.getElementById('chat-head');
    if (!h) { document.getElementById('view-title').insertAdjacentHTML('afterend', '<button type="button" id="chat-head" class="chat-head"></button>'); h = document.getElementById('chat-head'); h.onclick = () => this.roomInfo(); }
    const room = this.room;
    const hr = new Date().getHours(), tod = hr >= 6 && hr < 12 ? 'm' : hr >= 12 && hr < 18 ? 'a' : 'n';
    const app = document.getElementById('app');
    ['m', 'a', 'n'].forEach(k => app.classList.toggle(`tod-${k}`, k === tod));
    const oldWave = document.getElementById('chh-wave'); if (oldWave) oldWave.remove();
    const me = this.me();
    const typers = Object.entries(this.typing || {}).filter(([id, v]) => (!me || id !== me.id) && v.room === room && Date.now() - v.at < 9000).map(([id]) => (Store.find('employees', id) || {}).name).filter(Boolean);
    const typingTxt = typers.length ? `<span class="chh-dot"></span>${esc(typers.length === 1 ? t('chat.typing1', { name: typers[0] }) : t('chat.typingN', { n: typers.length }))}` : '';
    let av, sub;
    if (room === 'loja') {
      av = this.avatar({}, 40, true);
      const online = Object.entries(this.pres || {}).filter(([id, ms]) => (!me || id !== me.id) && Date.now() - ms < 2 * 60000).length;
      const team = this.groupMembers().length;
      sub = typingTxt || (online ? `<span class="chh-dot on"></span>${esc(t('chat.nOnline', { n: online + 1 }))}` : esc(t(team === 1 ? 'chat.member1' : 'chat.members', { n: team })));
    } else if (room === 'avisos') {
      av = this.bellAvatar(40); sub = esc(t('chat.alertsSub'));
    } else {
      const o = this.other(room);
      av = this.avatar(o, 40);
      sub = typingTxt || esc([o.role ? roleLabel(o.role) : '', this.lastSeen(o.id)].filter(Boolean).join(' · '));
    }
    // Atualiza sozinho (o "a escrever…" apaga-se e a cor muda com a hora).
    clearTimeout(this._topT);
    this._topT = setTimeout(() => { if (location.hash === '#chat' && this.room === room && !(typeof Rec !== 'undefined' && Rec.on)) this.paintTop(); }, typers.length ? 3000 : 60000);
    h.innerHTML = `${av}<span class="chh-t"><b>${esc(this.roomName(room))}</b><small>${sub}</small></span>`;
    h.hidden = false;
  },
  // Voltar à lista: deslizar para a direita num sítio vazio da conversa (sem botão de voltar).
  wireSwipeBack(main) {
    const roomEl = $('.ch-room', main), list = $('#ch-msgs', main);
    // Move a conversa e o cabeçalho juntos.
    const setT = (tr, tf) => [roomEl, document.querySelector('.topbar')].filter(Boolean).forEach(el => { el.style.transition = tr; el.style.transform = tf; });
    if (!roomEl || !list) return;
    let st = null;
    list.addEventListener('pointerdown', e => {
      if (e.button > 0 || e.target.closest('.ch-b, .tf, .tf-wrap, button, a, input, textarea, .exp-bar')) return;
      st = { x: e.clientX, y: e.clientY, id: e.pointerId, go: false };
    });
    list.addEventListener('pointermove', e => {
      if (!st || e.pointerId !== st.id) return;
      const dx = e.clientX - st.x, dy = e.clientY - st.y;
      if (!st.go && Math.abs(dy) > 24 && Math.abs(dy) > dx) { st = null; setT('', ''); return; } // é para rolar
      if (dx > 12 && dx > Math.abs(dy) * 1.5) {
        if (!st.go) { st.go = true; try { list.setPointerCapture(e.pointerId); } catch (er) { /* sem captura */ } }
        setT('none', `translateX(${Math.min(dx, 160) * 0.45}px)`);
      }
    });
    const end = e => {
      if (!st || e.pointerId !== st.id) return;
      const dx = e.clientX - st.x, go = st.go; st = null;
      setT('transform .18s ease', '');
      if (go && dx > 90 && App.back) App.back.fn();
    };
    list.addEventListener('pointerup', end);
    list.addEventListener('pointercancel', end);
    list.style.touchAction = 'pan-y';
    // Na 1.ª vez, uma dica.
    try { if (!localStorage.getItem('stoi-hint-swipe')) { localStorage.setItem('stoi-hint-swipe', '1'); setTimeout(() => toast(t('chat.swipeHint')), 600); } } catch (er) { /* nada */ }
  },
  hideTop() {
    const app = document.getElementById('app'); if (app) app.classList.remove('in-room');
    const h = document.getElementById('chat-head'); if (h) h.hidden = true;
    const m = document.getElementById('ch-more'); if (m) m.remove();
    const wv = document.getElementById('chh-wave'); if (wv) wv.style.display = 'none';
  },
  // Menu ⋮: Media, Tema e papel de parede, Pesquisar.
  moreMenu() {
    const old = document.getElementById('ch-more'); if (old) { old.remove(); return; }
    const it = (k, ic, label) => `<button type="button" data-mm="${k}">${thinIcon(ic)}<span>${esc(t(label))}</span></button>`;
    document.body.insertAdjacentHTML('beforeend', `<div id="ch-more" class="ch-more">${it('media', 'gallery', 'chat.media')}${it('theme', 'drop', 'chat.look')}${this.me() && this.me().role === 'owner' ? `<button type="button" data-mm="clear" class="red">${thinIcon('trash')}<span>${esc(t('chat.clear'))}</span></button>` : ''}</div>`);
    const m = document.getElementById('ch-more');
    const close = () => { m.remove(); document.removeEventListener('click', close, true); };
    setTimeout(() => document.addEventListener('click', close, true), 0);
    $$('[data-mm]', m).forEach(b => b.addEventListener('click', e => {
      e.stopPropagation(); close();
      if (b.dataset.mm === 'media') this.mediaModal(); else if (b.dataset.mm === 'clear') this.clearModal(); else this.themeModal();
    }));
  },
  // Limpar conversas (só o dono): apaga as mensagens e os ficheiros da nuvem, para todos.
  clearModal() {
    const room = this.room;
    const m = openModal({ title: t('chat.clear'), autofocus: false, body: `<p class="muted small" style="margin:0 2px 12px">${esc(t('chat.clearHint'))}</p><div class="sx-list">
      <button type="button" class="sx-row" data-cl="room"><span class="sx-ic" style="background:#ea580c">${thinIcon('trash')}</span><span class="sx-t"><b>${esc(t('chat.clearRoom'))}</b><small>${esc(this.roomName(room))}</small></span></button>
      <button type="button" class="sx-row" data-cl="all"><span class="sx-ic" style="background:#dc2626">${thinIcon('trash')}</span><span class="sx-t"><b>${esc(t('chat.clearAll'))}</b><small>${esc(t('chat.clearAllSub'))}</small></span></button></div>` });
    $$('[data-cl]', m).forEach(b => b.addEventListener('click', async () => {
      const all = b.dataset.cl === 'all';
      closeModal();
      if (!await confirmDialog(t(all ? 'chat.clearAllQ' : 'chat.clearRoomQ', { room: this.roomName(room) }), t('common.delete'), true)) return;
      try { const n = await this.clearChat(all ? null : room); toast(t('chat.cleared', { n })); } catch (e) { console.error('clear', e && (e.code || e.message)); toast(t('err.network'), true); }
    }));
  },
  async clearChat(room) {
    if (!this._uid) throw new Error('offline');
    const st = FB.store(this._uid), db = FB.db;
    const chat = st.collection('chat');
    const snap = room ? await chat.where('room', '==', room).get() : await chat.get();
    const fileIds = new Set();
    const refs = [];
    snap.docs.forEach(d => { refs.push(d.ref); const f = d.data().file; if (f && f.id) fileIds.add(`${f.id}__`); });
    // ficheiros (partes) dessas mensagens; ao limpar tudo, apaga todas as partes
    const files = await st.collection('files').get();
    files.docs.forEach(d => { if (!room || [...fileIds].some(p => d.id.startsWith(p))) refs.push(d.ref); });
    for (let i = 0; i < refs.length; i += 400) {
      const batch = db.batch();
      refs.slice(i, i + 400).forEach(r => batch.delete(r));
      await batch.commit();
    }
    // rascunhos e tabelas à espera deste celular
    if (room) { this.setDraft(room, ''); this.setCard(room, null); } else { try { localStorage.removeItem(this._draftKey()); localStorage.removeItem(this._cardKey()); } catch (e) { /* nada */ } }
    return snap.size;
  },
  // Tocar no nome: quem está na conversa.
  roomInfo() {
    const room = this.room;
    if (room === 'loja') { this.groupInfo(); return; }
    const people = room === 'loja' ? Store.data.employees : room && room.startsWith('dm:') ? [this.me(), this.other(room)].filter(Boolean) : [];
    if (!people.length) return;
    const me = this.me();
    openModal({ title: this.roomName(room), autofocus: false, body: `<div class="sx-list">${people.map(e => `<div class="sx-row">${this.avatar(e, 40)}<span class="sx-t"><b>${esc(e.name)}${me && e.id === me.id ? ` (${esc(t('chat.you'))})` : ''}</b><small>${esc([e.role ? roleLabel(e.role) : '', me && e.id === me.id ? '' : this.lastSeen(e.id)].filter(Boolean).join(' · '))}</small></span></div>`).join('')}</div>` });
  },
  // ---------- Info do grupo da loja: foto grande que encolhe ao deslizar ----------
  groupInfo() {
    document.getElementById('ginfo')?.remove();
    const me = this.me(), admin = this.isGroupAdmin();
    const online = id => { const ms = (this.pres || {})[id]; return (me && id === me.id) || (ms && Date.now() - ms < 2 * 60000); };
    const mem = this.groupMembers().sort((a, b) => (a.id === (me && me.id) ? -1 : b.id === (me && me.id) ? 1 : (b.role === 'owner') - (a.role === 'owner') || a.name.localeCompare(b.name, 'pt')));
    const nOn = mem.filter(e => online(e.id)).length;
    const out = Store.data.employees.filter(e => !this.inGroup(e.id));
    const pins = this.pins('loja').length;
    const ic = Store.settings.chatIcon || '';
    const big = ic.startsWith('data:') ? `<span class="gi-photo" style="background-image:url('${ic}')"></span>` : ic ? `<span class="gi-emoji">${esc(ic)}</span>` : `<span class="gi-cart">${icon('cart')}</span>`;
    const sub2 = t('ginfo.sub', { n: mem.length, on: nOn });
    const el = document.createElement('div');
    el.id = 'ginfo'; el.className = 'ginfo';
    el.innerHTML = `<div class="gi-bar"><button type="button" class="gi-back" aria-label="${esc(t('common.back'))}">${icon('back')}</button><span class="gi-mini">${this.avatar({}, 34, true)}<span><b>${esc(this.roomName('loja'))}</b><small>${esc(sub2)}</small></span></span>${admin ? `<button type="button" class="gi-edit" data-gedit>${icon('edit')}<span>${esc(t('common.edit'))}</span></button>` : ''}</div>
      <div class="gi-scroll"><div class="gi-hero" ${admin ? 'data-gedit' : ''}>${big}<div class="gi-name"><b>${esc(this.roomName('loja'))}</b><small>${esc(sub2)}</small></div></div>
      <div class="gi-card"><div class="gi-h"><span>${esc(t('ginfo.members'))}</span>${admin && out.length ? `<button type="button" data-gadd>＋ ${esc(t('ginfo.add'))}</button>` : ''}</div>
        ${mem.map(e => `<button type="button" class="gi-row" data-gm="${esc(e.id)}"><span class="gi-av ${online(e.id) ? 'on' : ''}">${this.avatar(e, 40)}</span><span class="gi-t"><b>${esc(e.name)}${me && e.id === me.id ? ` (${esc(t('chat.you'))})` : ''}</b><small>${esc([roleName(e), me && e.id === me.id ? '' : (online(e.id) ? t('chat.online') : this.lastSeen(e.id))].filter(Boolean).join(' · '))}</small></span>${this.isGroupAdmin(e) ? `<i class="gi-chip">${esc(t('ginfo.admin'))}</i>` : ''}</button>`).join('')}</div>
      <div class="gi-card">
        <button type="button" class="gi-row" data-gopt="pins"><span class="gi-t"><b>📌 ${esc(t('ginfo.pins'))}</b></span><small>${pins || ''}</small><span class="gi-ch">›</span></button>
        <button type="button" class="gi-row" data-gopt="media"><span class="gi-t"><b>🖼️ ${esc(t('chat.media'))}</b></span><span class="gi-ch">›</span></button>
        <button type="button" class="gi-row" data-gopt="theme"><span class="gi-t"><b>🎨 ${esc(t('ginfo.theme'))}</b></span><span class="gi-ch">›</span></button>
      </div></div>`;
    document.body.appendChild(el);
    const close = () => { el.remove(); };
    this.ginfoClose = close;
    el.querySelector('.gi-back').onclick = close;
    const sc = el.querySelector('.gi-scroll');
    sc.addEventListener('scroll', () => el.classList.toggle('mini', sc.scrollTop > 140), { passive: true });
    el.querySelectorAll('[data-gedit]').forEach(b => b.addEventListener('click', () => this.groupEdit()));
    const add = el.querySelector('[data-gadd]');
    if (add) add.onclick = () => this.groupAdd();
    el.querySelectorAll('[data-gm]').forEach(b => b.addEventListener('click', () => this.groupMember(b.dataset.gm)));
    el.querySelectorAll('[data-gopt]').forEach(b => b.addEventListener('click', () => {
      const k = b.dataset.gopt; close();
      if (k === 'media' && this.mediaModal) this.mediaModal(); else if (k === 'theme') this.themeModal(); else if (k === 'pins') { this.room = null; this.home = 'today'; this.paint(); }
    }));
  },
  groupSave(patch) {
    Object.assign(Store.settings, patch);
    Store.save();
    this.paintTop();
    if (document.getElementById('ginfo')) this.groupInfo();
  },
  groupMember(id) {
    const e = Store.find('employees', id), me = this.me();
    if (!e) return;
    const admin = this.isGroupAdmin(), self = me && e.id === me.id, isAdm = this.isGroupAdmin(e);
    const op = (k, ic, label, cls = '') => `<button type="button" class="sx-row ${cls}" data-mo="${k}"><span class="sx-t"><b>${ic} ${esc(label)}</b></span></button>`;
    const m = openModal({ title: e.name, autofocus: false, body: `<div class="sx-list">
      ${self ? '' : op('dm', '💬', t('ginfo.msgTo', { name: e.name }))}
      ${can('products') || (me && me.role === 'owner') ? op('emp', '👤', t('ginfo.viewEmp')) : ''}
      ${admin && !self && e.role !== 'owner' ? op('adm', '⭐', t(isAdm ? 'ginfo.unadmin' : 'ginfo.makeAdmin')) : ''}
      ${admin && !self && e.role !== 'owner' ? op('rm', '⛔', t('ginfo.remove'), 'gi-red') : ''}</div>` });
    m.querySelectorAll('[data-mo]').forEach(b => b.addEventListener('click', async () => {
      const k = b.dataset.mo;
      closeModal();
      if (k === 'dm') { this.ginfoClose && this.ginfoClose(); this.room = this.dm(me.id, e.id); this.paint(); }
      else if (k === 'emp') { this.ginfoClose && this.ginfoClose(); App.empOpen = e.id; location.hash = '#funcionarios'; }
      else if (k === 'adm') { const list = new Set(Store.settings.chatAdmins || []); if (isAdm) list.delete(e.id); else list.add(e.id); this.groupSave({ chatAdmins: [...list] }); }
      else if (k === 'rm') { if (!await confirmDialog(t('ginfo.removeQ', { name: e.name }), t('ginfo.remove'), true)) return; this.groupSave({ chatOut: [...new Set([...(Store.settings.chatOut || []), e.id])], chatAdmins: (Store.settings.chatAdmins || []).filter(x => x !== e.id) }); toast(t('ginfo.removed', { name: e.name })); }
    }));
  },
  groupAdd() {
    const out = Store.data.employees.filter(e => !this.inGroup(e.id));
    const m = openModal({ title: t('ginfo.add'), autofocus: false, body: out.length ? `<div class="sx-list">${out.map(e => `<button type="button" class="sx-row" data-ga="${esc(e.id)}">${this.avatar(e, 40)}<span class="sx-t"><b>${esc(e.name)}</b><small>${esc(roleName(e))}</small></span></button>`).join('')}</div>` : `<p class="muted">${esc(t('ginfo.allIn'))}</p>` });
    m.querySelectorAll('[data-ga]').forEach(b => b.addEventListener('click', () => { closeModal(); this.groupSave({ chatOut: (Store.settings.chatOut || []).filter(x => x !== b.dataset.ga) }); toast(t('ginfo.added')); }));
  },
  groupEdit() {
    const ICONS = ['', '🍺', '🍷', '🥃', '🏪', '🍾', '🧃'];
    let pick = Store.settings.chatIcon || '', photo = pick.startsWith('data:') ? pick : '';
    const m = openModal({ title: t('ginfo.editTitle'), autofocus: false,
      body: `<label class="field"><span>${esc(t('ginfo.name'))}</span><input class="input" id="gname" maxlength="40" value="${esc(this.roomName('loja'))}"></label>
        <div class="field"><span>${esc(t('ginfo.icon'))}</span><div class="gi-icons">${ICONS.map(x => `<button type="button" class="gi-ic ${pick === x ? 'on' : ''}" data-gi="${esc(x)}">${x || icon('cart')}</button>`).join('')}
        <label class="gi-ic gi-up ${photo ? 'on' : ''}" ${photo ? `style="background-image:url('${photo}')"` : ''}>${photo ? '' : '📷'}<input type="file" accept="image/*" id="gphoto" hidden></label></div>
        <small class="muted">${esc(t('ginfo.photoHint'))}</small></div>`,
      footer: `<button class="btn primary" data-ok>${esc(t('common.save'))}</button>` });
    const mark = () => m.querySelectorAll('.gi-ic').forEach(b => b.classList.toggle('on', b.classList.contains('gi-up') ? !!photo && pick === photo : b.dataset.gi === pick));
    m.querySelectorAll('[data-gi]').forEach(b => b.addEventListener('click', () => { pick = b.dataset.gi; mark(); }));
    m.querySelector('#gphoto').addEventListener('change', async ev => {
      const f = ev.target.files[0]; if (!f) return;
      const img = new Image(); img.src = await readAsDataURL(f); await img.decode();
      const s = 256, cv = document.createElement('canvas'); cv.width = cv.height = s;
      const k = Math.max(s / img.width, s / img.height), w = img.width * k, h = img.height * k;
      cv.getContext('2d').drawImage(img, (s - w) / 2, (s - h) / 2, w, h);
      photo = pick = cv.toDataURL('image/jpeg', 0.82);
      const up = m.querySelector('.gi-up'); up.style.backgroundImage = `url('${photo}')`; up.firstChild && up.firstChild.nodeType === 3 && (up.firstChild.textContent = '');
      mark();
    });
    m.querySelector('[data-ok]').onclick = () => {
      const name = m.querySelector('#gname').value.trim();
      closeModal();
      this.groupSave({ chatName: name && name !== (Store.settings.storeName || t('chat.store')) ? name : '', chatIcon: pick });
      toast(t('ginfo.saved'));
    };
  },
  // Visto: cada celular avisa (no máximo a cada minuto) que a pessoa tem o chat aberto.
  lastSeen(id) {
    const ms = (this.pres || {})[id];
    if (!ms) return '';
    const d = Date.now() - ms;
    if (d < 2 * 60000) return t('chat.online');
    const dt = new Date(ms), today = new Date().toDateString() === dt.toDateString();
    const y = new Date(Date.now() - 864e5).toDateString() === dt.toDateString();
    return t(today ? 'chat.seenToday' : y ? 'chat.seenYday' : 'chat.seenDay', { h: this.hhmm(ms), d: dt.toLocaleDateString(dateLocale(), { day: '2-digit', month: '2-digit' }) });
  },
  typingNow(room) {
    const me = this.me();
    if (!me || !this._uid) return;
    const now = Date.now(), ref = FB.store(this._uid).collection('presence').doc(me.id);
    clearTimeout(this._tyStop);
    this._tyStop = setTimeout(() => this.typingStop(), 4000);
    if (this._tyRoom === room && now - (this._tyAt || 0) < 5000) return;
    this._tyRoom = room; this._tyAt = now;
    ref.set({ typing: room, tAt: firebase.firestore.FieldValue.serverTimestamp(), at: firebase.firestore.FieldValue.serverTimestamp(), name: me.name }, { merge: true }).catch(() => {});
  },
  typingStop() {
    clearTimeout(this._tyStop);
    if (!this._tyRoom || !this._uid || !this.me()) return;
    this._tyRoom = null; this._tyAt = 0;
    FB.store(this._uid).collection('presence').doc(this.me().id).set({ typing: null }, { merge: true }).catch(() => {});
  },
  ping() {
    const me = this.me();
    if (!me || !this._uid || document.hidden || Date.now() - (this._ping || 0) < 60000) return;
    this._ping = Date.now();
    FB.store(this._uid).collection('presence').doc(me.id).set({ at: firebase.firestore.FieldValue.serverTimestamp(), name: me.name }).catch(() => {});
  },
  // Pesquisar: o topo vira um campo; as palavras ficam marcadas e as setas saltam entre elas.
  openSearch() {
    if (this.q != null) return;
    this.q = ''; this.qi = -1;
    const top = document.querySelector('.topbar');
    top.insertAdjacentHTML('beforeend', `<div class="chs" id="ch-search"><button type="button" data-q="x" aria-label="${esc(t('common.close'))}">${thinIcon('x')}</button><input type="search" placeholder="${esc(t('chat.searchPh'))}" enterkeyhint="search"><small></small><button type="button" data-q="up" aria-label="↑">${thinIcon('up')}</button><button type="button" data-q="down" aria-label="↓">${thinIcon('down')}</button></div>`);
    const bar = document.getElementById('ch-search'), inp = bar.querySelector('input');
    let tm = null;
    inp.addEventListener('input', () => { clearTimeout(tm); tm = setTimeout(() => { this.q = inp.value; this.qi = -1; this.highlight(true); }, 180); });
    inp.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); this.step(-1); } });
    bar.querySelector('[data-q="x"]').onclick = () => this.closeSearch();
    bar.querySelector('[data-q="up"]').onclick = () => this.step(-1);
    bar.querySelector('[data-q="down"]').onclick = () => this.step(1);
    inp.focus();
  },
  closeSearch() {
    const bar = document.getElementById('ch-search'); if (bar) bar.remove();
    if (this.q == null) return;
    this.q = null; this.qi = -1;
    document.querySelectorAll('#ch-msgs mark').forEach(m => m.replaceWith(m.textContent));
    const l = document.getElementById('ch-msgs'); if (l) l.normalize();
  },
  highlight(jump) {
    const list = document.getElementById('ch-msgs');
    if (!list) return;
    list.querySelectorAll('mark').forEach(m => m.replaceWith(m.textContent));
    list.normalize();
    const norm = s => [...s].map(c => (c.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase()[0] || c)).join('');
    const q = norm((this.q || '').trim());
    const info = document.querySelector('#ch-search small');
    if (!q) { if (info) info.textContent = ''; return; }
    for (const b of list.querySelectorAll('.ch-b')) {
      const walk = document.createTreeWalker(b, NodeFilter.SHOW_TEXT, { acceptNode: n => (n.parentElement.closest('.ch-t, .ch-n, .tc-go') ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT) });
      const nodes = []; while (walk.nextNode()) nodes.push(walk.currentNode);
      for (const n of nodes) {
        const s = n.nodeValue, ns = norm(s);
        if (ns.length !== s.length || !ns.includes(q)) continue;
        const frag = document.createDocumentFragment();
        let i = 0, k;
        while ((k = ns.indexOf(q, i)) !== -1) {
          frag.appendChild(document.createTextNode(s.slice(i, k)));
          const m = document.createElement('mark'); m.textContent = s.slice(k, k + q.length); frag.appendChild(m);
          i = k + q.length;
        }
        frag.appendChild(document.createTextNode(s.slice(i)));
        n.replaceWith(frag);
      }
    }
    const marks = [...list.querySelectorAll('mark')];
    if (!marks.length) { if (info) info.textContent = t('chat.noRes'); return; }
    if (this.qi < 0 || this.qi >= marks.length) this.qi = marks.length - 1; // começa pela mais recente
    this.showMark(marks, jump);
  },
  showMark(marks, jump) {
    marks.forEach((m, i) => m.classList.toggle('cur', i === this.qi));
    const info = document.querySelector('#ch-search small');
    if (info) info.textContent = t('chat.nOf', { i: this.qi + 1, n: marks.length });
    if (jump && marks[this.qi]) marks[this.qi].scrollIntoView({ block: 'center', behavior: 'smooth' });
  },
  step(d) {
    const marks = [...document.querySelectorAll('#ch-msgs mark')];
    if (!marks.length) return;
    this.qi = (this.qi + d + marks.length) % marks.length;
    this.showMark(marks, true);
  },
  gotoMsg(id) {
    const el = document.querySelector(`#ch-msgs [data-id="${CSS.escape(id)}"]`);
    if (el) { el.scrollIntoView({ block: 'center', behavior: 'smooth' }); el.classList.add('flash'); setTimeout(() => el.classList.remove('flash'), 1200); }
  },
  // Media: fotos, documentos e tabelas enviados nesta conversa.
  mediaModal(tab) {
    const ms = this.inRoom(this.room).filter(m => !m.deleted);
    const ph = ms.filter(m => m.file && m.file.kind === 'img').reverse();
    const dc = ms.filter(m => m.file && m.file.kind !== 'img' && m.file.kind !== 'audio').reverse();
    const tb = ms.filter(m => m.card).reverse();
    tab = tab || (ph.length ? 'ph' : dc.length ? 'dc' : tb.length ? 'tb' : 'ph');
    const when = m => `${m.name} · ${this.when(this.ts(m))}`;
    const list = tab === 'ph' ? (ph.length ? `<div class="cm-grid">${ph.map(m => `<button type="button" data-m="${esc(m.id)}"><img src="${esc(m.file.thumb || '')}" alt=""></button>`).join('')}</div>` : '')
      : tab === 'dc' ? dc.map(m => { const ext = (m.file.name.split('.').pop() || 'DOC').slice(0, 4).toUpperCase(); const col = ext === 'PDF' ? '#e53935' : /XLS|CSV/.test(ext) ? '#16a34a' : /DOC/.test(ext) ? '#2563eb' : '#64748b';
        return `<button type="button" class="cm-row" data-m="${esc(m.id)}"><i style="background:${col}">${esc(ext)}</i><span><b>${esc(m.file.name)}</b><small>${esc(fmtKB(m.file.size))} · ${esc(when(m))}</small></span></button>`; }).join('')
      : tb.map(m => `<button type="button" class="cm-row" data-m="${esc(m.id)}"><i style="background:#0891b2">${thinIcon('check')}</i><span><b>${esc(m.card.title)}</b><small>${esc(t('tc.table'))} · ${esc(when(m))}</small></span></button>`).join('');
    const tabs = [['ph', 'chat.tPhotos', ph.length], ['dc', 'chat.tDocs', dc.length], ['tb', 'chat.tTables', tb.length]];
    const m = openModal({ title: t('chat.media'), sheet: true, autofocus: false,
      body: `<div class="cm-tabs">${tabs.map(([k, l, n]) => `<button type="button" class="${k === tab ? 'on' : ''}" data-tab="${k}">${esc(t(l, { n }))}</button>`).join('')}</div>
        ${list || `<p class="cm-empty">${esc(t('chat.noMedia'))}</p>`}
        ${list ? `<p class="muted small cm-hint">${esc(t('chat.mediaHint'))}</p>` : ''}` });
    $$('[data-tab]', m).forEach(b => b.addEventListener('click', () => { closeModal(); this.mediaModal(b.dataset.tab); }));
    $$('[data-m]', m).forEach(b => {
      const msg = this.msgs.find(x => x.id === b.dataset.m);
      let timer = null, long = false;
      const goto = () => { long = true; closeModal(); this.gotoMsg(msg.id); };
      b.addEventListener('pointerdown', () => { long = false; timer = setTimeout(goto, 550); });
      ['pointerup', 'pointerleave', 'pointercancel'].forEach(ev => b.addEventListener(ev, () => clearTimeout(timer)));
      b.addEventListener('contextmenu', e => { e.preventDefault(); clearTimeout(timer); if (!long) goto(); });
      b.addEventListener('click', () => { if (long) return; closeModal(); if (msg.card) openTableCard(msg); else openFile(msg); });
    });
  },
  // Tema: fundo da conversa, guardado só neste celular.
  THEMES: [['def', '#efe7de'], ['green', '#d4ecd9'], ['blue', '#dbe7f5'], ['pink', '#f8e1ea'], ['plain', '#f3f4f6'], ['dark', '#0b141a']],
  theme() { try { return localStorage.getItem('stoi-chat-theme') || 'def'; } catch (e) { return 'def'; } },
  themeModal() {
    const cur = this.theme();
    const m = openModal({ title: t('chat.theme'), sheet: true, autofocus: false,
      body: `<div class="cth">${this.THEMES.map(([k, c]) => `<button type="button" class="${k === cur ? 'on' : ''} ${k === 'dark' ? 'dk' : ''}" data-th="${k}" style="background:${c}"><em></em><em></em><span>${esc(t(`chat.th.${k}`))}</span></button>`).join('')}</div>
        <p class="muted small" style="margin:12px 2px 0">${esc(t('chat.thLocal'))}</p>` });
    $$('[data-th]', m).forEach(b => b.addEventListener('click', () => {
      try { localStorage.setItem('stoi-chat-theme', b.dataset.th); } catch (e) { /* sem espaço */ }
      $$('[data-th]', m).forEach(x => x.classList.toggle('on', x === b));
      const r = document.querySelector('.ch-room'); if (r) r.dataset.theme = b.dataset.th;
    }));
  },
  paintList(main) {
    App.back = null; paintBack(); setTitle(t('chat.title'));
    const tc = document.getElementById('top-chat'); if (tc) tc.hidden = true;
    this.hideTop();
    const rows = this.rooms().map(r => { const ms = this.inRoom(r).filter(m => !m.deleted); const last = ms[ms.length - 1]; return { r, last, ts: last ? this.ts(last) : 0 }; })
      .sort((a, b) => (a.r === 'loja' ? -1 : b.r === 'loja' ? 1 : a.r === 'avisos' ? -1 : b.r === 'avisos' ? 1 : b.ts - a.ts));
    const home = this.home === 'today' ? 'today' : 'chats', un = this.totalUnread();
    const seg = `<div class="chl-seg" role="tablist"><button type="button" role="tab" data-hm="chats" class="${home === 'chats' ? 'on' : ''}">${esc(t('chat.tabChats'))}${un ? `<em>${un}</em>` : ''}</button><button type="button" role="tab" data-hm="today" class="${home === 'today' ? 'on' : ''}">${esc(t('chat.tabToday'))}</button></div>`;
    if (home === 'today') { main.innerHTML = seg + this.todayHtml(); this.wireList(main); return; }
    main.innerHTML = seg + `<div class="ch-list">${rows.map(({ r, last }) => {
      const n = this.unread(r);
      const who = r === 'loja' || r === 'avisos' ? null : this.other(r);
      const prev = last ? `${this.mine(last) ? `${this.tick(last)}` : r === 'loja' ? `${esc(last.name)}: ` : ''}${esc(last.card && !last.text ? `${t('tc.table')} · ${last.card.title}` : last.file && !last.text ? this.fileLabel(last) : plainText(last.text))}` : `<i>${esc(r === 'loja' ? t('chat.storeHint') : t('chat.dmHint'))}</i>`;
      return `<button type="button" class="ch-row ${n ? 'unread' : ''}" data-room="${esc(r)}">${r === 'loja' ? this.avatar({}, 50, true) : r === 'avisos' ? this.bellAvatar(50) : this.avatar(who)}
        <span class="ch-body"><span class="ch-top"><b>${esc(this.roomName(r))}</b><small>${last ? this.when(this.ts(last)) : ''}</small></span>
        <span class="ch-sub"><span>${prev}</span>${n ? `<em class="ch-un">${n}</em>` : ''}</span></span></button>`;
    }).join('')}
    ${Store.data.employees.length < 2 ? `<p class="ch-tip">${esc(t('chat.noOthers'))}</p>` : ''}</div>`;
    this.wireList(main);
  },
  // Separadores, abrir conversa e o botão de nova conversa (comum a "Conversas" e "Loja hoje").
  wireList(main) {
    $$('[data-hm]', main).forEach(b => b.addEventListener('click', () => { this.home = b.dataset.hm; this.paint(); main.scrollTop = 0; }));
    $$('[data-room]', main).forEach(b => b.addEventListener('click', () => { this.room = b.dataset.room; this.reply = null; this.paint(); }));
    $$('[data-ev]', main).forEach(b => b.addEventListener('click', () => {
      const [k, id] = b.dataset.ev.split(':');
      if (k === 'card') { const m = this.msgs.find(x => x.id === id); if (m && m.card) openTableCard(m); }
      else location.hash = k === 'count' ? '#balanco' : '#stock';
    }));
    $$('[data-pins]', main).forEach(b => b.addEventListener('click', () => { this.pinsAll = !this.pinsAll; this.paint(); }));
    $$('[data-al]', main).forEach(b => b.addEventListener('click', () => { if (b.dataset.al === 'in') location.hash = '#stock'; else if (typeof alertsModal === 'function') alertsModal(); }));
    // Botão redondo em baixo: iniciar uma conversa (escolher com quem).
    main.insertAdjacentHTML('beforeend', `<button type="button" class="ch-fab" id="ch-new" aria-label="${esc(t('chat.new'))}" title="${esc(t('chat.new'))}"><svg viewBox="0 0 24 24"><path d="M22 2 11 13M22 2l-7 20-4-9-9-4z"/></svg></button>`);
    $('#ch-new', main).addEventListener('click', () => this.newChat());
  },
  // "Loja hoje": o que cada pessoa fez hoje (quadros enviados no chat, entradas de stock, contagens).
  // Cada um só vê o que as suas permissões e conversas deixam.
  todayEvents() {
    const today = new Date().toDateString(), isToday = ms => ms && new Date(ms).toDateString() === today;
    const ev = [];
    for (const m of this.msgs) {
      if (!m.card || m.deleted || !this.visible(m.room) || !isToday(this.ts(m))) continue;
      const c = m.card, n = (c.rows || []).length + (c.more || 0);
      ev.push({ who: m.from, ms: this.ts(m), ic: 'box', key: `card:${m.id}`, html: esc(t('today.sent', { title: c.title || t('tc.table'), n })) });
    }
    if (canAny(STOCK_PERMS) || can('reports')) {
      for (const e of Store.data.stockEntries) {
        const ms = Date.parse(e.createdAt);
        if (e.type !== 'in' || !isToday(ms)) continue;
        const it = Store.find('items', e.itemId);
        ev.push({ who: e.employeeId, ms, ic: 'download', key: `in:${e.id}`, html: `${esc(t('today.in', { name: it ? it.name : '?' }))} <b>+${esc(fmtNum(e.qty))}</b>` });
      }
    }
    if (canAny(['count', 'close'])) {
      for (const c of Store.data.stockCounts) {
        const ms = Date.parse(c.finishedAt);
        if (c.status !== 'done' || !isToday(ms) || Store.isCheck(c)) continue;
        const tt = c.totals || {};
        ev.push({ who: c.finishedBy, ms, ic: 'clipboard', key: `count:${c.id}`, html: esc(`${t('today.count', { n: tt.counted != null ? tt.counted : (tt.items || 0) })} · ${tt.withDiff ? t('today.countDiff', { n: tt.withDiff }) : t('today.countOk')}`) });
      }
    }
    return ev.filter(e => e.who && Store.find('employees', e.who)).sort((a, b) => b.ms - a.ms); // sem nome de quem fez: não aparece
  },
  // Mensagens fixadas em todas as conversas que a pessoa vê (as mais recentes primeiro).
  pinsHtml() {
    const pins = this.msgs.filter(m => m.pinned && !m.deleted && this.visible(m.room)).sort((a, b) => this.ts(b) - this.ts(a));
    if (!pins.length) return '';
    const shown = this.pinsAll ? pins : pins.slice(0, 2);
    const txt = m => (m.card && !m.text ? `${t('tc.table')} · ${m.card.title || ''}` : m.file && !m.text ? this.fileLabel(m) : plainText(m.text || ''));
    return `<div class="td-sec"><span>${icon('pin')}${esc(t('today.pins'))}</span>${pins.length > 2 ? `<button type="button" data-pins>${esc(this.pinsAll ? t('today.less') : t('today.allPins', { n: pins.length }))}</button>` : ''}</div>
      <div class="td-card">${shown.map(m => `<button type="button" class="td-i td-pin" data-room="${esc(m.room)}"><span class="td-ic">${icon('pin')}</span><span class="td-t"><b>${esc(txt(m))}</b><small>${esc([this.roomName(m.room), m.name, this.when(this.ts(m))].filter(Boolean).join(' · '))}</small></span></button>`).join('')}</div>`;
  },
  // Stock: o que acabou, o que está baixo (os mesmos alertas do sino) e o que entrou hoje.
  stockHtml() {
    if (!can('alStock') || typeof computeAlerts !== 'function') return '';
    const al = computeAlerts(), rows = [];
    for (const a of al.out) rows.push({ k: 'out', name: dn(a.item), tag: t('today.out') });
    for (const a of al.low) rows.push({ k: 'low', name: dn(a.item), tag: t('today.low', { n: fmtQty(a.stock) }) });
    const today = new Date().toDateString(), ins = new Map();
    for (const e of Store.data.stockEntries) {
      if (e.type !== 'in' || new Date(Date.parse(e.createdAt)).toDateString() !== today) continue;
      ins.set(e.itemId, (ins.get(e.itemId) || 0) + (Number(e.qty) || 0));
    }
    for (const [id, q] of ins) { const it = Store.find('items', id); if (it && q > 0) rows.push({ k: 'in', name: dn(it), tag: t('today.new', { n: fmtQty(q) }) }); }
    if (!rows.length) return '';
    const shown = rows.slice(0, 4), more = rows.length - shown.length;
    return `<div class="td-sec"><span>${esc(t('today.stock'))}</span><button type="button" data-al="all">${esc(t('today.seeAlerts'))}</button></div>
      <div class="td-card">${shown.map(r => `<button type="button" class="td-i td-st ${r.k}" data-al="${r.k}"><i></i><span class="td-t">${esc(r.name)}</span><b>${esc(r.tag)}</b></button>`).join('')}${more > 0 ? `<button type="button" class="td-more" data-al="all">${esc(t('today.more', { n: more }))}</button>` : ''}</div>`;
  },
  todayHtml() {
    const me = this.me(), ev = this.todayEvents();
    const top = this.pinsHtml() + this.stockHtml();
    if (!ev.length) return `<div class="td">${top || `<div class="td-empty">${icon('clipboard')}<b>${esc(t('today.empty'))}</b><small>${esc(t('today.emptySub'))}</small></div>`}</div>`;
    const person = id => Store.find('employees', id) || { id: id || 'x', name: t('today.noName') };
    const online = id => { const ms = (this.pres || {})[id]; return (me && id === me.id) || (ms && Date.now() - ms < 2 * 60000); };
    const item = (e, withWho) => `<button type="button" class="td-i" data-ev="${esc(e.key)}">${withWho ? this.avatar(person(e.who), 30) : `<span class="td-ic">${icon(e.ic)}</span>`}<span class="td-t">${withWho ? `<b>${esc(person(e.who).name)}</b> · ` : ''}${e.html}</span><small>${this.hhmm(e.ms)}</small></button>`;
    const groups = new Map();
    for (const e of ev) { const k = e.who || ''; if (!groups.has(k)) groups.set(k, []); groups.get(k).push(e); }
    return `<div class="td">${top}${top ? `<div class="td-sec"><span>${esc(t('today.people'))}</span></div>` : ''}${[...groups].map(([id, list]) => {
      const p = person(id), mine = me && id === me.id, on = online(id);
      const sub = mine ? (p.role ? roleLabel(p.role) : '') : on ? t('chat.online') : (this.lastSeen(id) || (p.role ? roleLabel(p.role) : ''));
      const shown = list.slice(0, 5), more = list.length - shown.length;
      return `<div class="td-card"><div class="td-h"><span class="td-av">${this.avatar(p, 42)}${on ? '<i></i>' : ''}</span><span class="td-n"><b>${esc(p.name)}${mine ? ` (${esc(t('chat.you'))})` : ''}</b><small>${esc(sub)}</small></span>${me && id && !mine && Store.find('employees', id) ? `<button type="button" class="td-chat" data-room="${esc(this.dm(me.id, id))}" aria-label="${esc(t('chat.title'))}">${icon('chat')}</button>` : ''}</div>
        ${shown.map(e => item(e, false)).join('')}${more > 0 ? `<div class="td-more">${esc(t('today.more', { n: more }))}</div>` : ''}</div>`;
    }).join('')}</div>`;
  },
  newChat() {
    const me = this.me();
    const people = Store.data.employees.filter(e => me && e.id !== me.id).sort((a, b) => a.name.localeCompare(b.name, 'pt'));
    const row = (k, av, title, sub) => `<button type="button" class="sx-row" data-nc="${esc(k)}">${av}<span class="sx-t"><b>${esc(title)}</b>${sub ? `<small>${esc(sub)}</small>` : ''}</span></button>`;
    const isOwner = me && me.role === 'owner';
    const m = openModal({ title: t('chat.new'), autofocus: false, body: `<div class="sx-list">
        ${row('loja', this.avatar({}, 40, true), this.roomName('loja'), t('chat.newStore'))}
        ${people.map(e => row(this.dm(me.id, e.id), this.avatar(e, 40), e.name, roleLabel(e.role))).join('')}</div>
      ${people.length ? '' : `<p class="muted small" style="margin:12px 4px 0">${esc(t('chat.noOthers'))}</p>`}
      ${isOwner ? `<div class="sx-list" style="margin-top:12px"><button type="button" class="sx-row" data-nc="add"><span class="sx-ic" style="background:#1f6f3a">${icon('plus')}</span><span class="sx-t"><b>${esc(t('chat.newEmp'))}</b><small>${esc(t('chat.newEmpSub'))}</small></span></button></div>` : ''}` });
    $$('[data-nc]', m).forEach(b => b.addEventListener('click', () => {
      closeModal();
      if (b.dataset.nc === 'add') { location.hash = '#funcionarios'; return; }
      this.room = b.dataset.nc; this.reply = null; this.paint();
    }));
  },
  tick(m) {
    return m.pending ? `<svg class="ch-clock" viewBox="0 0 16 16"><path d="M8 1.5a6.5 6.5 0 1 0 0 13 6.5 6.5 0 0 0 0-13zm0 1.3a5.2 5.2 0 1 1 0 10.4A5.2 5.2 0 0 1 8 2.8zM7.4 4.5v4l3.2 1.9.6-1-2.6-1.6V4.5z"/></svg>`
      : '<svg class="ch-tick" viewBox="0 0 16 11"><path d="M13.07.65l-7.6 8.1L2.6 5.9l-.94 1 3.86 3.8 8.56-9.27z"/></svg>'; // enviada (chegou à nuvem)
  },
  paintRoom(main) {
    const room = this.room;
    App.back = { title: this.roomName(room), fn: () => { if (this.q != null) { this.closeSearch(); return; } if (this.sel.size) { this.clearSel(); return; } this.room = null; this.reply = null; this.paint(); } };
    paintBack();
    const draft = $('#ch-text', main) && $('#ch-text', main).dataset.room === room ? $('#ch-text', main).value : this.getDraft(room);
    const wasBottom = !$('#ch-msgs', main) || ($('#ch-msgs', main).scrollHeight - $('#ch-msgs', main).scrollTop - $('#ch-msgs', main).clientHeight < 80);
    const oldTop = $('#ch-msgs', main) ? $('#ch-msgs', main).scrollTop : 0;
    const ms = this.inRoom(room);
    let html = '', lastDay = '', prev = null;
    for (const m of ms) {
      const ms2 = this.ts(m), day = new Date(ms2).toDateString();
      if (day !== lastDay) { html += `<div class="ch-day"><span>${esc(this.dayLabel(ms2))}</span></div>`; lastDay = day; prev = null; }
      const me = this.mine(m), first = !prev || prev.from !== m.from || ms2 - this.ts(prev) > 5 * 60000;
      const name = (room === 'loja' || room === 'avisos') && !me && first ? `<span class="ch-n" style="color:${this.color(m.from)}">${esc(m.name)}</span>` : '';
      const quote = m.reply && !m.deleted ? `<span class="ch-q" data-goto="${esc(m.reply.id)}"><b>${esc(m.reply.name)}</b>${esc(plainText(m.reply.text))}</span>` : '';
      // Tabela partilhada: ficha solta (fora do balão); o texto, se houver, vai num balão por cima.
      if (m.card && !m.deleted) {
        const meta = `${me ? '' : `${esc(m.name)} · `}${this.hhmm(ms2)}${me ? this.tick(m) : ''}`;
        html += `<div class="ch-m ch-mcard ${me ? 'me' : ''} ${first ? 'gap' : ''} ${this.sel.has(m.id) ? 'sel' : ''}" data-id="${esc(m.id)}"><div class="tf-wrap">
          ${tableCardHtml(m.card, m.id)}${m.text || quote ? `<div class="tf-under">${quote}${richText(m.text)}</div>` : ''}<span class="tf-meta">${meta}</span></div></div>`;
        prev = m; continue;
      }
      const body = m.deleted ? `<i class="ch-del">${esc(t('chat.deleted'))}</i>` : `${m.file ? FileBox.html(m) : ''}${richText(m.text)}`;
      html += `<div class="ch-m ${me ? 'me' : ''} ${first ? 'tail gap' : ''} ${this.sel.has(m.id) ? 'sel' : ''}" data-id="${esc(m.id)}"><div class="ch-b">${name}${quote}${m.pinned && !m.deleted ? `<span class="ch-pinmark">${icon('pin')}${esc(t('chat.pinned'))}</span>` : ''}${body}<span class="ch-sp" aria-hidden="true"></span><span class="ch-t">${this.hhmm(ms2)}${me && !m.deleted ? this.tick(m) : ''}</span></div></div>`;
      prev = m;
    }
    if (!ms.length) html = `<div class="ch-empty">${esc(t('chat.empty'))}</div>`;
    const pins = this.pins(room);
    if (this.pinRoom !== room || this.pinIdx == null || this.pinIdx >= pins.length) { this.pinRoom = room; this.pinIdx = pins.length - 1; }
    const pin = pins[this.pinIdx] || null;
    main.innerHTML = `<div class="ch-room" data-theme="${this.theme()}" style="${this.lookStyle()}">
      ${pin ? `<button type="button" class="ch-pinbar" data-goto="${esc(pin.id)}" data-pinnext>${pins.length > 1 ? `<i class="ch-pindots">${pins.map((x, i) => `<em class="${i === this.pinIdx ? 'on' : ''}"></em>`).join('')}</i>` : ''}${icon('pin')}<span><b>${esc(pins.length > 1 ? t('chat.pinnedN', { i: this.pinIdx + 1, n: pins.length }) : t('chat.pinned'))} · ${esc(pin.name)}</b>${esc(this.pinText(pin))}</span></button>` : ''}
      <div class="ch-msgs" id="ch-msgs">${html}</div>
      <div class="ch-bar">
        ${this.reply ? `<div class="ch-replying"><span><b>${esc(this.reply.name)}</b>${esc(this.reply.text)}</span><button type="button" id="ch-noreply" aria-label="${esc(t('common.close'))}">${icon('close')}</button></div>` : ''}
        <div class="ch-fmt" id="ch-fmt" hidden><button type="button" data-f="*" aria-label="Negrito"><b>B</b></button><button type="button" data-f="_" aria-label="Itálico"><i>I</i></button><button type="button" data-f="~" aria-label="Riscado"><s>S</s></button></div>
        <div class="ch-inrow"><div class="ch-in ${this.getCard(room) ? 'has-pend' : ''}">${(() => { const cd = this.getCard(room); if (!cd) return ''; const n = (cd.snap && cd.snap.rows ? cd.snap.rows.length : (cd.rows || []).length + (cd.more || 0)); return `<div class="ch-pend"><span class="ch-pend-ic"><svg viewBox="0 0 24 24"><rect x="5" y="4" width="14" height="17" rx="2"/><path d="M9 4V3h6v1M8.5 13l2.5 2.5 4.5-5"/></svg></span><span class="ch-pend-t"><b>${esc(t('tc.table'))}</b><small>${esc(cd.title)}${n ? ` · ${esc(t(n === 1 ? 'tc.more1' : 'tc.more', { n }).replace(/^\+\s*/, ''))}` : ''}</small></span><button type="button" id="ch-nocard" aria-label="${esc(t('common.close'))}">${icon('close')}</button></div><div class="ch-sugg">${TC_TITLES.map(k => `<button type="button" class="${cd.title === t(k) ? 'on' : ''}" data-ttl="${esc(t(k))}">${esc(t(k))}</button>`).join('')}<button type="button" data-ttl-other>${esc(t('tc.other'))}</button></div>`; })()}<button type="button" class="ch-clip" id="ch-clip" aria-label="${esc(t('att.title'))}"><svg viewBox="0 0 24 24"><path d="m21.4 11.1-8.5 8.5a5.5 5.5 0 0 1-7.8-7.8l8.5-8.5a3.7 3.7 0 0 1 5.2 5.2l-8.5 8.5a1.8 1.8 0 0 1-2.6-2.6l7.8-7.8"/></svg></button><textarea id="ch-text" rows="1" placeholder="${esc(t('chat.placeholder'))}" enterkeyhint="enter"></textarea></div>
        <button type="button" class="ch-send" id="ch-send" aria-label="${esc(t('chat.send'))}"><svg viewBox="0 0 24 24"><path d="${PLANE_D}"/></svg></button></div>
      </div></div>`;
    const list = $('#ch-msgs', main), ta = $('#ch-text', main);
    ta.value = draft; ta.dataset.room = room;
    const fit = () => { ta.style.height = 'auto'; ta.style.height = `${Math.min(ta.scrollHeight, 120)}px`; };
    fit();
    list.scrollTop = wasBottom ? list.scrollHeight : oldTop;
    this.markRead(room);
    this.ackSeen(room);
    this.ping();
    this.wireSwipeBack(main);
    ta.addEventListener('input', () => { fit(); this.setDraft(room, ta.value); if (ta.value.trim()) this.typingNow(room); else this.typingStop(); });
    // Formatar: ao selecionar texto aparece B / I / S, que põe *…*, _…_ ou ~…~ à volta (como no WhatsApp).
    const fmt = $('#ch-fmt', main);
    const showFmt = () => { fmt.hidden = document.activeElement !== ta || ta.selectionStart === ta.selectionEnd; };
    ['select', 'keyup', 'mouseup', 'touchend', 'blur', 'focus'].forEach(ev => ta.addEventListener(ev, () => setTimeout(showFmt, 0)));
    if (!this._selListen) { // uma só vez: segue a seleção do campo de escrever aberto
      this._selListen = true;
      document.addEventListener('selectionchange', () => { const x = document.getElementById('ch-text'), f = document.getElementById('ch-fmt'); if (x && f) f.hidden = document.activeElement !== x || x.selectionStart === x.selectionEnd; });
    }
    $$('[data-f]', fmt).forEach(b => {
      b.addEventListener('mousedown', e => e.preventDefault()); // não tira o foco do campo
      b.addEventListener('click', () => {
        const mk = b.dataset.f, a = ta.selectionStart, z = ta.selectionEnd;
        if (a === z) return;
        let sel = ta.value.slice(a, z);
        const lead = sel.match(/^\s*/)[0], trail = sel.match(/\s*$/)[0];
        sel = sel.trim();
        const wrapped = sel.startsWith(mk) && sel.endsWith(mk) && sel.length > 1 ? sel.slice(1, -1) : `${mk}${sel}${mk}`;
        ta.value = ta.value.slice(0, a) + lead + wrapped + trail + ta.value.slice(z);
        ta.focus(); ta.setSelectionRange(a + lead.length, a + lead.length + wrapped.length);
        fit(); this.setDraft(room, ta.value); showFmt();
      });
    });
    ta.addEventListener('keydown', e => { if (e.key === 'Enter' && !e.shiftKey && !('ontouchstart' in window)) { e.preventDefault(); go(); } });
    const go = () => {
      const v = ta.value, card = this.getCard(room);
      if (!v.trim() && !card) { ta.focus(); return; }
      planeFly($('#ch-send', main));
      this.send(room, v, this.reply, null, card); this.typingStop();
      ta.value = ''; this.reply = null; fit(); this.setDraft(room, ''); this.setCard(room, null); { const pd = $('.ch-pend', main); if (pd) { pd.parentElement.classList.remove('has-pend'); pd.outerHTML = ''; } const sg = $('.ch-sugg', main); if (sg) sg.outerHTML = ''; }
      $$('.ch-replying', main).forEach(r => r.remove());
      ta.focus();
    };
    $('#ch-send', main).addEventListener('click', go);
    if (typeof wireVoice === 'function') wireVoice(room, main, () => { const r = this.reply; this.reply = null; return r; }, () => { $$('.ch-replying', main).forEach(r => r.remove()); });
    $('#ch-clip', main).addEventListener('click', () => attachMenu(room, () => { const r = this.reply; this.reply = null; return r; }));
    $$('[data-file]', list).forEach(el => el.addEventListener('click', e => { if (this.sel.size) return; e.stopPropagation(); openFile(this.msgs.find(x => x.id === el.dataset.file)); }));
    const nr = $('#ch-noreply', main); if (nr) nr.addEventListener('click', () => { this.reply = null; this.paint(); });
    const nc = $('#ch-nocard', main); if (nc) nc.addEventListener('click', () => { this.setCard(room, null); this.paint(); });
    // Título da tabela: um toque numa sugestão; outra vez volta ao nome original; "+ Outro" deixa escrever.
    const setTitle = v => { const cd = this.getCard(room); if (!cd) return; cd.orig = cd.orig || cd.title; cd.title = v && v.trim() ? v.trim().slice(0, 60) : cd.orig; this.setCard(room, cd); this.paint(); };
    $$('[data-ttl]', main).forEach(b => b.addEventListener('click', () => setTitle(b.classList.contains('on') ? '' : b.dataset.ttl)));
    const oth = $('[data-ttl-other]', main);
    if (oth) oth.addEventListener('click', () => { const cd = this.getCard(room); fieldModal({ title: t('tc.titleQ'), value: cd ? cd.title : '', onSave: v => setTitle(v) }); });
    $$('[data-card]', list).forEach(el => el.addEventListener('click', e => { if (this.sel.size) return; e.stopPropagation(); const m = this.msgs.find(x => x.id === el.dataset.card); if (m && m.card) openTableCard(m); }));
    $$('[data-goto]', main).forEach(b => b.addEventListener('click', e => {
      e.stopPropagation();
      const el = list.querySelector(`[data-id="${CSS.escape(b.dataset.goto)}"]`);
      if (el) { el.scrollIntoView({ block: 'center', behavior: 'smooth' }); el.classList.add('flash'); setTimeout(() => el.classList.remove('flash'), 1200); }
      // Barra das fixadas: a seguir mostra a fixada anterior (e volta à mais recente no fim).
      if (b.hasAttribute('data-pinnext')) {
        const n = this.pins(room).length;
        if (n > 1) { this.pinIdx = (this.pinIdx - 1 + n) % n; const keep = list.scrollTop; this.paint(); const l2 = document.getElementById('ch-msgs'); if (l2) l2.scrollTop = keep; const el2 = l2 && l2.querySelector(`[data-id="${CSS.escape(b.dataset.goto)}"]`); if (el2) el2.scrollIntoView({ block: 'center' }); }
      }
    }));
    // Tocar e manter numa mensagem: fica selecionada e o topo mostra as ações em ícones.
    // Com mensagens selecionadas, tocar noutras junta-as ou tira-as da seleção.
    let timer = null, pickedAt = 0;
    const longPick = id => { if (Date.now() - pickedAt < 700) return; pickedAt = Date.now(); pick(id); };
    const pick = id => { const m = this.msgs.find(x => x.id === id); if (!m || m.deleted) return; if (this.sel.has(id)) this.sel.delete(id); else this.sel.add(id); this.paintSel(); };
    list.addEventListener('contextmenu', e => { const b = e.target.closest('.ch-m'); if (b) { e.preventDefault(); longPick(b.dataset.id); } });
    let sx = 0, sy = 0;
    list.addEventListener('touchstart', e => {
      const b = e.target.closest('.ch-m'); if (!b) return;
      sx = e.touches[0].clientX; sy = e.touches[0].clientY;
      clearTimeout(timer);
      timer = setTimeout(() => { timer = null; if (navigator.vibrate) navigator.vibrate(10); longPick(b.dataset.id); }, 450);
    }, { passive: true });
    // O dedo treme um pouco ao manter: só cancela se se mexer a sério (deslizar a conversa).
    list.addEventListener('touchmove', e => { const p = e.touches[0]; if (Math.abs(p.clientX - sx) > 10 || Math.abs(p.clientY - sy) > 10) { clearTimeout(timer); timer = null; } }, { passive: true });
    ['touchend', 'touchcancel'].forEach(ev => list.addEventListener(ev, () => { clearTimeout(timer); timer = null; }, { passive: true }));
    list.addEventListener('click', e => {
      if (Date.now() - pickedAt < 600) return; // o clique que acaba o "tocar e manter"
      const b = e.target.closest('.ch-m');
      if (b && this.sel.size) { e.preventDefault(); e.stopPropagation(); pick(b.dataset.id); }
    }, true);
    this.paintSel();
  },
  // ---------- Rascunhos (por conversa, guardados neste celular) ----------
  _draftKey() { return `stoi-chat-drafts-${this.me() ? this.me().id : ''}`; },
  _drafts() { try { return JSON.parse(localStorage.getItem(this._draftKey())) || {}; } catch (e) { return {}; } },
  getDraft(room) { return this._drafts()[room] || ''; },
  setDraft(room, text) {
    const d = this._drafts();
    if (text && text.trim()) d[room] = text; else delete d[room];
    try { localStorage.setItem(this._draftKey(), JSON.stringify(d)); } catch (e) { /* sem espaço */ }
  },
  // Tabela à espera de envio em cada conversa (sai junto com a próxima mensagem).
  _cardKey() { return `stoi-chat-cards-${this.me() ? this.me().id : ''}`; },
  _cards() { try { return JSON.parse(localStorage.getItem(this._cardKey())) || {}; } catch (e) { return {}; } },
  getCard(room) { return this._cards()[room] || null; },
  setCard(room, card) {
    const d = this._cards();
    if (card) d[room] = card; else delete d[room];
    try { localStorage.setItem(this._cardKey(), JSON.stringify(d)); } catch (e) { /* sem espaço */ }
  },
  // Junta texto ao rascunho de uma conversa (ex.: alertas): só sai quando se carregar em enviar.
  addToDraft(room, text) {
    const cur = this.getDraft(room).replace(/\s+$/, '');
    this.setDraft(room, cur ? `${cur}\n\n${text}` : text);
  },
  // ---------- Seleção de mensagens ----------
  selected() { return this.inRoom(this.room).filter(m => this.sel.has(m.id) && !m.deleted); },
  clearSel() { this.sel.clear(); this.paintSel(); },
  paintSel() {
    document.querySelectorAll('.ch-m').forEach(el => el.classList.toggle('sel', this.sel.has(el.dataset.id)));
    const old = document.getElementById('ch-selbar'); if (old) old.remove();
    const ms = this.selected();
    if (!ms.length || location.hash !== '#chat' || !this.room) { this.sel.clear(); return; }
    const one = ms.length === 1, allMine = ms.every(m => this.mine(m));
    const btns = [['close', 'close', t('common.close')]];
    const acts = [];
    if (one) acts.push(['reply', 'undo', t('chat.reply')]);
    acts.push(['copy', 'copy', t('chat.copy')]);
    if (one && this.canPin()) acts.push([ms[0].pinned ? 'unpin' : 'pin', 'pin', t(ms[0].pinned ? 'chat.unpin' : 'chat.pin')]);
    acts.push(['fwd', 'forward', t('chat.forward')]);
    if (allMine) acts.push(['del', 'trash', t('chat.delete')]);
    const bar = document.createElement('div');
    bar.id = 'ch-selbar'; bar.className = 'ch-selbar';
    bar.innerHTML = `${btns.map(([k, ic, l]) => `<button type="button" data-sa="${k}" aria-label="${esc(l)}">${icon(ic)}</button>`).join('')}<b>${ms.length}</b>${acts.map(([k, ic, l]) => `<button type="button" data-sa="${k}" title="${esc(l)}" aria-label="${esc(l)}" class="${k === 'pin' ? 'pinb' : k === 'unpin' ? 'pinb unpinb' : ''}">${icon(ic)}</button>`).join('')}`;
    document.body.appendChild(bar);
    bar.querySelectorAll('[data-sa]').forEach(b => b.addEventListener('click', () => this.selAction(b.dataset.sa)));
  },
  async selAction(k) {
    const ms = this.selected();
    if (k === 'close') { this.clearSel(); return; }
    if (k === 'reply') { const m = ms[0]; this.reply = { id: m.id, name: this.mine(m) ? t('chat.you') : m.name, text: m.text }; this.sel.clear(); this.paint(); const ta = $('#ch-text'); if (ta) ta.focus(); return; }
    if (k === 'copy') {
      const text = ms.length === 1 ? ms[0].text : ms.map(m => `${m.name}: ${m.text}`).join('\n');
      const ok = typeof copyText === 'function' ? await copyText(text) : await navigator.clipboard.writeText(text).then(() => true, () => false);
      toast(ok ? t('chat.copied') : t('err.server'), !ok); this.clearSel(); return;
    }
    if (k === 'pin' || k === 'unpin') {
      const m = ms[0];
      this.update(m, { pinned: k === 'pin' });
      this.pinIdx = null; // a barra volta a mostrar a mais recente
      toast(t(k === 'pin' ? 'chat.pinDone' : 'chat.unpinDone'));
      this.clearSel(); return;
    }
    if (k === 'fwd') { this.pickRoom(t('chat.forwardTo'), room => { for (const m of ms) this.send(room, m.text, null, null, m.card || null); toast(t('chat.forwarded')); this.clearSel(); }); return; }
    if (k === 'del') {
      if (!await confirmDialog(t(ms.length > 1 ? 'chat.deleteManyConfirm' : 'chat.deleteConfirm', { n: ms.length }), t('chat.delete'), true)) return;
      for (const m of ms) this.update(m, { deleted: true, pinned: false, text: '' });
      this.clearSel();
    }
  },
  // Escolher uma conversa (reencaminhar, ou enviar alertas para o chat).
  pickRoom(title, cb) {
    const rooms = this.rooms().filter(r => r !== this.room || title === t('chat.sendTo'));
    const m = openModal({ title, autofocus: false, body: `<div class="sx-list">${rooms.map(r => {
      const who = r === 'loja' || r === 'avisos' ? null : this.other(r);
      return `<button type="button" class="sx-row" data-r="${esc(r)}">${r === 'loja' ? this.avatar({}, 40, true) : r === 'avisos' ? this.bellAvatar(40) : this.avatar(who, 40)}<span class="sx-t"><b>${esc(this.roomName(r))}</b></span></button>`;
    }).join('')}</div>` });
    $$('[data-r]', m).forEach(b => b.addEventListener('click', () => { closeModal(); cb(b.dataset.r); }));
  },
};

// Botão de enviar: aviãozinho de papel. Ao tocar, um avião de papel branco parte do botão,
// dá um giro e sobe numa grande curva até encher o ecrã (1 segundo).
const PLANE_D = 'M21.4 2.6a1 1 0 0 0-1.05-.23l-17 6.5a1 1 0 0 0-.04 1.85l7.12 3.06 3.06 7.12a1 1 0 0 0 .92.6h.04a1 1 0 0 0 .9-.64l6.5-17a1 1 0 0 0-.45-1.26zM14.9 17.6l-2.13-4.97 3.9-3.9-1.41-1.42-3.9 3.9-4.97-2.13L19.1 4.9z';
function planeFly(btn) {
  // Mostra sempre (mesmo com "reduzir animações" no Android): é o efeito pedido para o botão de enviar.
  if (!btn) return;
  if (navigator.vibrate) navigator.vibrate(12);
  const old = document.querySelector('.plane-fly'); if (old) old.remove();
  // Desenho em SVG (camada por cima de tudo), mais fiável que canvas no WebView do Android.
  const W = window.innerWidth, H = window.innerHeight, NS = 'http://www.w3.org/2000/svg';
  const svg = document.createElementNS(NS, 'svg');
  svg.setAttribute('class', 'plane-fly'); svg.setAttribute('viewBox', `0 0 ${W} ${H}`); svg.setAttribute('width', W); svg.setAttribute('height', H);
  svg.innerHTML = `<defs>
    <linearGradient id="pf-top" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffffff"/><stop offset="1" stop-color="#eef1f4"/></linearGradient>
    <linearGradient id="pf-low" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#e3e8ed"/><stop offset="1" stop-color="#cfd6dd"/></linearGradient>
    <linearGradient id="pf-keel" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#b9c3cc"/><stop offset="1" stop-color="#a3aeb8"/></linearGradient></defs>
    <g class="pf-trail">${'<circle r="0" fill="#fff"/>'.repeat(22)}</g>
    <ellipse class="pf-shadow" rx="11" ry="9" fill="rgba(60,40,20,.08)"/>
    <g class="pf-plane"><polygon class="pf-k" fill="url(#pf-keel)"/><polygon class="pf-b"/><polygon class="pf-a"/></g>`;
  document.body.appendChild(svg);
  const dots = svg.querySelectorAll('.pf-trail circle'), shadow = svg.querySelector('.pf-shadow'), plane = svg.querySelector('.pf-plane');
  const [pk, pb, pa] = ['.pf-k', '.pf-b', '.pf-a'].map(q => svg.querySelector(q));
  const r = btn.getBoundingClientRect(), u = Math.min(W, 420) / 360, v = H / 780;
  const k = (x, y) => [x * u, y * v];
  const pts = [[r.left + r.width / 2, r.top + r.height / 2], k(259, 567), k(194, 468), k(108, 440), k(50, 496), k(72, 581), k(180, 610), k(259, 560),
    k(288, 425), k(295, 298), k(252, 191), k(173, 106), k(86, 71), k(10, 40), k(-90, 10)];
  const at = tt => {
    const n = pts.length - 1, f = Math.min(Math.max(tt, 0) * n, n - 1e-6), i = Math.floor(f), s2 = f - i;
    const p0 = pts[Math.max(i - 1, 0)], p1 = pts[i], p2 = pts[i + 1], p3 = pts[Math.min(i + 2, n)];
    const c = (a, b, c2, dd) => 0.5 * (2 * b + (-a + c2) * s2 + (2 * a - 5 * b + 4 * c2 - dd) * s2 * s2 + (-a + 3 * b - 3 * c2 + dd) * s2 * s2 * s2);
    const dc = (a, b, c2, dd) => 0.5 * ((-a + c2) + 2 * (2 * a - 5 * b + 4 * c2 - dd) * s2 + 3 * (-a + 3 * b - 3 * c2 + dd) * s2 * s2);
    return { x: c(p0[0], p1[0], p2[0], p3[0]), y: c(p0[1], p1[1], p2[1], p3[1]), a: Math.atan2(dc(p0[1], p1[1], p2[1], p3[1]), dc(p0[0], p1[0], p2[0], p3[0])) };
  };
  const ease = tt => (tt < 0.55 ? 0.55 * Math.pow(tt / 0.55, 1.15) : 0.55 + 0.45 * (1 - Math.pow(1 - (tt - 0.55) / 0.45, 2.2)));
  const P = ps => ps.map(q => `${q[0].toFixed(2)},${q[1].toFixed(2)}`).join(' ');
  const DEG = 180 / Math.PI;
  btn.classList.add('gone');
  const t0 = performance.now(), DUR = 1000;
  const done = () => { svg.remove(); btn.classList.remove('gone'); };
  const step = () => {
    const tt = Math.max(0, (performance.now() - t0) / DUR);
    if (tt >= 1 || !svg.isConnected) { done(); return; }
    const e = ease(tt);
    dots.forEach((dot, j) => {
      const i = 22 - j, q = e - i * 0.011;
      if (q <= 0) { dot.setAttribute('r', 0); return; }
      const p = at(q);
      dot.setAttribute('cx', p.x.toFixed(1)); dot.setAttribute('cy', p.y.toFixed(1)); dot.setAttribute('r', (1.6 + 2.5 * q).toFixed(2));
      dot.setAttribute('opacity', ((1 - i / 22) * 0.5 * (1 - tt)).toFixed(3));
    });
    const p = at(e), p2 = at(Math.max(0, e - 0.02));
    let da = p.a - p2.a; while (da > Math.PI) da -= 2 * Math.PI; while (da < -Math.PI) da += 2 * Math.PI;
    const roll = Math.max(-0.9, Math.min(0.9, da * 6)) + Math.sin(tt * 18) * 0.12;
    const sc = 1.15 + Math.pow(tt, 3.2) * 38;
    const kk = Math.cos(roll), f = kk < 0 ? -1 : 1, y = val => val * (0.55 + 0.45 * Math.abs(kk)) * f;
    const N = [11, 0], A = [-10, y(-16)], C = [-4, 0], B = [-10, y(14)], K = [-7, y(4.5)];
    pk.setAttribute('points', P([N, K, C]));
    pb.setAttribute('points', P([N, C, B])); pb.setAttribute('fill', kk > 0 ? 'url(#pf-low)' : 'url(#pf-top)');
    pa.setAttribute('points', P([N, A, C])); pa.setAttribute('fill', kk > 0 ? 'url(#pf-top)' : 'url(#pf-low)');
    const op = tt > 0.88 ? (1 - tt) / 0.12 : 1;
    plane.setAttribute('transform', `translate(${p.x.toFixed(1)} ${p.y.toFixed(1)}) rotate(${(p.a * DEG).toFixed(2)}) scale(${sc.toFixed(3)})`);
    plane.setAttribute('opacity', op.toFixed(3));
    shadow.setAttribute('transform', `translate(${(p.x + 3).toFixed(1)} ${(p.y + 5).toFixed(1)}) rotate(${(p.a * DEG).toFixed(2)}) scale(${sc.toFixed(3)} ${(sc * 0.9).toFixed(3)})`);
    shadow.setAttribute('opacity', op.toFixed(3));
    requestAnimationFrame(step);
  };
  step();
}

// Sair do chat (mudar de página) fecha a seleção de mensagens.
window.addEventListener('hashchange', () => { if (location.hash !== '#chat') Chat.clearSel(); });

// Formatação simples das mensagens (como no WhatsApp): *negrito*, _itálico_, ~riscado~.
function richText(s) {
  return esc(s || '')
    .replace(/(^|[\s(])\*([^*\n]+?)\*(?=$|[\s.,;:!?)])/g, '$1<b>$2</b>')
    .replace(/(^|[\s(])_([^_\n]+?)_(?=$|[\s.,;:!?)])/g, '$1<i>$2</i>')
    .replace(/(^|[\s(])~([^~\n]+?)~(?=$|[\s.,;:!?)])/g, '$1<s>$2</s>')
    .replace(/\n/g, '<br>');
}
// Texto sem as marcas de formatação (lista de conversas, avisos, citações).
function plainText(s) {
  return String(s || '').replace(/(^|[\s(])([*_~])([^\n]+?)\2(?=$|[\s.,;:!?)])/g, '$1$3').replace(/\n+/g, ' · ');
}

// ---------- Anexos: fotos (comprimidas) e documentos até 1 MB ----------
const ATT_MAX = 10 * 1024 * 1024; // qualidade original até 10 MB (o Firebase só serve de carteiro)
const fmtKB = n => (n >= 1024 * 1024 ? `${(n / 1048576).toFixed(1).replace('.', ',')} MB` : `${Math.max(1, Math.round(n / 1024))} KB`);
// Cartão de tabela: título, mini-tabela com colunas (até 4 linhas) e "Abrir tabela".
const tcRow = r => (Array.isArray(r) ? r : (r && r.c) || []);
function tableCardHtml(c, id) {
  const rows = (c.rows || []).map(tcRow), n = (c.cols || []).length || 1;
  const cls = v => (/^[−-]\s?\d/.test(v) ? 'neg' : /^\+\d/.test(v) ? 'pos' : '');
  return `<button type="button" class="tf" data-card="${esc(id)}"><span class="tf-tab">${esc(c.title || '')}</span><span class="tf-body">
    ${c.sub ? `<span class="tf-sub">${esc(c.sub)}</span>` : ''}
    ${rows.map(r => { const v = String(r[n - 1] == null ? '' : r[n - 1]); return `<span class="tf-row"><span>${esc(r[0] || '')}</span><b class="${cls(v)}">${esc(v)}</b></span>`; }).join('')}
    ${c.more ? `<span class="tf-more">${esc(t(c.more === 1 ? 'tc.more1' : 'tc.more', { n: c.more }))}</span>` : ''}
    <span class="tf-go">${esc(t('tc.open'))} ›</span></span></button>`;
}
function fileHtml(m) {
  const f = m.file;
  if (f.kind === 'img') return `<button type="button" class="ch-ph" data-file="${esc(m.id)}"><img src="${esc(f.thumb || '')}" alt=""></button>`;
  const ext = (f.name.split('.').pop() || 'DOC').slice(0, 4).toUpperCase();
  const col = ext === 'PDF' ? '#e53935' : /XLS|CSV/.test(ext) ? '#16a34a' : /DOC/.test(ext) ? '#2563eb' : '#64748b';
  return `<button type="button" class="ch-doc" data-file="${esc(m.id)}"><span class="ch-doc-ic" style="background:${col}">${esc(ext)}</span><span class="ch-doc-tx"><b>${esc(f.name)}</b><small>${esc(fmtKB(f.size))}</small></span></button>`;
}
function attachMenu(room, takeReply) {
  const svg = d => `<svg viewBox="0 0 24 24">${d}</svg>`;
  const m = openModal({ title: t('att.title'), autofocus: false, body: `<div class="att-grid">
    <label><span style="background:#e91e63">${svg('<path d="M3 8h3l2-3h8l2 3h3v12H3z"/><circle cx="12" cy="13.5" r="3.5"/>')}</span>${esc(t('att.camera'))}<input type="file" accept="image/*" capture="environment" data-k="img" hidden></label>
    <label><span style="background:#7c3aed">${svg('<rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="9" cy="9" r="2"/><path d="m21 16-5-5L5 21"/>')}</span>${esc(t('att.gallery'))}<input type="file" accept="image/*" data-k="img" hidden></label>
    <label><span style="background:#0284c7">${svg('<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5M9 13h6M9 17h6"/>')}</span>${esc(t('att.doc'))}<input type="file" accept=".pdf,.doc,.docx,.xls,.xlsx,.csv,.txt,application/pdf" data-k="doc" hidden></label>
  </div><p class="muted small" style="margin:4px 4px 0">${esc(t('att.hint'))}</p>` });
  $$('input[type=file]', m).forEach(inp => inp.addEventListener('change', async () => {
    const file = inp.files && inp.files[0];
    if (!file) return;
    closeModal();
    try {
      if (inp.dataset.k === 'img' || /^image\//.test(file.type)) await photoPreview(room, file, takeReply);
      else await docSend(room, file, takeReply);
    } catch (e) { toast(t('att.fail'), true); }
  }));
}
const readAsDataURL = file => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = rej; r.readAsDataURL(file); });
const loadImg = src => new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = rej; i.src = src; });
function drawJpeg(img, maxSide, q) {
  const k = Math.min(1, maxSide / Math.max(img.naturalWidth, img.naturalHeight));
  const c = document.createElement('canvas');
  c.width = Math.round(img.naturalWidth * k); c.height = Math.round(img.naturalHeight * k);
  const x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height); x.drawImage(img, 0, 0, c.width, c.height);
  return { url: c.toDataURL('image/jpeg', q), w: c.width, h: c.height };
}
// Comprimir: medidas até 1280, JPEG 78%; se ainda passar de ~700 KB, baixa a qualidade.
async function compressPhoto(file) {
  const light = typeof FileBox !== 'undefined' && FileBox.dev().quality === 'light';
  const url0 = await readAsDataURL(file);
  const img = await loadImg(url0);
  const bytes = u => Math.round((u.length - u.indexOf(',') - 1) * 0.75);
  const thumb = drawJpeg(img, 480, 0.6).url;
  // Original: o próprio ficheiro, sem mexer, se for JPEG/PNG/WebP até 10 MB.
  if (!light && /^image\/(jpeg|png|webp)$/.test(file.type) && file.size <= ATT_MAX) {
    return { b64: url0.slice(url0.indexOf(',') + 1), size: file.size, thumb, w: img.naturalWidth, h: img.naturalHeight, orig: file.size, preview: url0, mime: file.type, keep: true };
  }
  let q = light ? 0.78 : 0.9, side = light ? 1280 : 4096, out = drawJpeg(img, side, q);
  const max = light ? 700 * 1024 : ATT_MAX;
  while (bytes(out.url) > max && (q > 0.45 || side > 800)) { if (q > 0.45) q -= 0.1; else side -= 400; out = drawJpeg(img, side, q); }
  return { b64: out.url.slice(out.url.indexOf(',') + 1), size: bytes(out.url), thumb, w: out.w, h: out.h, orig: file.size, preview: out.url, mime: 'image/jpeg' };
}
async function photoPreview(room, file, takeReply) {
  toast(t('att.compressing'));
  const ph = await compressPhoto(file);
  const m = openModal({ title: t('att.sendPhoto'), autofocus: false, body: `<div class="att-pv"><img src="${ph.preview}" alt=""><span class="att-sz">${ph.keep ? `${esc(t('cf.qOrig'))} · ${esc(fmtKB(ph.size))}` : `${esc(fmtKB(ph.orig))} → ${esc(fmtKB(ph.size))}`}</span></div>
    <div class="att-cap"><input class="input" id="att-cap" placeholder="${esc(t('att.caption'))}"><button type="button" class="ch-send" id="att-go"><svg viewBox="0 0 24 24"><path d="${PLANE_D}"/></svg></button></div>` });
  $('#att-go', m).onclick = () => {
    const cap = $('#att-cap', m).value;
    planeFly($('#att-go', m));
    closeModal();
    Chat.send(room, cap, takeReply(), { kind: 'img', name: ph.keep ? (file.name || 'foto.jpg') : (file.name || 'foto').replace(/\.[^.]+$/, '') + '.jpg', mime: ph.mime, size: ph.size, b64: ph.b64, thumb: ph.thumb, w: ph.w, h: ph.h });
  };
}
async function docSend(room, file, takeReply) {
  if (file.size > ATT_MAX) {
    const m = openModal({ title: t('att.tooBig'), autofocus: false, body: `<div class="ch-doc" style="width:auto;margin:0 0 12px"><span class="ch-doc-ic" style="background:#e53935">${esc((file.name.split('.').pop() || '').slice(0, 4).toUpperCase())}</span><span class="ch-doc-tx"><b>${esc(file.name)}</b><small>${esc(t('att.tooBigSub', { size: fmtKB(file.size) }))}</small></span></div><p style="margin:0">${esc(t('att.tooBigHint'))}</p>`,
      footer: navigator.share ? `<button class="btn primary" data-sh>${esc(t('att.shareOther'))}</button>` : '' });
    const sh = $('[data-sh]', m);
    if (sh) sh.onclick = async () => { try { await navigator.share({ files: [file], title: file.name }); } catch (e) { /* cancelado ou sem suporte */ } closeModal(); };
    return;
  }
  const url = await readAsDataURL(file);
  if (!await confirmDialog(t('att.sendDocQ', { name: file.name, size: fmtKB(file.size) }), t('chat.send'))) return;
  Chat.send(room, '', takeReply(), { kind: 'doc', name: file.name, mime: file.type || 'application/octet-stream', size: file.size, b64: url.slice(url.indexOf(',') + 1) });
}
// Abrir: junta as partes do ficheiro; fotos em ecrã inteiro, documentos pelo Android (abrir / partilhar).
function openFile(m) { if (m && m.file) FileBox.open(m); }

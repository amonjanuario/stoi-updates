'use strict';
// Stoi — impressão de recibos em impressoras térmicas Bluetooth (ESC/POS).
// Na app Android usa o plugin nativo "BluetoothPrinter" (android/.../BluetoothPrinterPlugin.java).
// No browser não há Bluetooth clássico: a impressão usa a janela de impressão do sistema.

const ESC = 0x1b;
const GS = 0x1d;

// Converte texto para ASCII simples: a maioria das impressoras baratas não tem acentos fiáveis.
function toPrinterText(s) {
  return String(s ?? '')
    .replace(/[  ]/g, ' ')
    .replace(/€/g, 'EUR')
    .normalize('NFD').replace(/[̀-ͯ]/g, '')
    .replace(/[^\x20-\x7e\n]/g, '?');
}

class EscPos {
  constructor(width = 32) {
    this.width = width;
    this.bytes = [ESC, 0x40]; // inicializar
  }
  raw(...b) { this.bytes.push(...b); return this; }
  text(s) { for (const ch of toPrinterText(s)) this.bytes.push(ch.charCodeAt(0)); return this; }
  line(s = '') { return this.text(s).raw(0x0a); }
  align(a) { return this.raw(ESC, 0x61, { left: 0, center: 1, right: 2 }[a] ?? 0); }
  bold(on) { return this.raw(ESC, 0x45, on ? 1 : 0); }
  big(on) { return this.raw(GS, 0x21, on ? 0x11 : 0); }
  rule(ch = '-') { return this.line(ch.repeat(this.width)); }
  // Texto à esquerda e valor à direita na mesma linha.
  pair(left, right, width = this.width) {
    const l = toPrinterText(left);
    const r = toPrinterText(right);
    const space = width - l.length - r.length;
    if (space >= 1) return this.line(l + ' '.repeat(space) + r);
    return this.line(l).line(' '.repeat(Math.max(0, width - r.length)) + r);
  }
  feed(n = 3) { return this.raw(ESC, 0x64, n); }
  cut() { return this.raw(GS, 0x56, 0x42, 0x00); }
  toBase64() {
    let s = '';
    for (const b of this.bytes) s += String.fromCharCode(b);
    return typeof btoa === 'function' ? btoa(s) : Buffer.from(s, 'binary').toString('base64');
  }
}

// Recibo em ESC/POS. `fmt` traz as funções de formatação da interface: { t, money, qty, date, payLabel, employee, customer, store }.
function receiptEscPos(r, fmt, width = 32) {
  const p = new EscPos(width);
  const s = fmt.store;
  p.align('center');
  if (r.type === 'refund') p.bold(true).line(fmt.t('receipt.refundBanner')).bold(false);
  p.bold(true).big(true).line(s.storeName).big(false).bold(false);
  if (s.address) p.line(s.address);
  if (s.phone) p.line(`${fmt.t('receipt.phone')} ${s.phone}`);
  p.align('left').rule();
  p.pair(`${fmt.t('receipt.number')} ${fmt.number(r)}`, fmt.date(r.date));
  if (fmt.refOf) p.line(`${fmt.t('receipt.refOf')} ${fmt.refOf}`);
  p.line(`${fmt.t('receipt.operator')}: ${fmt.employee}`);
  if (fmt.customer) p.line(`${fmt.t('receipt.customer')}: ${fmt.customer}`);
  p.rule();
  for (const l of r.lines) {
    p.line(l.name);
    p.pair(`  ${fmt.qty(l.qty)} x ${fmt.money(l.price)}`, fmt.money(l.qty * l.price));
  }
  p.rule();
  p.pair(fmt.t('totals.subtotal'), fmt.money(r.subtotal));
  if (r.discount) p.pair(fmt.t('totals.discount'), `-${fmt.money(r.discount)}`);
  if (r.points) p.pair(fmt.t('totals.pointsRedeemed'), `-${fmt.money(r.points)}`);
  if (r.tax) p.pair(fmt.t('totals.tax'), fmt.money(r.tax));
  p.bold(true).pair(fmt.t('totals.total').toUpperCase(), fmt.money(r.total)).bold(false);
  p.pair(fmt.payLabel, fmt.money(r.payment.received));
  if (r.payment.change) p.pair(fmt.t('pay.change'), fmt.money(r.payment.change));
  if (r.pointsEarned) p.pair(fmt.t('receipt.pointsEarned'), fmt.qty(r.pointsEarned));
  const footer = s.receiptFooter || fmt.t('receipt.thanks');
  if (footer) p.rule().align('center').line(footer).align('left');
  return p.feed(4).cut();
}

const Printer = {
  plugin() {
    const C = typeof window !== 'undefined' && window.Capacitor;
    return C && C.isNativePlatform && C.isNativePlatform() && C.Plugins && C.Plugins.BluetoothPrinter ? C.Plugins.BluetoothPrinter : null;
  },
  available() { return !!this.plugin(); },
  async listPaired() {
    const r = await this.plugin().listPaired();
    return r.devices || [];
  },
  async printBytes(address, escpos) {
    await this.plugin().print({ address, data: escpos.toBase64() });
  },
  async disconnect() {
    if (this.available()) await this.plugin().disconnect();
  },
};

// Serviço de impressão do Android (Guardar como PDF / impressoras instaladas) e partilha de ficheiros.
// Plugin nativo em android/.../NativePrintPlugin.java; no browser usa-se window.print() e transferências.
const NativePrint = {
  plugin() {
    const C = typeof window !== 'undefined' && window.Capacitor;
    return C && C.isNativePlatform && C.isNativePlatform() && C.Plugins && C.Plugins.NativePrint ? C.Plugins.NativePrint : null;
  },
  available() { return !!this.plugin(); },
  print(html, title) { return this.plugin().print({ html, title }); },
  share(name, mime, content, base64 = false) { return this.plugin().share({ name, mime, content, base64 }); },
  saveFile(name, mime, data, folder) { return this.plugin().saveFile({ name, mime, data, folder }); },
  savePdf(html, name, folder) { return this.plugin().savePdf({ html, name, folder }); },
};

if (typeof module !== 'undefined') module.exports = { EscPos, receiptEscPos, toPrinterText, Printer, NativePrint };
